// Website Icons
import icon from '../img/logo/icon.png';

// Website Logo
import logo from '../img/logo/logo.png';
import logo2 from '../img/logo/logo2.png';

// Icons Images
import loading from '../img/icons/loading.png';
import empty from '../img/icons/empty2.png';


// Social Icons
import facebook from '../img/icons/social/facebook.svg';
import instagram from '../img/icons/social/instagram.svg';
import linkedin from '../img/icons/social/linkedin.svg';
import telegram from '../img/icons/social/telegram.svg';
import youtube from '../img/icons/social/youtube.svg';

// Payment Images
import bankicon from '../img/icons/payment/bank-icon.svg';
import qricon from '../img/icons/payment/qr-icon.svg';
import qrcode from '../img/icons/payment/qrcode.jpg';

// Payment Method Icons
import USDTTRC20 from "../img/icons/paymentmethod/USDT-TRC20.png"
import USDTBEP20 from "../img/icons/paymentmethod/USDT-BEP20.png"
import USDTERC20 from "../img/icons/paymentmethod/USDT-ERC20.png"
import banktransfer from "../img/icons/paymentmethod/bank-transfer.png"
import UPI from "../img/icons/paymentmethod/UPI.png"
import BTC from "../img/icons/paymentmethod/bitcoin.png"

// Pattern
import Linepattern from "../img/icons/pattern/line-pattern.png"


// Ranks
import rank1 from "../img/icons/ranks/rank1.png"
import rank2 from "../img/icons/ranks/rank2.png"
import rank3 from "../img/icons/ranks/rank3.png"

// Badge
import Badge1 from "../img/icons/ranks/badge1.png"
import Badge2 from "../img/icons/ranks/badge2.png"
import Badge3 from "../img/icons/ranks/badge3.png"

// Rank img
import Rank1 from "../img/icons/ranks/rank1.svg"
import Rank2 from "../img/icons/ranks/rank2.svg"
import Rank3 from "../img/icons/ranks/rank3.svg"
import Rank4 from "../img/icons/ranks/rank4.svg"
import Rank5 from "../img/icons/ranks/rank5.svg"
import Rank6 from "../img/icons/ranks/rank6.svg"
import Rank7 from "../img/icons/ranks/rank7.svg"
import Rank8 from "../img/icons/ranks/rank8.svg"
import Rank9 from "../img/icons/ranks/rank9.svg"
import Rank10 from "../img/icons/ranks/rank10.svg"

// Avatar
import Avatar1 from "../img/icons/avatar/avatar1.png"
import Avatar2 from "../img/icons/avatar/avatar2.png"
import Avatar3 from "../img/icons/avatar/avatar3.png"
import Avatar4 from "../img/icons/avatar/avatar4.png"
import Avatar5 from "../img/icons/avatar/avatar5.png"
import Avatar6 from "../img/icons/avatar/avatar6.png"
import Avatar7 from "../img/icons/avatar/avatar7.png"
import Avatar8 from "../img/icons/avatar/avatar8.png"
import Avatar9 from "../img/icons/avatar/avatar9.png"
import Avatar10 from "../img/icons/avatar/avatar10.png"

export { 
    icon,
    logo, logo2,
    loading, empty,
    facebook, instagram, linkedin, telegram, youtube,
    bankicon, qricon, qrcode,
    USDTTRC20, USDTBEP20, USDTERC20, banktransfer, UPI, BTC,
    Linepattern,
    rank1, rank2, rank3,
    Badge1, Badge2, Badge3,
    Rank1, Rank2, Rank3, Rank4, Rank5, Rank6, Rank7, Rank8, Rank9, Rank10,
    Avatar1, Avatar2, Avatar3, Avatar4, Avatar5, Avatar6, Avatar7, Avatar8, Avatar9, Avatar10
};