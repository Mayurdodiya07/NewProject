import React from 'react';
import { Link } from 'react-router-dom'

// Icons
import Icons from './icons';
import AccountStatus from './AccountStatus';

const ChallengeCard = ({col="col-12", to, className, imgSrc, name, type, step, status, trades, days, statusClass, CredentialsClick,BoxClick}) => {
  return (
    <div className={col}>
      <div className={`challenge-card-bx ${className}`}>
        <div className="ccb-inner" onClick={BoxClick}>

          <div className="ccd-ss-bx">
            <div className="ccb-step">{step}</div>
            <AccountStatus className={statusClass} statusText={status} />
          </div>

          <div className="challenge-top-bx">
            <div className="ccb-info-bx">
              <div className="ccb-i-img"><img src={imgSrc} alt='' /></div>
              <div className="ccb-i-data">
                <div className="ccb-i-name">{name}</div>
                <div className="ccb-i-type">{type}</div>
              </div>
            </div>
          </div>

          <div className="challenge-trade-info">
            <div className="cti-item">
              <div className="cti-icon">
                <Icons.TradeSvg />
              </div>
              <div className="cti-data-bx">
                <div className="cti-label">No. of trades</div>
                <div className="cti-num">{trades}</div>
              </div>
            </div>

            <div className="cti-item">
              <div className="cti-icon">
                <Icons.CalendarSvg />
              </div>
              <div className="cti-data-bx">
                <div className="cti-label">Days traded</div>
                <div className="cti-num">{days}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="challenge-btns">
          <div className="common-btn cb-w2-fill cwf-am-hover" onClick={CredentialsClick}><span><Icons.Key2Svg />Credentials</span></div>
          <Link to={to} className="common-btn cb-white-fill cwf-am-hover"><span><Icons.BarSvg />Dashboard</span></Link>
        </div>
      </div>
    </div>
  );
};

export default ChallengeCard;
