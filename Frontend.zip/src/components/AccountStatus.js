import React from 'react'

export default function AccountStatus({className = " ", statusText}) {
  return (
    <div className={`account-status-bx ${className}`}>{statusText}</div>
  )
}
