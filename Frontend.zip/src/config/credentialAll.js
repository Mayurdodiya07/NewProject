export default {
    "WEB_SOCKET_HOST": 'http://185.52.53.50:6952/',
    "userName": 'testdemo',
    "password": 'LrUhYF2f+9bcdULN7q8TAQ==',
};
