
const API_HOST = 'http://localhost:8000';
// const API_HOST = 'http://fundedfirmcrmbackend.pm';
//  const API_HOST = 'https://fundedfirmcrmbackend.pmcommu.in';
const API_VERSION = '/api/';
const API_URL = API_HOST + API_VERSION;

export default API_URL;