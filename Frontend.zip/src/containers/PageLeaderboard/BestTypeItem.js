import React from 'react'

// Icons & Imges common files
import Icons from '../../components/icons'

export default function BestTypeItem({ heading, avatar, name, amount, data, badge }) {
  return (
    <>
    <div className="best-type-bx">
      <div className="btb-heading">{heading}</div>
      <div className="btb-inner">
        <div className="btb-user-bx">
          <img className="btb-user-img" src={avatar} alt="" />
          <div>
            <div className="btb-name">{name}</div>
            <div className="btb-amount">{amount}</div>
          </div>
        </div>
        <div className="btb-data"><Icons.ArrowTrendingUpSvg />{data}</div>
        <img className="btb-badge-img" src={badge} alt="" />
      </div>
    </div>
    </>
  )
}
