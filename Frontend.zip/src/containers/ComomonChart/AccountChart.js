import React from 'react';
import { LineChart } from '@mui/x-charts/LineChart';
import { BarChart } from '@mui/x-charts/BarChart';
import { axisClasses } from '@mui/x-charts/ChartsAxis';

export default function AccountChart({profitChartData,filterValue='daily',startDate,endDate, chartType}) {
    const valueFormatter = (value) => {
        if (value >= 1000) {
            // console.log(value / 1000);
            return `$${(value / 1000).toFixed(2)}k`; // Format as 1k, 2k, etc.
        } else {
            return `$${value}`; // Default format for values below 1000
        }
    };

    const DateDifferenceAndFormat = (start_date,end_date) =>{
        // Example start and end dates in the specified format
        const startDateString = start_date;
        const endDateString = end_date;
    
        // Parse strings into Date objects
        const startDate = new Date(startDateString);
        const endDate = new Date(endDateString);
    
        // Calculate the difference in milliseconds
        const diffInMilliseconds = Math.abs(endDate - startDate);
        
        // Convert milliseconds into other units if needed
        const diffInSeconds = Math.floor(diffInMilliseconds / 1000);
        const diffInMinutes = Math.floor(diffInSeconds / 60);
        const diffInHours = Math.floor(diffInMinutes / 60);
        const diffInDays = Math.floor(diffInHours / 24);
    
        // Return data or use as needed
        return diffInDays;
    }
    

    const anotherFormatDate = (dateString) => {
        //console.log('startDate',startDate);
       // console.log('filterValue',filterValue);
        if (filterValue === 'today' || filterValue === 'week') {
            const date = new Date(dateString);
            // console.log(date);
            const options = {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            };
          
            return date.toLocaleString('en-US', options);
        } else if (filterValue === 'custom' && DateDifferenceAndFormat(startDate,endDate) <= 7) {
            const date = new Date(dateString);
            // console.log(date);
            const options = {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            };
          
            return date.toLocaleString('en-US', options);
            
        } else if (filterValue === 'daily') {
            const date = new Date(dateString);
            // console.log(date);
            const options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
          
            return date.toLocaleString('en-US', options);
            
        } else {
            const date = new Date(dateString);
            const options = {
              month: 'short'
            };
          
            return date.toLocaleString('en-US', options);
        }
      };

    const tooltipFormatter = (data) => {
        // if (!data || !data.month || !data.Profit) return [];
        console.log(data.Profit);
        return [
            { name: 'Month', value: data.month },
            { name: 'Profit', value: data.Profit},
        ];
    };

    const transformChartData = () => {
        // console.log('profitChartDataprofitChartDataprofitChartDataprofitChartData', profitChartData);
        return profitChartData.map(item => ({
            Profit: Number(item.profit),
            month: anotherFormatDate(item.date_formatted)
        }));
    };

    const chartSetting = {
        borderRadius: 8,
        height: 305,
        series: [{ 
            dataKey: 'Profit',
            color: '#37b793',
            area: true,
            showMark: true,
            // label: 'IB reward', 
            valueFormatter,
        }],
        xAxis: [{
            // label: 'Year '+new Date().getFullYear(),
            scaleType: 'band', 
            dataKey: 'month' ,
        }],
        yAxis: [{
            // label: 'Account Balance',
            min: 0,
            max: Math.max(...profitChartData.map((item) => item.profit), 100),
            valueFormatter,
        }],
        tooltip: {
            formatter: tooltipFormatter,
        },
        sx: {
            [`& .${axisClasses.directionX} .${axisClasses.label}`]: {
                transform: 'translateY(8px)',
            },
        },
        grid: {
            vertical: {
                strokeDasharray: '0', // Customize the grid lines
            },
            horizontal: {
                strokeDasharray: '1', // Customize the grid lines
            },
        },
    };

    // const dataset = [
    //     { Profit: 42, month: 'Jan' },
    //     { Profit: 81, month: 'Feb' },
    //     { Profit: 57, month: 'Mar' },
    //     { Profit: 48, month: 'Apr' },
    //     { Profit: 10, month: 'May' },
    //     { Profit: 30, month: 'June' },
    //     { Profit: 20, month: 'July' },
    //     { Profit: 40, month: 'Aug' },
    //     { Profit: 28, month: 'Sept' },
    //     { Profit: 53, month: 'Oct' },
    //     { Profit: 84, month: 'Nov' },
    //     { Profit: 75, month: 'Dec' },
    // ];

    return (
        <div className='Mycharts'>
            {chartType === 'line' ? (
            <LineChart
                dataset={transformChartData()}
                // dataset={dataset}
                {...chartSetting}
            />
            ) : (
            <BarChart
                dataset={transformChartData()}
                // dataset={dataset}
                {...chartSetting}
            />
            )}
        </div>
    );
}
