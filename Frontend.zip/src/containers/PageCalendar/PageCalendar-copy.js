import React, { useState, useEffect, useMemo } from 'react';
import { Modal } from 'react-bootstrap';
import Breadcrumb from '../../components/Breadcrumb';
import CalendarNavigation from '../../components/CalendarNavigation';
import DropItem from '../../components/commonfield/DropItem';
import PredictionItem from './PredictionItem';
import PredictionCard from './PredictionCard';
import CloseIcon from '../../components/CloseIcon';
import useApi from '../../utility/apiCall';
import API_URL from '../../config/config';

const parseDate = (isoDate) => {
  const date = new Date(isoDate);
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
};

const formatDateForApi = (date) => {
  const formattedDate = new Date(date);
  return formattedDate.toISOString().split('T')[0];
};

const formatDateForDisplay = (isoDate) => {
  const date = new Date(isoDate);
  return date.toLocaleDateString('en-US', {
    weekday: 'long', // Full name of the day (e.g., "Monday")
    day: '2-digit', // Two-digit day (e.g., "12")
    month: 'short', // Abbreviated month name (e.g., "Nov")
    year: 'numeric', // Four-digit year (e.g., "2024")
  });
};


export default function PageCalendar() {
  const [isCurrency, setIsCurrency] = useState('Select Currency');
  const [isImpact, setIsImpact] = useState('Select Impact');
  const [newsData, setNewsData] = useState([]);
  const [isPrediction, setIsPrediction] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const impact = ['Select Impact', 'High', 'Medium', 'Low', 'No Impact'];
  const [selectedNewsItem, setSelectedNewsItem] = useState(null);


  const currency = ['Select Currency', 'AUD', 'USD', 'CAD', 'EUR', 'CHF', 'CNY', 'GBP', 'JPY', 'NZD'];
  const impactMapping = {
    'Select Impact' : 'Select Impact',
    'High': 'high',
    'Medium': 'medium',
    'Low': 'small',
    'No Impact': 'no_impact'
  };
  
  // Create the reverse mapping if needed for display
  const displayImpactMapping = Object.keys(impactMapping).reduce((acc, key) => {
    acc[impactMapping[key]] = key;
    return acc;
  }, {});

  const handlePredictionOpen = (newsItem) => {
  setSelectedDate(newsItem.date); // Optional: Set the date to the clicked item's date.
  setSelectedNewsItem(newsItem);
  setIsPrediction(true);
};


  const handleCurrencyChange = (option) => {
    setIsCurrency(option);
  };

  const handleImpactChange = (option) => {
    const dbValue = impactMapping[option] || ''; // Get the stored value for the selected display value
    setIsImpact(dbValue);
  };
  

  

  const handlePredictionClose = () => {
    setIsPrediction(false);
  };

  // Function to go to the previous day
  const goToPreviousDate = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() - 1);
    setSelectedDate(formatDateForApi(newDate));
  };

  // Function to go to the next day
  const goToNextDate = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + 1);
    setSelectedDate(formatDateForApi(newDate));
  };

  // Memoize today's date so it doesn't trigger re-renders unnecessarily
  const today = useMemo(() => new Date().toISOString().split('T')[0], []);

  // Fetch news data whenever `selectedDate` changes
  const { apiCall } = useApi();

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const formattedDate = formatDateForApi(selectedDate);
        const params = {
          day: [formattedDate],
          currency_id: isCurrency !== 'Select Currency' ? isCurrency : undefined, // Pass currency if not default
          impact: isImpact !== 'Select Impact' ? [isImpact] : undefined, // Pass impact if not default
        };
  
        console.log('Request Params:', params);
  
        const response = await apiCall(`${API_URL}get-news`, params);
  
        if (response && response.data && response.data.success == 0 && Array.isArray(response.data.data) && response.data.data.length > 0) {
          setNewsData(response.data.data);
        } else {
          console.warn('No valid news data available for this date or success is 0');
          setNewsData([]);
        }
      } catch (error) {
        console.error('Error fetching news:', error);
        setNewsData([]);
      }
    };
  
    fetchNews();
  }, [selectedDate, isCurrency, isImpact]); // Include `isCurrency` and `isImpact` in dependency array
  

  return (
    <>
      <Breadcrumb className="" breadcrumbIcon="CalendarSvg" breadcrumbHeading="Calendar" />
      <div className="container-lg cl-custome3">
        <div className="row row-gap-4">
          <div className="col-12">
            <div className="common-box overflowhidden p-0">
              <div className="prediction-filter-bx">
              <CalendarNavigation
                  date={formatDateForDisplay(selectedDate)} // Use the formatting function here
                  prev={goToPreviousDate}
                  next={goToNextDate}
                />
                <div className="pfb-drop-bx">
                  <div className="pfb-drop-item">
                    <div className="sgr-outer-label">Currency</div>
                    <DropItem 
                      options={currency}
                      selectedOption={isCurrency}
                      onChange={handleCurrencyChange}
                    />
                  </div>
                  <div className="pfb-drop-item">
                    <div className="sgr-outer-label">Impact</div>
                    <DropItem
                      options={impact}
                      selectedOption={displayImpactMapping[isImpact] || isImpact}
                      onChange={handleImpactChange}
                    />
                  </div>
                </div>
              </div>
              <div className="table-responsive tr-prediction">
                <table className="custom-table off-tr-bg ct-prediction">
                  <tbody>
                    {newsData.length > 0 ? (
                      newsData.map((newsItem) => (
                        <PredictionItem
                          key={newsItem.id}
                          time={parseDate(newsItem.date)}
                          child={
                            <PredictionCard
                            onClick={() => handlePredictionOpen(newsItem)}
                              impact={newsItem.impact}
                              statusClass={`status-${
                                newsItem.impact === 'no_impact' ? 'blue2' :
                                newsItem.impact === 'high' ? 'red2' :
                                newsItem.impact === 'small' ? 'yellow' :
                                newsItem.impact === 'medium' ? 'green' :
                                'default'  // Fallback if no match found
                              }`}
                              currency={newsItem.currency_name}
                              event={newsItem.event_type}
                              actual={newsItem.actual || 'N/A'}
                              forecast={newsItem.forecast}
                              previous={newsItem.previous}
                            />
                          }
                        />
                      ))
                    ) : (
                      <tr><td colSpan="5">No news available for the selected date.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal className="zoom custom-content" centered show={isPrediction} onHide={handlePredictionClose}>
  <div className="custom-modal-header">
    <div className="cmh-lable"> 
      <CalendarNavigation
        date={formatDateForDisplay(selectedDate)}
        prev={goToPreviousDate}
        next={goToNextDate}
      />
    </div>
  </div>
  <div className="custom-modal-body">
    {selectedNewsItem ? (
      <PredictionCard
        className="pci-full mb-4"
        impact={selectedNewsItem.impact}
        statusClass={`status-${
          selectedNewsItem.impact === 'no_impact' ? 'blue2' :
          selectedNewsItem.impact === 'high' ? 'red2' :
          selectedNewsItem.impact === 'small' ? 'yellow' :
          selectedNewsItem.impact === 'medium' ? 'green' :
          'default'
        }`}
        currency={selectedNewsItem.currency_name}
        event={selectedNewsItem.event_type}
        actual={selectedNewsItem.actual || 'N/A'}
        forecast={selectedNewsItem.forecast}
        previous={selectedNewsItem.previous}
        text={selectedNewsItem.description}
      />
    ) : (
      <div>No news available for this item.</div>
    )}
  </div>
</Modal>

    </>
  );
}
