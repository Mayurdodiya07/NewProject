import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import useApi from '../../utility/apiCall';
import API_URL from '../../config/config';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth, getLoggedInUserData } from '../../context/AuthContext';

import FlashMessage from '../../components/FlashMessage';
import Loaders from '../../components/Loader';



// import ReactTooltip from 'react-tooltip';

// Icons & Images Files
import Breadcrumb from '../../components/Breadcrumb'
import Icons from '../../components/icons';
import Alert from "../../components/Alert";
// import Pagination from "../../components/Pagination";


const PageAffiliate = () => {

  //Auth related var

  const { apiCall } = useApi();
  const navigate = useNavigate();
  const { state, dispatch } = useAuth();
  const token = state.token || '';
  const isInitialMount = useRef(true);


  //Loader
  const [isLoading, setIsLoading] = useState(false);
  const [dataLoaded, setDataLoaded] = useState(false);
  const [requestSubmitError, setRequestSubmitError] = useState(false);
  const [requestSubmitErrorMsg, setRequestSubmitErrorMsg] = useState(false);
  const [requestSubmitSuccess, setRequestSubmitSuccsess] = useState(false);
  const [requestSubmitSuccessMsg, setRequestSubmitSuccessMsg] = useState('');

  const [referralLink, setReferralLink] = useState('');
  const [affilateData, setAffilateData] = useState({ referralCodeUserFind: [] });
  const [sortField, setSortField] = useState('created_at'); // Default field for sorting
const [sortDirection, setSortDirection] = useState('desc'); // Default sorting direction
const [isSorting, setIsSorting] = useState(false);


  const copyClick = (value) => {
    setRequestSubmitSuccsess(false);
    setRequestSubmitError(false);
    navigator.clipboard.writeText(value)
      .then(() => {
        setRequestSubmitSuccsess(true);
        setRequestSubmitSuccessMsg('Text copied to clipboard');
        // console.log('Text copied to clipboard');
      })
      .catch((error) => {
        setRequestSubmitError(true)
        setRequestSubmitErrorMsg('Error copying text')
        // console.error('Error copying text: ', error);
      });
  };

  // const [isAffiliate, setAffiliate] = useState(1);

  // Early redirection based on isAffiliate
  // useEffect(() => {
  //   if (isAffiliate == 0) {
  //     navigate('/home');
  //   }
  // }, [isAffiliate, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      const loggedInUser = getLoggedInUserData();
      const isUserLoggedIn = !!loggedInUser;

      if (isUserLoggedIn) {
        if (loggedInUser.id && token) {
          try {
            console.log(localStorage.getItem('userData'));
            // if(isAffiliate != '0'){

            // const checkAffiliate = await checkAffiliateAvailable();
            const reffalLink = await getReferralLink();
            const affiliteDetails = await getAffilateDetails();
            setDataLoaded(true);
            // console.log(tradeHistory);
            // Assuming getUserWalletGroupWise returns the data needed for wallets and walletGroups
            // }
          } catch (error) {
            navigate('/login');
            console.error('Failed to fetch ib data:', error);
          }
        }
      }
    };

    if (isInitialMount.current) {
      isInitialMount.current = false;
      fetchData();
    }
  }, [token]);

  // const [isAffiliate, setAffiliate] = useState(1);
  // useEffect(() => {
  //   if(isAffiliate != 1){
  //     navigate('/home');
  //   }
  // },[isAffiliate])

  //  const checkAffiliateAvailable = async () => {
  //     try {
  //       // setIsLoading(true);
  //       // console.log({id});
  //       const response = await apiCall(API_URL +'check-affiliate-available', {
  //           user_id: state.userData.id,
  //           token: token
  //       });
  //       if (response.data.success == '0') {
  //         // console.log(response.data.data);
  //         setAffiliate(response.data.data);
  //         // setTotalPagesDailySummary(response.data.data.last_page)
  //       }
  //       // setIsLoading(false);
  //     } catch (error) {
  //         console.error('Error fetching data:', error);
  //     }
  //   };

  const getReferralLink = async () => {
    try {
      setIsLoading(true);
      // console.log({id});
      const response = await apiCall(API_URL + 'get-referral-link-new', {
        user_id: state.userData.id,
        token: token,
      });
      if (response.data.success == '0') {
        //   console.log('Affilite refreeal ', response.data.data);
        setReferralLink(response.data.data.referral_link);
        //   setTotalPagesTradingHistory(response.data.data.last_page)
      }
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleSort = (field) => {
    setIsSorting(true); // Show skeleton loader

    // Simulate sorting delay of 2-3 seconds
    setTimeout(() => {
      // Here you should implement your sorting logic
      setSortField(field);
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
      setIsSorting(false); // Hide skeleton loader after sorting
    }, 1500); // 2 seconds delay
  };


  const sortData = () => {
    return affilateData.referralCodeUserFind.sort((a, b) => {
      // Get nested fields from wallets
      const aWallet = a.wallets.find(wallet => wallet.account_type.step !== 'HFT');
      const bWallet = b.wallets.find(wallet => wallet.account_type.step !== 'HFT');

      let aValue, bValue;

      switch (sortField) {
        case 'account_size.limit':
          aValue = aWallet?.account_size?.limit || 0;
          bValue = bWallet?.account_size?.limit || 0;
          break;
        case 'account_type.step':
          aValue = aWallet?.account_type?.step || '';
          bValue = bWallet?.account_type?.step || '';
          break;
        case 'incentive':
          const percentageA = aWallet?.account_type?.step === '1 step' ? 10 :
                              aWallet?.account_type?.step === '2 step' ? 15 : 0;
          const percentageB = bWallet?.account_type?.step === '1 step' ? 10 :
                              bWallet?.account_type?.step === '2 step' ? 15 : 0;
          aValue = parseFloat(aWallet?.account_size?.price || 0) * (percentageA / 100);
          bValue = parseFloat(bWallet?.account_size?.price || 0) * (percentageB / 100);
          break;
        case 'created_at':
        default:
          aValue = new Date(aWallet?.created_at);
          bValue = new Date(bWallet?.created_at);
          break;
      }

      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  };


  
  // Function to get affiliate details based on sort params
  const getAffilateDetails = async (sortField = 'created_at', sortDirection = 'asc') => {
    try {
      setIsLoading(true);
      const response = await apiCall(API_URL + 'get-affilate-details-new', {
        user_id: state.userData.id,
        token: token,
        sort_field: sortField,
        sort_direction: sortDirection, // Pass the sorting direction
      });
  
      if (response.data.success == '0') {
        setAffilateData(response.data.data);
      }
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  
  const handleToNavigate = () => {
    navigate('/payouts')
  }
  return (
    <>
      {!dataLoaded && <Loaders />}

      <Breadcrumb className="" breadcrumbIcon="GlobeEuropeAfricaSvg" breadcrumbHeading="Affiliate" />
      <div className='container-lg cl-custome3'>
        <div className='row row-gap-4'>

          <div className="col-12">
            <Alert
              className="status-green3 alert-wbtn referral-btn"
              icon="UserPlushSvg"
              heading="Your Referral Code"
              text="Use this URL to promote across different platforms and track your conversions on the referrals tab, this link is unique to you."
              btnIcon="CopySvg"
              btnText={referralLink}
              btnClick={() => copyClick(referralLink)}
            />
          </div>

          <div className="col-12">
            <Alert
              className="common-box alert-wbtn affiliate-program-bx"
              icon="ExclamationCircleSvg"
              heading="Click on the link to know more about how affiliates work"
              linkText="Visit Here"
              linkTo="https://www.fundedfirm.com/affiliate-program"
              linkTarget="_blank"
            />
          </div>

          <div className="col-12">
            <div className='common-box'>

              <div className='row row-gap-3 mb-2'>
                <div className='col-md-4'>
                  <div className="affiliate-data-item">
                    <div className="adi-icon"><Icons.ShoppingBagSvg /></div>
                    <div className="adi-heading">Total Purchased</div>
                    <div className="adi-data">{affilateData.countOfUser}</div>
                  </div>
                </div>
                <div className='col-md-4'>
                  <div className="affiliate-data-item">
                    <div className="adi-icon"><Icons.CurrencyDollarSvg /></div>
                    <div className="adi-heading">Total Earned</div>
                    <div className="adi-data">${affilateData.totalEarned > 0 ? affilateData.totalEarned.toFixed(2) : 0}</div>
                  </div>
                </div>
                <div className='col-md-4'>
                  <div className="affiliate-data-item">
                    <div className="adi-icon"><Icons.WithdrawSvg /></div>
                    <div className="adi-heading">Total Paid Out</div>
                    <div className="adi-data">${affilateData.totalPaidOut > 0 ? affilateData.totalPaidOut.toFixed(2) : 0}</div>
                  </div>
                </div>
              </div>

              <div className='input-note text-center mb-4'>Please use the <span onClick={handleToNavigate}>payouts</span> section to request a payout</div>

              {(affilateData.referralCodeUserFind && affilateData.referralCodeUserFind.length > 0 && !isLoading) && (
        <div className="table-responsive custom-table-responsive">
          {/* Table */}
          <table className="custom-table">
            <thead>
              <tr>
                <th onClick={() => handleSort('created_at')} className={sortField === 'created_at' ? (sortDirection === 'asc' ? 'asc active' : 'desc active') : ''}>
                  REFERRAL COMPLETED AT
                  <div className="th-sort-icons">
                    <Icons.ChevronUpSvg className={sortField === 'created_at' && sortDirection === 'asc' ? 'active' : ''} />
                    <Icons.ChevronDownSvg className={sortField === 'created_at' && sortDirection === 'desc' ? 'active' : ''} />
                  </div>
                </th>
                <th onClick={() => handleSort('account_size.limit')} className={sortField === 'account_size.limit' ? (sortDirection === 'asc' ? 'asc active' : 'desc active') : ''}>
                  ACCOUNT SIZE
                  <div className="th-sort-icons">
                    <Icons.ChevronUpSvg className={sortField === 'account_size.limit' && sortDirection === 'asc' ? 'active' : ''} />
                    <Icons.ChevronDownSvg className={sortField === 'account_size.limit' && sortDirection === 'desc' ? 'active' : ''} />
                  </div>
                </th>
                <th onClick={() => handleSort('account_type.step')} className={sortField === 'account_type.step' ? (sortDirection === 'asc' ? 'asc active' : 'desc active') : ''}>
                  ACCOUNT TYPE
                  <div className="th-sort-icons">
                    <Icons.ChevronUpSvg className={sortField === 'account_type.step' && sortDirection === 'asc' ? 'active' : ''} />
                    <Icons.ChevronDownSvg className={sortField === 'account_type.step' && sortDirection === 'desc' ? 'active' : ''} />
                  </div>
                </th>
                <th onClick={() => handleSort('incentive')} className={sortField === 'incentive' ? (sortDirection === 'asc' ? 'asc active' : 'desc active') : ''}>
                  INCENTIVE/FEE
                  <div className="th-sort-icons">
                    <Icons.ChevronUpSvg className={sortField === 'incentive' && sortDirection === 'asc' ? 'active' : ''} />
                    <Icons.ChevronDownSvg className={sortField === 'incentive' && sortDirection === 'desc' ? 'active' : ''} />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {isSorting ? (
                // Skeleton loader will show while sorting
                <tr>
                  <td colSpan="4">
                    <div className="table-skeletant-bx">
                      <div className="skeletant-bx skeletant-design sh-41"></div>
                      <div className="skeletant-bx skeletant-design sh-41"></div>
                      <div className="skeletant-bx skeletant-design sh-41"></div>
                      <div className="skeletant-bx skeletant-design sh-41"></div>
                      <div className="skeletant-bx skeletant-design sh-41"></div>
                    </div>
                  </td>
                </tr>
              ) : (
                // Render actual data when not sorting
                sortData().map((referralUser, index) =>
                  referralUser.wallets
                    .filter(wallet => wallet.account_type.step !== 'HFT') // Filter out wallets with step 'HFT'
                    .map((wallet, walletIndex) => {
                      const percentage = wallet.account_type.step === '1 step' ? 10 :
                        wallet.account_type.step === '2 step' ? 15 :
                          0;

                      return (
                        <tr key={`${index}-${walletIndex}`}>
                          <td>{wallet.created_date_time_formattad || ''}</td>
                          <td>{wallet.account_size.limit || 0}</td>
                          <td>{wallet.account_type.step || ''}</td>
                          <td>${(parseFloat(wallet.account_size.price) * (percentage / 100)).toFixed(2)}</td>
                        </tr>
                      );
                    })
                )
              )}
            </tbody>
          </table>
        </div>
      )}

                  
              
              {/* <Pagination /> */}

            </div>

          </div>
        </div>
      </div>

      <FlashMessage type="success" isVisible={requestSubmitSuccess} message={requestSubmitSuccessMsg} />
      <FlashMessage type="error" isVisible={requestSubmitError} message={requestSubmitErrorMsg} />
    </>
  )
}

export default PageAffiliate