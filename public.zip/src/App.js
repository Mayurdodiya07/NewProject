import { Helmet } from "react-helmet";
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute';  // Import Protected Route
import SignIn from './container/Auth/SingIn';
import AdminDashboard from './container/Auth/Dashboard';
import ChallengeRequests from './container/HomePage/challenge-requests';
import RealChallengeRequests from './container/HomePage/real-challenge-requests';
import PassedChallengeRequests from './container/HomePage/passed-challenge-requests';
import PassedAccounts from './container/HomePage/passed-accounts';
import AccountSize from './container/HomePage/account-size';
import Challenge from './container/HomePage/challenge';
import User from './container/HomePage/user';
import Reffereduser from './container/HomePage/reffereduser';
import Payout from './container/HomePage/payout';
import Trades from './container/HomePage/trades';
import PaymentMethods from './container/HomePage/paymentMethods';
import Leaderboard from './container/HomePage/leaderboard';
import News from './container/HomePage/news';
import NewsCurrencies from './container/HomePage/newsCurrencies';
import DisabledAccounts from './container/HomePage/disabledAccounts';
import Notification from './container/HomePage/notification';
import Contact from './container/HomePage/contact';
import Settings from './container/HomePage/settings';
import AccountSizeDetails from './container/HomePage/Pages/accountSizeDetails';
import Tradings from './container/HomePage/Pages/tradings';
import Edit from './container/HomePage/Pages/edit';
import ChallengeRequestDetails from './container/HomePage/Pages/challengeRequestDetails';
import RealChallengeRequestDetails from './container/HomePage/Pages/realChallengeRequestDetails';
import ChallengeDetails from './container/HomePage/Pages/challengeDetails';
import UserDetails from './container/HomePage/Pages/userDetails';
import RefferUserDetails from './container/HomePage/Pages/refferUserDetails';
import PayoutDetails from './container/HomePage/Pages/payoutDetails';
import TradesDetails from './container/HomePage/Pages/tradesDetails';
import EditPaymentMethod from './container/HomePage/Pages/editPaymentMethod';
import EditNewsCurrencies from './container/HomePage/Pages/editNewsCurrencies';
import AddNewsCurrencies from './container/HomePage/Pages/addNewsCurrencies';
import EditNews from './container/HomePage/Pages/editNews';
import AddNews from './container/HomePage/Pages/addNews';
import NewsDetails from './container/HomePage/Pages/newsDetails';
import PassedChallengeRequestsDetails from './container/HomePage/Pages/passedChallengeRequestsDetails';
import DisabledAccountDetails from './container/HomePage/Pages/disabledAccountDetails';
import PaymentMethodDetails from './container/HomePage/Pages/paymentMethodDetails';
import ChallengeTradings from './container/HomePage/Pages/challengeTradesDetails';
import UserAccount from './container/HomePage/Pages/userAccount';
import UserAccountDetails from './container/HomePage/Pages/user-Account-Details';
import AddUserDetails from './container/HomePage/Pages/addUserdetails';
import AddPaymentMethod from "./container/HomePage/Pages/addPaymentMethod";

// Promo code
import PromoCode from "./container/HomePage/promoCode";
import AddPromoCode from "./container/HomePage/Pages/addPromoCode";
import EditPromoCode from "./container/HomePage/Pages/editPromoCode";




// import ProtectedRoute from './components/ProtectedRoute';


function DynamicTitle() {
  const location = useLocation();

  const getTitle = () => {
    switch (location.pathname) {
      case "/admin/dashboard":
        return "Admin | Dashboard";
      case "/admin/challenge":
        return "Admin | Challenge";
      default:
        return "Admin | login";
    }
  };

  return (
    <Helmet>
      <title>{getTitle()}</title>
    </Helmet>
  );
}

function App() {
  return (
    <Router>

      <DynamicTitle />
      <Routes>
        {/* {/ Default SignIn Route /} */}
        <Route path="/admin/login" element={<SignIn />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/challenge-requests" element={<ChallengeRequests />} />
          <Route path="/admin/real-challenge-requests" element={<RealChallengeRequests />} />
          <Route path="/admin/passed-challenge-requests" element={<PassedChallengeRequests />} />
          <Route path="/admin/passed-accounts" element={<PassedAccounts />} />
          <Route path="/admin/account-size" element={<AccountSize />} />
          <Route path="/admin/challenge" element={<Challenge />} />
          <Route path="/admin/user" element={<User />} />
          <Route path="/admin/reffereduser" element={<Reffereduser />} />
          <Route path="/admin/payout" element={<Payout />} />
          <Route path="/admin/trades" element={<Trades />} />
          <Route path="/admin/payment-methods" element={<PaymentMethods />} />
          <Route path="/admin/leaderboard" element={<Leaderboard />} />
          <Route path="/admin/news" element={<News />} />
          <Route path="/admin/news-currencies" element={<NewsCurrencies />} />
          <Route path="/admin/disabled-accounts" element={<DisabledAccounts />} />
          <Route path="/admin/notification" element={<Notification />} />
          <Route path="/admin/contact" element={<Contact />} />
          <Route path="/admin/settings" element={<Settings />} />
          <Route path="/admin/challenge/trade/:id" element={<Tradings />} />
          <Route path="/admin/trade/showtrade/:id" element={<ChallengeTradings />} />
          <Route path="/admin/user/edit/:id" element={<Edit />} />
          <Route path="/admin/user/account/:id" element={<UserAccount />} />
          <Route path="/admin/user/account/showaccount/:id" element={<UserAccountDetails />} />
          <Route path="/admin/user/add" element={<AddUserDetails />} />
          {/* <Route path="/admin/challenge-requests/challengeRequestDetails" element={<ChallengeRequestDetails />} /> */}
          {/* <Route path="/admin/real-c  hallenge-requests/RealChallengeRequestDetails" element={<RealChallengeRequestDetails />} /> */}
          <Route path="/admin/challenge-requests/:id" element={<ChallengeRequestDetails />} />
          <Route path="/admin/real-challenge-requests/:id" element={<RealChallengeRequestDetails />} />
          <Route path="/admin/account-size/:id" element={<AccountSizeDetails />} />
          <Route path="/admin/challenge/:id" element={<ChallengeDetails />} />
          <Route path="/admin/user/:id" element={<UserDetails />} />
          <Route path="/admin/reffereduser/:id" element={<RefferUserDetails />} />
          <Route path="/admin/payout/:id" element={<PayoutDetails />} />
          <Route path="/admin/trades/:id" element={<TradesDetails />} />
          <Route path="/admin/passed-challenge-requests/:id" element={<PassedChallengeRequestsDetails />} />
          <Route path="/admin/news-currencies/edit/:id" element={<EditNewsCurrencies />} />
          <Route path="/admin/news-currencies/add" element={<AddNewsCurrencies />} />
          <Route path="/admin/disabled-accounts/:id" element={< DisabledAccountDetails />} />
          <Route path="/admin/payment-methods/:id" element={<PaymentMethodDetails />} />
          <Route path="/admin/payment-methods/edit/:id" element={<EditPaymentMethod />} />
          <Route path="/admin/payment-methods/add" element={<AddPaymentMethod />} />
          <Route path="/admin/news/:id" element={<NewsDetails />} />
          <Route path="/admin/news/edit/:id" element={<EditNews />} />
          <Route path="/admin/news/add" element={<AddNews />} />
          <Route path="/admin/promo-code" element={<PromoCode />} />
          <Route path="/admin/promo-code/add" element={<AddPromoCode />} />
          <Route path="/admin/promo-code/edit/:id" element={<EditPromoCode />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
