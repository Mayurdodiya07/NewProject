import React from "react";
import Icons from "../icons";

export default function DeleteModal({ onClose, onConfirm }) {
  const [visible, setVisible] = React.useState(true);

  const handleClose = () => {
    setVisible(false);
    setTimeout(onClose, 300);
  };

  return (
    <div
      className={`modal fade zoom cc-mw396px ${visible ? "show" : ""}`}
      role="dialog"
      aria-modal="true"
      style={{ display: visible ? "block" : "none" }}
    >
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content custom-content">
          <div className="custom-modal-header">
            <div className="cmh-lable">Delete Request</div>
            <div className="cmh-sub-lable">Are you sure to delete this record?</div>
            <span className="close-icon" onClick={handleClose}>
              <Icons.CrossIcon />
            </span>
          </div>

          <div className="custom-modal-btns">
            <div className="common-btn-item cbi-outline" onClick={handleClose}>
              <span>Close</span>
            </div>
            <div className="common-btn-item cbi-fill" onClick={onConfirm}>
              <span>Confirm</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
