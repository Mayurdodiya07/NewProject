
// import React from "react";

// export default function ShowPassedAccountModal({ onClose }) {
//   const [visible, setVisible] = React.useState(true);

//   const handleClose = () => {
//     setVisible(false);
//     setTimeout(onClose, 300);
//   };

//   return (
//     <div className={`modal my-modal fade zoom cc-mw396px ${visible ? "show" : ""}`} role="dialog" aria-modal="true" style={{ display: visible ? "block" : "none" }}>
//       <div className="modal-dialog modal-dialog-centered">
//         <div className="modal-content custom-content" style={{ maxWidth: "100%", height: "100%" }}>
//           <div className="custom-modal-header">
//             <div className="cmh-lable">Action on this account</div>
//             <span className="close-icon" onClick={handleClose}>
//               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
//                 <path
//                   fill="none"
//                   stroke="currentColor"
//                   strokeLinecap="round"
//                   strokeLinejoin="round"
//                   strokeWidth="32"
//                   d="M368 368L144 144M368 144L144 368"
//                 ></path>
//               </svg>
//             </span>
//           </div>
//           <div class="">
//             <div class="filter-checkbox-group">
//               <div class="fcg-item">
//                 <input type="radio" name="breachOption" id="dailyLoss" value="daily" />
//                 <label for="dailyLoss"><span class="check-icon"></span>Accept the request</label>
//               </div>
//               <div class="fcg-item">
//                 <input type="radio" name="breachOption" id="maxLoss" value="max" />
//                 <label for="maxLoss"><span class="check-icon"></span>30% Rules breach</label>
//               </div>
//             </div>
//           </div>

//           <div className="custom-modal-btns">
//             <div className="common-btn-item cbi-outline" onClick={handleClose}>
//               <span>Close</span>
//             </div>
//             <div className="common-btn-item cbi-fill">
//               <span>Apply</span>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }



import React, { useEffect, useState } from "react";
import axios from "axios";
import API_URL from "../../config/config";

export default function ShowPassedAccountModal({ onClose, accountId, userWalletID }) {
  const [userDetails, setUserDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedAction, setSelectedAction] = useState(null);
  const [processing, setProcessing] = useState(false);

  const token = localStorage.getItem("adminToken");

  // Fetch user details when modal opens
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await axios.get(`${API_URL}/real-challenge-requests/${accountId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        setUserDetails(response.data.data || {});
      } catch (err) {
        setError(err.response?.data?.message || "Failed to fetch details");
      } finally {
        setLoading(false);
      }
    };

    if (accountId) {
      fetchUserDetails();
    }
  }, [accountId]);

  // Handle apply action
  const handleApply = async () => {
    if (!selectedAction) {
      alert("Please select an action.");
      return;
    }

    // Ensure userWallet is properly structured
    const userWallet = userDetails?.user_wallet;

    if (!userWallet || !userWallet._id) {
      alert("User wallet ID is missing.");
      return;
    }

    console.log("Sending request with:", { id: accountId, user_wallet: userWallet, type: selectedAction });

    try {
      setProcessing(true);
      const response = await axios.post(
        `${API_URL}/action-on-real-account-request`,
        { id: accountId, user_wallet: userWallet._id, type: selectedAction },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
          }
        }
      );

      alert(response.data.message);
    } catch (error) {
      console.error("Error:", error);
      alert(error.response?.data?.message || "Something went wrong.");
    } finally {
      setProcessing(false);
    }
  };


  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  if (!userDetails) return <div>No data available</div>;

  return (
    <div className="modal my-modal fade zoom show" role="dialog" aria-modal="true" style={{ display: "block" }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content custom-content">
          <div className="custom-modal-header">
            <div className="cmh-lable">Action on this account</div>
            <span className="close-icon" onClick={onClose}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <path fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="32" d="M368 368L144 144M368 144L144 368"></path>
              </svg>
            </span>
          </div>

          <div className="filter-checkbox-group">
            <div className="fcg-item">
              <input type="radio" name="actionOption" id="approve" value="approved" onChange={(e) => setSelectedAction(e.target.value)} />
              <label htmlFor="approve"><span className="check-icon"></span>Accept the request</label>
            </div>
            <div className="fcg-item">
              <input type="radio" name="actionOption" id="breach" value="breach" onChange={(e) => setSelectedAction(e.target.value)} />
              <label htmlFor="breach"><span className="check-icon"></span>30% Rules breach</label>
            </div>
          </div>

          <div className="custom-modal-btns">
            <div className="common-btn-item cbi-outline" onClick={onClose}>
              <span>Close</span>
            </div>
            <div className="common-btn-item cbi-fill" onClick={handleApply}>
              <span>{processing ? "Processing..." : "Apply"}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
