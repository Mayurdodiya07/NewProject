// import React from "react";

// export default function AccountBreachModal({ onClose }) {
//   const [visible, setVisible] = React.useState(true);

//   const handleClose = () => {
//     setVisible(false);
//     setTimeout(onClose, 300);
//   };

//   return (
//     <div className={`modal my-modal fade zoom cc-mw396px ${visible ? "show" : ""}`} role="dialog" aria-modal="true" style={{ display: visible ? "block" : "none" }}>
//       <div className="modal-dialog modal-dialog-centered">
//         <div className="modal-content custom-content" style={{ maxWidth: "100%", height: "100%" }}>
//           <div className="custom-modal-header">
//             <div className="cmh-lable">Account Breach</div>
//             <span className="close-icon" onClick={handleClose}>
//               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
//                 <path
//                   fill="none"
//                   stroke="currentColor"
//                   strokeLinecap="round"
//                   strokeLinejoin="round"
//                   strokeWidth="32"
//                   d="M368 368L144 144M368 144L144 368"
//                 ></path>
//               </svg>
//             </span>
//           </div>
//           <div class="">
//   <div class="filter-checkbox-group">
//     <div class="fcg-item">
//       <input type="radio" name="breachOption" id="dailyLoss" value="daily" />
//       <label for="dailyLoss"><span class="check-icon"></span>Daily loss</label>
//     </div>
//     <div class="fcg-item">
//       <input type="radio" name="breachOption" id="maxLoss" value="max" />
//       <label for="maxLoss"><span class="check-icon"></span>Max loss</label>
//     </div>
//   </div>
// </div>

//           <div className="custom-modal-btns">
//             <div className="common-btn-item cbi-outline" onClick={handleClose}>
//               <span>Close</span>
//             </div>
//             <div className="common-btn-item cbi-fill">
//               <span>Apply</span>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }













import React, { useState } from "react";
import axios from "axios";
import API_URL from "../../config/config";
// import toastr from "toastr"; // make sure toastr is installed: npm install toastr
// import "toastr/build/toastr.min.css";

export default function AccountBreachModal({ onClose, userId }) {
  const [visible, setVisible] = useState(true);
  const [breachReason, setBreachReason] = useState("");

  const handleClose = () => {
    setVisible(false);
    setTimeout(onClose, 300);
  };

  const handleApply = async () => {
    if (!breachReason) {
      // toastr.error("Please select a breach reason.");
      return;
    }

    const token = localStorage.getItem("adminToken");

    try {
      const response = await axios.post(
        `${API_URL}/account-breach`,
        {
          userWalletID: userId,
          type: breachReason,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (response.data.success) {
        // toastr.success("Account has been disabled successfully.");
        setTimeout(() => {
          handleClose();
          window.location.reload();
        }, 2000);
      } else {
        // toastr.error(response.data.message || "Failed to report breach.");
      }
    } catch (error) {
      console.error("Error reporting breach:", error.response?.data || error.message);
      // toastr.error("Error reporting breach.");
    }
  };

  return (
    <div
      className={`modal my-modal fade zoom cc-mw396px ${visible ? "show" : ""}`}
      role="dialog"
      aria-modal="true"
      style={{ display: visible ? "block" : "none" }}
    >
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content custom-content" style={{ maxWidth: "100%", height: "100%" }}>
          <div className="custom-modal-header">
            <div className="cmh-lable">Account Breach</div>
            <span className="close-icon" onClick={handleClose}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <path
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="32"
                  d="M368 368L144 144M368 144L144 368"
                ></path>
              </svg>
            </span>
          </div>

          <div className="modal-body">
            <div className="filter-checkbox-group">
              <div className="fcg-item">
                <input
                  type="radio"
                  name="breachOption"
                  id="dailyLoss"
                  value="daily"
                  checked={breachReason === "daily"}
                  onChange={(e) => setBreachReason(e.target.value)}
                />
                <label htmlFor="dailyLoss">
                  <span className="check-icon"></span>Daily Loss
                </label>
              </div>
              <div className="fcg-item">
                <input
                  type="radio"
                  name="breachOption"
                  id="maxLoss"
                  value="max"
                  checked={breachReason === "max"}
                  onChange={(e) => setBreachReason(e.target.value)}
                />
                <label htmlFor="maxLoss">
                  <span className="check-icon"></span>Max Loss
                </label>
              </div>
            </div>
          </div>

          <div className="custom-modal-btns">
            <div className="common-btn-item cbi-outline" onClick={handleClose}>
              <span>Close</span>
            </div>
            <div className="common-btn-item cbi-fill" onClick={handleApply}>
              <span>Apply</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
