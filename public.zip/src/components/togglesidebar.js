import { useState, useEffect } from "react";

const useToggleSidebar = () => {
  // Set initial state: open if width > 992, closed otherwise.
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => window.innerWidth > 992);

  const toggleSidebar = () => {
    setIsSidebarOpen((prev) => !prev);
  };

  useEffect(() => {
    const handleResize = () => {
      // Automatically close the sidebar if the viewport is <= 992px.
      if (window.innerWidth <= 992 && isSidebarOpen) {
        setIsSidebarOpen(false);
      }
      // Automatically open the sidebar if the viewport is => 992px.
      else if (window.innerWidth > 992 && !isSidebarOpen) {
        setIsSidebarOpen(true);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [isSidebarOpen]);

  return { isSidebarOpen, toggleSidebar };
};

export default useToggleSidebar;
