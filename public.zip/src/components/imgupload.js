
import React, { useState } from "react";
import Icons from "./icons";

import LightGallery from "lightgallery/react";

import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";

// Plugins
import lgZoom from "lightgallery/plugins/zoom";
import lgFullscreen from "lightgallery/plugins/fullscreen";

const ImageUpload = ({ label, existingImage }) => {
    const [imagePreview, setImagePreview] = useState(existingImage || null);

    const handleImageChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => setImagePreview(e.target.result);
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="form-group col-sm-6">
            <label htmlFor={label.toLowerCase().replace(" ", "_")}>{label}</label>
            <input
                type="file"
                className="form-control"
                id={label.toLowerCase().replace(" ", "_")}
                name={label.toLowerCase().replace(" ", "_")}
                accept="image/*"
                onChange={handleImageChange}
            />
            <div className="input-note-2 mt-1">
                <Icons.InfoIcon /> Image should be 320px * 320px size.
            </div>

            {/* Image Preview Section */}
            {imagePreview && (

                <div id="lightgallery" className="mt-2">
                    <LightGallery speed={500} plugins={[lgZoom, lgFullscreen]}>
                        <a className="d-block col-12 zoom-img-item" href={imagePreview}>
                            <div className="upload-document-item">
                                <div className="udi-img-bx">
                                    <img src={imagePreview} alt="Transaction Screenshot" />
                                </div>
                                <div className="udi-icon-bx">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607ZM10.5 7.5v6m3-3h-6"></path></svg>
                                </div>
                            </div>
                        </a>
                    </LightGallery>

                </div>

            )}
        </div>
    );
};

export default ImageUpload;
