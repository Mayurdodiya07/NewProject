// import React, { useState, useEffect } from "react";
// import { Helmet } from "react-helmet";
// import { Link } from "react-router-dom";
// import Sidebar from "../sidebar";
// import Header from "../Header";
// import Footer from "../footer";
// import useToggleSidebar from "../../components/togglesidebar";
// import "../../styles/challengerequests.css";
// import axios from "axios";
// import API_URL from "../../config/config";
// import Icons from "../../components/icons";
// import SortIcon from "../../components/table/SortIcon";

// function ChallengeRequests() {
//     const [data, setData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);
//     const [currentPage, setCurrentPage] = useState(1);
//     const [itemsPerPage, setItemsPerPage] = useState(10);
//     const [totalItems, setTotalItems] = useState(0);
//     const [searchTerm, setSearchTerm] = useState("");
//     const [debouncedSearchTerm, setDebouncedSearchTerm] = useState(""); // NEW
//     const token = localStorage.getItem("adminToken");

//     // Debounce searchTerm
//     useEffect(() => {
//         const delayDebounce = setTimeout(() => {
//             setDebouncedSearchTerm(searchTerm);
//             setCurrentPage(1);
//         },);

//         return () => clearTimeout(delayDebounce);
//     }, [searchTerm]);

//     // Fetch data
//     useEffect(() => {
//         const fetchData = async () => {
//             setLoading(true);
//             try {
//                 const response = await axios.get(`${API_URL}/challenge-requests`, {
//                     headers: { Authorization: `Bearer ${token}` },
//                     params: {
//                         page: currentPage,
//                         limit: itemsPerPage,
//                         search: debouncedSearchTerm,
//                     },
//                 });

// const { data: fetchedData, total } = response.data;
// setData(fetchedData);
// setTotalItems(total);
//             } catch (err) {
//                 setError(err.response?.data?.message || "Server Error");
//             } finally {
//                 setLoading(false);
//             }
//         };

//         if (token) {
//             fetchData();
//         }
//     }, [token, currentPage, itemsPerPage, debouncedSearchTerm]);

//     // Ensure data is an array before using slice
//     // const safeData = Array.isArray(data) ? data : [];

//     // Calculate total pages
//     const totalPages = Math.ceil(totalItems / itemsPerPage);


//     const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
//     // Get current page data
//     // const currentData = safeData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
//     const currentData = data;

//     if (loading) return <div>Loading...</div>;
//     if (error) return <div>{error}</div>;



//     return (
//         <>
//             <Helmet>
//                 <title>Admin | Challenge Requests</title>
//             </Helmet>
//             <Sidebar isSidebarOpen={isSidebarOpen} />
//             <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
//                 <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
//                     <Header toggleSidebar={toggleSidebar} />
//                     <div className="breadcrumb-main-bx">
//                         <div className="breadcrumb-bx">
//                             <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
//                             <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                             <div className="breadcrumb-link breadcrumb-active">Challenge Requests</div>
//                         </div>
//                     </div>
//                     <section className="content">
//                         <div className="container-fluid">
//                             <div className="row">
//                                 <div className="col-md-12">
//                                     <div className="card">
//                                         <div className="card-header">Challenge Requests</div>
//                                         <div className="card-body">
//                                             <div id="challenge-requests-table_wrapper" className="dataTables_wrapper no-footer">

//                                                 {/* Items per page selection */}
//                                                 <div className="dataTables_length">
//                                                     <label>
//                                                         Show{" "}
//                                                         <select
//                                                             value={itemsPerPage}
//                                                             onChange={(e) => setItemsPerPage(Number(e.target.value))}
//                                                         >
//                                                             <option value="10">10</option>
//                                                             <option value="25">25</option>
//                                                             <option value="50">50</option>
//                                                             <option value="100">100</option>
//                                                         </select>{" "}
//                                                         entries
//                                                     </label>
//                                                 </div>
//                                                 {/* Search input */}
//                                                 <div id="challenge-requests-table_filter" className="dataTables_filter">
//                                                     <label>
//                                                         Search:
//                                                         <input
//                                                             type="search"
//                                                             className="form-control"
//                                                             placeholder="Search..."
//                                                             aria-controls="challenge-requests-table"
//                                                             value={searchTerm}
//                                                             onChange={(e) => {
//                                                                 setSearchTerm(e.target.value);
//                                                                 setCurrentPage(1);
//                                                             }}
//                                                         />
//                                                     </label>
//                                                 </div>
//                                                 {/* Table */}
//                                                 <div className="table-responsive">
//                                                     <table className="table table-bordered dataTable">
//                                                         <thead>
//                                                             <tr>
//                                                                 <th>No.</th>
//                                                                 <th>User<SortIcon /></th>
//                                                                 <th>Email</th>
//                                                                 <th>Status</th>
//                                                                 <th>Date</th>
//                                                                 <th>Action</th>
//                                                             </tr>
//                                                         </thead>
//                                                         <tbody>
//                                                             {currentData.length > 0 ? (
//                                                                 currentData.map((row, index) => (
//                                                                     <tr key={row._id || index}>
//                                                                         <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
//                                                                         <td>{row.name || "N/A"}</td>
//                                                                         <td>{row.email || (row.user_id?.email || "N/A")}</td>
//                                                                         <td>{row.account_status || "N/A"}</td>
// <td>{new Date(row.created_at).toISOString().split('T')[0].split('-').reverse().join('-')}</td>
//                                                                         <td>
//                                                                             <Link to={`/admin/challenge-requests/${row._id || row.id}`} className="common-action-btn" title="View">
//                                                                                 <Icons.ViewIcon />
//                                                                             </Link>
//                                                                         </td>
//                                                                     </tr>
//                                                                 ))
//                                                             ) : (
//                                                                 <tr>
//                                                                     <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
//                                                                         No data available
//                                                                     </td>
//                                                                 </tr>
//                                                             )}
//                                                         </tbody>
//                                                     </table>
//                                                 </div>

//                                                 {/* Pagination */}
//                                                 <div className="dataTables_info">
//                                                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                                                     {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems} entries
//                                                 </div>

//                                                 <div className="dataTables_paginate paging_simple_numbers">
//                                                     <button
//                                                         className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`}
//                                                         onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
//                                                     >
//                                                         Previous
//                                                     </button>
//                                                     <span>
//                                                         {Array.from({ length: totalPages }, (_, index) => (
//                                                             <button
//                                                                 key={index + 1}
//                                                                 className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`}
//                                                                 onClick={() => setCurrentPage(index + 1)}
//                                                             >
//                                                                 {index + 1}
//                                                             </button>
//                                                         ))}
//                                                     </span>
//                                                     <button
//                                                         className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`}
//                                                         onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
//                                                     >
//                                                         Next
//                                                     </button>
//                                                 </div>

//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </section>
//                     <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
//                         <Footer />
//                     </div>
//                 </div>
//             </div>
//         </>
//     );
// }

// export default ChallengeRequests;
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import Sidebar from "../sidebar";
import Header from "../Header";
import Footer from "../footer";
import useToggleSidebar from "../../components/togglesidebar";
import "../../styles/challengerequests.css";
import axios from "axios";
import API_URL from "../../config/config";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";

function ChallengeRequests() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);
    const [totalItems, setTotalItems] = useState(0);
    const [search, setSearch] = useState("");
    const token = localStorage.getItem("adminToken");

    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    const fetchData = async () => {
        setLoading(true);
        try {
            const response = await axios.get(`${API_URL}/challenge-requests`, {
                headers: { Authorization: `Bearer ${token}` },
                params: {
                    page: currentPage,
                    limit: itemsPerPage,
                    search: search
                },
            });
            // const { data: fetchedData, pagination } = response.data;
            // setData(fetchedData);
            // setTotalItems(pagination.total);
            const { data: fetchedData, total } = response.data;
            setData(fetchedData);
            setTotalItems(total);
        } catch (err) {
            setError(err.response?.data?.message || "Server Error");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (token) {
            fetchData();
        } else {
            setError("Unauthorized: No token found.");
            setLoading(false);
        }
    }, [token, currentPage, itemsPerPage, search]);


    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const currentData = data;

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <>
            <Helmet>
                <title>Admin | Challenge Requests</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <div className="breadcrumb-main-bx">
                        <div className="breadcrumb-bx">
                            <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                            <div className="breadcrumb-link breadcrumb-disabled">/</div>
                            <div className="breadcrumb-link breadcrumb-active">Challenge Requests</div>
                        </div>
                    </div>
                    <section className="content">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card">
                                        <div className="card-header">Challenge Requests</div>
                                        <div className="card-body">
                                            <div id="challenge-requests-table_wrapper" className="dataTables_wrapper no-footer">

                                                <div className="dataTables_length">
                                                    <label>
                                                        Show{" "}
                                                        <select
                                                            value={itemsPerPage}
                                                            onChange={(e) => {
                                                                const newLimit = parseInt(e.target.value, 10);
                                                                setCurrentPage(1);
                                                                setItemsPerPage(newLimit);
                                                            }}
                                                        >
                                                            <option value="10">10</option>
                                                            <option value="25">25</option>
                                                            <option value="50">50</option>
                                                            <option value="100">100</option>
                                                        </select>{" "}
                                                        entries
                                                    </label>
                                                </div>

                                                <div id="challenge-requests-table_filter" className="dataTables_filter">
                                                    <label>
                                                        Search:
                                                        <input
                                                            type="search"
                                                            className="form-control"
                                                            placeholder="Search..."
                                                            aria-controls="challenge-requests-table"
                                                            value={search}
                                                            onChange={(e) => {
                                                                setSearch(e.target.value);
                                                                setCurrentPage(1);
                                                            }}
                                                        />
                                                    </label>
                                                </div>

                                                <div className="table-responsive">
                                                    <table className="table table-bordered dataTable">
                                                        <thead>
                                                            <tr>
                                                                <th>No.</th>
                                                                <th>User<SortIcon /></th>
                                                                <th>Email</th>
                                                                <th>Status</th>
                                                                <th>Date</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {currentData.length > 0 ? (
                                                                currentData.map((row, index) => (
                                                                    <tr key={row._id || index}>
                                                                        <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                                                        <td>{row.name || "N/A"}</td>
                                                                        <td>{row.email || (row.user_id?.email || "N/A")}</td>
                                                                        <td>{row.account_status || "N/A"}</td>
                                                                        <td>{new Date(row.created_at).toISOString().split('T')[0].split('-').reverse().join('-')}</td>
                                                                        <td>
                                                                            <Link to={`/admin/challenge-requests/${row._id || row.id}`} className="common-action-btn" title="View">
                                                                                <Icons.ViewIcon />
                                                                            </Link>
                                                                        </td>
                                                                    </tr>
                                                                ))
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
                                                                        No data available
                                                                    </td>
                                                                </tr>
                                                            )}
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <div className="dataTables_info">
                                                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                                                    {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems} entries
                                                </div>

                                                <div className="dataTables_paginate paging_simple_numbers">
                                                    <button
                                                        className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`}
                                                        onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                                                    >
                                                        Previous
                                                    </button>
                                                    <span>
                                                        {Array.from({ length: totalPages }, (_, index) => (
                                                            <button
                                                                key={index + 1}
                                                                className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`}
                                                                onClick={() => setCurrentPage(index + 1)}
                                                            >
                                                                {index + 1}
                                                            </button>
                                                        ))}
                                                    </span>
                                                    <button
                                                        className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`}
                                                        onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                                                    >
                                                        Next
                                                    </button>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0" }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    );
}

export default ChallengeRequests;
