import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import useToggleSidebar from "../../components/togglesidebar";
import { Eye, EyeOff } from "lucide-react";
import Sidebar from "../sidebar";
import Header from "../Header";
import Footer from "../footer";
import axios from "axios";
import API_URL from "../../config/config";

function Settings() {
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const [currencyRate, setCurrencyRate] = useState({ from_currency_rate: 1, to_currency_rate: "" });
    const [users, setUsers] = useState([]);
    const [userWallets, setUserWallets] = useState([]);
    const [userAccount, setUserAccount] = useState({
        username: "",
        account_size: "",
        payout_percentage: ""
    });

    const [showPassword, setShowPassword] = useState({
        current: false,
        new: false,
        confirm: false
    });

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const token = localStorage.getItem("adminToken");
            if (!token) {
                console.error("No token found, redirecting to login...");
                return;
            }

            const response = await axios.get(`${API_URL}/settings/data`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            if (response.data) {
                setCurrencyRate(response.data.convertCurrencyData || { from_currency_rate: 1, to_currency_rate: "" });
                setUsers(response.data.users || []);
                setUserWallets(response.data.userWallets || []);
                setUserAccount(response.data.firstUserAccount || {});
            }
        } catch (error) {
            console.error("Error fetching settings data:", error);
        }
    };


    const togglePassword = (field) => {
        setShowPassword((prev) => ({ ...prev, [field]: !prev[field] }));
    };

    const handleCurrencyRateChange = (e) => {
        setCurrencyRate({ ...currencyRate, to_currency_rate: e.target.value });
    };

    const handleChangePassword = async (event) => {
        event.preventDefault();

        const current_password = event.target.current_password.value;
        const new_password = event.target.new_password.value;
        const new_password_confirmation = event.target.new_password_confirmation.value;

        if (!current_password || !new_password || !new_password_confirmation) {
            alert("All fields are required");
            return;
        }

        if (new_password !== new_password_confirmation) {
            alert("New password confirmation does not match");
            return;
        }

        try {
            const token = localStorage.getItem("adminToken");

            await axios.post(`${API_URL}/settings/change-password`,
                { current_password, new_password, new_password_confirmation },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            alert("Password Changed Successfully!");
        } catch (error) {
            console.error("Error changing password:", error);
            alert(error.response?.data?.error || "Failed to change password.");
        }
    };

    const handleHighestPayoutChange = (e) => {
        setUserAccount({ ...userAccount, [e.target.name]: e.target.value });
    };
    const handleCurrencySubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem("adminToken");
            await axios.post(`${API_URL}/settings/change-currencyRate`,
                { to_currency_rate: currencyRate.to_currency_rate },
                { headers: { Authorization: `Bearer ${token}` } }
            );
            alert("Currency Rate Updated Successfully!");
            fetchData(); // Refresh data after update
        } catch (error) {
            console.error("Error updating currency rate:", error);
            alert("Failed to update currency rate.");
        }
    };
    const handleHighestPayoutSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem("adminToken");
            await axios.post(`${API_URL}/settings/manage-user-account`,
                {
                    username: userAccount.username,
                    account_size: userAccount.account_size,
                    payout_percentage: userAccount.payout_percentage
                },
                { headers: { Authorization: `Bearer ${token}` } }
            );
            alert("User Account Updated Successfully!");
            fetchData(); // Refresh data after update
        } catch (error) {
            console.error("Error updating user account:", error);
            alert("Failed to update user account.");
        }
    };


    return (
        <>
            <Helmet>
                <title>Admin | Settings</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Settings</div>
                            </div>
                        </div>

                        {/* Change Currency Rate */}
                        <div className='container-fluid'>
                            <div className='row'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header">Change Currency Rate</div>
                                        <div className="card-body">
                                            <form id="change_currencyRate" method="POST" onSubmit={handleCurrencySubmit}>

                                                <div className="row">
                                                    <div className="form-group col-lg-4 col-sm-6">
                                                        <label>USD</label>
                                                        <input type="text" className="form-control" value="1" readOnly disabled />
                                                    </div>
                                                    <div className="form-group col-lg-4 col-sm-6">
                                                        <label>INR</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="to_currency_rate"
                                                            placeholder="Enter INR rate"
                                                            name="to_currency_rate"
                                                            value={currencyRate.to_currency_rate}
                                                            onChange={handleCurrencyRateChange}
                                                            required
                                                        />
                                                    </div>
                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Manage Highest Payout */}
                        <div className='container-fluid mt-3'>
                            <div className='row'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header">Manage Highest Payout</div>
                                        <div className="card-body">
                                            <form id="useraccount" method="POST" onSubmit={handleHighestPayoutSubmit}>
                                                <div className="row">
                                                    <div className="form-group col-lg-4 col-sm-4">
                                                        <label>Username</label>
                                                        <input type="text" className="form-control" name="username" placeholder="Enter user name" value={userAccount.username} onChange={handleHighestPayoutChange} />
                                                    </div>
                                                    <div className="form-group col-lg-4 col-sm-4">
                                                        <label>Account Size</label>
                                                        <input type="text" className="form-control" name="account_size" placeholder="Enter account size" value={userAccount.account_size} onChange={handleHighestPayoutChange} />
                                                    </div>
                                                    <div className="form-group col-lg-4 col-sm-4">
                                                        <label>Payout Percentage</label>
                                                        <input type="text" className="form-control" name="payout_percentage" placeholder="Enter payout percentage" value={userAccount.payout_percentage} onChange={handleHighestPayoutChange} required />
                                                    </div>
                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Change Password */}
                        <div className="container-fluid mt-3">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card">
                                        <div className="card-header">Change Password</div>
                                        <div className="card-body">
                                            <form id="change_password" onSubmit={handleChangePassword}>
                                                <div className="row">
                                                    {[
                                                        { key: "current", label: "Current Password", name: "current_password" },
                                                        { key: "new", label: "New Password", name: "new_password" },
                                                        { key: "confirm", label: "Confirm New Password", name: "new_password_confirmation" },
                                                    ].map(({ key, label, name }) => (
                                                        <div key={key} className="form-group col-lg-4 col-sm-6 position-relative">
                                                            <label>{label}</label>
                                                            <div className="input-container">
                                                                <input
                                                                    type={showPassword[key] ? "text" : "password"}
                                                                    className="form-control"
                                                                    name={name}
                                                                    required
                                                                />
                                                                <div className="group_right_icon" onClick={() => togglePassword(key)}>
                                                                    {showPassword[key] ? <EyeOff /> : <Eye />}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Footer />
                </div>
            </div>
        </>
    );
}

export default Settings;





// import React, { useState, useEffect } from "react";
// import { Helmet } from "react-helmet";
// import { Link } from 'react-router-dom';
// import useToggleSidebar from "../../components/togglesidebar";
// // import Icons from "../../components/icons";
// import { Eye, EyeOff } from "lucide-react";
// import Sidebar from '../sidebar';
// import Header from '../Header';
// import Footer from '../footer';
// import '../../styles/challengerequests.css';
// import axios from 'axios';
// import API_URL from "../../config/config";


// function Settings() {
//     const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
//     const [currencyRate, setCurrencyRate] = useState({ from_currency_rate: 1, to_currency_rate: "" });
//     const [users, setUsers] = useState([]);
//     const [userWallets, setUserWallets] = useState([]);
//     const [userAccount, setUserAccount] = useState({});

//     useEffect(() => {
//         fetchData();
//     }, []);

//     const fetchData = async () => {
//         try {
//             const response = await axios.get(`${API_URL}/data`);
//             setCurrencyRate(response.data.convertCurrencyData);
//             setUsers(response.data.users);
//             setUserWallets(response.data.userWallets);
//             setUserAccount(response.data.firstUserAccount);
//         } catch (error) {
//             console.error("Error fetching settings data:", error);
//         }
//     };
//     const handleCurrencyChange = async (event) => {
//         event.preventDefault();
//         const newRate = event.target.to_currency_rate.value;

//         try {
//             await axios.post(`${API_URL}/change-currency-rate`, { to_currency_rate: newRate });
//             alert("Currency Rate Updated Successfully!");
//             fetchData(); // Refresh data after update
//         } catch (error) {
//             console.error("Error updating currency rate:", error);
//         }
//     };
//     const handleChangePassword = async (event) => {
//         event.preventDefault();
//         const formData = new FormData(event.target);

//         try {
//             await axios.post(`${API_URL}/change-password`, {
//                 current_password: formData.get("current_password"),
//                 new_password: formData.get("new_password"),
//                 new_password_confirmation: formData.get("new_password_confirmation")
//             });
//             alert("Password Changed Successfully!");
//         } catch (error) {
//             console.error("Error changing password:", error);
//         }
//     };
//     const handleManageUserAccount = async (event) => {
//         event.preventDefault();
//         const formData = new FormData(event.target);

//         try {
//             await axios.post(`${API_URL}/manage-user-account`, {
//                 username: formData.get("username"),
//                 account_size: formData.get("account_size"),
//                 payout_percentage: formData.get("payout_percentage"),
//             });
//             alert("User Account Updated Successfully!");
//             fetchData(); // Refresh data after update
//         } catch (error) {
//             console.error("Error updating user account:", error);
//         }
//     };

//     return (
//         <>
//             <Helmet>
//                 <title>Admin | Settings</title>
//             </Helmet>
//             <Sidebar isSidebarOpen={isSidebarOpen} />
//             <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
//                 <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
//                     <Header toggleSidebar={toggleSidebar} />
//                     <section className='content'>
//                         <div className="breadcrumb-main-bx">
//                             <div className="breadcrumb-bx">
//                                 <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
//                                 <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                                 <div className="breadcrumb-link breadcrumb-active">Settings</div>
//                             </div>
//                         </div>

//                         {/* Change Currency Rate */}
//                         <div className='container-fluid'>
//                             <div className='row'>
//                                 <div className='col-md-12'>
//                                     <div className='card'>
//                                         <div className="card-header">Change Currency Rate</div>
//                                         <div className="card-body">
//                                             <form id="change_currencyRate" method="POST">
//                                                 <div className="row">
//                                                     <div className="form-group col-lg-4 col-sm-6">
//                                                         <label>USD</label>
//                                                         <input type="text" className="form-control" value="1" readOnly disabled />
//                                                     </div>
//                                                     <div className="form-group col-lg-4 col-sm-6">
//                                                         <label>INR</label>
//                                                         <input type="text" className="form-control" id="to_currency_rate" placeholder="Enter INR rate" name="to_currency_rate" required />
//                                                     </div>
//                                                 </div>
//                                                 <button type="submit" className="common-submit-btn mt-2">Submit</button>
//                                             </form>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>

//                         {/* Manage Highest Payout */}
//                         <div className='container-fluid mt-3'>
//                             <div className='row'>
//                                 <div className='col-md-12'>
//                                     <div className='card'>
//                                         <div className="card-header">Manage Highest Payout</div>
//                                         <div className="card-body">
//                                             <form id="useraccount" method="POST">
//                                                 <div className="row">
//                                                     <div className="form-group col-lg-4 col-sm-4">
//                                                         <label>Username</label>
//                                                         <input type="text" className="form-control" name="username" placeholder="Enter user name" />
//                                                     </div>
//                                                     <div className="form-group col-lg-4 col-sm-4">
//                                                         <label>Account Size</label>
//                                                         <input type="text" className="form-control" name="account_size" placeholder="Enter account size" />
//                                                     </div>
//                                                     <div className="form-group col-lg-4 col-sm-4">
//                                                         <label>Payout Percentage</label>
//                                                         <input type="text" className="form-control" name="payout_percentage" placeholder="Enter payout percentage" required />
//                                                     </div>
//                                                 </div>
//                                                 <button type="submit" className="common-submit-btn mt-2">Submit</button>
//                                             </form>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>

//                         {/* Change Password */}
//                         <div className='container-fluid mt-3'>
//                             <div className='row'>
//                                 <div className='col-md-12'>
//                                     <div className='card'>
//                                         <div className="card-header">Change Password</div>
//                                         <div className="card-body">
//                                             <form id="change_password" method="POST">
//                                                 <div className="row">
//                                                     {/* Current Password */}
//                                                     <div className="form-group col-lg-4 col-sm-6 position-relative">
//                                                         <label>Current Password</label>
//                                                         <div className="input-container">
//                                                             <input
//                                                                 type={showPassword.current ? "text" : "password"}
//                                                                 className="form-control"
//                                                                 id="current_password"
//                                                                 placeholder="Enter current password"
//                                                                 name="current_password"
//                                                                 required
//                                                             />
//                                                             <div className="group_right_icon" onClick={() => togglePassword("current")}>
//                                                                 {showPassword.current ? <EyeOff /> : <Eye />}
//                                                             </div>
//                                                         </div>
//                                                     </div>

//                                                     {/* New Password */}
//                                                     <div className="form-group col-lg-4 col-sm-6 position-relative">
//                                                         <label>New Password</label>
//                                                         <div className="input-container">
//                                                             <input
//                                                                 type={showPassword.new ? "text" : "password"}
//                                                                 className="form-control"
//                                                                 id="new_password"
//                                                                 placeholder="Enter new password"
//                                                                 name="new_password"
//                                                                 required
//                                                             />
//                                                             <div className="group_right_icon" onClick={() => togglePassword("new")}>
//                                                                 {showPassword.new ? <EyeOff /> : <Eye />}
//                                                             </div>
//                                                         </div>
//                                                     </div>

//                                                     {/* Confirm New Password */}
//                                                     <div className="form-group col-lg-4 col-sm-6 position-relative">
//                                                         <label>Confirm New Password</label>
//                                                         <div className="input-container">
//                                                             <input
//                                                                 type={showPassword.confirm ? "text" : "password"}
//                                                                 className="form-control"
//                                                                 id="new_password_confirmation"
//                                                                 placeholder="Confirm new password"
//                                                                 name="new_password_confirmation"
//                                                                 required
//                                                             />
//                                                             <div className="group_right_icon" onClick={() => togglePassword("confirm")}>
//                                                                 {showPassword.confirm ? <EyeOff /> : <Eye />}
//                                                             </div>
//                                                         </div>
//                                                     </div>
//                                                 </div>
//                                                 <button type="submit" className="common-submit-btn mt-2">Submit</button>
//                                             </form>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </section>
//                     <Footer />
//                 </div>
//                 {/* <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0" }}> */}
//                 {/* </div> */}
//             </div >
//         </>
//     );
// }

// export default Settings;
