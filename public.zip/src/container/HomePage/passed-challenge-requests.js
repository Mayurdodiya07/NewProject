import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../components/togglesidebar";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";
import Sidebar from '../sidebar';
import Header from '../Header';
import Footer from '../footer';
import '../../styles/challengerequests.css';
import API_URL from "../../config/config";
import React, { useState, useEffect } from "react";
import axios from 'axios';

function PassedChallengeRequests() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);
    const [searchTerm, setSearchTerm] = useState("");
    const [totalItems, setTotalItems] = useState(0);
    const token = localStorage.getItem("adminToken");

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${API_URL}/passed-challenge-requests`, {
                    headers: { Authorization: `Bearer ${token}` },
                    params: {
                        page: currentPage,
                        limit: itemsPerPage,
                        search: searchTerm
                    }
                });

                setData(Array.isArray(response.data.data) ? response.data.data : []);
                setTotalItems(response.data.total || 0);
            } catch (err) {
                setError(err.response?.data?.message || "Server Error");
            } finally {
                setLoading(false);
            }
        };


        if (token) {
            fetchData();
        }
    }, [token, currentPage, itemsPerPage, searchTerm]);
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    const safeData = Array.isArray(data) ? data : [];
    const filteredData = safeData.filter((row) => {
        const term = searchTerm.toLowerCase();
        return (
            row.name?.toLowerCase().includes(term) ||
            row.email?.toLowerCase().includes(term) ||
            row.user_id?.email?.toLowerCase().includes(term) || // Ensure user_id exists
            row.status?.toLowerCase().includes(term)
        );
    });

    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const currentData = filteredData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    // const [currentPage, setCurrentPage] = useState(1);
    // const itemsPerPage = 10;

    // // Calculate total pages
    // const totalPages = Math.ceil(tableData.length / itemsPerPage);

    // // Get current page data
    // const currentData = tableData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);


    return (

        <>
            <Helmet>
                <title>Admin | Passed Challenge Requests</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Passed Challenge Requests</div>
                            </div>
                        </div>
                        <div className='container-fluid'>
                            <div className='row'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className='card-header'>Passed Challenge Requests</div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='dataTables_length' id='challenge-requests-table_length'>
                                                    <label>Show
                                                        <select
                                                            name="challenge-requests-table_length"
                                                            aria-controls="challenge-requests-table"
                                                            value={itemsPerPage}
                                                            onChange={(e) => {
                                                                setItemsPerPage(Number(e.target.value));
                                                                setCurrentPage(1);
                                                            }}
                                                        >
                                                            <option value="10">10</option>
                                                            <option value="25">25</option>
                                                            <option value="50">50</option>
                                                            <option value="100">100</option>
                                                        </select>

                                                        entries
                                                    </label>
                                                </div>
                                                <div id='challenge-requests-table_filter' className='dataTables_filter'>
                                                    <label>
                                                        Search:
                                                        <input
                                                            type="search"
                                                            placeholder=""
                                                            aria-controls="challenge-requests-table"
                                                            value={searchTerm}
                                                            onChange={(e) => {
                                                                setSearchTerm(e.target.value);
                                                                setCurrentPage(1);
                                                            }}
                                                        />
                                                    </label>
                                                </div>
                                                <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer mt-2" id="challenge-requests-table">
                                                        <thead>
                                                            <tr role="row">
                                                                <th >No.<SortIcon /></th>
                                                                <th>User<SortIcon /></th>
                                                                <th>E-mail<SortIcon /></th>
                                                                <th>Account Number<SortIcon /></th>
                                                                <th>Status<SortIcon /></th>
                                                                <th className="sorting_desc">Date<SortIcon /></th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {currentData.length > 0 ? (
                                                                currentData.map((row, index) => (
                                                                    <tr key={row._id}>
                                                                        <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                                                        <td>
                                                                            {row.title} {row.first_name} {row.last_name}
                                                                        </td>
                                                                        <td>{row.email || (row.user_id?.email || "N/A")}</td>
                                                                        <td>{row.account_number || 'N/A'}</td>
                                                                        <td>{row.status}</td>
                                                                        <td>{new Date(row.created_at).toISOString().replace('T', ' ').split('.')[0]}</td>
                                                                        <td>
                                                                            <Link to={`/admin/passed-challenge-requests/${row._id || row.id}`} className="common-action-btn" title="View">
                                                                                <Icons.ViewIcon />
                                                                            </Link>
                                                                        </td>
                                                                    </tr>
                                                                ))
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
                                                                        No data available in table
                                                                    </td>
                                                                </tr>
                                                            )}
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <div className="dataTables_info">
                                                    Showing {totalItems === 0 ? 0 : (itemsPerPage * (currentPage - 1) + 1)} to{" "}
                                                    {Math.min(itemsPerPage * currentPage, totalItems)} of {totalItems} entries
                                                </div>

                                                <div className="dataTables_paginate paging_simple_numbers">
                                                    <Link className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}>Previous</Link>
                                                    <span>
                                                        {Array.from({ length: totalPages }, (_, index) => (
                                                            <Link
                                                                key={index + 1}
                                                                className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`}
                                                                onClick={() => setCurrentPage(index + 1)}
                                                            >
                                                                {index + 1}
                                                            </Link>
                                                        ))}
                                                    </span>
                                                    <Link
                                                        className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`}
                                                        onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                                                    >
                                                        Next
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    {safeData.length < 8 ? (
                        <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
                            <Footer />
                        </div>
                    ) : (
                        <Footer />
                    )}
                </div>
            </div>
        </>
    )
}

export default PassedChallengeRequests
