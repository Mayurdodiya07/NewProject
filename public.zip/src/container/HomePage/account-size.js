import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../components/togglesidebar";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";
import Sidebar from '../sidebar';
import Header from '../Header';
import Footer from '../footer';
import '../../styles/challengerequests.css';
import API_URL from "../../config/config";
import axios from "axios";

function AccountSize() {
    const token = localStorage.getItem("adminToken");
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const [totalItems, setTotalItems] = useState(0);
    const [itemsPerPage, setItemsPerPage] = useState(10);

    // Fetch data from API using token
    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${API_URL}/account-size`, {
                    headers: { Authorization: `Bearer ${token}` },
                    params: {
                        page: currentPage,
                        limit: itemsPerPage,
                        search: search
                    }
                });

                setData(Array.isArray(response.data.data) ? response.data.data : []);
                setTotalItems(response.data.total);
            } catch (err) {
                if (err.response) {
                    console.error("API Error:", err.response.data);
                } else {
                    console.error("Network Error:", err.message);
                }
                setError(err.response?.data?.message || "Server Error");
            } finally {
                setLoading(false);
            }
        };

        if (token) {
            fetchData();
        } else {
            setError("Unauthorized: No token found.");
            setLoading(false);
        }
    }, [token, currentPage, itemsPerPage, search]);
    const safeData = Array.isArray(data) ? data : [];
    // Calculate pagination values
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const currentData = data;

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <>
            <Helmet>
                <title>Admin | Account Size</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Account Size</div>
                            </div>
                        </div>
                        <div className='container-fluid'>
                            <div className='row'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className='card-header'>Account Size</div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='dataTables_length' id='challenge-requests-table_length'>
                                                    <label>Show
                                                        <select
                                                            name="challenge-requests-table_length"
                                                            aria-controls="challenge-requests-table"
                                                            value={itemsPerPage}
                                                            onChange={(e) => {
                                                                const newLimit = parseInt(e.target.value, 10);
                                                                setCurrentPage(1);
                                                                setItemsPerPage(newLimit);
                                                            }}
                                                        >
                                                            <option value="10">10</option>
                                                            <option value="25">25</option>
                                                            <option value="50">50</option>
                                                            <option value="100">100</option>
                                                        </select>

                                                        entries
                                                    </label>
                                                </div>
                                                {/* Search input */}
                                                <div className="dataTables_filter">
                                                    <label>
                                                        Search:
                                                        <input
                                                            type="search"
                                                            className="search"
                                                            placeholder="Type to search..."
                                                            onChange={(e) => {
                                                                setSearch(e.target.value);
                                                                setCurrentPage(1);
                                                            }}
                                                            value={search}
                                                        />
                                                    </label>
                                                </div>
                                                <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer mt-2" id="challenge-requests-table">
                                                        <thead>
                                                            <tr role="row">
                                                                <th >No.</th>
                                                                <th>Name<SortIcon /></th>
                                                                <th>Account Type<SortIcon /></th>
                                                                <th>Account Step<SortIcon /></th>
                                                                <th>Limit<SortIcon /></th>
                                                                <th>Price<SortIcon /></th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {currentData.length > 0 ? (
                                                                currentData.map((row, index) => (
                                                                    <tr key={row._id || index}>
                                                                        <td>
                                                                            {(currentPage - 1) * itemsPerPage + index + 1}
                                                                        </td>
                                                                        <td>{row.name}</td>
                                                                        <td>{row.account_type_id ? row.account_type_id.name : "N/A"}</td>
                                                                        <td>{row.account_type_id ? row.account_type_id.step : "N/A"}</td>
                                                                        <td>{row.limit}</td>
                                                                        <td>{row.price}</td>
                                                                        <td>
                                                                            <Link to={`/admin/account-size/${row._id || row.id}`} className="common-action-btn" title="View">
                                                                                <Icons.ViewIcon />
                                                                            </Link>
                                                                        </td>
                                                                    </tr>
                                                                ))
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="7" style={{ textAlign: "center", padding: "10px" }}>
                                                                        No data available in table
                                                                    </td>
                                                                </tr>
                                                            )}
                                                        </tbody>
                                                    </table>
                                                </div>
                                                {/* Pagination */}
                                                <div className="dataTables_info">
                                                    Showing {(totalItems === 0) ? 0 : ((currentPage - 1) * itemsPerPage + 1)} to{" "}
                                                    {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems} entries
                                                </div>

                                                <div className="dataTables_paginate paging_simple_numbers">
                                                    <Link className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}>Previous</Link>
                                                    <span>
                                                        {Array.from({ length: totalPages }, (_, index) => (
                                                            <Link
                                                                key={index + 1}
                                                                className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`}
                                                                onClick={() => setCurrentPage(index + 1)}
                                                            >
                                                                {index + 1}
                                                            </Link>
                                                        ))}
                                                    </span>
                                                    <Link
                                                        className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`}
                                                        onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                                                    >
                                                        Next
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    {safeData.length < 8 ? (
                        <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
                            <Footer />
                        </div>
                    ) : (
                        <Footer />
                    )}
                </div>
            </div>
        </>
    )
}

export default AccountSize
