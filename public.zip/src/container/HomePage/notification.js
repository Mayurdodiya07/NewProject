import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import useToggleSidebar from "../../components/togglesidebar";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";
import Sidebar from "../sidebar";
import Header from "../Header";
import Footer from "../footer";
import axios from "axios";
import API_URL from "../../config/config";

function Notification() {
  const [notifications, setNotifications] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [totalItems, setTotalItems] = useState(0);

  const token = localStorage.getItem("adminToken");

  // Fetch Notifications
  useEffect(() => {
    const fetchData = async () => {
      if (!token) return;
      try {
        setLoading(true);
        const response = await axios.get(`${API_URL}/notification`, {
          headers: { Authorization: `Bearer ${token}` },
          params: { page: currentPage, limit: itemsPerPage, search: searchTerm },
        });

        console.log("API Response:", response.data);
        setNotifications(Array.isArray(response.data.data) ? response.data.data : []);
        setTotalPages(response.data.totalPages || 1);
        setTotalItems(response.data.totalItems || 0);

      } catch (err) {
        console.error("Fetch error:", err);
        setError(err.response?.data?.message || "Server Error");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [token, currentPage, itemsPerPage, searchTerm]);

  // Fetch Unread Notification Count (Every 10 seconds)
  useEffect(() => {
    let interval;
    const fetchUnreadCount = async () => {
      if (!token) return;
      try {
        const response = await axios.get(`${API_URL}/notification/unreadCount`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUnreadCount(response.data.count || 0);
      } catch (error) {
        console.error("Error fetching unread notifications:", error);
      }
    };

    fetchUnreadCount();
    interval = setInterval(fetchUnreadCount, 50000);
    return () => clearInterval(interval);
  }, [token]);

  function getAction(notification) {
    if (!notification || !notification.notification_type || !notification.action_id) {
      return "/admin";
    }

    const routes = {
      challange_request: `/admin/challenge-requests/${notification.action_id}`,
      real_account_request: `/admin/real-challenge-requests/${notification.action_id}`,
      payout_request: `/admin/payout/${notification.action_id}`,
    };

    return routes[notification.notification_type] || "/admin";
  }

  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

  // Filtering notifications based on search term
  const filteredData = notifications.filter((row) => {
    const term = searchTerm.toLowerCase();
    return (
      row.user_id?.first_name?.toLowerCase().includes(term) ||
      row.user_id?.last_name?.toLowerCase().includes(term) ||
      row.notification_type?.toLowerCase().includes(term)
    );
  });

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <>
      <Helmet>
        <title>Admin | Notification</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen} unreadCount={unreadCount} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Notification</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='card'>
                    <div className='card-header'>Notification</div>
                    <div className='card-body'>
                      <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                        <div className='dataTables_length' id='challenge-requests-table_length'>
                          <label>Show
                            <select
                              value={itemsPerPage}
                              onChange={(e) => {
                                setItemsPerPage(Number(e.target.value));
                                setCurrentPage(1); // Reset to page 1 on change
                              }}
                            >
                              <option value="10">10</option>
                              <option value="25">25</option>
                              <option value="50">50</option>
                              <option value="100">100</option>
                            </select>

                            entries
                          </label>
                        </div>
                        <div id='challenge-requests-table_filter' className='dataTables_filter'>
                          <label>Search:
                            <input type="search" className="" placeholder="" aria-controls="challenge-requests-table" />
                          </label>
                        </div>
                        <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                        <div className='table-responsive'>
                          <table className="table table-bordered dataTable no-footer mt-2" id="challenge-requests-table">
                            <thead>
                              <tr role="row">
                                <th >No.<SortIcon /></th>
                                <th>User<SortIcon /></th>
                                <th>Notification type<SortIcon /></th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {filteredData.length > 0 ? (
                                filteredData.map((row, index) => (
                                  <tr key={row._id || row.id || index}>
                                    <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                    <td>{row.user_id?.title || ''} {row.user_id?.first_name || ''} {row.user_id?.last_name || ''}</td>
                                    <td>{row.notification_type}</td>
                                    <td>
                                      <Link to={getAction(row)} className="common-action-btn" title="View">
                                        <Icons.ViewIcon />
                                      </Link>
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
                                    No data available in table
                                  </td>
                                </tr>
                              )}

                            </tbody>
                          </table>
                        </div>
                        <div className="dataTables_info">
                          Showing {notifications.length === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1} to{" "}
                          {(currentPage - 1) * itemsPerPage + notifications.length} of {totalPages * itemsPerPage} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`}
                            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                          >
                            Previous
                          </Link>
                          <span>
                            {Array.from({ length: totalPages }, (_, index) => (
                              <Link
                                key={index + 1}
                                className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`}
                                onClick={() => setCurrentPage(index + 1)}
                              >
                                {index + 1}
                              </Link>
                            ))}
                          </span>
                          <Link
                            className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`}
                            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}>
                            Next
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {filteredData.length < 8 ? (
            <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
              <Footer />
            </div>
          ) : (
            <Footer />
          )}
        </div>
      </div>
    </>
  )
}

export default Notification
