import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../components/togglesidebar";
import DeleteModal from "../../components/Modal/Modal";
import Icons from "../../components/icons";
import Sidebar from '../sidebar';
import Header from '../Header';
import Footer from '../footer';
import axios from "axios";
import API_URL from "../../config/config";

function RealChallengeRequests() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [search, setSearch] = useState("");
  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
  const token = localStorage.getItem("adminToken");
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [selectedId, setSelectedId] = React.useState(null);
  const [sortField, setSortField] = useState(null);
  const [sortOrder, setSortOrder] = useState("asc");
  const [totalPages, setTotalPages] = useState(1);


  const handleSort = (field) => {
    const order = sortField === field && sortOrder === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortOrder(order);
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`${API_URL}/real-challenge-requests`, {
          headers: { Authorization: `Bearer ${token}` },
          params: {
            page: currentPage,
            limit: itemsPerPage,
            search,
            sortField,
            sortOrder
          }
        });

        setData(response.data.data || []);
        setTotalPages(response.data.pagination?.totalPages || 1);
      } catch (err) {
        console.error("Error:", err.response ? err.response.data : err.message);
        setError(err.response?.data?.message || "Server Error");
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchData();
  }, [token, currentPage, itemsPerPage, search, sortField, sortOrder]);


  // Ensure data is always an array
  const safeData = Array.isArray(data) ? data : [];

  // });
  const currentData = safeData;
  // const currentData = sortedData;



  const handleDelete = async (_id) => {
    // if (!window.confirm("Are you sure you want to delete this request?")) return;

    try {
      await axios.delete(`${API_URL}/real-challenge-pending/destroy/${_id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Remove the deleted request from the state
      setData((prevData) => prevData.filter((item) => item._id !== _id));

      // alert("Request deleted successfully.");
    } catch (err) {
      console.error("Delete Error:", err.response?.data || err.message);
      // alert("Failed to delete the request.");
    } finally {
      setIsModalOpen(false);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div style={{ color: "red" }}>{error}</div>;
  return (
    <>
      <Helmet>
        <title>Admin | Real Challenge Requests</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Real Challenge Requests</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='card'>
                    <div className='card-header'>Real Challenge Requests</div>
                    <div className='card-body'>
                      <div id='real-challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                        <div className="dataTables_length" id="challenge-requests-table_length">
                          <label>
                            Show{" "}
                            <select
                              name="challenge-requests-table_length"
                              aria-controls="challenge-requests-table"
                              value={itemsPerPage}
                              onChange={(e) => {
                                setItemsPerPage(Number(e.target.value));
                                setCurrentPage(1);
                              }}
                            >
                              <option value="10">10</option>
                              <option value="25">25</option>
                              <option value="50">50</option>
                              <option value="100">100</option>
                            </select>{" "}
                            entries
                          </label>
                        </div>
                        <div id="real-challenge-requests-table_filter" className="dataTables_filter">
                          <label>
                            Search:
                            <input
                              type="search"
                              placeholder=""
                              aria-controls="real-challenge-requests-table"
                              value={search}
                              onChange={(e) => {
                                setSearch(e.target.value);
                                setCurrentPage(1);
                              }}
                            />
                          </label>
                        </div>
                        <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                        <div className='table-responsive'>
                          <table className="table table-bordered dataTable no-footer" id="challenge-requests-table">
                            <thead>
                              <tr role="row">
                                <th className="sorting_disabled" rowSpan="1" colSpan="1" style={{ width: '68px' }} aria-label="No.">No.
                                  <div className="th-sort-icons">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512">
                                      <path d="M414 321.94L274.22 158.82a24 24 0 00-36.44 0L98 321.94c-13.34 15.57-2.28 39.62 18.22 39.62h279.6c20.5 0 31.56-24.05 18.18-39.62z"></path>
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512">
                                      <path d="M98 190.06l139.78 163.12a24 24 0 0036.44 0L414 190.06c13.34-15.57 2.28-39.62-18.22-39.62h-279.6c-20.5 0-31.56 24.05-18.18 39.62z"></path>
                                    </svg>
                                  </div>
                                </th>

                                <th className="sorting" tabIndex="0" aria-controls="challenge-requests-table" rowSpan="1" colSpan="1" style={{ width: '116px' }} aria-label="User : activate to sort column ascending">User
                                  <div className="th-sort-icons">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512">
                                      <path d="M414 321.94L274.22 158.82a24 24 0 00-36.44 0L98 321.94c-13.34 15.57-2.28 39.62 18.22 39.62h279.6c20.5 0 31.56-24.05 18.18-39.62z"></path>
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512">
                                      <path d="M98 190.06l139.78 163.12a24 24 0 0036.44 0L414 190.06c13.34-15.57 2.28-39.62-18.22-39.62h-279.6c-20.5 0-31.56 24.05-18.18 39.62z"></path>
                                    </svg>
                                  </div>
                                </th>

                                <th className="sorting" tabIndex="0" aria-controls="challenge-requests-table" rowSpan="1" colSpan="1" style={{ width: '410px' }} aria-label="E-mail : activate to sort column ascending">E-mail
                                  <div className="th-sort-icons">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M414 321.94L274.22 158.82a24 24 0 00-36.44 0L98 321.94c-13.34 15.57-2.28 39.62 18.22 39.62h279.6c20.5 0 31.56-24.05 18.18-39.62z"></path></svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M98 190.06l139.78 163.12a24 24 0 0036.44 0L414 190.06c13.34-15.57 2.28-39.62-18.22-39.62h-279.6c-20.5 0-31.56 24.05-18.18 39.62z"></path></svg>
                                  </div>
                                </th>
                                <th className="sorting" tabIndex="0" aria-controls="challenge-requests-table" rowSpan="1" colSpan="1" style={{ width: '300px' }} aria-label="Status : activate to sort column ascending">Account Number
                                  <div className="th-sort-icons">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M414 321.94L274.22 158.82a24 24 0 00-36.44 0L98 321.94c-13.34 15.57-2.28 39.62 18.22 39.62h279.6c20.5 0 31.56-24.05 18.18-39.62z"></path></svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M98 190.06l139.78 163.12a24 24 0 0036.44 0L414 190.06c13.34-15.57 2.28-39.62-18.22-39.62h-279.6c-20.5 0-31.56 24.05-18.18 39.62z"></path></svg>
                                  </div>
                                </th>
                                <th className="sorting" tabIndex="0" aria-controls="challenge-requests-table" rowSpan="1" colSpan="1" style={{ width: '150px' }} aria-label="Status : activate to sort column ascending">Status
                                  <div className="th-sort-icons">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M414 321.94L274.22 158.82a24 24 0 00-36.44 0L98 321.94c-13.34 15.57-2.28 39.62 18.22 39.62h279.6c20.5 0 31.56-24.05 18.18-39.62z"></path></svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M98 190.06l139.78 163.12a24 24 0 0036.44 0L414 190.06c13.34-15.57 2.28-39.62-18.22-39.62h-279.6c-20.5 0-31.56 24.05-18.18 39.62z"></path></svg>
                                  </div>
                                </th>
                                <th className="sorting sorting_desc" tabIndex="0" aria-controls="challenge-requests-table" rowSpan="1" colSpan="1" style={{ width: '300px' }} aria-sort="descending" aria-label="Date : activate to sort column ascending">Date
                                  <div className="th-sort-icons">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M414 321.94L274.22 158.82a24 24 0 00-36.44 0L98 321.94c-13.34 15.57-2.28 39.62 18.22 39.62h279.6c20.5 0 31.56-24.05 18.18-39.62z"></path></svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M98 190.06l139.78 163.12a24 24 0 0036.44 0L414 190.06c13.34-15.57 2.28-39.62-18.22-39.62h-279.6c-20.5 0-31.56 24.05-18.18 39.62z"></path></svg>
                                  </div>
                                </th>
                                <th className="sorting_disabled" rowSpan="1" colSpan="1" style={{ width: '150px' }} aria-label="Action">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {currentData.length > 0 ? (
                                currentData.map((row, index) => (
                                  <tr key={row._id}>
                                    <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                    <td> {row.first_name} {row.last_name}</td>
                                    <td>{row.email || (row.user_id?.email || "N/A")}</td>
                                    <td>{row.user_wallet?.account_number || "N/A"}</td>
                                    <td>{row.account_status}</td>
                                    <td>{new Date(row.created_at).toISOString().replace('T', ' ').split('.')[0]}</td>

                                    <td>
                                      <Link
                                        to={`/admin/real-challenge-requests/${row._id || row.id}`}
                                        className="common-action-btn"
                                        title="View"
                                      >
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="size-6">
                                          <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"></path>
                                          <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                                        </svg>
                                      </Link>
                                      <Link
                                        className="common-action-btn"
                                        title="Delete"
                                        onClick={() => {
                                          setSelectedId(row._id || row.id);
                                          setIsModalOpen(true);
                                        }}
                                      >
                                        <Icons.DeleteIcon />
                                      </Link>
                                      {isModalOpen && (
                                        <DeleteModal
                                          isOpen={isModalOpen}
                                          onClose={() => setIsModalOpen(false)}
                                          onConfirm={() => handleDelete(selectedId)}
                                        />
                                      )}
                                    </td>

                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
                                    No data available in table
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                        <div className="dataTables_info">
                          Showing {Math.min((currentPage - 1) * itemsPerPage + 1, totalPages === 0 ? 0 : Infinity)} to{" "}
                          {Math.min(currentPage * itemsPerPage, totalPages * itemsPerPage)} of {totalPages * itemsPerPage} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}>Previous</Link>
                          <span>
                            {Array.from({ length: totalPages }, (_, index) => (
                              <Link key={index + 1} className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`} onClick={() => setCurrentPage(index + 1)}>{index + 1}</Link>
                            ))}
                          </span>
                          <Link className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}>Next</Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {safeData.length < 8 ? (
            <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
              <Footer />
            </div>
          ) : (
            <Footer />
          )}
        </div>
      </div>
    </>
  )
}

export default RealChallengeRequests
