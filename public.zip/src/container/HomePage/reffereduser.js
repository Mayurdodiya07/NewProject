import React, { useState, useEffect } from "react"
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../components/togglesidebar";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";
import DateRangePickerComponent from "../../components/DateRangePicker";
import Sidebar from '../sidebar';
import Header from '../Header';
import Footer from '../footer';
import axios from "axios";
import API_URL from "../../config/config";

function Reffereduser() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [tableData, setTableData] = useState([]);
  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
  const [totalPages, setTotalPages] = useState(1);
  const [totalUsers, setTotalUsers] = useState(0);
  const [dateRange, setDateRange] = useState("");


  // useEffect(() => {
  const fetchData = async (page = 1, dateRange = "") => {
    try {
      const response = await axios.get(`${API_URL}/referreduser`, {
        params: {
          page,
          limit: itemsPerPage,
          dateRange,
        },
        headers: {
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      });

      setData(response.data.users);
      setTableData(response.data.users);
      setLoading(false);
      setTotalPages(response.data.totalPages);
      setTotalUsers(response.data.totalUsers);

    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(currentPage, dateRange);
  }, [currentPage, itemsPerPage, dateRange]);

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };
  const currentData = data;

  return (
    <>
      <Helmet>
        <title>Admin | User</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Refer User</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='card'>
                    <div className="card-header d-flex justify-content-between align-items-center">
                      <div>Refer User
                        <div className="common-field common-field-date mt-2">
                          <DateRangePickerComponent setDateRange={setDateRange} />
                        </div>
                      </div>
                    </div>
                    <div className='card-body'>
                      <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                        <div className='dataTables_length' id='challenge-requests-table_length'>
                          <label>Show
                            <select
                              value={itemsPerPage}
                              onChange={(e) => {
                                setItemsPerPage(parseInt(e.target.value));
                                setCurrentPage(1); // reset to page 1
                              }}
                            >
                              <option value="10">10</option>
                              <option value="25">25</option>
                              <option value="50">50</option>
                              <option value="100">100</option>
                            </select>

                            entries
                          </label>
                        </div>
                        <div id='challenge-requests-table_filter' className='dataTables_filter'>
                          <label>Search:
                            <input type="search" className="" placeholder="" aria-controls="challenge-requests-table" />
                          </label>
                        </div>
                        <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                        <div className='table-responsive'>
                          <table className="table table-bordered dataTable no-footer mt-2" id="challenge-requests-table">
                            <thead>
                              <tr role="row">
                                <th >No.<SortIcon /></th>
                                <th>User<SortIcon /></th>
                                <th>E-mail Id<SortIcon /></th>
                                <th>No of Referrals<SortIcon /></th>
                                <th>No of Accounts<SortIcon /></th>
                                <th>Rewards<SortIcon /></th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {currentData.length > 0 ? (
                                currentData.map((user, index) => (
                                  <tr key={user.id}>
                                    <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                    <td>{user.name}</td>
                                    <td>{user.email}</td>
                                    <td>{user.referral_count}</td>
                                    <td>{user.account_count}</td>
                                    <td>{user.reward}</td>
                                    <td>
                                      <Link to={`/admin/reffereduser/${user._id || user.id}`} className="common-action-btn" title="View">
                                        <Icons.ViewIcon />
                                      </Link>
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
                                    No data available in table
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <div className="dataTables_info">
                          Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                          {(currentPage - 1) * itemsPerPage + data.length} of {totalUsers} entries


                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`}
                            onClick={() => handlePageChange(Math.max(currentPage - 1, 1))}
                          >
                            Previous
                          </Link>
                          <span>
                            {Array.from({ length: totalPages }, (_, index) => (
                              <Link
                                key={index + 1}
                                className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`}
                                onClick={() => handlePageChange(index + 1)}
                              >
                                {index + 1}
                              </Link>
                            ))}
                          </span>
                          <Link
                            className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`}
                            onClick={() => handlePageChange(Math.min(currentPage + 1, totalPages))}
                          >
                            Next
                          </Link>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <Footer />
            </div>
          </section>
          {tableData.length < 8 ? (
            <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
            </div>
          ) : (
            <Footer />
          )}
        </div>
      </div>
    </>
  )
}

export default Reffereduser
