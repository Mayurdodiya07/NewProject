
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import DateRangePickerComponent from "../../components/DateRangePicker";
import useToggleSidebar from "../../components/togglesidebar";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";
import Sidebar from '../sidebar';
import Header from '../Header';
import Footer from '../footer';
import API_URL from "../../config/config";
import axios from "axios";

function DisabledAccounts() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [search, setSearch] = useState("");
  const [totalEntries, setTotalEntries] = useState(0);
  const token = localStorage.getItem("adminToken");
  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
  const [selectedDateFilter, setSelectedDateFilter] = useState("all");
  const [dateRange, setDateRange] = useState({ startDate: null, endDate: null });

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`${API_URL}/disabled-accounts`, {
          headers: { Authorization: `Bearer ${token}` },
          params: {
            page: currentPage,
            limit: itemsPerPage,
            search: search,
            filter: selectedDateFilter,
            startDate: dateRange.startDate,
            endDate: dateRange.endDate
          }
        });
        setData(response.data.data || []);
        setTotalEntries(response.data.pagination?.total || 0);
      } catch (err) {
        console.error("Error:", err.response ? err.response.data : err.message);
        setError(err.response?.data?.message || "Server Error");
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchData();
  }, [token, currentPage, itemsPerPage, search, selectedDateFilter, dateRange]);


  const handleExportExcel = async () => {
    try {
      const response = await axios.post(
        `${API_URL}/disabled-accounts/export`,
        {},
        {
          responseType: 'blob',
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'disabled-accounts.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error exporting Excel:', error);
      alert('Failed to export Excel');
    }
  };
  const handleDateRangeChange = (e) => {
    const selectedFilter = e.target.value;
    setSelectedDateFilter(selectedFilter); // update state
  };
  if (loading) return <div>Loading...</div>;
  if (error) return <div style={{ color: "red" }}>{error}</div>;

  return (
    <>
      <Helmet><title>Admin | Disabled Accounts</title></Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Disabled  Accounts</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='card'>
                    <div className="card-header d-flex justify-content-between align-items-center">
                      <div>Disabled  Accounts</div>
                      <div className="d-flex gap-3 align-items-center">
                        <button className="btn btn-primary mb-3 mt-3" onClick={handleExportExcel}>Download Report</button>
                        <DateRangePickerComponent setDateRange={setDateRange} />
                        <div className="d-flex align-items-center gap-2">
                          <select className="form-control" id="filter-date-range" onChange={handleDateRangeChange}>
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="month">This Month</option>
                          </select>

                          <svg className="dropdown-icon" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6" /></svg>
                        </div>
                      </div>
                    </div>
                    <div className='card-body'>
                      <div className='dataTables_wrapper'>
                        <div className='dataTables_length'>
                          <label>Show
                            <select
                              value={itemsPerPage}
                              onChange={(e) => {
                                setItemsPerPage(parseInt(e.target.value));
                                setCurrentPage(1);
                              }}
                            >
                              <option value="10">10</option>
                              <option value="25">25</option>
                              <option value="50">50</option>
                              <option value="100">100</option>
                            </select>
                            entries
                          </label>
                        </div>
                        <div className='dataTables_filter'>
                          <label>Search:
                            <input
                              type="search"
                              placeholder="Search..."
                              value={search}
                              onChange={(e) => {
                                setSearch(e.target.value);
                                setCurrentPage(1);
                              }}
                            />
                          </label>
                        </div>
                        <div className='table-responsive'>
                          <table className="table table-bordered dataTable mt-2">
                            <thead>
                              <tr>
                                <th>No.<SortIcon /></th>
                                <th>User<SortIcon /></th>
                                <th>E-mail<SortIcon /></th>
                                <th>Phone<SortIcon /></th>
                                <th>Account Number<SortIcon /></th>
                                <th>Account Type<SortIcon /></th>
                                <th>Status<SortIcon /></th>
                                <th>Disable Reason<SortIcon /></th>
                                <th>Date<SortIcon /></th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {data.length > 0 ? (
                                data.map((row, index) => (
                                  <tr key={row._id || row.id || index}>
                                    <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                    <td>{row.first_name || "N/A"} {row.last_name || ""}</td>
                                    <td>{row.email || row?.user_id?.email || "N/A"}</td>
                                    <td>{row?.user_id?.phone || "N/A"}</td>
                                    <td>{row.account_number || "N/A"}</td>
                                    <td>{row.mt5_type || "N/A"}</td>
                                    <td>{row.account_status || "N/A"}</td>
                                    <td>{row.disableReason || "N/A"}</td>
                                    <td>{new Date(row.created_at).toISOString().split('T')[0].split('-').reverse().join('-')}</td>
                                    <td>
                                      <Link to={`/admin/disabled-accounts/${row._id || row.id}`} className="common-action-btn" title="View">
                                        <Icons.ViewIcon />
                                      </Link>
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="10" className="text-center py-3">No data available in table</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                        <div className="dataTables_info">
                          Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, totalEntries)} of {totalEntries} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`}
                            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                          >
                            Previous
                          </Link>
                          <span>
                            {Array.from({ length: Math.ceil(totalEntries / itemsPerPage) }, (_, index) => (
                              <Link
                                key={index + 1}
                                className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`}
                                onClick={() => setCurrentPage(index + 1)}
                              >
                                {index + 1}
                              </Link>
                            ))}
                          </span>
                          <Link
                            className={`paginate_button next ${currentPage === Math.ceil(totalEntries / itemsPerPage) ? "disabled" : ""}`}
                            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, Math.ceil(totalEntries / itemsPerPage)))}
                          >
                            Next
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {data.length < 8 ? (
            <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0" }}>
              <Footer />
            </div>
          ) : (
            <Footer />
          )}
        </div>
      </div>
    </>
  );
}

export default DisabledAccounts;
