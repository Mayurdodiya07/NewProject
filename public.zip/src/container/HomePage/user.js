import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../components/togglesidebar";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";
import Sidebar from '../sidebar';
import Header from '../Header';
import Footer from '../footer';
import API_URL from "../../config/config";
import axios from "axios";


function User() {
  const [users, setUsers] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [countries, setCountries] = useState([]);
  const [successMessage, setSuccessMessage] = useState("");
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const token = localStorage.getItem("adminToken");
  // const [sortBy, setSortBy] = useState("created_at");
  // const [sortOrder, setSortOrder] = useState("desc");

  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

  useEffect(() => {
    const fetchUsers = async () => {
      const token = localStorage.getItem("adminToken");
      if (!token) {
        setError("Unauthorized: No token provided");
        setLoading(false);
        return;
      }
      //user data fetch
      try {
        const response = await axios.get(`${API_URL}/user`, {
          headers: { Authorization: `Bearer ${token}` },
          params: { page: currentPage, limit: itemsPerPage, search: searchTerm },
        });
        setUsers(response.data.data || []);
        setTotalPages(response.data.pagination.totalPages || 1);
        setTotalUsers(response.data.pagination.total || 0);


      } catch (err) {
        setError(err.response?.data?.message || "Server Error");
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [currentPage, itemsPerPage, searchTerm]);

  //	Status active or Inacive 
  const toggleUserStatus = async (userId) => {
    try {
      const response = await axios.post(`${API_URL}/user/toggle-status/${userId}`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.data.success) {
        setSuccessMessage(response.data.success);

        // Update user status in state
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user._id === userId ? { ...user, status: response.data.status } : user
          )
        );

        setTimeout(() => setSuccessMessage(""), 3000);
      }
    } catch (error) {
      console.error("Error updating status:", error.response?.data?.message || error.message);
    }
  };

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      setCurrentPage(1);
    }, 500);
    return () => clearTimeout(delayDebounce);
  }, [searchTerm]);

  //E-mail verficaton link send 
  const sendVerificationEmail = async (userId) => {
    try {
      const response = await axios.post(`${API_URL}/user/toggle-verified/${userId}`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.data.success) {
        setSuccessMessage("Verification email sent successfully!");
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user._id === userId ? { ...user, email_verified_at: new Date() } : user
          )
        );

        setTimeout(() => setSuccessMessage(""), 3000);
      }
    } catch (error) {
      console.error("Error sending email:", error.response?.data?.message || error.message);
    }
  };
  // 	Affiliate button 
  const toggleAffiliateStatus = async (userId) => {
    try {
      const response = await axios.post(
        `${API_URL}/user/toggle-affiliate/${userId}`,
        {},
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.data.success) {
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user._id === userId ? { ...user, is_affiliate: response.data.is_affiliate } : user
          )
        );
      }
    } catch (error) {
      console.error("Error toggling affiliate status:", error.response?.data?.message || error.message);
    }
  };
  // useEffect(() => {
  //   const fetchCountries = async () => {
  //     try {
  //       const res = await axios.get(`${API_URL}/countries`, {
  //         headers: { Authorization: `Bearer ${token}` }
  //       });
  //       setCountries(res.data.data); // Adjust based on your response format
  //     } catch (err) {
  //       console.error("Failed to fetch countries", err);
  //     }
  //   };
  //   fetchCountries();
  // }, [token]);


  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <>
      <Helmet>
        <title>Admin | User</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">User</div>
                {successMessage && (
                  <div className="alert alert-success" role="alert">
                    {successMessage}
                  </div>
                )}

              </div>
            </div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='card'>
                    <div className="card-header d-flex justify-content-between align-items-center">
                      <div>User</div>
                      <Link to="/admin/user/add" className="cbi-small common-btn-item cbi-fill text-decoration-none"><span><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="size-6"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15"></path></svg>Add New User</span></Link>
                    </div>
                    <div className='card-body'>
                      <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                        <div className='dataTables_length' id='challenge-requests-table_length'>
                          <label>Show
                            <select
                              value={itemsPerPage}
                              onChange={(e) => {
                                setCurrentPage(1);
                                setItemsPerPage(Number(e.target.value));
                              }}
                            >
                              <option value={10}>10</option>
                              <option value={25}>25</option>
                              <option value={50}>50</option>
                              <option value={100}>100</option>
                            </select>

                            entries
                          </label>
                        </div>
                        <div id='challenge-requests-table_filter' className='dataTables_filter'>
                          <label>Search:
                            {/* <input type="search" className="" placeholder="" aria-controls="challenge-requests-table" /> */}
                            <input
                              type="search"
                              className="form-control"
                              placeholder="Search..."
                              aria-controls="challenge-requests-table"
                              value={searchTerm}
                              onChange={(e) => {
                                setSearchTerm(e.target.value);
                                setCurrentPage(1);
                              }}
                            />

                          </label>
                        </div>
                        <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                        <div className='table-responsive'>
                          <table className="table table-bordered dataTable no-footer overflow-x-auto mt-2" id="challenge-requests-table">
                            <thead>
                              <tr role="row">
                                <th >No.<SortIcon /></th>
                                <th>User<SortIcon /></th>
                                <th>E-mail Id<SortIcon /></th>
                                <th>Phone<SortIcon /></th>
                                <th>Country<SortIcon /></th>
                                <th className="sorting_desc">Date<SortIcon /></th>
                                <th>Status</th>
                                <th>Action</th>
                                <th>E-mail</th>
                                <th>Affiliate</th>
                              </tr>
                            </thead>
                            <tbody>
                              {users.length > 0 ? (
                                users.map((row, index) => (
                                  <tr key={row._id || row.id || index}>
                                    <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                    <td>{row.name}</td>
                                    <td>{row.email || (row.user_id?.email || "N/A")}</td>
                                    <td>{row.phone}</td>
                                    <td>
                                      {row.country
                                        ? countries.find(c => c.id === row.country)?.name || "-"
                                        : "-"}
                                    </td>

                                    <td>{new Date(row.created_at).toISOString().split('T')[0].split('-').reverse().join('-')}</td>
                                    <td>
                                      <span
                                        className={`badge badge-pill ${row.status === "Active" ? "badge-primary" : "badge-danger"}`}
                                        style={{ cursor: "pointer" }}
                                        onClick={() => toggleUserStatus(row._id || row.id)}
                                      >
                                        {row.status}
                                      </span>
                                    </td>
                                    <td>
                                      <Link to={`/admin/user/${row._id || row.id}`} className="common-action-btn" title="View">
                                        <Icons.ViewIcon />
                                      </Link>
                                      <Link to={`/admin/user/edit/${row._id || row.id}`} className="common-action-btn toggle-status" data-id="674060c2893b38fdb1880389" title="Toggle Status">
                                        <Icons.EditIcon />
                                      </Link>
                                      <Link to={`/admin/user/account/${row._id || row.id}`} className="common-action-btn" title="View">
                                        <Icons.SettingIcon />
                                      </Link>
                                    </td>
                                    <td>
                                      {row.email_verified_at ? (
                                        <span className="badge badge-pill badge-primary">Verified</span>
                                      ) : (
                                        <span
                                          className="badge badge-pill badge-danger toggle-status"
                                          style={{ cursor: "pointer" }}
                                          onClick={() => sendVerificationEmail(row._id || row.id)}
                                        >
                                          Click To Send Link
                                        </span>
                                      )}
                                    </td>
                                    <td>
                                      <label className="switch">
                                        <input
                                          type="checkbox"
                                          className="toggle-affiliate"
                                          checked={row.is_affiliate === true || row.is_affiliate === "1"}
                                          onChange={() => toggleAffiliateStatus(row._id || row.id)}
                                        />
                                        <span className="slider round"></span>
                                      </label>
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>No data available in table</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <div className="dataTables_info">
                          {totalUsers > 0 ? (
                            <>Showing {(itemsPerPage * (currentPage - 1)) + 1} to {Math.min(itemsPerPage * currentPage, totalUsers)} of {totalUsers} entries</>
                          ) : (
                            <>Showing 0 to 0 of 0 entries</>
                          )}
                        </div>



                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}>Previous</Link>
                          <span>
                            {Array.from({ length: totalPages }, (_, index) => (
                              <Link key={index + 1} className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`} onClick={() => setCurrentPage(index + 1)}>{index + 1}</Link>
                            ))}
                          </span>
                          <Link className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}>Next</Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <Footer />
            </div>
          </section>
          {tableData.length < 8 ? (
            <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
            </div>
          ) : (
            <Footer />
          )}
        </div>
      </div>
    </>
  )
}

export default User
