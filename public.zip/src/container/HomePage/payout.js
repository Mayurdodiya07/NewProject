import React, { useState, useEffect } from "react"
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../components/togglesidebar";
import Icons from "../../components/icons";
import SortIcon from "../../components/table/SortIcon";
import Sidebar from '../sidebar';
import Header from '../Header';
import Footer from '../footer';
import DeleteModal from "../../components/Modal/ModalPayout";
import axios from "axios";
import API_URL from "../../config/config";


function Payout() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const token = localStorage.getItem("adminToken");
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${API_URL}/payout`, {
          headers: { Authorization: `Bearer ${token}` },
          params: {
            page: currentPage,
            limit: itemsPerPage,
            search: searchTerm
          }
        });

        setData(response.data.data || []);
        setTotalPages(response.data.totalPages || 1);
        setTotalItems(response.data.totalItems || 0);
      } catch (err) {
        setError(err.response?.data?.message || "Unable to fetch data");
      } finally {
        setLoading(false);
      }
    };

    if (token) {
      fetchData();
    }
  }, [token, currentPage, itemsPerPage, searchTerm]);

  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const safeData = Array.isArray(data) ? data : [];


  // const currentData = filteredData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const currentData = data;
  // delete payout
  const handleDelete = async (id) => {
    if (!id) {
      alert("Invalid payout ID");
      return;
    }

    // if (!window.confirm("Are you sure you want to delete this payout?")) return;

    try {
      const response = await axios.delete(`${API_URL}/payout/destroy/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.data.success) {
        // Remove deleted payout from the state
        setData((prevData) => prevData.filter((item) => item.id !== id));
      } else {
      }
    } catch (err) {
      console.error("Delete Error:", err.response?.data || err.message);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;


  return (
    <>
      <Helmet>
        <title>Admin | Payouts</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Payouts</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='card'>
                    <div className='card-header'>Payouts</div>
                    <div className='card-body'>
                      <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                        <div className='dataTables_length' id='challenge-requests-table_length'>
                          <label>Show
                            <select
                              name="challenge-requests-table_length"
                              value={itemsPerPage}
                              onChange={(e) => {
                                setItemsPerPage(parseInt(e.target.value));
                                setCurrentPage(1);
                              }}
                            >
                              <option value="10">10</option>
                              <option value="25">25</option>
                              <option value="50">50</option>
                              <option value="100">100</option>
                            </select>

                            entries
                          </label>
                        </div>
                        <div id='challenge-requests-table_filter' className='dataTables_filter'>
                          <label>Search:
                            <input type="search" className="" placeholder="" aria-controls="challenge-requests-table" />
                          </label>
                        </div>
                        <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                        <div className='table-responsive'>
                          <table className="table table-bordered dataTable no-footer mt-2" id="challenge-requests-table">
                            <thead>
                              <tr role="row">
                                <th >No.<SortIcon /></th>
                                <th>User<SortIcon /></th>
                                <th>Status<SortIcon /></th>
                                <th>Amount<SortIcon /></th>
                                <th>Payment Type<SortIcon /></th>
                                <th>Payout Type<SortIcon /></th>
                                <th className="sorting_desc">Date<SortIcon /></th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {currentData.length > 0 ? (
                                currentData.map((row, index) => (
                                  <tr key={row._id || row.id || index}>
                                    <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                                    <td>{row.user?.first_name} {row.user?.last_name}</td>
                                    <td>{row.payment_status}</td>
                                    <td>{row.amount}</td>
                                    <td>{row.payment_method_id?.name}</td>
                                    <td>{row.payout_type}</td>
                                    <td>{row.created_at_formatted}</td>
                                    <td>
                                      <Link to={`/admin/payout/${row.id || row._id}`} className="common-action-btn" title="View">
                                        <Icons.ViewIcon />
                                      </Link>

                                      <Link
                                        className="common-action-btn"
                                        title="Delete"
                                        onClick={() => setIsModalOpen(row.id || row._id)}
                                      >
                                        <Icons.DeleteIcon />
                                      </Link>

                                      {isModalOpen === (row.id || row._id) && (
                                        <DeleteModal
                                          onClose={() => setIsModalOpen(null)}
                                          onConfirm={() => {
                                            handleDelete(row.id || row._id);
                                            setIsModalOpen(null);
                                          }}
                                        />
                                      )}
                                    </td>

                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
                                    No data available in table
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <div className="dataTables_info">
                          Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                          {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems} entries
                        </div>

                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}>Previous</Link>
                          <span>
                            {Array.from({ length: totalPages }, (_, index) => (
                              <Link key={index + 1} className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`} onClick={() => setCurrentPage(index + 1)}>{index + 1}</Link>
                            ))}
                          </span>
                          <Link className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}>Next</Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {safeData.length < 8 ? (
            <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
              <Footer />
            </div>
          ) : (
            <Footer />
          )}
        </div>
      </div>
    </>
  )
}

export default Payout
