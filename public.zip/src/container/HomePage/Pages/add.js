// import React, { useState } from "react";
// import { Helmet } from "react-helmet";
// import { Link } from "react-router-dom";
// import useToggleSidebar from "../../../components/togglesidebar";

// import Sidebar from "../../sidebar";
// import Header from "../../Header";
// import Footer from "../../footer";

// function Add() {
//     const [formData, setFormData] = useState({
//         first_name: "",
//         last_name: "",
//         email: "",
//         password: "",
//         phone_number: "",
//         country: "",
//         city: "",
//         status: "",
//     });

//     const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

//     const handleChange = (e) => {
//         setFormData({ ...formData, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         console.log("Submitting form data:", formData);
//         // Implement API call to update user details here
//     };


//     return (
//         <>
//             <Helmet>
//                 <title>Admin | Add Account Size Details</title>
//             </Helmet>
//             <Sidebar isSidebarOpen={isSidebarOpen} />
//             <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
//                 <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
//                     <Header toggleSidebar={toggleSidebar} />
//                     <div className="breadcrumb-main-bx">
//                         <div className="breadcrumb-bx">
//                             <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
//                             <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                             <Link className="breadcrumb-link" to="/admin/account-size">Account Size</Link>
//                             <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                             <div className="breadcrumb-link breadcrumb-active">Add Account Size</div>
//                         </div>
//                     </div>
//                     <section className="content">
//                         <div className="container-fluid">
//                             <div className="row">
//                                 <div className="col-md-12">
//                                     <div className="card">
//                                         <div className="card-header">Add Account Size</div>
//                                         <div className="card-body">
//                                             <form onSubmit={handleSubmit}>
//                                                 <div className="row">
//                                                     <div className="form-group col-6">
//                                                         <label htmlFor="first_name">First Name</label>
//                                                         <input
//                                                             type="text"
//                                                             className="form-control"
//                                                             id="first_name"
//                                                             placeholder="Enter first name"
//                                                             name="first_name"
//                                                             value={formData.first_name}
//                                                             onChange={handleChange}
//                                                         />
//                                                     </div>
//                                                     <div className="form-group col-6">
//                                                         <label htmlFor="last_name">Last Name</label>
//                                                         <input
//                                                             type="text"
//                                                             className="form-control"
//                                                             id="last_name"
//                                                             placeholder="Enter last name"
//                                                             name="last_name"
//                                                             value={formData.last_name}
//                                                             onChange={handleChange}
//                                                         />
//                                                     </div>

//                                                     <div className="form-group col-sm-6">
//                                                         <label htmlFor="email">Email address</label>
//                                                         <input
//                                                             type="email"
//                                                             className="form-control"
//                                                             id="email"
//                                                             placeholder="Enter email"
//                                                             name="email"
//                                                             value={formData.email}
//                                                             onChange={handleChange}
//                                                         />
//                                                     </div>
//                                                     <div className="form-group col-sm-6">
//                                                         <label htmlFor="password">Password</label>
//                                                         <input
//                                                             type="password"
//                                                             className="form-control"
//                                                             id="password"
//                                                             placeholder="Password"
//                                                             name="password"
//                                                             value={formData.password}
//                                                             onChange={handleChange}
//                                                         />
//                                                     </div>

//                                                     <div className="form-group col-sm-6">
//                                                         <label htmlFor="phone">Phone</label>
//                                                         <input
//                                                             type="text"
//                                                             className="form-control"
//                                                             id="phone"
//                                                             placeholder="Enter phone number"
//                                                             name="phone_number"
//                                                             value={formData.phone_number}
//                                                             onChange={handleChange}
//                                                         />
//                                                     </div>

//                                                     <div className="form-group col-sm-6">
//                                                         <label htmlFor="country">Country</label>
//                                                         <select
//                                                             className="form-control"
//                                                             id="country"
//                                                             name="country"
//                                                             value={formData.country}
//                                                             onChange={handleChange}
//                                                         >
//                                                             <option value="">Select Country</option>
//                                                             <option value="USA">USA</option>
//                                                             <option value="UK">UK</option>
//                                                             <option value="India">India</option>
//                                                         </select>
//                                                     </div>
//                                                     <div className="form-group col-sm-6">
//                                                         <label htmlFor="city">City</label>
//                                                         <input
//                                                             type="text"
//                                                             className="form-control"
//                                                             id="city"
//                                                             placeholder="Enter city"
//                                                             name="city"
//                                                             value={formData.city}
//                                                             onChange={handleChange}
//                                                         />
//                                                     </div>

//                                                     <div className="form-group col-sm-6">
//                                                         <label htmlFor="status">Status</label>
//                                                         <select
//                                                             className="form-control"
//                                                             id="status"
//                                                             name="status"
//                                                             value={formData.status}
//                                                             onChange={handleChange}
//                                                         >
//                                                             <option value="">Select Status</option>
//                                                             <option value="Active">Active</option>
//                                                             <option value="Inactive">Inactive</option>
//                                                         </select>
//                                                     </div>
//                                                 </div>
//                                                 <button type="submit" className="common-submit-btn mt-2">
//                                                     Submit
//                                                 </button>
//                                             </form>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </section>
//                     <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
//                         <Footer />
//                     </div>
//                 </div>
//             </div>
//         </>
//     )
// }

// export default Add
