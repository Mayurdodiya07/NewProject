
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from "react-router-dom";
import axios from "axios";
import useToggleSidebar from "../../../components/togglesidebar";
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import API_URL from "../../../config/config";

function RefferUserDetails() {
  const { id } = useParams();
  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

  const [tableData, setTableData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`${API_URL}/referreduser/${id}?page=${currentPage}&limit=${itemsPerPage}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
          },
        });

        setTableData(response.data.referralsWithWallets || []);
        setTotalPages(response.data.totalPages || 1);
        setTotalItems(response.data.totalItems || 0);
      } catch (err) {
        setError("Failed to fetch data.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, currentPage, itemsPerPage]);



  // Calculate total pages
  // const totalPages = Math.ceil(tableData.length / itemsPerPage);
  // const currentData = tableData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const currentData = tableData;


  return (
    <>
      <Helmet>
        <title>Admin | View User Details</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <Link className="breadcrumb-link" to="/admin/reffereduser">Refer User</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Details</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='card'>
                    <div className="card-header d-flex justify-content-between align-items-center">
                      <div>Referred Users and Wallet Details</div>
                    </div>
                    <div className='card-body'>
                      <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                        <div className='dataTables_length' id='challenge-requests-table_length'>
                          <label>Show
                            <select
                              value={itemsPerPage}
                              onChange={(e) => {
                                setCurrentPage(1); // reset to page 1
                                setItemsPerPage(parseInt(e.target.value));
                              }}
                            >
                              <option value="10">10</option>
                              <option value="25">25</option>
                              <option value="50">50</option>
                              <option value="100">100</option>
                            </select>

                            entries
                          </label>
                        </div>
                        <div id='challenge-requests-table_filter' className='dataTables_filter'>
                          <label>Search:
                            <input type="search" className="" placeholder="" aria-controls="challenge-requests-table" />
                          </label>
                        </div>
                        <div id='challenge-requests-table_processing' className='dataTables_processing'></div>
                        <div className='table-responsive'>
                          <table className="table table-bordered dataTable no-footer overflow-x-auto mt-2" id="challenge-requests-table">
                            <thead>
                              <tr>
                                <th>No.</th>
                                <th>Referred User</th>
                                <th>Email Id</th>
                                <th>Account Number</th>
                                <th>Account Size</th>
                              </tr>
                            </thead>
                            <tbody>
                              {currentData.length > 0 ? (
                                currentData.map((row, index) => (
                                  <tr key={row.id} className="odd">
                                    <td>{index + 1}</td> {/* This will show 1, 2, 3, ... instead of row.id */}
                                    <td>{row.name}</td>
                                    <td>{row.emailId}</td>
                                    <td>{row.accNumber}</td>
                                    <td>{row.accSize}</td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="6" style={{ textAlign: "center", padding: "10px" }}>
                                    No data available in table
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <div className="dataTables_info">
                          Showing {itemsPerPage * (currentPage - 1) + 1} to{" "}
                          {Math.min(itemsPerPage * currentPage, totalItems)} of {totalItems} entries
                        </div>

                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link className={`paginate_button previous ${currentPage === 1 ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}>Previous</Link>
                          <span>
                            {Array.from({ length: totalPages }, (_, index) => (
                              <Link key={index + 1} className={`paginate_button ${currentPage === index + 1 ? "current active" : ""}`} onClick={() => setCurrentPage(index + 1)}>{index + 1}</Link>
                            ))}
                          </span>
                          <Link className={`paginate_button next ${currentPage === totalPages ? "disabled" : ""}`} onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}>Next</Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {tableData.length < 8 ? (
            <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
              <Footer />
            </div>
          ) : (
            <Footer />
          )}
        </div>
      </div>
    </>
  )
}

export default RefferUserDetails
