import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
// import Demo from '../../../assets/img/demo.png';
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";
import axios from "axios";
import API_URL from "../../../config/config";


function AccountSizeDetails() {

    // const [isModalOpen, setIsModalOpen] = useState(false);
    const { id } = useParams();
    const [accountSize, setAccountSize] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const token = localStorage.getItem("adminToken");
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    useEffect(() => {
        const fetchAccountSizeDetails = async () => {
            try {
                const response = await axios.get(`${API_URL}/account-size/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setAccountSize(response.data.data);
            } catch (err) {
                setError(err.response?.data?.message || "Failed to fetch account size details");
            } finally {
                setLoading(false);
            }
        };

        if (id) {
            fetchAccountSizeDetails();
        }
    }, [id, token]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    if (!accountSize) return <div>No data available</div>;

    // const [currentPage] = useState(1);
    // const itemsPerPage = 10;

    // Calculate total pages
    // const totalPages = Math.ceil(tableData.length / itemsPerPage);

    // Get current page data
    // const currentData = tableData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);


    return (
        <>
            <Helmet>
                <title>Admin | View Account Size Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/account-size">Account Size</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Details</div>
                            </div>
                        </div>
                        <div className='container-fluid'>
                            {/* -----------Details-------------------- */}
                            <div className='row mt-3'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <div>Account Size Details</div>
                                        </div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer overflow-x-auto" id="challenge-requests-table">
                                                        <tbody>
                                                            <tr>
                                                                <td className="table-head"><strong>Name:</strong></td>
                                                                <td>{accountSize.name}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Type:</strong></td>
                                                                <td>{accountSize.account_type_id?.name || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Size:</strong></td>
                                                                <td>{accountSize.account_type_id?.step || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Limit:</strong></td>
                                                                <td>{accountSize.limit}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Minimum Trade Days:</strong></td>
                                                                <td>{accountSize.min_trade_days}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Profit Target:</strong></td>
                                                                <td>{accountSize.profit_target}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Maximum Overall Loss:</strong></td>
                                                                <td>{accountSize.max_overall_loss}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Maximum Daily Loss:</strong></td>
                                                                <td>{accountSize.max_daily_loss}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Price:</strong></td>
                                                                <td>{accountSize.price}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* ------------------------------------------------------------------------------ */}
                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    )
}

export default AccountSizeDetails
