import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
// import Demo from '../../../assets/img/demo.png';
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import axios from 'axios';
import API_URL from "../../../config/config";


function TradesDetails() {


    const { id } = useParams();
    const [userDetails, setUserDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const token = localStorage.getItem("adminToken");
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const response = await axios.get(`${API_URL}/trades/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                if (!response.data || !response.data.data) {
                    throw new Error("Invalid API response");
                }
                setUserDetails(response.data.data);
            } catch (err) {
                console.error("Error fetching user details:", err);
                setError(err.response?.data?.message || "Failed to fetch user details");
            } finally {
                setLoading(false);
            }
        };
        fetchUserDetails();
    }, [id, token]);



    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;

    if (!userDetails) {
        return <div>No data available</div>;
    }

    // // Calculate total pages
    // // const totalPages = Math.ceil(tableData.length / itemsPerPage);

    // // Get current page data
    // const currentData = tableData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    return (
        <>
            <Helmet>
                <title>Admin | View Trade Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/trades">Trades</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Details</div>
                            </div>
                        </div>
                        <div className='container-fluid'>


                            <div className='row mt-3'>
                                {/* -----------Details-------------------- */}
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <div>Details</div>
                                        </div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer overflow-x-auto" id="challenge-requests-table">

                                                        <tbody>
                                                            {userDetails ? (
                                                                <>
                                                                    <tr>
                                                                        <td><strong>Account Number:</strong></td>
                                                                        <td>{userDetails.user_wallet?.account_number || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>User Name:</strong></td>
                                                                        <td>{userDetails.user?.name || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Lots:</strong></td>
                                                                        <td>{userDetails.lots || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Trade ID:</strong></td>
                                                                        <td>{userDetails.trade_id || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Open Price:</strong></td>
                                                                        <td>{userDetails.open_price || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Close Price:</strong></td>
                                                                        <td>{userDetails.close_price || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Profit:</strong></td>
                                                                        <td>{userDetails.profit ?? 0}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Loss:</strong></td>
                                                                        <td>{userDetails.loss ?? 0}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Side:</strong></td>
                                                                        <td>{userDetails.side || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Reversal:</strong></td>
                                                                        <td>{userDetails.reversal || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Open Date:</strong></td>
                                                                        <td>{new Date(userDetails.open_date).toISOString().replace('T', ' ').split('.')[0]}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Close Date:</strong></td>
                                                                        <td>{new Date(userDetails.close_date).toISOString().replace('T', ' ').split('.')[0]}</td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td><strong>Position Id:</strong></td>
                                                                        <td>{userDetails.position_id || "-"}</td>

                                                                    </tr>

                                                                    <tr>
                                                                        <td><strong>Deal Id:</strong></td>
                                                                        <td>{userDetails.deal_id || "-"}</td>
                                                                    </tr>
                                                                </>
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="2" style={{ textAlign: "center", padding: "10px" }}>
                                                                        No data available
                                                                    </td>
                                                                </tr>
                                                            )}
                                                        </tbody>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* ------------------------------------------------------------------------------ */}

                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>

    )
}

export default TradesDetails
