import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { useParams, useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import useToggleSidebar from "../../../components/togglesidebar";
import Sidebar from "../../sidebar";
import Header from "../../Header";
import Footer from "../../footer";
import axios from "axios";
import API_URL from "../../../config/config";

function EditPromoCode() {
    const navigate = useNavigate();
    const { id } = useParams(); // Get promo code ID from URL params
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const token = localStorage.getItem("adminToken");

    const [formData, setFormData] = useState({
        name: "",
        type: "",
        code: "",
        discount_in_rupees: "",
        discount_in_pr: "",
        starting_date: "",
        ending_date: "",
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Fetch existing promo code details
    useEffect(() => {
        const fetchPromoCode = async () => {
            try {
                const response = await axios.get(`${API_URL}/promo-code/edit/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setFormData(response.data.data);
            } catch (err) {
                console.error("Error fetching promo code:", err);
                setError("Failed to fetch promo code.");
            }
        };
        fetchPromoCode();
    }, [id, token]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        // Validation
        if (!formData.name || !formData.type || !formData.code || !formData.starting_date || !formData.ending_date) {
            alert("Please fill all required fields.");
            setLoading(false);
            return;
        }

        try {
            const response = await axios.patch(
                `${API_URL}/promo-code/update/${id}`,
                formData,
                { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
            );

            alert(response.data.message || "Promo Code Updated Successfully!");
            navigate("/admin/promo-code");
        } catch (error) {
            console.error("Error:", error);
            alert("Failed to update promo code. " + (error.response?.data?.message || ""));
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Helmet>
                <title>Admin | Edit Promo Code</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className="content">
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/promo-code">Promo Code</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Edit Promo Code</div>
                            </div>
                        </div>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card">
                                        <div className="card-header">Edit Promo Code Details</div>
                                        <div className="card-body">
                                            {error && <p className="text-danger">{error}</p>}
                                            <form onSubmit={handleSubmit}>
                                                <div className="row">
                                                    <div className="form-group col-6">
                                                        <label htmlFor="name">Name</label>
                                                        <input type="text" className="form-control" id="name" name="name" value={formData.name} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="type">Type</label>
                                                        <input className="form-control" id="type" name="type" value={formData.type} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="code">Code</label>
                                                        <input className="form-control" id="code" name="code" value={formData.code} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="discount_in_rupees">Discount In $</label>
                                                        <input className="form-control" id="discount_in_rupees" name="discount_in_rupees" value={formData.discount_in_rupees} onChange={handleChange} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="discount_in_pr">Discount In %</label>
                                                        <input className="form-control" id="discount_in_pr" name="discount_in_pr" value={formData.discount_in_pr} onChange={handleChange} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="starting_date">Start Date</label>
                                                        <input type="datetime-local" className="form-control" id="starting_date" name="starting_date" value={formData.starting_date} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="ending_date">End Date</label>
                                                        <input type="datetime-local" className="form-control" id="ending_date" name="ending_date" value={formData.ending_date} onChange={handleChange} required />
                                                    </div>
                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2" disabled={loading}>
                                                    {loading ? "Updating..." : "Update"}
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Footer />
                </div>
            </div>
        </>
    );
}

export default EditPromoCode;
