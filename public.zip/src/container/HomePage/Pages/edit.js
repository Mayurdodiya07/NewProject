// import React, { useState } from "react";
// import { Helmet } from "react-helmet";
// import { Link } from "react-router-dom";
// import useToggleSidebar from "../../../components/togglesidebar";

// import Sidebar from "../../sidebar";
// import Header from "../../Header";
// import Footer from "../../footer";

// function Edit() {
//   const [formData, setFormData] = useState({
//     first_name: "",
//     last_name: "",
//     email: "",
//     password: "",
//     phone_number: "",
//     country: "",
//     city: "",
//     status: "",
//   });

//   const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log("Submitting form data:", formData);
//     // Implement API call to update user details here
//   };

//   return (
//     <>
//       <Helmet>
//         <title>Admin | Edit User</title>
//       </Helmet>
//       <Sidebar isSidebarOpen={isSidebarOpen} />
//       <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
//         <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
//           <Header toggleSidebar={toggleSidebar} />
//           <div className="breadcrumb-main-bx">
//             <div className="breadcrumb-bx">
//               <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
//               <div className="breadcrumb-link breadcrumb-disabled">/</div>
//               <Link className="breadcrumb-link" to="/admin/user">User</Link>
//               <div className="breadcrumb-link breadcrumb-disabled">/</div>
//               <div className="breadcrumb-link breadcrumb-active">Edit User</div>
//             </div>
//           </div>
//           <section className="content">
//             <div className="container-fluid">
//               <div className="row">
//                 <div className="col-md-12">
//                   <div className="card">
//                     <div className="card-header">Edit User Details</div>
//                     <div className="card-body">
//                       <form onSubmit={handleSubmit}>
//                         <div className="row">
//                           <div className="form-group col-6">
//                             <label htmlFor="first_name">First Name</label>
//                             <input
//                               type="text"
//                               className="form-control"
//                               id="first_name"
//                               placeholder="Enter first name"
//                               name="first_name"
//                               value={formData.first_name}
//                               onChange={handleChange}
//                             />
//                           </div>
//                           <div className="form-group col-6">
//                             <label htmlFor="last_name">Last Name</label>
//                             <input
//                               type="text"
//                               className="form-control"
//                               id="last_name"
//                               placeholder="Enter last name"
//                               name="last_name"
//                               value={formData.last_name}
//                               onChange={handleChange}
//                             />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="email">Email address</label>
//                             <input
//                               type="email"
//                               className="form-control"
//                               id="email"
//                               placeholder="Enter email"
//                               name="email"
//                               value={formData.email}
//                               onChange={handleChange}
//                             />
//                           </div>
//                           <div className="form-group col-sm-6">
//                             <label htmlFor="password">Password</label>
//                             <input
//                               type="password"
//                               className="form-control"
//                               id="password"
//                               placeholder="Password"
//                               name="password"
//                               value={formData.password}
//                               onChange={handleChange}
//                             />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="phone">Phone</label>
//                             <input
//                               type="text"
//                               className="form-control"
//                               id="phone"
//                               placeholder="Enter phone number"
//                               name="phone_number"
//                               value={formData.phone_number}
//                               onChange={handleChange}
//                             />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="country">Country</label>
//                             <select
//                               className="form-control"
//                               id="country"
//                               name="country"
//                               value={formData.country}
//                               onChange={handleChange}
//                             >
//                               <option value="">Select Country</option>
//                               <option value="USA">USA</option>
//                               <option value="UK">UK</option>
//                               <option value="India">India</option>
//                             </select>
//                           </div>
//                           <div className="form-group col-sm-6">
//                             <label htmlFor="city">City</label>
//                             <input
//                               type="text"
//                               className="form-control"
//                               id="city"
//                               placeholder="Enter city"
//                               name="city"
//                               value={formData.city}
//                               onChange={handleChange}
//                             />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="status">Status</label>
//                             <select
//                               className="form-control"
//                               id="status"
//                               name="status"
//                               value={formData.status}
//                               onChange={handleChange}
//                             >
//                               <option value="">Select Status</option>
//                               <option value="Active">Active</option>
//                               <option value="Inactive">Inactive</option>
//                             </select>
//                           </div>
//                         </div>
//                         <button type="submit" className="common-submit-btn mt-2">
//                           Submit
//                         </button>
//                       </form>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </section>
//           <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
//             <Footer />
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default Edit;
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import useToggleSidebar from "../../../components/togglesidebar";
import axios from "axios";
import API_URL from "../../../config/config";

import Sidebar from "../../sidebar";
import Header from "../../Header";
import Footer from "../../footer";

function Edit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    phone_number: "",
    country: "",
    city: "",
    status: "",
  });
  const [countries, setCountries] = useState([]);
  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      setLoading(true);
      setError(null);

      try {
        const token = localStorage.getItem("adminToken");
        if (!token) {
          setError("Unauthorized: No token provided");
          setLoading(false);
          return;
        }

        const response = await axios.get(`${API_URL}/user/edit/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (response.data.success) {
          const userData = response.data.data.user || {};
          setFormData({
            first_name: userData.first_name || "",
            last_name: userData.last_name || "",
            email: userData.email || "",
            password: "", // Do not pre-fill password
            phone_number: userData.phone_number || "",
            country: userData.country || "",
            city: userData.city || "",
            status: userData.status || "Active",
          });
          setCountries(response.data.data.countries || []);
        } else {
          setError(response.data.message || "Failed to fetch user data");
        }
      } catch (error) {
        setError(error.response?.data?.message || "Server Error");
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [id]);

  // Handle form input changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem("adminToken");
      if (!token) {
        setError("Unauthorized: No token provided");
        setLoading(false);
        return;
      }

      // Remove empty password field before sending request
      const updatedData = { ...formData };
      if (!updatedData.password) delete updatedData.password;

      const response = await axios.patch(`${API_URL}/user/update/${id}`, updatedData, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.data.success) {
        alert("User updated successfully!");
        navigate("/admin/user");
      } else {
        setError(response.data.message || "Failed to update user");
      }
    } catch (error) {
      setError(error.response?.data?.message || "Server Error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Admin | Edit User</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div
        className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`}
        onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}
      >
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <div className="breadcrumb-main-bx">
            <div className="breadcrumb-bx">
              <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
              <div className="breadcrumb-link breadcrumb-disabled">/</div>
              <Link className="breadcrumb-link" to="/admin/user">User</Link>
              <div className="breadcrumb-link breadcrumb-disabled">/</div>
              <div className="breadcrumb-link breadcrumb-active">Edit User</div>
            </div>
          </div>
          <section className="content">
            <div className="container-fluid">
              <div className="row">
                <div className="col-md-12">
                  <div className="card">
                    <div className="card-header">Edit User Details</div>
                    <div className="card-body">
                      <form onSubmit={handleSubmit}>
                        <div className="row">
                          <div className="form-group col-6">
                            <label htmlFor="first_name">First Name</label>
                            <input
                              type="text"
                              className="form-control"
                              id="first_name"
                              name="first_name"
                              value={formData.first_name}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="form-group col-6">
                            <label htmlFor="last_name">Last Name</label>
                            <input
                              type="text"
                              className="form-control"
                              id="last_name"
                              name="last_name"
                              value={formData.last_name}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="form-group col-6">
                            <label htmlFor="email">Email</label>
                            <input
                              type="email"
                              className="form-control"
                              id="email"
                              name="email"
                              value={formData.email}
                              disabled
                            />
                          </div>
                          <div className="form-group col-6">
                            <label htmlFor="password">New Password</label>
                            <input
                              type="password"
                              className="form-control"
                              id="password"
                              name="password"
                              placeholder="Leave blank to keep unchanged"
                              onChange={handleChange}
                            />
                          </div>
                          <div className="form-group col-6">
                            <label htmlFor="phone_number">Phone</label>
                            <input
                              type="text"
                              className="form-control"
                              id="phone_number"
                              name="phone_number"
                              value={formData.phone_number}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="form-group col-6">
                            <label htmlFor="country">Country</label>
                            <select className="form-control" id="country" name="country" value={formData.country} onChange={handleChange}>
                              <option value="">Select Country</option>
                              {countries.map((country) => (
                                <option key={country._id} value={country.name}>{country.name}</option>
                              ))}
                            </select>
                          </div>
                          <div className="form-group col-6">
                            <label htmlFor="city">City</label>
                            <input
                              type="text"
                              className="form-control"
                              id="city"
                              name="city"
                              value={formData.city}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="form-group col-6">
                            <label htmlFor="status">Status</label>
                            <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange}>
                              <option value="Active">Active</option>
                              <option value="Inactive">Inactive</option>
                            </select>
                          </div>
                        </div>
                        <button type="submit" className="common-submit-btn mt-2">Update</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <Footer />
        </div>
      </div>
    </>
  );
}

export default Edit;
