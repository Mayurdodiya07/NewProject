import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import axios from "axios";
import API_URL from "../../../config/config";
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";

function UserAccountDetails() {

    const { id } = useParams();
    const [userDetails, setUserDetails] = useState(null);
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const token = localStorage.getItem("adminToken");

    useEffect(() => {
        if (!id) {
            setError("Invalid Challenge ID");
            setLoading(false);
            return;
        }

        const fetchUserDetails = async () => {
            try {
                const response = await axios.get(`${API_URL}/user/account/showaccount/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                if (!response.data) throw new Error("Empty response from server");

                setUserDetails(response.data.data); // Updated to match backend response format
            } catch (err) {
                console.error("Error fetching user details:", err);
                setError(err.response?.data?.message || "Failed to fetch user details");
            } finally {
                setLoading(false);
            }
        };

        fetchUserDetails();
    }, [id, token]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    if (!userDetails) return <div>No account data found</div>;

    return (
        <>
            <Helmet>
                <title>Admin | View Account Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/user">User</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Account Details</div>
                            </div>
                        </div>
                        <div className='container-fluid'>
                            <div className='row mt-3'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <div> Account Details</div>
                                        </div>
                                        <div className='card-body'>
                                            <div className='table-responsive'>
                                                <table className="table table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <td><strong>User Name:</strong></td>
                                                            <td>{userDetails.user_id?.first_name} {userDetails.user_id?.last_name}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Account:</strong></td>
                                                            <td>{userDetails.mt5_type || "-"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Account Number:</strong></td>
                                                            <td>{userDetails.account_number || "-"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Account Type:</strong></td>
                                                            <td>{userDetails?.account_size_id?.account_type_id?.name || "-"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Account Size:</strong></td>
                                                            <td>{userDetails?.account_size_id?.name || "-"}</td>
                                                        </tr>

                                                        <tr>
                                                            <td><strong>Balance:</strong></td>
                                                            <td>{userDetails.balance || "0"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Available Balance:</strong></td>
                                                            <td>{userDetails.available_balance || "0"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>On Hold Balance:</strong></td>
                                                            <td>{userDetails.on_hold_balance || "0"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Leverage:</strong></td>
                                                            <td>{userDetails.leverage || "-"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Equity:</strong></td>
                                                            <td>{userDetails.equity || "0"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Free Funds:</strong></td>
                                                            <td>{userDetails.free_funds || "0"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Credit:</strong></td>
                                                            <td>{userDetails.credit || "0"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Investor Password:</strong></td>
                                                            <td>{userDetails.investor_password || "-"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Master Password:</strong></td>
                                                            <td>{userDetails.master_password || "-"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>US Residence:</strong></td>
                                                            <td>{userDetails.not_us_residence ? "Yes" : "No"}</td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Account Status:</strong></td>
                                                            <td>{userDetails.account_status || "-"}</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0" }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    );
}

export default UserAccountDetails;
