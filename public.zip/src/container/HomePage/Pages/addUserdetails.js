

import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import useToggleSidebar from "../../../components/togglesidebar";
import axios from "axios";
import API_URL from "../../../config/config";

import Sidebar from "../../sidebar";
import Header from "../../Header";
import Footer from "../../footer";

function AddUserDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        first_name: "",
        last_name: "",
        email: "",
        password: "",
        phone_number: "",
        country: "",
        city: "",
        status: "Active",
    });
    const [validationErrors, setValidationErrors] = useState({});
    const [countries, setCountries] = useState([]);
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchCountries = async () => {
            setLoading(true);
            setError(null);

            try {
                const token = localStorage.getItem("adminToken");
                if (!token) {
                    setError("Unauthorized: No token provided");
                    setLoading(false);
                    return;
                }

                const response = await axios.get(`${API_URL}/user/add`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                if (response.data.success) {
                    setCountries(response.data.data.countries || []);
                } else {
                    setError(response.data.message || "Failed to fetch countries");
                }
            } catch (error) {
                setError(error.response?.data?.message || "Server Error");
            } finally {
                setLoading(false);
            }
        };

        fetchCountries();
    }, [id]);

    // Handle form input changes
    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            const token = localStorage.getItem("adminToken");
            if (!token) {
                setError("Unauthorized: No token provided");
                setLoading(false);
                return;
            }

            // Remove empty password field before sending request
            const addData = { ...formData };
            if (!addData.password) delete addData.password;

            const response = await axios.post(`${API_URL}/user/store`, addData, {
                headers: { Authorization: `Bearer ${token}` },
            });

            if (response.data.success) {
                alert("User added successfully!");
                navigate("/admin/user");
            } else {
                setError(response.data.message || "Failed to add user");
            }
        } catch (error) {
            setError(error.response?.data?.message || "Server Error");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Helmet>
                <title>Admin | Add User</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div
                className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`}
                onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}
            >
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <div className="breadcrumb-main-bx">
                        <div className="breadcrumb-bx">
                            <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                            <div className="breadcrumb-link breadcrumb-disabled">/</div>
                            <Link className="breadcrumb-link" to="/admin/user">User</Link>
                            <div className="breadcrumb-link breadcrumb-disabled">/</div>
                            <div className="breadcrumb-link breadcrumb-active">Add User</div>
                        </div>
                    </div>
                    <section className="content">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card">
                                        <div className="card-header">Add User Details</div>
                                        <div className="card-body">
                                            <form onSubmit={handleSubmit}>
                                                <div className="row">
                                                    <div className="form-group col-6">
                                                        <label htmlFor="first_name">First Name</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="first_name"
                                                            name="first_name"
                                                            placeholder="Enter first name"
                                                            value={formData.first_name}
                                                            onChange={handleChange}
                                                        />
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="last_name">Last Name</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="last_name"
                                                            name="last_name"
                                                            placeholder="Enter last name"
                                                            value={formData.last_name}
                                                            onChange={handleChange}
                                                        />
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="email">Email</label>
                                                        <input
                                                            type="email"
                                                            className="form-control"
                                                            id="email"
                                                            name="email"
                                                            placeholder="Enter email"
                                                            value={formData.email}
                                                            onChange={handleChange}
                                                        />
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="password">New Password</label>
                                                        <input
                                                            type="password"
                                                            className="form-control"
                                                            id="password"
                                                            name="password"
                                                            placeholder="Password"
                                                            onChange={handleChange}
                                                        />
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="phone_number">Phone</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="phone_number"
                                                            name="phone_number"
                                                            placeholder="Enter phone number "
                                                            value={formData.phone_number}
                                                            onChange={handleChange}
                                                        />
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="country">Country</label>
                                                        <select className="form-control" id="country" name="country" value={formData.country} onChange={handleChange}>
                                                            <option value="">Select Country</option>
                                                            {countries.map((country) => (
                                                                <option key={country._id} value={country.name}>{country.name}</option>
                                                            ))}
                                                        </select>
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="city">City</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="city"
                                                            name="city"
                                                            placeholder="Enter city"
                                                            value={formData.city}
                                                            onChange={handleChange}
                                                        />
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="status">Status</label>
                                                        <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange}>
                                                            <option value="Active">Active</option>
                                                            <option value="Inactive">Inactive</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Footer />
                </div>
            </div>
        </>
    );
}

export default AddUserDetails;

// validtion
// import React, { useState, useEffect } from "react";
// import { useParams, useNavigate } from "react-router-dom";
// import { Helmet } from "react-helmet";
// import { Link } from "react-router-dom";
// import useToggleSidebar from "../../../components/togglesidebar";
// import axios from "axios";
// import API_URL from "../../../config/config";

// import Sidebar from "../../sidebar";
// import Header from "../../Header";
// import Footer from "../../footer";

// function AddUserDetails() {
//     const { id } = useParams();
//     const navigate = useNavigate();
//     const [formData, setFormData] = useState({
//         first_name: "",
//         last_name: "",
//         email: "",
//         password: "",
//         phone_number: "",
//         country: "",
//         city: "",
//         status: "Active",
//     });
//     const [validationErrors, setValidationErrors] = useState({});
//     const [countries, setCountries] = useState([]);
//     const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
//     const [loading, setLoading] = useState(false);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         const fetchCountries = async () => {
//             setLoading(true);
//             setError(null);

//             try {
//                 const token = localStorage.getItem("adminToken");
//                 if (!token) {
//                     setError("Unauthorized: No token provided");
//                     setLoading(false);
//                     return;
//                 }

//                 const response = await axios.get(`${API_URL}/user/add`, {
//                     headers: { Authorization: `Bearer ${token}` },
//                 });

//                 if (response.data.success) {
//                     setCountries(response.data.data.countries || []);
//                 } else {
//                     setError(response.data.message || "Failed to fetch countries");
//                 }
//             } catch (error) {
//                 setError(error.response?.data?.message || "Server Error");
//             } finally {
//                 setLoading(false);
//             }
//         };

//         fetchCountries();
//     }, []);

//     // Function to validate form fields
//     const validateForm = () => {
//         let errors = {};

//         if (!formData.first_name.trim()) {
//             errors.first_name = "First name is required";
//         }
//         if (!formData.last_name.trim()) {
//             errors.last_name = "Last name is required";
//         }
//         if (!formData.email.trim()) {
//             errors.email = "Email is required";
//         } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
//             errors.email = "Invalid email format";
//         }
//         if (!id && !formData.password.trim()) {
//             errors.password = "Password is required";
//         } else if (formData.password && formData.password.length < 6) {
//             errors.password = "Password must be at least 6 characters";
//         }
//         if (!formData.phone_number.trim()) {
//             errors.phone_number = "Phone number is required";
//         }
//         if (!formData.country) {
//             errors.country = "Please select a country";
//         }
//         if (!formData.city.trim()) {
//             errors.city = "City is required";
//         }

//         setValidationErrors(errors);
//         return Object.keys(errors).length === 0;
//     };

//     // Handle input changes & clear validation errors
//     const handleChange = (e) => {
//         setFormData({ ...formData, [e.target.name]: e.target.value });
//         setValidationErrors({ ...validationErrors, [e.target.name]: "" });
//     };

//     // Handle form submission
//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         if (!validateForm()) return; // Stop if validation fails

//         setLoading(true);
//         setError(null);

//         try {
//             const token = localStorage.getItem("adminToken");
//             if (!token) {
//                 setError("Unauthorized: No token provided");
//                 setLoading(false);
//                 return;
//             }

//             // Remove empty password field before sending request
//             const addData = { ...formData };
//             if (!addData.password) delete addData.password;

//             const response = await axios.post(`${API_URL}/user/store`, addData, {
//                 headers: { Authorization: `Bearer ${token}` },
//             });

//             if (response.data.success) {
//                 alert("User added successfully!");
//                 navigate("/admin/user");
//             } else {
//                 setError(response.data.message || "Failed to add user");
//             }
//         } catch (error) {
//             setError(error.response?.data?.message || "Server Error");
//         } finally {
//             setLoading(false);
//         }
//     };

//     return (
//         <>
//             <Helmet>
//                 <title>Admin | Add User</title>
//             </Helmet>
//             <Sidebar isSidebarOpen={isSidebarOpen} />
//             <div
//                 className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`}
//                 onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}
//             >
//                 <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
//                     <Header toggleSidebar={toggleSidebar} />
//                     <div className="breadcrumb-main-bx">
//                         <div className="breadcrumb-bx">
//                             <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
//                             <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                             <Link className="breadcrumb-link" to="/admin/user">User</Link>
//                             <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                             <div className="breadcrumb-link breadcrumb-active">Add User</div>
//                         </div>
//                     </div>
//                     <section className="content">
//                         <div className="container-fluid">
//                             <div className="row">
//                                 <div className="col-md-12">
//                                     <div className="card">
//                                         <div className="card-header">Add User Details</div>
//                                         <div className="card-body">
//                                             <form onSubmit={handleSubmit}>
//                                                 <div className="row">
//                                                     {[
//                                                         { label: "First Name", name: "first_name" },
//                                                         { label: "Last Name", name: "last_name" },
//                                                         { label: "Email", name: "email", type: "email" },
//                                                         { label: "New Password", name: "password", type: "password" },
//                                                         { label: "Phone", name: "phone_number" },
//                                                         { label: "City", name: "city" }
//                                                     ].map(({ label, name, type = "text" }) => (
//                                                         <div className="form-group col-6" key={name}>
//                                                             <label htmlFor={name}>{label}</label>
//                                                             <input
//                                                                 type={type}
//                                                                 className="form-control"
//                                                                 id={name}
//                                                                 name={name}
//                                                                 placeholder={`Enter ${label.toLowerCase()}`}
//                                                                 value={formData[name]}
//                                                                 onChange={handleChange}
//                                                             />
//                                                             {validationErrors[name] && <span className="text-danger">{validationErrors[name]}</span>}
//                                                         </div>
//                                                     ))}
//                                                     <div className="form-group col-6">
//                                                         <label htmlFor="country">Country</label>
//                                                         <select className="form-control" id="country" name="country" value={formData.country} onChange={handleChange}>
//                                                             <option value="">Select Country</option>
//                                                             {countries.map((country) => (
//                                                                 <option key={country._id} value={country.name}>{country.name}</option>
//                                                             ))}
//                                                         </select>
//                                                         {validationErrors.country && <span className="text-danger">{validationErrors.country}</span>}
//                                                     </div>
//                                                     <div className="form-group col-6">
//                                                         <label htmlFor="status">Status</label>
//                                                         <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange}>
//                                                             <option value="Active">Active</option>
//                                                             <option value="Inactive">Inactive</option>
//                                                         </select>
//                                                     </div>
//                                                 </div>
//                                                 <button type="submit" className="common-submit-btn mt-2">Submit</button>
//                                             </form>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </section>
//                     <Footer />
//                 </div>
//             </div>
//         </>
//     );
// }

// export default AddUserDetails;


// hello md
