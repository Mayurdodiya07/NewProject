// import React, { useState } from "react";
// import { Helmet } from "react-helmet";
// import { Link } from 'react-router-dom';
// import useToggleSidebar from "../../../components/togglesidebar";
// import Demo from '../../../assets/img/demo.png';
// import Icons from "../../../components/icons";
// import Sidebar from '../../sidebar';
// import Header from '../../Header';
// import Footer from '../../footer';
// // import LightGallery from "lightgallery/react";
// import "lightgallery/css/lightgallery.css";
// import "lightgallery/css/lg-zoom.css";
// import "lightgallery/css/lg-fullscreen.css";
// import axios from "axios";
// import ImageUpload from "../../../components/imgupload";

// // Plugins
// import lgZoom from "lightgallery/plugins/zoom";
// import lgFullscreen from "lightgallery/plugins/fullscreen";


// function EditPaymentMethod() {

//   const [formData, setFormData] = useState({
//     name: "",
//     currency: "",
//     lower_limit: "",
//     upper_limit: "",
//     fee: "",
//     processing_time: "",
//     acc_name: "",
//     acc_number: "",
//     bank_name: "",
//     branch: "",
//     upi_id: "",
//     ifsc_code: "",
//     sequence: "",
//     deposit_address: "",
//     status: "",
//   });


//   const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log("Submitting form data:", formData);
//     // Implement API call to update user details here
//   };

//   const [currentPage] = useState(1);
//   const itemsPerPage = 10;

//   // Calculate total pages
//   // const totalPages = Math.ceil(tableData.length / itemsPerPage);
//   // const { isSidebarOpen, toggleSidebar } = useToggleSidebar();




//   return (
//     <>
//       <Helmet>
//         <title>Admin | add Payment Method</title>
//       </Helmet>
//       <Sidebar isSidebarOpen={isSidebarOpen} />
//       <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
//         <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
//           <Header toggleSidebar={toggleSidebar} />
//           <section className='content'>
//             <div className="breadcrumb-main-bx">
//               <div className="breadcrumb-bx">
//                 <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
//                 <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                 <Link className="breadcrumb-link" to="/admin/payment-methods">Payment Method</Link>
//                 <div className="breadcrumb-link breadcrumb-disabled">/</div>
//                 <div className="breadcrumb-link breadcrumb-active">Edit Payment Method</div>
//               </div>
//             </div>
//             <div className='container-fluid'>
//               <div className="row">
//                 <div className="col-md-12">
//                   <div className="card">
//                     <div className="card-header">Edit User Details</div>
//                     <div className="card-body">
//                       <form onSubmit={handleSubmit}>
//                         <div className="row">

//                           <div className="form-group col-6">
//                             <label htmlFor="name">Name</label>
//                             <input type="text" className="form-control" id="name" placeholder="Enter your name" name="name" value={formData.name} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="currency">Currency</label>
//                             <select className="form-control" id="currency" name="currency" value={formData.currency} onChange={handleChange}>
//                               <option value="">Select Currency</option>
//                               <option value="USA">ETH</option>
//                               <option value="UK">INR</option>
//                               <option value="UK">USD</option>
//                               <option value="India">USDT</option>
//                             </select>
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="lower_limit">Lower Limit</label>
//                             <input className="form-control" id="lower_limit" placeholder="Add Amount" name="lower_limit" value={formData.lower_limit} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="upper_limit">Upper Limit</label>
//                             <input className="form-control" id="upper_limit" placeholder="Add Amount" name="upper_limit" value={formData.upper_limit} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="fee">Fee</label>
//                             <input className="form-control" id="fee" placeholder="Add Fee" name="fee" value={formData.fee} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="processing_time">Processing Time</label>
//                             <input type="text" className="form-control" id="processing_time" placeholder="Enter Processing Time" name="processing_time" value={formData.processing_time} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="acc_name">Account Name</label>
//                             <input type="text" className="form-control" id="acc_name" placeholder="Enter Account Name" name="acc_name" value={formData.acc_name} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="acc_number">Account Number</label>
//                             <input type="text" className="form-control" id="acc_number" placeholder="Enter Account Number" name="acc_number" value={formData.acc_number} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="bank_name">Bank Name</label>
//                             <input type="text" className="form-control" id="bank_name" placeholder="Enter Bank Name" name="bank_name" value={formData.bank_name} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="branch">Branch</label>
//                             <input type="text" className="form-control" id="branch" placeholder="Enter Branch Name" name="branch" value={formData.branch} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="upi_id">UPI Id</label>
//                             <input type="text" className="form-control" id="upi_id" placeholder="Enter UPI Id" name="upi_id" value={formData.upi_id} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="ifsc_code">IFSC Code</label>
//                             <input type="text" className="form-control" id="ifsc_code" placeholder="Enter IFSC Code" name="ifsc_code" value={formData.ifsc_code} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="sequence">Sequence</label>
//                             <input type="text" className="form-control" id="sequence" placeholder="Enter Sequence" name="sequence" value={formData.sequence} onChange={handleChange} />
//                           </div>

//                           <div className="form-group col-sm-6">
//                             <label htmlFor="deposit_address">Deposit Address</label>
//                             <input type="text" className="form-control" id="deposit_address" placeholder="Enter Deposit Address" name="deposit_address" value={formData.deposit_address} onChange={handleChange} />
//                           </div>

//                           <ImageUpload />
//                           <ImageUpload />



//                           <div className="form-group col-sm-6">
//                             <label htmlFor="status">Status</label>
//                             <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange}>
//                               <option value="">Select Status</option>
//                               <option value="Active">Active</option>
//                               <option value="Inactive">Inactive</option>
//                             </select>
//                           </div>

//                         </div>
//                         <button type="submit" className="common-submit-btn mt-2">
//                           Submit
//                         </button>
//                       </form>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>



//           </section>
//           <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
//             <Footer />
//           </div>
//         </div>
//       </div>
//     </>
//   )
// }

// export default EditPaymentMethod

import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
import Demo from '../../../assets/img/demo.png';
import Icons from "../../../components/icons";
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
// import LightGallery from "lightgallery/react";
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";
import axios from "axios";
import ImageUpload from "../../../components/imgupload";
import API_URL from "../../../config/config";


function AddPaymentMethod() {
  const { id } = useParams();
  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
  const [formData, setFormData] = useState({
    name: "",
    currency: "",
    lower_limit: "",
    upper_limit: "",
    fee: "",
    processing_time: "",
    acc_name: "",
    acc_number: "",
    bank_name: "",
    branch: "",
    upi_id: "",
    ifsc_code: "",
    sequence: "",
    deposit_address: "",
    status: "",
  });

  const [currencies, setCurrencies] = useState([]);

  // Fetch available currencies
  useEffect(() => {
    const fetchPaymentMethod = async () => {
      const token = localStorage.getItem("adminToken");

      if (!token) return;
      try {
        const response = await axios.get(`${API_URL}/payment-methods/add`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCurrencies(response.data.currencies || []);
      } catch (error) {
        console.error("Error fetching payment methods:", error.response?.data || error);
      }
    };

    fetchPaymentMethod();
  }, [id]);

  // Handle Input Changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle Form Submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("adminToken");

    if (!token) {
      alert("Unauthorized access! Please log in again.");
      return;
    }

    try {
      await axios.post(`${API_URL}/payment-methods/store`, formData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      alert("Payment Method added successfully!");
    } catch (error) {
      console.error("Error updating payment method:", error.response?.data || error);
      alert(error.response?.data?.message || "Failed to add payment method. Please try again.");
    }
  };

  return (
    <>
      <Helmet>
        <title>Admin | add Payment Method</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <Link className="breadcrumb-link" to="/admin/payment-methods">Payment Method</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Add Payment Method</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className="row">
                <div className="col-md-12">
                  <div className="card">
                    <div className="card-header">Edit User Details</div>
                    <div className="card-body">
                      <form onSubmit={handleSubmit}>
                        <div className="row">

                          <div className="form-group col-6">
                            <label htmlFor="name">Name</label>
                            <input type="text" className="form-control" id="name" placeholder="Enter your name" name="name" value={formData.name} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="currency">Currency</label>
                            <select className="form-control" id="currency" name="currency" value={formData.currency} onChange={handleChange}>
                              <option value="">Select Currency</option>
                              <option value="USA">ETH</option>
                              <option value="UK">INR</option>
                              <option value="UK">USD</option>
                              <option value="India">USDT</option>
                            </select>
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="lower_limit">Lower Limit</label>
                            <input className="form-control" id="lower_limit" placeholder="Add Amount" name="lower_limit" value={formData.lower_limit} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="upper_limit">Upper Limit</label>
                            <input className="form-control" id="upper_limit" placeholder="Add Amount" name="upper_limit" value={formData.upper_limit} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="fee">Fee</label>
                            <input className="form-control" id="fee" placeholder="Add Fee" name="fee" value={formData.fee} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="processing_time">Processing Time</label>
                            <input type="text" className="form-control" id="processing_time" placeholder="Enter Processing Time" name="processing_time" value={formData.processing_time} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="acc_name">Account Name</label>
                            <input type="text" className="form-control" id="acc_name" placeholder="Enter Account Name" name="acc_name" value={formData.acc_name} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="acc_number">Account Number</label>
                            <input type="text" className="form-control" id="acc_number" placeholder="Enter Account Number" name="acc_number" value={formData.acc_number} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="bank_name">Bank Name</label>
                            <input type="text" className="form-control" id="bank_name" placeholder="Enter Bank Name" name="bank_name" value={formData.bank_name} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="branch">Branch</label>
                            <input type="text" className="form-control" id="branch" placeholder="Enter Branch Name" name="branch" value={formData.branch} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="upi_id">UPI Id</label>
                            <input type="text" className="form-control" id="upi_id" placeholder="Enter UPI Id" name="upi_id" value={formData.upi_id} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="ifsc_code">IFSC Code</label>
                            <input type="text" className="form-control" id="ifsc_code" placeholder="Enter IFSC Code" name="ifsc_code" value={formData.ifsc_code} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="sequence">Sequence</label>
                            <input type="text" className="form-control" id="sequence" placeholder="Enter Sequence" name="sequence" value={formData.sequence} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="deposit_address">Deposit Address</label>
                            <input type="text" className="form-control" id="deposit_address" placeholder="Enter Deposit Address" name="deposit_address" value={formData.deposit_address} onChange={handleChange} />
                          </div>

                          {/* <ImageUpload />
                          <ImageUpload /> */}
                          <ImageUpload label="Payment Method Image" existingImage="https://example.com/path/to/payment-method-image.png" />
                          <ImageUpload label="QR Code Image" existingImage="https://example.com/path/to/qr-code-image.png" />


                          <div className="form-group col-sm-6">
                            <label htmlFor="status">Status</label>
                            <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange}>
                              <option value="">Select Status</option>
                              <option value="Active">Active</option>
                              <option value="Inactive">Inactive</option>
                            </select>
                          </div>

                        </div>
                        <button type="submit" className="common-submit-btn mt-2">
                          Submit
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
            <Footer />
          </div>
        </div>
      </div>
    </>
  )
}


export default AddPaymentMethod;
