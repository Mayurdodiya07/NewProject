import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
import Demo from '../../../assets/img/demo.png';
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import ShowPassedAccountModal from "../../../components/Modal/showPassedAccountModal";
import LightGallery from "lightgallery/react";
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";
import axios from 'axios';
import API_URL from "../../../config/config";
// Plugins
import lgZoom from "lightgallery/plugins/zoom";
import lgFullscreen from "lightgallery/plugins/fullscreen";

export default function PassedChallengeRequests() {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const { id } = useParams();
    const [userDetails, setUserDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const token = localStorage.getItem("adminToken");
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const response = await axios.get(`${API_URL}/passed-challenge-requests/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUserDetails(response.data);
            } catch (err) {
                setError(err.response?.data?.message || "Failed to fetch challenge request details");
            } finally {
                setLoading(false);
            }
        };

        if (id) fetchUserDetails();
    }, [id, token]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    if (!userDetails) return <div>No data available</div>;

    // const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    // const [currentPage] = useState(1);
    // const itemsPerPage = 10;

    // Calculate total pages
    // const totalPages = Math.ceil(tableData.length / itemsPerPage);

    // Get current page data
    // const currentData = tableData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    return (
        <>
            <Helmet>
                <title>Admin | View Request Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/passed-challenge-requests">Passed Challenge Requests</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Details</div>
                            </div>
                        </div>
                        <div className='container-fluid'>

                            <div className="row justify-content-end mb-3">
                                <button
                                    type="button"
                                    onClick={() => setIsModalOpen(true)}
                                    className="common-btn-item cbi-fill">
                                    <span>Action on this account</span>
                                </button>
                                {isModalOpen && <ShowPassedAccountModal onClose={() => setIsModalOpen(false)} />}
                            </div>


                            <div class="row dashboard-link-row mb-4">
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <a href="javascript::void(0);" class="dashboard-link-item">
                                        <div class="dli-label">30% of total profit</div>
                                        <div class="dli-data">$75.843</div>
                                    </a>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            Trade list in which a single trade contributes more than 30% of the&nbsp;total&nbsp;profit.
                                        </div>
                                        <div class="card-body"></div>
                                    </div>
                                </div>
                            </div>

                            {/* -----------Details-------------------- */}
                            <div className='row mt-3'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <div>Details</div>
                                        </div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer overflow-x-auto" id="challenge-requests-table">
                                                        {/* <tbody>
                                                            {userDetails.length > 0 ? (
                                                                userDetails.map((userDetails) => (
                                                                    <>
                                                                        <tr key={userDetails.id}>
                                                                            <td><strong>User Name:</strong></td>
                                                                            <td>{userDetails.passedAccountRequest?.user?.name}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Email:</strong></td>
                                                                            <td>{userDetails.email}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Challenge For:</strong></td>
                                                                            <td>{userDetails.challengeFor}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Requested Date:</strong></td>
                                                                            <td>{userDetails.requestedDate}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Account Number:</strong></td>
                                                                            <td>{userDetails.accountNumber}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Balance:</strong></td>
                                                                            <td>{userDetails.balance}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Available Balance:</strong></td>
                                                                            <td>{userDetails.availableBalance}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Equity:</strong></td>
                                                                            <td>{userDetails.equity}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><strong>Account status:</strong></td>
                                                                            <td>{userDetails.accountStatus}</td>
                                                                        </tr>
                                                                    </>
                                                                ))
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="2" style={{ textAlign: "center", padding: "10px" }}>
                                                                        No data available in table
                                                                    </td>
                                                                </tr>
                                                            )}
                                                        </tbody> */}
                                                        <tbody>
                                                            {userDetails ? (
                                                                <>
                                                                    <tr>
                                                                        <td><strong>User Name:</strong></td>
                                                                        <td>{userDetails.passedAccountRequest?.user?.name}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Email:</strong></td>
                                                                        <td>{userDetails.email}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Challenge For:</strong></td>
                                                                        <td>{userDetails.challengeFor}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Requested Date:</strong></td>
                                                                        <td>{userDetails.requestedDate}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Account Number:</strong></td>
                                                                        <td>{userDetails.accountNumber}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Balance:</strong></td>
                                                                        <td>{userDetails.balance}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Available Balance:</strong></td>
                                                                        <td>{userDetails.availableBalance}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Equity:</strong></td>
                                                                        <td>{userDetails.equity}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Account status:</strong></td>
                                                                        <td>{userDetails.accountStatus}</td>
                                                                    </tr>
                                                                </>
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="2" style={{ textAlign: "center", padding: "10px" }}>
                                                                        No data available in table
                                                                    </td>
                                                                </tr>
                                                            )}
                                                        </tbody>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* ------------------------------------------------------------------------------ */}
                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    )
}
