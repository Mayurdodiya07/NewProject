import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useNavigate } from "react-router-dom";
import useToggleSidebar from "../../../components/togglesidebar";
import Sidebar from "../../sidebar";
import Header from "../../Header";
import Footer from "../../footer";
import axios from "axios";
import API_URL from "../../../config/config";

function AddNewsCurrencies() {
    const [formData, setFormData] = useState({
        name: "",
        code: "",
        short_code: "",
        status: "",
    });
    const [dropdownData, setDropdownData] = useState([]);
    const [loading, setLoading] = useState(false);  // Track loading state
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const navigate = useNavigate();

    // Fetch data for dropdown (if necessary)
    useEffect(() => {
        const token = localStorage.getItem("adminToken");
        if (!token) {
            navigate("/admin/login");
        } else {
            const fetchData = async () => {
                try {
                    const response = await axios.get(`${API_URL}/news-currencies/add`, {
                        headers: {
                            "Authorization": `Bearer ${token}`,
                        },
                    });
                    setDropdownData(response.data);
                } catch (error) {
                    console.error("Error fetching data:", error);
                    // Handle error if needed
                }
            };

            fetchData();
        }
    }, [navigate]);  // The dependency array makes sure it runs only once when the component mounts

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        console.log("Form Data:", formData); // Debugging: Check what is actually being sent

        // Validate fields
        if (!formData.name.trim() || !formData.code.trim() || !formData.short_code.trim() || !formData.status.trim()) {
            alert("Please fill all fields.");
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post(`${API_URL}/news-currencies/store`, formData, {
                headers: {
                    "Authorization": `Bearer ${localStorage.getItem("adminToken")}`,
                },
            });

            if (response.status === 201) {
                alert("News Currency added successfully!");
                setFormData({ name: "", code: "", short_code: "", status: "" });
                navigate("/admin/news-currencies");
            }
        } catch (error) {
            console.error("Error submitting form:", error);
            alert("Error: " + (error.response?.data?.message || "Something went wrong"));
        } finally {
            setLoading(false);
        }
    };


    return (
        <>
            <Helmet>
                <title>Admin | Add News Currency Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <div className="breadcrumb-main-bx">
                        <div className="breadcrumb-bx">
                            <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                            <div className="breadcrumb-link breadcrumb-disabled">/</div>
                            <Link className="breadcrumb-link" to="/admin/news-currencies">News Currency</Link>
                            <div className="breadcrumb-link breadcrumb-disabled">/</div>
                            <div className="breadcrumb-link breadcrumb-active">Add News Currency</div>
                        </div>
                    </div>
                    <section className="content">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card">
                                        <div className="card-header">Add News Currency</div>
                                        <div className="card-body">
                                            <form onSubmit={handleSubmit}>
                                                <div className="row">
                                                    <div className="form-group col-6">
                                                        <label htmlFor="currency_name">Currency Name</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="currency_name"
                                                            placeholder="Enter Currency Name"
                                                            name="name"
                                                            value={formData.name}
                                                            onChange={handleChange}
                                                        />
                                                    </div>
                                                    <div className="form-group col-6">
                                                        <label htmlFor="last_name">Code</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="code"
                                                            placeholder="Enter Code"
                                                            name="code"
                                                            value={formData.code}
                                                            onChange={handleChange}
                                                        />
                                                    </div>

                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="short_code">Short Code</label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="short_code"
                                                            placeholder="Enter Short Code"
                                                            name="short_code"
                                                            value={formData.short_code}
                                                            onChange={handleChange}
                                                        />
                                                    </div>

                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="status">Status</label>
                                                        <select
                                                            className="form-control"
                                                            id="status"
                                                            name="status" // Updated to 'status'
                                                            value={formData.status} // Updated to use 'status'
                                                            onChange={handleChange}
                                                        >
                                                            <option value="">Select Status</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Inactive">Inactive</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2">
                                                    Submit
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div className="ref-ft" style={{ marginLeft: isSidebarOpen ? "250px" : "0", }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddNewsCurrencies
