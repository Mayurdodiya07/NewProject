import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
import Demo from '../../../assets/img/demo.png';
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
// import Icons from "../../../components/icons";
import LightGallery from "lightgallery/react";
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";
import axios from 'axios';
import API_URL from "../../../config/config";
// Plugins
import lgZoom from "lightgallery/plugins/zoom";
import lgFullscreen from "lightgallery/plugins/fullscreen";



function ChallengeRequestDetails() {
    const { id } = useParams();
    const [userDetails, setUserDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [status, setStatus] = useState("pending");
    // const [comment, setComment] = useState("");

    const token = localStorage.getItem("adminToken");
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const response = await axios.get(`${API_URL}/challenge-requests/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUserDetails(response.data.data);
                setStatus(response.data.data.account_status);
            } catch (err) {
                setError(err.response?.data?.message || "Failed to fetch challenge request details");
            } finally {
                setLoading(false);
            }
        };

        if (id) {
            fetchUserDetails();
        }
    }, [id, token]);

    const updateStatus = async (newStatus) => {
        try {
            const response = await axios.put(
                `${API_URL}/challenge-requests/approve/${id}`,
                { status: newStatus },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            if (response.data.success) {
                alert("Status updated successfully!");
                setUserDetails((prev) => ({ ...prev, account_status: newStatus }));
            } else {
                alert("Failed to update status.");
            }
        } catch (error) {
            alert(error.response?.data?.message || "Error updating status");
        }
    };


    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    if (!userDetails) return <div>No data available</div>;
    // const [currentPage] = useState(1);
    // const itemsPerPage = 10;

    // Calculate total pages
    // const totalPages = Math.ceil(tableData.length / itemsPerPage);

    // Get current page data
    // const currentData = tableData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    return (
        <>
            <Helmet>
                <title> Admin | View Request Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/challenge-requests">Challenge Requests</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Details</div>
                            </div>
                        </div>
                        <div className='container-fluid'>

                            {/* -----------Details-------------------- */}
                            <div className='row mt-3'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <div>Challenge Request Details</div>
                                        </div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer overflow-x-auto" id="challenge-requests-table">

                                                        <tbody>
                                                            <tr>
                                                                <td><strong>User Name:</strong></td>
                                                                <td>{userDetails.user_id?.first_name} {userDetails.user_id?.last_name}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>E-mail :</strong></td>
                                                                <td>{userDetails.user_id?.email}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Challenge For:</strong></td>
                                                                <td>{`${userDetails.account_size_id.name} ${userDetails.account_size_id.account_type_id.step} ${userDetails.account_size_id.account_type_id.name} Account`}</td>
                                                            </tr>

                                                            <tr>
                                                                <td><strong>Requested Date:</strong></td>
                                                                <td>{new Date(userDetails.created_at).toISOString().split('T')[0].split('-').reverse().join('-')}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Street:</strong></td>
                                                                <td>{userDetails.street}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>City:</strong></td>
                                                                <td>{userDetails.city}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Country:</strong></td>
                                                                <td>{userDetails.country_name || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Pincode:</strong></td>
                                                                <td>{userDetails.postal_code}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Type:</strong></td>
                                                                <td>{userDetails.account_type_id?.name}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Step:</strong></td>
                                                                <td>{userDetails.account_type_id?.step}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Size:</strong></td>
                                                                <td>{userDetails.account_size_id?.name}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Payment Method:</strong></td>
                                                                <td>{userDetails.payment_method_id?.name || "-"}</td>
                                                            </tr>

                                                            <tr>
                                                                <td><strong>Promo Code:</strong></td>
                                                                <td>{userDetails.accountNumber}</td>
                                                            </tr>

                                                            <tr>
                                                                <td><strong>Price:</strong></td>
                                                                {/* <td>${userDetails.amount ? userDetails.amount.toFixed(2) : "0.00"}</td> */}
                                                                <td>${userDetails.amount ? userDetails.amount : "0.00"}</td>

                                                            </tr>
                                                            <tr>
                                                                <td><strong>UTR Id:</strong></td>
                                                                <td>{userDetails.transaction_id}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* ------------------------------------------------------------------------------ */}

                                {/* -------------------------Transaction-Screenshot------------------------------------ */}
                                <div className="col-md-12 mt-3">
                                    <div className="card">
                                        <div className="card-header">Transaction Screenshot</div>
                                        <div className="card-body">
                                            <div className="row" id="lightgallery">
                                                <LightGallery speed={500} plugins={[lgZoom, lgFullscreen]}>
                                                    <a className="d-block col-lg-4 col-sm-6 zoom-img-item" href={Demo}>
                                                        <div className="upload-document-item">
                                                            <div className="udi-img-bx">
                                                                <img src={Demo} alt="Transaction Screenshot" />
                                                            </div>
                                                            <div className="udi-icon-bx">
                                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607ZM10.5 7.5v6m3-3h-6"></path></svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </LightGallery>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* -------------------------------------------------------------------- */} {/* --------------------------Status--------------------------------------- */}

                                <div className="col-md-12 mt-3">
                                    <div className="card">
                                        <div className="card-header">Status</div>
                                        <div className="card-body">
                                            <div className="common-status-field custom-field form-group"
                                                style={{ display: "flex", gap: "10px", alignItems: "center", margin: "0px", fontSize: "14px" }}>
                                                <label htmlFor="status">Change Status:</label>
                                                <select
                                                    style={{ width: "fit-content" }}
                                                    name="status"
                                                    id="status"
                                                    className="select-control"
                                                    value={userDetails.account_status}
                                                    onChange={(e) => updateStatus(e.target.value)}
                                                >
                                                    <option value="pending">Pending</option>
                                                    <option value="rejected">Reject</option>
                                                    <option value="approved">Approve</option>
                                                </select>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    )
}
export default ChallengeRequestDetails
