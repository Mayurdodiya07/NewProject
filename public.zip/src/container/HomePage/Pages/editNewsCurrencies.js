import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
import Demo from '../../../assets/img/demo.png';
import Icons from "../../../components/icons";
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import API_URL from "../../../config/config";


function EditNewsCurrencies() {
  const { id } = useParams();  // Get the currency ID from the URL
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    short_code: "",
    status: "",
  });
  const [loading, setLoading] = useState(false);
  const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

  // Fetch the existing currency data when the component mounts
  useEffect(() => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      navigate("/admin/login");
      return;
    }

    const fetchCurrencyData = async () => {
      try {
        const response = await axios.get(`${API_URL}/news-currencies/edit/${id}`, {
          headers: {
            "Authorization": `Bearer ${token}`,
          },
        });

        // Populate the form with the existing data
        setFormData({
          name: response.data.name,
          code: response.data.code,
          short_code: response.data.short_code,
          status: response.data.status,
        });
      } catch (error) {
        console.error("Error fetching data:", error);
        alert("Error fetching currency data.");
      }
    };

    fetchCurrencyData();
  }, [id, navigate]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Submitting form data:", formData);

    if (!formData.name.trim() || !formData.code.trim() || !formData.short_code.trim() || !formData.status.trim()) {
      alert("Please fill all fields.");
      return;
    }

    setLoading(true);

    try {
      const response = await axios.patch(`${API_URL}/news-currencies/update/${id}`, formData, {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("adminToken")}`,
        },
      });

      if (response.status === 200) {
        alert("News Currency updated successfully!");
        navigate("/admin/news-currencies");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Error: " + (error.response?.data?.message || "Something went wrong"));
    } finally {
      setLoading(false);
    }
  };
  // Calculate total pages
  // const totalPages = Math.ceil(tableData.length / itemsPerPage);
  return (
    <>
      <Helmet>
        <title>Admin | Edit News Currency</title>
      </Helmet>
      <Sidebar isSidebarOpen={isSidebarOpen} />
      <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
        <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
          <Header toggleSidebar={toggleSidebar} />
          <section className='content'>
            <div className="breadcrumb-main-bx">
              <div className="breadcrumb-bx">
                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <Link className="breadcrumb-link" to="/admin/news-currencies">News Currency</Link>
                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                <div className="breadcrumb-link breadcrumb-active">Edit Payment Method</div>
              </div>
            </div>
            <div className='container-fluid'>
              <div className="row">
                <div className="col-md-12">
                  <div className="card">
                    <div className="card-header">Edit User Details</div>
                    <div className="card-body">
                      <form onSubmit={handleSubmit}>
                        <div className="row">

                          <div className="form-group col-6">
                            <label htmlFor="name">Name</label>
                            <input type="text" className="form-control" id="name" placeholder="Enter Currency Name" name="name" value={formData.name} onChange={handleChange} />
                          </div>
                          <div className="form-group col-sm-6">
                            <label htmlFor="code">Code</label>
                            <input className="form-control" id="code" placeholder="Enter Code" name="code" value={formData.code} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="short_code">Short Code</label>
                            <input className="form-control" id="short_code" placeholder="Enter Short Code" name="short_code" value={formData.short_code} onChange={handleChange} />
                          </div>

                          <div className="form-group col-sm-6">
                            <label htmlFor="status">Status</label>
                            <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange}>
                              <option value="">Select Status</option>
                              <option value="Active">Active</option>
                              <option value="Inactive">Inactive</option>
                            </select>
                          </div>
                        </div>
                        <button type="submit" className="common-submit-btn mt-2">
                          Submit
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
            <Footer />
          </div>
        </div>
      </div>
    </>
  )
}

export default EditNewsCurrencies