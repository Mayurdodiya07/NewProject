import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
// import Demo from '../../../assets/img/demo.png';
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import axios from 'axios';
import API_URL from '../../../config/config';
import moment from "moment";

function PayoutDetails() {
    const { id } = useParams();
    const [userDetails, setUserDetails] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const token = localStorage.getItem("adminToken");
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const response = await axios.get(`${API_URL}/payout/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUserDetails(response.data); // Ensure API returns an array
            } catch (err) {
                setError(err.response?.data?.message || "Failed to fetch payout details");
            } finally {
                setLoading(false);
            }
        };

        if (id) {
            fetchUserDetails();
        }
    }, [id, token]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    if (!userDetails || userDetails.length === 0) return <div>No data available</div>;

    // const [currentPage] = useState(1);
    // const itemsPerPage = 10;

    // Calculate total pages
    // const totalPages = Math.ceil(tableData.length / itemsPerPage);

    // Get current page data
    // const currentData = tableData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    return (
        <>
            <Helmet>
                <title>Admin | View Payout Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/payout">Payout</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Details</div>
                            </div>
                        </div>
                        <div className='container-fluid'>
                            {/* -----------Total Profit Box---------------------- */}
                            <div className="row dashboard-link-row mb-4">
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <a href="#" className="dashboard-link-item">
                                        <div className="dli-label">Total Profit</div>
                                        <div className="dli-data">${userDetails.totalProfit.toLocaleString()}</div>
                                    </a>
                                </div>
                                {/* -----------Total Paid Box---------------------- */}
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <a href="#" className="dashboard-link-item">
                                        <div className="dli-label">Total Paid</div>
                                        <div className="dli-data">${userDetails.totalPaid.toLocaleString()}</div>
                                    </a>
                                </div>
                                {/* -----------Remain Amount Box---------------------- */}
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <a href="#" className="dashboard-link-item">
                                        <div className="dli-label">Remain Amount</div>
                                        <div className="dli-data">${userDetails.remainAmount.toLocaleString()}</div>
                                    </a>
                                </div>
                            </div>

                            <div className='row mt-3'>
                                {/* -----------Details-------------------- */}
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <div>Details</div>
                                        </div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer overflow-x-auto" id="challenge-requests-table">

                                                        <tbody>
                                                            {userDetails && userDetails.accountRequest ? (
                                                                <>
                                                                    <tr>
                                                                        <td><strong>User Name:</strong></td>
                                                                        <td>{userDetails.accountRequest.user.first_name} {userDetails.accountRequest.user.last_name}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Email:</strong></td>
                                                                        <td>{userDetails.accountRequest.user.email}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Mt5 Account:</strong></td>
                                                                        <td>{userDetails.accountRequest.user_wallet_id.account_number || "-"}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Requested Date:</strong></td>
                                                                        {/* <td>{userDetails.accountRequest.created_at_formatted}</td> */}
                                                                        <td>{moment(userDetails.accountRequest.created_at).format("DD-MM-YYYY HH:mm")}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Payment Method:</strong></td>
                                                                        <td>{userDetails.accountRequest.paymentMethod.name}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><strong>Amount:</strong></td>
                                                                        <td>${userDetails.accountRequest.amount.toLocaleString()}</td>
                                                                    </tr>
                                                                </>
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="2" style={{ textAlign: "center", padding: "10px" }}>
                                                                        No data available in table
                                                                    </td>
                                                                </tr>
                                                            )}
                                                        </tbody>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* ------------------------------------------------------------------------------ */}
                                <div class="col-md-12 mt-3">
                                    <div class="card">
                                        <div class="card-header">USDT BEP20 Details</div>
                                        <div class="card-body">
                                            <table class="table table-bordered table-style-2">
                                                <tbody>
                                                    <tr>
                                                        <th>Wallet Address ID:</th>
                                                        <td>{userDetails.accountRequest?.payment_wallet_address_id || "-"}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>

    )
}

export default PayoutDetails
