import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { useParams, useNavigate } from "react-router-dom";
import { Link } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
import Demo from '../../../assets/img/demo.png';
import Icons from "../../../components/icons";
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import axios from "axios";
import API_URL from "../../../config/config";

function AddNews() {
    const navigate = useNavigate();
    const { id } = useParams(); // Extracts id from URL params
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const token = localStorage.getItem("adminToken");
    // const [countries, setCountries] = useState([]);
    const [Currencies, setCurrencies] = useState([]);

    const [formData, setFormData] = useState({
        event_type: "",
        currency: "",
        previous: "",
        actual: "",
        forecast: "",
        date: "",
        status: "",
        impact: "",
        description: "",
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${API_URL}/news/add`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                // Filter specific currencies only
                const allowedCurrencies = ["CHF", "INR", "CAD", "EUR", "USD"];
                const filtered = response.data.currencies
                    .filter(currency => allowedCurrencies.includes(currency.name))
                    .reduce((acc, current) => {
                        const exists = acc.find(item => item.name === current.name);
                        if (!exists) {
                            acc.push(current);
                        }
                        return acc;
                    }, []);

                setCurrencies(filtered);
            } catch (error) {
                console.error("Error fetching data:", error);
                setError(error.response?.data?.message || "Failed to fetch data");
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [id, token]);


    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        console.log("Submitting form data:", formData);


        if (!formData.currency) {
            alert("Please select a valid currency.");
            setLoading(false);
            return;
        }

        try {
            const response = await axios.post(`${API_URL}/news/store`, {
                ...formData,
                currency_id: formData.currency
            }, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": "application/json",
                },
            });

            alert(response.data.message);
            navigate("/admin/news");
        } catch (error) {
            console.error("Error:", error);
            alert("Failed to save news. " + (error.response?.data?.message || ""));
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    // Calculate total pages
    // const totalPages = Math.ceil(tableData.length / itemsPerPage);



    return (
        <>
            <Helmet>
                <title>Admin | Add News</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/news">News</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Add News</div>
                            </div>
                        </div>
                        <div className='container-fluid'>
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card">
                                        <div className="card-header">Add News Details</div>
                                        <div className="card-body">
                                            <form onSubmit={handleSubmit}>
                                                <div className="row">

                                                    <div className="form-group col-6">
                                                        <label htmlFor="event_type">Event Type</label>
                                                        <input type="text" className="form-control" id="event_type" placeholder="Enter Event Type" name="event_type" value={formData.event_type} onChange={handleChange} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="currency">Currency</label>
                                                        <select
                                                            className="form-control"
                                                            id="currency"
                                                            name="currency"
                                                            value={formData.currency}
                                                            onChange={handleChange}
                                                        >
                                                            <option value="">Select Currency</option>
                                                            {Currencies.map((currency) => (
                                                                <option key={currency.id} value={currency.id}>
                                                                    {currency.name}
                                                                </option>
                                                            ))}
                                                        </select>

                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="previous">Previous</label>
                                                        <input className="form-control" id="previous" placeholder="Enter Previous Percentage" name="previous" value={formData.previous} onChange={handleChange} />
                                                    </div>

                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="actual">Actual</label>
                                                        <input className="form-control" id="actual" placeholder="Enter Actual Percentage" name="actual" value={formData.actual} onChange={handleChange} />
                                                    </div>

                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="forecast">Forecast</label>
                                                        <input className="form-control" id="forecast" placeholder="Add Forecast" name="forecast" value={formData.forecast} onChange={handleChange} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="date">Date & Time</label>
                                                        <input type="datetime-local" className="form-control" id="date" name="date" value={formData.date} onChange={handleChange} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="status">Status</label>
                                                        <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange}>
                                                            <option value="">Select Status</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Inactive">Inactive</option>
                                                        </select>
                                                    </div>

                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="impact">Impact</label>
                                                        <select className="form-control" id="impact" name="impact" value={formData.impact} onChange={handleChange}>
                                                            <option value="">Select Impact</option>
                                                            <option value="High">High</option>
                                                            <option value="Medium">Medium</option>
                                                            <option value="Low">Low</option>
                                                            <option value="No Impact">No Impact</option>
                                                        </select>
                                                    </div>

                                                    <div className="form-group col-12">
                                                        <label htmlFor="description">Description</label>
                                                        <textarea className="form-control" id="description" placeholder="Enter Description" name="description" value={formData.description} onChange={handleChange} rows="3" />
                                                    </div>

                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2">
                                                    Submit
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
                        <Footer />
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddNews