import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import { useParams, useNavigate } from "react-router-dom";
import useToggleSidebar from "../../../components/togglesidebar";
// import Demo from '../../../assets/img/demo.png';
// import Icons from "../../../components/icons";
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
// import LightGallery from "lightgallery/react";
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";
import ImageUpload from "../../../components/imgupload";
import axios from "axios";
import API_URL from "../../../config/config";


function EditPaymentMethod() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const token = localStorage.getItem("adminToken");

    const [formData, setFormData] = useState({
        name: "",
        currency_id: "",
        lower_limit: "",
        upper_limit: "",
        fee: "",
        processing_time: "",
        acc_name: "",
        acc_number: "",
        bank_name: "",
        branch: "",
        upi_id: "",
        ifsc_code: "",
        sequence: "",
        deposit_address: "",
        status: "Active",
    });

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchPaymentMethod = async () => {
            try {
                const response = await axios.get(`${API_URL}/payment-methods/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                console.log("API Response:", response.data);

                setFormData((prevState) => ({
                    ...prevState,
                    ...response.data, // Spread API response directly
                    currency_id: response.data.currency_id || "",
                    status: response.data.status || "Active",
                }));
            } catch (error) {
                console.error("Error fetching payment method:", error);
                setError(error.response?.data?.message || "Failed to fetch payment method details");
            } finally {
                setLoading(false);
            }
        };

        if (id) fetchPaymentMethod();
    }, [id, token]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            await axios.patch(`${API_URL}/payment-methods/update/${id}`, formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": "application/json",
                },
            });

            alert("Payment Method updated successfully!");
            navigate("/admin/payment-methods");
        } catch (error) {
            console.error("Error updating payment method:", error);
            alert("Failed to update payment method.");
        }
    };

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    return (
        <>
            <Helmet>
                <title>Admin | Edit Payment Method</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className="content">
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/payment-methods">Payment Method</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Edit Payment Method</div>
                            </div>
                        </div>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="card">
                                        <div className="card-header">Edit Payment Method</div>
                                        <div className="card-body">
                                            <form onSubmit={handleSubmit}>
                                                <div className="row">
                                                    <div className="form-group col-6">
                                                        <label htmlFor="name">Name</label>
                                                        <input type="text" className="form-control" id="name" name="name" value={formData.name} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="currency_id">Currency</label>
                                                        <select className="form-control" id="currency_id" name="currency_id" value={formData.currency_id} onChange={handleChange} required>
                                                            <option value="">Select Currency</option>
                                                            <option value="ETH">ETH</option>
                                                            <option value="INR">INR</option>
                                                            <option value="USD">USD</option>
                                                            <option value="USDT">USDT</option>
                                                        </select>
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="lower_limit">Lower Limit</label>
                                                        <input type="number" className="form-control" id="lower_limit" name="lower_limit" value={formData.lower_limit} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="upper_limit">Upper Limit</label>
                                                        <input type="number" className="form-control" id="upper_limit" name="upper_limit" value={formData.upper_limit} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="fee">Fee</label>
                                                        <input type="number" className="form-control" id="fee" name="fee" value={formData.fee} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="processing_time">Processing Time</label>
                                                        <input type="text" className="form-control" id="processing_time" name="processing_time" value={formData.processing_time} onChange={handleChange} required />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="acc_name">Account Name</label>
                                                        <input type="text" className="form-control" id="acc_name" placeholder="Enter Account Name" name="acc_name" value={formData.acc_name} onChange={handleSubmit} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="acc_number">Account Number</label>
                                                        <input type="text" className="form-control" id="acc_number" placeholder="Enter Account Number" name="acc_number" value={formData.acc_number} onChange={handleSubmit} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="bank_name">Bank Name</label>
                                                        <input type="text" className="form-control" id="bank_name" placeholder="Enter Bank Name" name="bank_name" value={formData.bank_name} onChange={handleSubmit} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="branch">Branch</label>
                                                        <input type="text" className="form-control" id="branch" placeholder="Enter Branch Name" name="branch" value={formData.branch} onChange={handleSubmit} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="upi_id">UPI Id</label>                                                        <input type="text" className="form-control" id="upi_id" placeholder="Enter UPI Id" name="upi_id" value={formData.upi_id} onChange={handleSubmit} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="ifsc_code">IFSC Code</label>
                                                        <input type="text" className="form-control" id="ifsc_code" placeholder="Enter IFSC Code" name="ifsc_code" value={formData.ifsc_code} onChange={handleSubmit} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="sequence">Sequence</label>
                                                        <input type="text" className="form-control" id="sequence" placeholder="Enter Sequence" name="sequence" value={formData.sequence} onChange={handleSubmit} />
                                                    </div>
                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="deposit_address">Deposit Address</label>
                                                        <input type="text" className="form-control" id="deposit_address" placeholder="Enter Deposit Address" name="deposit_address" value={formData.deposit_address} onChange={handleSubmit} />
                                                    </div>
                                                    <ImageUpload label="Payment Method Image" existingImage="https://example.com/path/to/payment-method-image.png" />
                                                    <ImageUpload label="QR Code Image" existingImage="https://example.com/path/to/qr-code-image.png" />


                                                    <div className="form-group col-sm-6">
                                                        <label htmlFor="status">Status</label>
                                                        <select className="form-control" id="status" name="status" value={formData.status} onChange={handleChange} required>
                                                            <option value="Active">Active</option>
                                                            <option value="Inactive">Inactive</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <button type="submit" className="common-submit-btn mt-2">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Footer />
                </div>
            </div>
        </>
    );
}
export default EditPaymentMethod
