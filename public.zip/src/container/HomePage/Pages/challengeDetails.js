import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link, useParams } from 'react-router-dom';
import useToggleSidebar from "../../../components/togglesidebar";
import AccountBreachModal from "../../../components/Modal/accountBreachModal";
import Sidebar from '../../sidebar';
import Header from '../../Header';
import Footer from '../../footer';
import axios from "axios";
import API_URL from "../../../config/config";
import "lightgallery/css/lightgallery.css";
import "lightgallery/css/lg-zoom.css";
import "lightgallery/css/lg-fullscreen.css";


function ChallengeDetails() {
    const { id } = useParams();
    const [userDetails, setUserDetails] = useState(null);
    const [dashboardData, setDashboardData] = useState(null);
    const [realTimeData, setRealTimeData] = useState(null);
    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isUpdating, setIsUpdating] = useState(false);
    const [status, setStatus] = useState("");
    const [successMessage, setSuccessMessage] = useState("");

    const token = localStorage.getItem("adminToken");

    useEffect(() => {
        if (!id) {
            setError("Invalid Challenge ID");
            setLoading(false);
            return;
        }

        const fetchUserDetails = async () => {
            try {
                const response = await axios.get(`${API_URL}/challenge/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                console.log("Challenge Details:", response.data);
                if (!response.data) throw new Error("Empty response from server");

                setUserDetails(response.data);
            } catch (err) {
                console.error("Error fetching challenge details:", err);
                setError(err.response?.data?.message || "Failed to fetch challenge request details");
            } finally {
                setLoading(false);
            }
        };

        const fetchDashboardDetails = async () => {
            try {
                const response = await axios.post(
                    `${API_URL}/get-trade-dashboard-details`,
                    { userWalletID: id },
                    { headers: { Authorization: `Bearer ${token}` } }
                );

                console.log("Dashboard Details:", response.data);
                setDashboardData(response.data.data);
            } catch (error) {
                console.error("Error fetching dashboard details:", error);
            }
        };

        const fetchRealTimeDetails = async () => {
            try {
                const response = await axios.post(
                    `${API_URL}/get-real-time-data-for-account-details`,
                    { user_wallet_id: id },
                    { headers: { Authorization: `Bearer ${token}` } }
                );

                setRealTimeData(response.data.data);
            } catch (error) {
                console.error("Error fetching real-time details:", error);
            }
        };

        fetchUserDetails();
        fetchDashboardDetails();
        fetchRealTimeDetails();

        const intervalId = setInterval(fetchRealTimeDetails, 10000);
        return () => clearInterval(intervalId);
    }, [id, token]);

    const handleUpdateStatus = async () => {
        const isConfirmed = window.confirm("Are you sure you want to pass this challenge?");
        if (!isConfirmed) return;

        setIsUpdating(true);
        try {
            const response = await axios.put(
                `${API_URL}/challenge/status/${id}`,
                { account_status: "passed" },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            if (response.data.success) {
                alert("Challenge status updated successfully!");
                window.location.reload(); // Refresh the page after success
            }
        } catch (error) {
            console.error("Error updating challenge status:", error);
            alert(error.response?.data?.error || "Failed to update challenge status.");
        } finally {
            setIsUpdating(false);
        }
    };
    const handleStatusChange = async (newStatus) => {
        const isConfirmed = window.confirm(`Are you sure you want to change the status to ${newStatus}?`);
        if (!isConfirmed) return;

        setIsUpdating(true);
        try {
            const response = await axios.put(
                `${API_URL}/challenge/approve/${id}`,
                { status: newStatus },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            if (response.data.success) {
                setStatus(newStatus);
                setSuccessMessage("Challenge status updated successfully!");
                setTimeout(() => setSuccessMessage(""), 10000);
            }
        } catch (error) {
            alert(error.response?.data?.error || "Failed to update challenge status.");
        } finally {
            setIsUpdating(false);
        }
    };


    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    if (!userDetails || !dashboardData) return <div>No challenge data found</div>;

    //Min trading days
    const minTradingDays = dashboardData.maxTradingDays || 0;
    const usedTradingDays = minTradingDays - (dashboardData.countMaxTradingDaysLeft || 0);
    const remainTradingDays = dashboardData.countMaxTradingDaysLeft || 0;
    const countMaxTradingDaysLeftPercentage = dashboardData.countMaxTradingDaysLeftPercentage || "0.00";


    //Profit target
    const profitTarget = dashboardData.profitTarget || 0;
    const usedProfitTarget = dashboardData.totalProfit || 0;
    const remainProfitTarget = profitTarget - usedProfitTarget;
    const makeOverAllProfitPercentage = dashboardData.makeOverAllProfitPercentage || "0";


    // Daily Loss Limit
    const dailyLossLimit = realTimeData?.dailyLossLimit ?? 0;
    const usedDailyLoss = realTimeData?.totalDailyLoss ?? 0;
    const remainDailyLoss = realTimeData?.remainDailyLoss ?? 0;
    const totalDailyLossPercentage = realTimeData?.totalDailyLossPercentage ?? "0";




    // Max Loss Limit
    const maxLossLimit = realTimeData?.overallLossLimit || 0;
    const usedMaxLoss = realTimeData?.totalOverAllLoss || 0;
    const remainMaxLoss = realTimeData?.remainOverAllLoss || 0;
    const totalOverAllLossPercentage = realTimeData?.data?.totalOverAllLossPercentage ?? "0";



    return (
        <>
            <Helmet>
                <title>Admin | View Challenge Details</title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className='content'>
                        <div className="breadcrumb-main-bx">
                            <div className="breadcrumb-bx">
                                <Link className="breadcrumb-link" to="/admin/dashboard">Dashboard</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <Link className="breadcrumb-link" to="/admin/challenge">Challenge</Link>
                                <div className="breadcrumb-link breadcrumb-disabled">/</div>
                                <div className="breadcrumb-link breadcrumb-active">Details</div>
                            </div>
                        </div>
                        {/* ------------Account-Breach-btn----------------- */}
                        <div className='container-fluid'>
                            <div>
                                {userDetails?.account_status !== 'disabled' && (
                                    <div className="row justify-content-end mb-3">
                                        <button
                                            type="button"
                                            onClick={() => setIsModalOpen(true)}
                                            className="common-btn-item cbi-fill"
                                        >
                                            <span>Account Breach</span>
                                        </button>
                                    </div>
                                )}
                                {/* {isModalOpen && <AccountBreachModal onClose={() => setIsModalOpen(false)} />} */}
                                {isModalOpen && (
                                    <AccountBreachModal
                                        userId={userDetails?._id}
                                        onClose={() => setIsModalOpen(false)}
                                    />
                                )}

                            </div>

                            <div className="col-md-12 mt-3">
                                {successMessage && (
                                    <div style={{ color: "green", background: "#E6F4EA", padding: "10px", borderRadius: "5px", marginBottom: "10px" }}>
                                        {successMessage}
                                    </div>
                                )}
                            </div>

                            <div class="row">
                                {/* --------------------------------Min trading days-box----------------------------------------- */}
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">Min trading days</div>
                                        <div class="card-body">
                                            <table class="table table-bordered table-style-2">
                                                <tbody>
                                                    <tr>
                                                        <th>Min trading days:</th>
                                                        <td id="min_trading_days">{minTradingDays}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Remain trading days:</th>
                                                        <td id="remain_trading_days">{remainTradingDays}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Used trading days:</th>
                                                        <td id="used_trading_days">{usedTradingDays}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Percentage of used trading days:</th>
                                                        <td id="percentage_used_trading_days">{countMaxTradingDaysLeftPercentage}%</td>
                                                    </tr>
                                                </tbody></table>
                                        </div>
                                    </div>
                                </div>

                                {/* --------------------------------Profit target-box----------------------------------------- */}

                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">Profit target</div>
                                        <div class="card-body">
                                            <table className="table table-bordered table-style-2">
                                                <tbody>
                                                    <tr>
                                                        <th>Profit target:</th>
                                                        <td id="profit_target">{profitTarget}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Remain profit target:</th>
                                                        <td id="remain_profit_target">{remainProfitTarget}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Used profit target:</th>
                                                        <td id="used_profit_target">{usedProfitTarget}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>Percentage of used profit target:</th>
                                                        <td id="percentage_used_profit_target">{makeOverAllProfitPercentage}%</td>
                                                    </tr>
                                                </tbody></table>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row mt-3">

                                {/* --------------------------------Daily Loss Limit-box----------------------------------------- */}
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">Daily Loss Limit</div>
                                        <div class="card-body">
                                            <table class="table table-bordered table-style-2">
                                                <tbody>
                                                    <tr>
                                                        <th>Daily loss limit:</th>
                                                        <td id="daily_loss_limit">{dailyLossLimit}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Remain daily loss:</th>
                                                        <td id="remain_daily_loss">{remainDailyLoss}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Used daily loss:</th>
                                                        <td id="used_daily_loss">{usedDailyLoss}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Percentage of used daily loss:</th>
                                                        <td id="percentage_used_daily_loss">{totalDailyLossPercentage}%</td>
                                                    </tr>
                                                </tbody>


                                            </table>
                                        </div>
                                    </div>
                                </div>

                                {/* --------------------------------Max Loss Limit-box----------------------------------------- */}
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">Max Loss Limit</div>
                                        <div class="card-body">
                                            <table class="table table-bordered table-style-2">
                                                <tbody>
                                                    <tr>
                                                        <th>Max loss limit:</th>
                                                        <td id="max_loss">{maxLossLimit}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Remain max loss:</th>
                                                        <td id="remain_max_loss">{remainMaxLoss}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Used max loss:</th>
                                                        <td id="used_max_loss">{usedMaxLoss}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Percentage of used max loss:</th>
                                                        <td id="percentage_used_max_loss">{totalOverAllLossPercentage}%</td>
                                                    </tr>
                                                </tbody></table>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            {/* -----------Details-------------------- */}
                            <div className='row mt-3'>
                                <div className='col-md-12'>
                                    <div className='card'>
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <div>Challenge Details</div>
                                        </div>
                                        <div className='card-body'>
                                            <div id='challenge-requests-table_wrapper' className='dataTables_wrapper no-footer'>
                                                <div className='table-responsive'>
                                                    <table className="table table-bordered dataTable no-footer overflow-x-auto" id="challenge-requests-table">
                                                        <tbody>
                                                            <tr>
                                                                <td><strong>User Name:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.first_name} {dashboardData.challengeInfo?.last_name}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account :</strong></td>
                                                                <td>{dashboardData.challengeInfo?.mt5_type || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Number:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.account_number || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account :</strong></td>
                                                                <td>{dashboardData.challengeInfo?.account_type?.name || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Step:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.account_type?.step || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Size:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.account_size?.name || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Type:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.mt5_type || "-"}</td>
                                                            </tr>

                                                            <tr>
                                                                <td><strong>Balance:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.balance || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Available Balance:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.available_balance || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>On Hold Balance: </strong></td>
                                                                <td>{dashboardData.challengeInfo?.on_hold_balance || "0"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Leverage:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.City || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Equity:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.equity || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Free Funds:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.free_funds || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Credit:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.credit || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Investor Password:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.investor_password || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Master Password:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.master_password || "-"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>US Residence:</strong></td>
                                                                <td>{dashboardData.challengeInfo?.not_us_residence ? "Yes" : "No"}</td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Account Status:</strong></td>
                                                                <td className="click-to-pass">
                                                                    {dashboardData?.challengeInfo?.account_status || "-"}
                                                                    {dashboardData?.challengeInfo?.account_status === "not_passed" && (
                                                                        <button
                                                                            type="button"
                                                                            className="cbi-small common-btn-item cbi-fill ml-2"
                                                                            onClick={handleUpdateStatus}
                                                                            disabled={isUpdating}
                                                                        >
                                                                            {isUpdating ? "Processing..." : "Click To Pass"}
                                                                        </button>
                                                                    )}
                                                                </td>

                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* ------------------------------------------------------------------------------ */}

                                {/* -------------------------Transaction-Screenshot------------------------------------ */}
                                {/* <div className="col-md-12 mt-3">
                                    <div className="card">
                                        <div className="card-header">Transaction Screenshot</div>
                                        <div className="card-body">
                                            <div className="row" id="lightgallery">
                                                <LightGallery speed={500} plugins={[lgZoom, lgFullscreen]}>
                                                    <a className="d-block col-lg-4 col-sm-6 zoom-img-item" href={Demo}>
                                                        <div className="upload-document-item">
                                                            <div className="udi-img-bx">
                                                                <img src={Demo} alt="Transaction Screenshot" />
                                                            </div>
                                                            <div className="udi-icon-bx">
                                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607ZM10.5 7.5v6m3-3h-6"></path></svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </LightGallery>
                                            </div>
                                        </div>
                                    </div>
                                </div> */}
                                {/* --------------------------Status--------------------------------------- */}
                                <div className="col-md-12 mt-3">
                                    <div className="card">
                                        <div className="card-header">Status</div>
                                        <div className="card-body">
                                            <div className="common-status-field custom-field form-group"
                                                style={{ display: "flex", gap: "10px", alignItems: "center", margin: "0px", fontSize: "14px" }}>
                                                <label htmlFor="status">Change Status:</label>
                                                <select
                                                    style={{ width: "fit-content" }}
                                                    name="status"
                                                    id="status"
                                                    className="select-control"
                                                    value={status}
                                                    onChange={(e) => handleStatusChange(e.target.value)}
                                                >
                                                    <option value="active">Active</option>
                                                    <option value="inactive">Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/* ---------------------------------------------------------------------------------- */}
                            </div>
                        </div>
                    </section>
                    <div style={{ marginLeft: isSidebarOpen ? "0" : "0", }}>
                        <Footer />
                    </div>
                </div >
            </div >
        </>
    )
}

export default ChallengeDetails
