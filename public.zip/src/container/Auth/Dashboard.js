import React, { useEffect, useState } from 'react';
import { Helmet } from "react-helmet";
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import API_URL from '../../config/config';
import '../../styles/dashboard.css';
import Sidebar from '../sidebar';
import Icons from "../../components/icons";
import useToggleSidebar from "../../components/togglesidebar";
import Header from '../Header';
import Footer from '../footer';

function Dashboard() {

    const { isSidebarOpen, toggleSidebar } = useToggleSidebar();

    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const token = localStorage.getItem('adminToken');

    // Redirect to login if no token is found
    useEffect(() => {
        const storedToken = localStorage.getItem('adminToken');
        if (!storedToken) navigate('/login');
    }, [navigate]);


    useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const response = await axios.get(`${API_URL}/dashboard`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setData(response.data);
            } catch (error) {
                setError('Error fetching data');
            } finally {
                setLoading(false);
            }
        };

        if (token) {
            fetchData();
        }
    }, [token]);




    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;


    return (
        <>
            <Helmet>
                <title>Admin | Dashboard </title>
            </Helmet>
            <Sidebar isSidebarOpen={isSidebarOpen} />
            <div className={`content-overlay ${isSidebarOpen && window.innerWidth <= 992 ? "blurred" : ""}`} onClick={() => isSidebarOpen && window.innerWidth <= 992 && toggleSidebar()}>
                <div className="content-wrapper" style={{ marginLeft: isSidebarOpen ? "250px" : "70px", transition: "margin-left .3s" }}>
                    <Header toggleSidebar={toggleSidebar} />
                    <section className="content">
                        <div className="container-fluid">
                            <div className="row dashboard-link-row">
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/challenge-requests" className="dashboard-link-item">
                                        <div className="dli-label">Challenge Requests</div>
                                        <div className="dli-data">{data.challengeRequestsCount}</div>
                                        <div className="dli-icon">
                                            <Icons.PlusIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/real-challenge-requests" className="dashboard-link-item">
                                        <div className="dli-label">Real Account Requests</div>
                                        <div className="dli-data">{data.realchallengeRequestsCount}</div>
                                        <div className="dli-icon">
                                            <Icons.PlusIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/account-size" className="dashboard-link-item">
                                        <div className="dli-label">Account Size</div>
                                        <div className="dli-data">{data.accountSizeCount}</div>
                                        <div className="dli-icon">
                                            <Icons.PlusIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/challenge" className="dashboard-link-item">
                                        <div className="dli-label">Challenge</div>
                                        <div className="dli-data">{data.challengeCount}</div>
                                        <div className="dli-icon">
                                            <Icons.ChallengeIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/user" className="dashboard-link-item">
                                        <div className="dli-label">Users</div>
                                        <div className="dli-data">{data.userCount}</div>
                                        <div className="dli-icon">
                                            <Icons.UserIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/payout" className="dashboard-link-item">
                                        <div className="dli-label">Payouts</div>
                                        <div className="dli-data">{data.payoutsCount}</div>
                                        <div className="dli-icon">
                                            <Icons.PayoutIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/trades" className="dashboard-link-item">
                                        <div className="dli-label">Trades</div>
                                        <div className="dli-data">{data.tradesCount}</div>
                                        <div className="dli-icon">
                                            <Icons.TradeIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/payment-methods" className="dashboard-link-item">
                                        <div className="dli-label">Payment Methods</div>
                                        <div className="dli-data">{data.paymentMethodsCount}</div>
                                        <div className="dli-icon">
                                            <Icons.PaymentMethodIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/leaderboard" className="dashboard-link-item">
                                        <div className="dli-label">Leaderboard</div>
                                        <div className="dli-data">{data.leaderboardCount}</div>
                                        <div className="dli-icon">
                                            <Icons.LeaderboardIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/news" className="dashboard-link-item">
                                        <div className="dli-label">News Calendar</div>
                                        <div className="dli-data">{data.newsCalenderCount}</div>
                                        <div className="dli-icon">
                                            <Icons.CalendarIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/news-currencies" className="dashboard-link-item">
                                        <div className="dli-label">News Currency</div>
                                        <div className="dli-data">{data.newsCurrenciesCount}</div>
                                        <div className="dli-icon">
                                            <Icons.NewsCurrencyIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/disabled-accounts" className="dashboard-link-item">
                                        <div className="dli-label">Disabled Accounts</div>
                                        <div className="dli-data">{data.disabledAccountsCount}</div>
                                        <div className="dli-icon">
                                            <Icons.DisableAccountIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/notification" className="dashboard-link-item">
                                        <div className="dli-label">Notification</div>
                                        <div className="dli-data">{data.notificationCount}</div>
                                        <div className="dli-icon">
                                            <Icons.NotificationIcon />
                                        </div>
                                    </Link>
                                </div>
                                <div className="col-lg-3 col-md-4 col-sm-6">
                                    <Link to="/admin/settings" className="dashboard-link-item">
                                        <div className="dli-label">Settings</div>
                                        <div className="dli-icon">
                                            <Icons.SettingIcon />
                                        </div>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </section>

                    <Footer />
                </div>
                <div className='ft'>
                </div>

            </div>
        </>
    );
}

export default Dashboard;
