import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import API_URL from '../../config/config';
import Logo from '../../assets/img/Logo.png';
import '../../styles/style.css';
import { useEffect } from 'react';
function SignIn() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const [remember, setRemember] = useState(false);

    useEffect(() => {
        const storedEmail = localStorage.getItem('admin_email') || '';
        const storedPassword = localStorage.getItem('admin_password') || '';
        const storedRemember = localStorage.getItem('admin_remember') === "1";

        setEmail(storedEmail);
        setPassword(storedPassword);
        setRemember(storedRemember);
    }, []);

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(`${API_URL}/login`,
                { email, password, remember },
                { withCredentials: true }
            );

            if (response.data.token) {
                localStorage.setItem('adminToken', response.data.token);

                if (remember) {
                    localStorage.setItem('admin_email', email);
                    localStorage.setItem('admin_password', password);
                    localStorage.setItem('admin_remember', "1");
                } else {
                    localStorage.removeItem('admin_email');
                    localStorage.removeItem('admin_password');
                    localStorage.removeItem('admin_remember');
                }

                navigate(response.data.redirect || '/dashboard');
            } else {
                setError('Invalid credentials.');
            }
        } catch (err) {
            console.error('Login error:', err.response ? err.response.data : err.message);
            setError(err.response?.data?.error || 'Login failed. Please check your email and password.');
        }
    };


    return (
        <div className='signin-screen'>
            <div className='logo'>
                <img src={Logo} alt='Logo' />
            </div>
            <form className='signin-width' onSubmit={handleLogin}>
                <h2 className='signin-head'>Admin Login</h2>
                {error && <p className="error-msg">{error}</p>}
                <div className='input-group'>
                    <input type='email' placeholder='Email' value={email} onChange={(e) => setEmail(e.target.value)} required />
                </div>
                <div className='input-group'>
                    <input type='password' placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                {/* <div className='check-bx'>
                    <label htmlFor="Remember" className="remember-label">
                        <input type="checkbox" id="Remember" />
                        <span>Remember Me</span>
                    </label>
                </div> */}
                <div className='check-bx'>
                    <label htmlFor="Remember" className="remember-label">
                        <input
                            type="checkbox"
                            id="Remember"
                            checked={remember}
                            onChange={(e) => setRemember(e.target.checked)}
                        />
                        <span>Remember Me</span>
                    </label>
                </div>

                <div className='btn'>
                    <button type='submit'>Sign In</button>
                </div>
            </form>
        </div>
    );
}

export default SignIn;
