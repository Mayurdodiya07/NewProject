// import React, { useState } from "react";
// import { Link } from 'react-router-dom';
// import Icons from "../components/icons";
// import '../styles/header.css';
// import 'bootstrap/dist/css/bootstrap.min.css';


// function Header({ toggleSidebar, isSidebarOpen }) {

// const [notificationsCount, setNotificationsCount] = useState(31);

//   return (
//     <nav className={`main-header navbar navbar-expand navbar-white navbar-light ${isSidebarOpen ? "overlay" : ""}`}>
//       <div className="menu-icon-bx" onClick={toggleSidebar} data-widget="pushmenu">
//         <span></span>
//         <span></span>
//         <span></span>
//       </div>
//       <Link to="javascript:void(0);" className="mh-brand-link">
//         <img className="mh-main-logo" src="/img/logo/logo2.png" alt="" />
//         <img className="mh-logo-icon" src="/img/logo/icon.png" alt="" />
//       </Link>
//       {/* Right navbar links */}
//       <ul className="navbar-nav ml-auto">
//         <li className="nav-item item-nav">
//           <Link className="nav-link nav-notification" to="">
//             <Icons.BellIcon />
//             {notificationsCount > 0 && (
//               <span id="notification-badge" className="nav-num">
//                 {notificationsCount}
//                 {/* <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="3" stroke="currentColor" className="size-6">
//                 <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15"/>
//               </svg> */}
//               </span>
//             )}
//           </Link>
//         </li>
//         <li className="nav-item item-nav">
//           <Link className="nav-link nav-logout" to="http://localhost:8000/api/admin/logout">
//             {/* to="https://fundedfirmbackend.pmcommu.in/admin/logout"> */}
//             <Icons.LogoutIcon />
//             <div className="nav-label">Logout</div>
//           </Link>
//           <form id="logout-form" action="http://localhost:8000/api/admin/logout"
//             // action="https://fundedfirmbackend.pmcommu.in/admin/logout"
//             method="POST" className="d-none">
//             <input type="hidden" name="_token" value="tLOig0dpev1iGh0myz9Ll2EYuIx9SC8qrZdmyKtX" autoComplete="off" />
//           </form>
//         </li>
//       </ul>
//     </nav>
//   )
// }

// export default Header
// import React, { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import Icons from "../components/icons";
// import "../styles/header.css";
// import "bootstrap/dist/css/bootstrap.min.css";

// function Header({ toggleSidebar, isSidebarOpen }) {
//   const [notificationsCount, setNotificationsCount] = useState(31);
//   const navigate = useNavigate();

//   // Logout Function
//   const handleLogout = async () => {
//     try {
//       localStorage.removeItem("adminToken");
//       localStorage.removeItem("remember_token");

//       document.cookie = "admin_token=; Max-Age=0; path=/; domain=" + window.location.hostname;
//       document.cookie = "remember_token=; Max-Age=0; path=/; domain=" + window.location.hostname;

//       // Redirect to login page
//       navigate("/admin/login", { replace: true });

//       setTimeout(() => {
//         window.history.replaceState(null, "", "/admin/login");
//       }, 100);

//     } catch (error) {
//       console.error("Error during logout:", error);
//     }
//   };


//   return (
//     <nav className={`main-header navbar navbar-expand navbar-white navbar-light ${isSidebarOpen ? "overlay" : ""}`}>
//       <div className="menu-icon-bx" onClick={toggleSidebar}>
//         <span></span>
//         <span></span>
//         <span></span>
//       </div>
//       <Link to="#" className="mh-brand-link">
//         <img className="mh-main-logo" src="/img/logo/logo2.png" alt="Main Logo" />
//         <img className="mh-logo-icon" src="/img/logo/icon.png" alt="Icon Logo" />
//       </Link>

//       <ul className="navbar-nav ml-auto">
//         <li className="nav-item item-nav">
//           <Link className="nav-link nav-notification" to="#">
//             <Icons.BellIcon />
//             {notificationsCount > 0 && (
//               <span id="notification-badge" className="nav-num">{notificationsCount}</span>
//             )}
//           </Link>
//         </li>
//         <li className="nav-item item-nav">
//           <button type="button" className="nav-link nav-logout" onClick={handleLogout}>
//             <Icons.LogoutIcon />
//             <div className="nav-label">Logout</div>
//           </button>
//         </li>
//       </ul>
//     </nav>
//   );
// }

// export default Header;

import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import Icons from "../components/icons";
import "../styles/header.css";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import API_URL from "../config/config";


function Header({ toggleSidebar, isSidebarOpen }) {
  const [notificationsCount, setNotificationsCount] = useState(0);
  const navigate = useNavigate();

  // Function to fetch unread notifications count
  const fetchUnreadNotifications = async () => {
    try {
      const response = await axios.get(`${API_URL}/notification/unreadCount`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("adminToken")}` }, // Include token if needed
      });
      setNotificationsCount(response.data.count || 0);
    } catch (error) {
      console.error("Error fetching unread notifications:", error);
    }
  };
  // Fetch unread notifications count when component mounts
  useEffect(() => {
    fetchUnreadNotifications();
  }, []);

  // Function to handle clicking the notification icon
  const handleNotificationClick = () => {
    navigate("/admin/notification");
    setNotificationsCount(0);
  };

  // Logout Function
  const handleLogout = async () => {
    try {
      localStorage.removeItem("adminToken");
      localStorage.removeItem("remember_token");

      document.cookie = "admin_token=; Max-Age=0; path=/; domain=" + window.location.hostname;
      document.cookie = "remember_token=; Max-Age=0; path=/; domain=" + window.location.hostname;

      navigate("/admin/login", { replace: true });

      setTimeout(() => {
        window.history.replaceState(null, "", "/admin/login");
      }, 100);

    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  return (
    <nav className={`main-header navbar navbar-expand navbar-white navbar-light ${isSidebarOpen ? "overlay" : ""}`}>
      <div className="menu-icon-bx" onClick={toggleSidebar}>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <Link to="#" className="mh-brand-link">
        <img className="mh-main-logo" src="/img/logo/logo2.png" alt="Main Logo" />
        <img className="mh-logo-icon" src="/img/logo/icon.png" alt="Icon Logo" />
      </Link>
      <ul className="navbar-nav ml-auto">
        <li className="nav-item item-nav">
          <Link className="nav-link nav-notification" to="/admin/notification" onClick={handleNotificationClick}>
            <Icons.BellIcon />
            {notificationsCount > 0 && (
              <span id="notification-badge" className="nav-num">{notificationsCount}</span>
            )}
          </Link>
        </li>
        <li className="nav-item item-nav">
          <button type="button" className="nav-link nav-logout" onClick={handleLogout}>
            <Icons.LogoutIcon />
            <div className="nav-label">Logout</div>
          </button>
        </li>
      </ul>
    </nav>
  );
}

export default Header;
