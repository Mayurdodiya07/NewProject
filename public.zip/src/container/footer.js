import React from 'react'
import { Link } from 'react-router-dom';
import '../styles/footer.css'
import 'bootstrap/dist/css/bootstrap.min.css';

function footer() {
  return (
    <footer className="main-footer">
      <p className="text-center pb-0 mb-0">Copyright © 2024 <Link to="/admin/dashboard">Fundedfirm Node CRM</Link>. All rights reserved.</p>
    </footer>
  )
}

export default footer
