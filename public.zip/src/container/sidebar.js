import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import '../styles/Sidebar.css';
import Icons from '../components/icons'
import 'bootstrap/dist/css/bootstrap.min.css';
import Logo from '../assets/img/Logo.png';
import Logo2 from '../assets/img/Logo2.png';


function Sidebar({ isSidebarOpen }) {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      localStorage.removeItem("adminToken");
      localStorage.removeItem("remember_token");

      document.cookie = "admin_token=; Max-Age=0; path=/; domain=" + window.location.hostname;
      document.cookie = "remember_token=; Max-Age=0; path=/; domain=" + window.location.hostname;

      navigate("/admin/login", { replace: true });

      setTimeout(() => {
        window.history.replaceState(null, "", "/admin/login");
      }, 100);

    } catch (error) {
      console.error("Error during logout:", error);
    }
  };




  return (
    <>
      <aside className={`main-sidebar sidebar-collapse account-side-menu ${isSidebarOpen ? "open" : "closed"}`}>
        <Link to="#" className="brand-link">
          <img className="asm-main-logo" src={Logo} alt="Logo" />
        </Link>
        <div className="sidebar">
          <nav className="mt-2-nav">
            <ul className="nav nav-pills nav-sidebar flex-column">
              <li className="nav-item">
                <Link to="/admin/dashboard" className={`nav-link ${location.pathname === "/admin/dashboard" ? "active" : ""}`}>
                  <Icons.SvgIcon />
                  <p className={`sidebar-text ${isSidebarOpen ? "visible" : "hidden"}`}>Dashboard</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/challenge-requests" className={`nav-link ${location.pathname === "/admin/challenge-requests" ? "active" : ""}`}>
                  <Icons.PlusIcon />
                  <p>Challenge Request</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/real-challenge-requests" className={`nav-link ${location.pathname === "/admin/real-challenge-requests" ? "active" : ""}`}>
                  <Icons.PlusIcon />
                  <p>Real Account Request</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/passed-challenge-requests" className={`nav-link ${location.pathname === "/admin/passed-challenge-requests" ? "active" : ""}`}>
                  <Icons.PlusIcon />
                  <p>Passed Account Request</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/passed-accounts" className={`nav-link ${location.pathname === "/admin/passed-accounts" ? "active" : ""}`}>
                  <Icons.PlusIcon />
                  <p>Passed Accounts</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/account-size" className={`nav-link ${location.pathname === "/admin/account-size" ? "active" : ""}`}>
                  <Icons.CalendarIcon />
                  <p>Account Size</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/challenge" className={`nav-link ${location.pathname === "/admin/challenge" ? "active" : ""}`}>
                  <Icons.ChallengeIcon />
                  <p>Challenge</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/user" className={`nav-link ${location.pathname === "/admin/user" ? "active" : ""}`}>
                  <Icons.UserIcon />
                  <p>Users</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/reffereduser" className={`nav-link ${location.pathname === "/admin/reffereduser" ? "active" : ""}`}>
                  <Icons.UserIcon />
                  <p>Affiliates</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/payout" className={`nav-link ${location.pathname === "/admin/payout" ? "active" : ""}`}>
                  <Icons.PayoutIcon />
                  <p>Payouts</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/trades" className={`nav-link ${location.pathname === "/admin/trades" ? "active" : ""}`}>
                  <Icons.TradeIcon />
                  <p>Trades</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/payment-methods" className={`nav-link ${location.pathname === "/admin/payment-methods" ? "active" : ""}`}>
                  <Icons.PaymentMethodIcon />
                  <p>Payment Methods</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/leaderboard" className={`nav-link ${location.pathname === "/admin/leaderboard" ? "active" : ""}`}>
                  <Icons.LeaderboardIcon />
                  <p>Leaderboard</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/news" className={`nav-link ${location.pathname === "/admin/news" ? "active" : ""}`}>
                  <Icons.CalendarIcon />
                  <p>News Calendar</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/news-currencies" className={`nav-link ${location.pathname === "/admin/news-currencies" ? "active" : ""}`}>
                  <Icons.NewsCurrencyIcon />
                  <p>News Currency</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/disabled-accounts" className={`nav-link ${location.pathname === "/admin/disabled-accounts" ? "active" : ""}`}>
                  <Icons.DisableAccountIcon />
                  <p>Disabled Accounts</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/notification" className={`nav-link ${location.pathname === "/admin/notification" ? "active" : ""}`}>
                  <Icons.NotificationIcon />
                  <p>Notifications</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/promo-code" className={`nav-link ${location.pathname === "/admin/promo-code" ? "active" : ""}`}>
                  <Icons.NotificationIcon />
                  <p>Promo code</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/contact" className={`nav-link ${location.pathname === "/admin/contact" ? "active" : ""}`}>
                  <Icons.ContactIcon />
                  <p>Contact</p>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin/settings" className={`nav-link ${location.pathname === "/admin/settings" ? "active" : ""}`}>
                  <Icons.SettingIcon />
                  <p>Settings</p>
                </Link>
              </li>
              <li className="nav-item">
                <button onClick={handleLogout} className={`nav-link btn-link ${location.pathname === "/admin/logout" ? "active" : ""}`}>
                  <Icons.LogoutIcon />
                  <p>Logout</p>
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </aside >

      {!isSidebarOpen &&
        <aside className="main-sidebar account-side-menu min-sidebar">
          <Link to="#" className="brand-link">
            <img className="asm-logo-icon1 img-visible1" src={Logo2} alt="Icon" />
            <img className="asm-main-logo img-visible" src={Logo} alt="Logo" />
          </Link>
          <div className="sidebar">
            <nav className="mt-2-nav">
              <ul className="nav nav-pills nav-sidebar flex-column">
                <li className="nav-item">
                  <Link to="/admin/dashboard" className={`nav-link ${location.pathname === "/admin/dashboard" ? "active1" : ""}`}>
                    <Icons.SvgIcon />
                    <p className="text-visible">Dashboard</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/challenge-requests" className={`nav-link ${location.pathname === "/admin/challenge-requests" ? "active1" : ""}`}>
                    <Icons.PlusIcon />
                    <p className="text-visible">Challenge Request</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/real-challenge-requests" className={`nav-link ${location.pathname === "/admin/real-challenge-requests" ? "active1" : ""}`}>
                    <Icons.PlusIcon />
                    <p className="text-visible">Real Account Request</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/passed-challenge-requests" className={`nav-link ${location.pathname === "/admin/passed-challenge-requests" ? "active1" : ""}`}>
                    <Icons.PlusIcon />
                    <p className="text-visible">Passed Account Request</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/passed-accounts" className={`nav-link ${location.pathname === "/admin/passed-accounts" ? "active1" : ""}`}>
                    <Icons.PlusIcon />
                    <p className="text-visible">Passed Accounts</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/account-size" className={`nav-link ${location.pathname === "/admin/account-size" ? "active1" : ""}`}>
                    <Icons.CalendarIcon />
                    <p className="text-visible">Account Size</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/challenge" className={`nav-link ${location.pathname === "/admin/challenge" ? "active1" : ""}`}>
                    <Icons.ChallengeIcon />
                    <p className="text-visible">Challenge</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/user" className={`nav-link ${location.pathname === "/admin/user" ? "active1" : ""}`}>
                    <Icons.UserIcon />
                    <p className="text-visible">Users</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/reffereduser" className={`nav-link ${location.pathname === "/admin/reffereduser" ? "active1" : ""}`}>
                    <Icons.UserIcon />
                    <p className="text-visible">Affiliates</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/payout" className={`nav-link ${location.pathname === "/admin/payout" ? "active1" : ""}`}>
                    <Icons.PayoutIcon />
                    <p className="text-visible">Payouts</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/trades" className={`nav-link ${location.pathname === "/admin/trades" ? "active1" : ""}`}>
                    <Icons.TradeIcon />
                    <p className="text-visible">Trades</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/payment-methods" className={`nav-link ${location.pathname === "/admin/payment-methods" ? "active1" : ""}`}>
                    <Icons.PaymentMethodIcon />
                    <p className="text-visible">Payment Methods</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/leaderboard" className={`nav-link ${location.pathname === "/admin/leaderboard" ? "active1" : ""}`}>
                    <Icons.LeaderboardIcon />
                    <p className="text-visible">Leaderboard</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/news" className={`nav-link ${location.pathname === "/admin/news" ? "active1" : ""}`}>
                    <Icons.CalendarIcon />
                    <p className="text-visible">News Calendar</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/news-currencies" className={`nav-link ${location.pathname === "/admin/news-currencies" ? "active1" : ""}`}>
                    <Icons.NewsCurrencyIcon />
                    <p className="text-visible">News Currency</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/disabled-accounts" className={`nav-link ${location.pathname === "/admin/disabled-accounts" ? "active1" : ""}`}>
                    <Icons.DisableAccountIcon />
                    <p className="text-visible">Disabled Accounts</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/notification" className={`nav-link ${location.pathname === "/admin/notification" ? "active1" : ""}`}>
                    <Icons.NotificationIcon />
                    <p className="text-visible">Notifications</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/contact" className={`nav-link ${location.pathname === "/admin/contact" ? "active1" : ""}`}>
                    <Icons.ContactIcon />
                    <p className="text-visible">Contact</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/settings" className={`nav-link ${location.pathname === "/admin/settings" ? "active1" : ""}`}>
                    <Icons.SettingIcon />
                    <p className="text-visible">Settings</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/admin/logout" className={`nav-link ${location.pathname === "/admin/logout" ? "active1" : ""}`}>
                    <Icons.LogoutIcon />
                    <p className="text-visible">Logout</p>
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </aside>
      }
    </>
  );
}

export default Sidebar;
