"# FundedFirmBackendinNodejs"

# start with command with "npm  i"  to node modules package downloaded

#
### `npm start` or `run dev` 

Runs the app in the development mode.\
Open [http://localhost:8000](http://localhost:8000) to view it in your console or vs code terminal.

