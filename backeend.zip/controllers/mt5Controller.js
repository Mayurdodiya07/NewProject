const { validationResult } = require("express-validator");
const User = require("../models/User");
const Currency = require("../models/Currency");
const StartAmount = require("../models/StartAmount");
const Leverage = require("../models/Leverage");
const TradeGroup = require("../models/TradeGroup");
const UserWallet = require("../models/UserWallet");
const Mt5Service = require("../services/mt5Service");
// const PasswordHelper = require("../utils/PasswordHelper");
const nodemailer = require("nodemailer");

class Mt5Controller {
    constructor() {
        this.mt5Service = new Mt5Service();
    }

    async createWallet(req, res) {
        try {
            // Validate request body
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                const errorMessages = errors
                    .array()
                    .map((err) => err.msg)
                    .join(" ");
                return res
                    .status(400)
                    .json({ error: `Validation Error: ${errorMessages}` });
            }

            const {
                user_id,
                mt5_type,
                leverage_id,
                start_amount_id,
                account_type_id,
                product_id,
            } = req.body;

            // Check if user exists
            const user = await User.findById(user_id);
            if (!user) {
                return res.status(404).json({ error: "User profile not found!" });
            }

            // Fetch necessary details
            const currency = await Currency.findOne({ code: "USD" });
            if (!currency) {
                return res.status(404).json({ error: "Currency not found!" });
            }

            const startAmount = await StartAmount.findById(start_amount_id);
            const leverageValue = await Leverage.findById(leverage_id);
            const tradeGroup = await TradeGroup.findOne({ name: "demo\\PXM_B\\LP" });

            // Prepare data for MT5 account creation
            const iPassword = PasswordHelper.generateRandomPassword(12);
            const mPassword = PasswordHelper.generateRandomPassword(12);

            const mt5AccountData = {
                accountid: 0,
                type: 0,
                platform: 0,
                currency: currency.name,
                server: "",
                group: tradeGroup.name,
                name: `${user.first_name} ${user.last_name}`,
                email: user.email,
                phone: user.phone_number,
                country: user.country_name,
                city: user.city,
                address: "",
                balance: 0,
                mPassword,
                iPassword,
                leverage: leverageValue.value,
            };

            // Call MT5 API to create account
            const response = await this.mt5Service.createAccount(mt5AccountData);

            if (!response || !response.user) {
                return res.status(500).json({
                    error: "Failed to create MT5 account. Please try again later.",
                });
            }

            // Prepare wallet data
            const walletData = {
                user_id,
                account: "mt5",
                account_number: response.user.accountid,
                code: response.user.accountid,
                investor_password: response.user.iPassword,
                master_password: response.user.mPassword,
                currency: currency.name,
                currency_id: currency.id,
                balance: mt5_type === "demo" ? startAmount.value : 0.0,
                available_balance: mt5_type === "demo" ? startAmount.value : 0.0,
                on_hold_balance: 0.0,
                equity: mt5_type === "demo" ? startAmount.value : 0.0,
                free_funds: mt5_type === "demo" ? startAmount.value : 0.0,
                credit: 0,
                favourite: false,
                fiat: false,
                enabled: true,
                status: "active",
                archived: false,
                mt5_type,
                leverage_id,
                start_amount_id,
                account_type_id,
                product_id,
            };

            // Save wallet to database
            const userWallet = await UserWallet.create(walletData);

            // Update MT5 balance
            const balanceDepositInMT5 = {
                loginid: response.user.accountid,
                amount: walletData.balance,
                txnType: 0,
                description: "",
                comment: "DEPOSIT - CRM",
            };

            await this.mt5Service.updateBalance(balanceDepositInMT5);

            // Send email to user
            const transporter = nodemailer.createTransport({
                host: process.env.MAIL_HOST,
                port: process.env.MAIL_PORT,
                secure: process.env.MAIL_ENCRYPTION === "tls",
                auth: {
                    user: process.env.mail_username,
                    pass: process.env.MAIL_PASSWORD,
                },
            });

            const mailOptions = {
                from: `${process.env.MAIL_FROM_NAME} <${process.env.mail_from_address}>`,
                to: user.email,
                subject: "Your MT5 Account Details",
                text: `Dear ${user.first_name},

Your MT5 account has been successfully created.

Account Type: ${account_type_id}
Login ID: ${walletData.account_number}
Master Password: ${walletData.master_password}
Investor Password: ${walletData.investor_password}
Currency: ${currency.name}
Account Type: ${mt5_type}

Thank you for choosing FundedFirm.

Best regards,
FundedFirm Team`,
            };

            await transporter.sendMail(mailOptions);

            return res.status(201).json({
                message: "MT5 account created successfully",
                wallet: userWallet,
            });
        } catch (error) {
            console.error("Error creating wallet:", error);
            return res
                .status(500)
                .json({ error: "Internal server error", details: error.message });
        }
    }
}

module.exports = new Mt5Controller();
