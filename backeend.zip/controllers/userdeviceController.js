const { validationResult } = require('express-validator');
const UserDevice = require('../models/UserDevice');
// const logger = require('./logger');

exports.getUserDeviceData = async (req, res) => {
    try {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ success: 2, message: 'Validation failed.', errors: errors.array() });
        }

        const { user_id } = req.body;

        // Fetch the latest user device data by user_id, sorted by createdAt in descending order
        const userDeviceData = await UserDevice.findOne({ user_id }).sort({ createdAt: -1 });


        if (!userDeviceData) {
            return res.status(404).json({ success: 2, message: 'No data found for the provided user.', data: [] });
        }

        return res.status(200).json({ success: 0, message: 'User device data fetched successfully.', data: userDeviceData });
    } catch (error) {
        logger.error(`Error fetching user device data: ${error.message}`);
        return res.status(500).json({ success: 20, message: 'Server Error.', error: error.message });
    }
};
