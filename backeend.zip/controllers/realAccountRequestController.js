
const mongoose = require('mongoose');
const jwt = require("jsonwebtoken");
const RealAccountRequest = require("../models/RealAccountRequest");
const UserWallet = require("../models/UserWallet");
const { sendResponse, sendServerError } = require("../utils/responseHelper");
const moment = require('moment');
const Trade = require('../models/Trade');  // Replace with the correct relative path




exports.index = async (req, res) => {
  try {
    const filters = {};
    const populateOptions = [
      {
        path: 'userWallet',
        populate: [
          { path: 'account_type_id' },
          { path: 'account_size_id' }
        ]
      }
    ];

    // Apply filters based on query parameters
    if (req.query.type && req.query.type !== 'all') {
      filters['userWallet.accountType.name'] = req.query.type;
    }

    if (req.query.step && req.query.step !== 'all') {
      filters['userWallet.accountType.step'] = req.query.step;
    }

    filters.account_status = { $ne: 'approved' };

    // Additional filters based on request query
    if (req.query.type) filters.type = req.query.type;
    if (req.query.user_id) filters.user_id = req.query.user_id;
    if (req.query.transaction_type) filters.transaction_type = req.query.transaction_type;
    if (req.query.transfer_type) filters.transfer_type = req.query.transfer_type;
    if (req.query.payment_method_id) filters.payment_method_id = req.query.payment_method_id;
    if (req.query.user_wallet_id) filters.user_wallet_id = req.query.user_wallet_id;
    if (req.query.currency_id) filters.currency_id = req.query.currency_id;
    if (req.query.transaction_status) filters.transaction_status = req.query.transaction_status;

    const sort = {};
    if (req.query.order && ['asc', 'desc'].includes(req.query.order)) {
      sort.id = req.query.order;
    } else {
      sort.created_at = -1;
    }

    // Set perPage and page to default values if not provided in query
    const page = parseInt(req.query.page, 10) || 1;
    const perPage = parseInt(req.query.per_page, 10) || 20;

    let accountRequests;
    if (req.query.nopaginate && req.query.nopaginate == '1') {
      accountRequests = await RealAccountRequest.find(filters)
        .populate(populateOptions)
        .sort(sort);
    } else {
      accountRequests = await RealAccountRequest.find(filters)
        .populate(populateOptions)
        .sort(sort)
        .skip((page - 1) * perPage)  // Ensure this is correctly used
        .limit(perPage);
    }

    // Transform data into desired format
    const transformedData = accountRequests.map((item, index) => ({
      user_id: item.user_id,
      user_wallet_id: item.userWallet._id,
      account_status: item.account_status,
      status: item.status,
      created_at_formatted: moment(item.created_at).format('DD-MM-YYYY'),
      user_wallet: {
        user_id: item.userWallet.user_id,
        mt5_type: item.userWallet.mt5_type,
        title: item.userWallet.title,
        first_name: item.userWallet.first_name,
        last_name: item.userWallet.last_name,
        city: item.userWallet.city,
        postal_code: item.userWallet.postal_code,
        address_country_id: item.userWallet.address_country_id,
        country_id: item.userWallet.country_id,
        account_type_id: item.userWallet.account_type_id,
        account_size_id: item.userWallet.account_size_id,
        not_us_residence: item.userWallet.not_us_residence,
        platform_id: item.userWallet.platform_id,
        account: item.userWallet.account,
        account_status: item.userWallet.account_status,
        currency: item.userWallet.currency,
        currency_id: item.userWallet.currency_id,
        balance: item.userWallet.balance || 0,
        available_balance: item.userWallet.available_balance || 0,
        equity: item.userWallet.equity || 0,
        formatted_balance: (item.userWallet.balance || 0).toLocaleString(),
        formatted_available_balance: (item.userWallet.available_balance || 0).toLocaleString(),
        formatted_on_hold_balance: (item.userWallet.on_hold_balance || 0).toLocaleString(),
        account_type: item.userWallet.accountType?.name || 'Unknown',
        account_size: item.userWallet.accountSize?.name || 'Unknown',
        account_type_step: item.userWallet.accountType?.step || 'Unknown',
        account_type_id: item.userWallet.accountType?._id || null,
        account_size_id: item.userWallet.accountSize?._id || null,
        created_at_formatted: moment(item.userWallet.created_at).format('DD-MM-YYYY'),
        updated_at_formatted: moment(item.userWallet.updated_at).format('DD-MM-YYYY')
      },
      id: item._id,
      sequence: (page - 1) * perPage + index + 1  // Ensure proper sequence
    }));

    res.status(200).json({ success: 0, data: transformedData });
  } catch (error) {
    res.status(500).json({ success: 1, message: 'Server Error.', error: error.message });
  }
};
