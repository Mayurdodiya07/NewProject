const multer = require('multer');
const { body, validationResult } = require('express-validator');
const User = require('../models/User'); // Your User model
const Application = require('../models/Application'); // Your Application model
const Document = require('../models/Document'); // Your Document model
const path = require('path')
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/documents'); // Save to 'public/documents'
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 3 * 1024 * 1024 }, // Limit file size to 3MB
  fileFilter: (req, file, cb) => {
    const fileTypes = /png|jpg|jpeg|pdf/;
    const extName = fileTypes.test(path.extname(file.originalname).toLowerCase());
    const mimeType = fileTypes.test(file.mimetype);
    if (extName && mimeType) {
      return cb(null, true);
    }
    cb(new Error('Only .png, .jpg, .jpeg, and .pdf files are allowed.'));
  },
}).array('documents'); // Accept multiple files under 'documents' field


exports.store = [
  // Validation middleware
  body('user_id').notEmpty().withMessage('user_id is required'),
  body('document_type_id').isArray().withMessage('document_type_id must be an array'),
  body('document_type_id.*').notEmpty().withMessage('Each document_type_id is required'),

  async (req, res) => {
    upload(req, res, async (err) => {
      if (err) {
        return res.status(400).json({
          success: 2,
          message: 'Validation Error.',
          errors: [err.message],
        });
      }

      // Validate other fields
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        const errorMessage = errors.array().map(err => err.msg).join(' ');
        return res.status(400).json({
          success: 2,
          message: 'Validation Error.',
          errors: [errorMessage],
        });
      }

      try {
        const { user_id, document_type_id } = req.body;

        // Check if user exists
        const user = await User.findById(user_id);
        if (!user) {
          return res.status(404).json({
            success: 2,
            message: 'User profile not found!',
          });
        }

        // Create application record
        const application = await Application.create({
          user_id,
          type: 'verification',
          status: 'pending',
        });

        // Save uploaded files and related documents
        const files = req.files;
        const fileUrls = [];
        for (let i = 0; i < files.length; i++) {
          const fileUrl = `/documents/${files[i].filename}`;
          fileUrls.push(fileUrl);

          // Create document records linked to the application
          await Document.create({
            file: fileUrl,
            document_type_id: document_type_id[i],
            application_id: application._id,
          });
        }

        return res.status(200).json({
          success: 0,
          message: 'Application request sent successfully.',
          data: application,
        });
      } catch (error) {
        return res.status(500).json({
          success: 2,
          message: 'Server Error.',
          error: error.message,
        });
      }
    });
  },
];

exports.approveDocumentRequests = async (req, res) => {
  try {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessage = errors.array().map(err => err.msg).join(' ');
      return res.status(400).json({
        success: false,
        message: 'Validation Error.',
        errors: [errorMessage]
      });
    }

    const { user_id, application_id } = req.body;

    // Find user
    const user = await User.findById(user_id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User profile not found!'
      });
    }

    // Find application with documents
    const application = await Application.findById(application_id).populate('documents');
    if (!application) {
      return res.status(404).json({
        success: 2,
        message: 'Application not found!'
      });
    }

    const appDocuments = application.documents;
    if (appDocuments.length === 0) {
      return res.status(404).json({
        success: 2,
        message: 'Application document not found!'
      });
    }

    // Approve documents and create/update user documents
    for (const document of appDocuments) {
      await document.updateOne({ approved: true });

      await Document.create({
        document_type_id: document.document_type_id,
        user_id: application.user_id,
        application_id: document.application_id,
        status: 'approved',
        file: document.file
      });
    }

    // Update application status
    application.status = 'approved';
    await application.save();

    // Fetch updated user documents
    const updatedUser = await User.findById(user_id).populate('documents');

    return res.status(200).json({
      success: 0,
      message: 'Application verified successfully.',
      data: updatedUser.documents
    });

  } catch (error) {
    return res.status(500).json({
      success: 2,
      message: 'Server Error.',
      error: error.message
    });
  }
};