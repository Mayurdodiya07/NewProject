const DocumentGroup = require('../models/DocumentGroup');
const VerificationLevel = require("../models/VerificationLevel");

exports.index = async (req, res) => {
  try {
    const { order, page, per_page } = req.body;
    let query = VerificationLevel.find().select(
      "id index caption description default visible"
    );

    // Apply sorting
    if (order && (order === "asc" || order === "desc")) {
      query = query.sort({ id: order });
    } else {
      query = query.sort({ index: "asc" });
    }

    // Apply pagination
    const perPage = per_page ? parseInt(per_page) : 20;
    const currentPage = page && parseInt(page) > 0 ? parseInt(page) : 1;
    const skipCount = (currentPage - 1) * perPage;

    const totalCount = await VerificationLevel.countDocuments();
    const countries = await query.skip(skipCount).limit(perPage);

    return res.status(200).json({
      success: 0,
      message: "Verification levels retrieved successfully.",
      data: countries,
      total: totalCount,
      page: currentPage,
      per_page: perPage,
      total_pages: Math.ceil(totalCount / perPage)
    });
  } catch (error) {
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

exports.getDocumentTypesGroupWise = async (req, res) => {
  try {
    // Fetch document groups along with their document types
    const documentGroups = await DocumentGroup.find({ enabled: true })
      .sort({ priority: 1 })
      .populate('documentTypes');

    return res.status(200).json({
      success: 0,
      message: 'Documents groups retrieved successfully.',
      data: documentGroups,
    });
  } catch (error) {
    return res.status(500).json({
      success: 2,
      message: 'Server Error.',
      error: error.message,
    });
  }
};