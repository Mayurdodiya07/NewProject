const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Country = require('../models/Country');

// exports.country = async (req, res) => {
//   try {
//     // Start with selecting the fields (id, name, iso3, iso2)
//     let query = Country.find().select("id name iso3 iso2");
//     if (
//       req.query.order &&
//       (req.query.order === "asc" || req.query.order === "desc")
//     ) {
//       query = query.sort({ id: req.query.order });
//     } else {
//       query = query.sort({ name: "asc" });
//     }
//     if (req.query.nopaginate !== "1") {
//       const perPage = req.query.per_page || 20;
//       const page = req.query.page || 1;

//       query = query.skip((page - 1) * perPage).limit(perPage);
//     }

//     // Fetch the countries
//     const countries = await query;

//     // Return the response in the expected format
//     return res.json({
//       success: 0,
//       message: "Countries fetched successfully.",
//       data: countries,
//     });
//   } catch (e) {
//     console.error(e);
//     return res.status(500).json({
//       success: false,
//       message: "Server Error.",
//       error: e.message,
//     });
//   }
// };
exports.country = async (req, res) => {
    try {
        const { order, nopaginate, per_page } = req.body;
        let query = Country.find({}, 'id name iso3 iso2');

        // Handle ordering
        if (order && (order === 'asc' || order === 'desc')) {
            query = query.sort({ id: order });
        } else {
            query = query.sort({ name: 'asc' });
        }
        if (nopaginate == '1') {
            query = query;
        } else {
            let page = parseInt(req.query.page) || 1;
            let perPage = parseInt(per_page) || 20;
            query = query.skip((page - 1) * perPage).limit(perPage);
        }
        const countries = await query.exec();
        return res.json({
            success: 0,
            message: 'Countries get successfully.',
            data: countries,
        });

    } catch (err) {
        return res.status(500).json({
            success: 2,
            message: 'Server Error.',
            error: err.message,
        });
    }
};