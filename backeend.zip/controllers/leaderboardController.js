const Trade = require("../models/Trade");
const userWallet = require("../models/UserWallet");
const responseHelper = require("../utils/responseHelper");
const Payouts = require("../models/Payouts");
const User = require("../models/User");
const mongoose = require("mongoose");
const AccountSize = require("../models/AccountSize");

// winners  api calling....//
exports.getWinner = async (req, res) => {
  try {
    const leaderBoardData = await Trade.find({
      profit: { $ne: 0 },
      position: "close",
    })
      .populate({
        path: "user_wallet_id",
        model: "UserWallet",
        populate: {
          path: "account_size_id",
          model: "AccountSize",
          select: "limit",
        },
      })
      .populate({ path: "symbol_id", model: "Symbol" })
      .exec();

    const groupedData = leaderBoardData.reduce((acc, item) => {
      const userWallet = item.user_wallet_id;
      if (userWallet && item.symbol_id) {
        acc.push({
          id: item.id,
          first_name: userWallet.first_name || "N/A",
          last_name: userWallet.last_name || "N/A",
          account_balance: userWallet.balance || 0,
          account_size: userWallet.account_size_id?.limit || 0, // Updated to fetch the nested `limit`
          symbol_name: item.symbol_id.name || "Unknown",
          open_price: item.open_price || 0,
          close_price: item.close_price || 0,
          close_date: item.close_date ? item.close_date.toISOString() : null,
          country: userWallet.country_code || "",
          side: item.side || null,
          profit: item.profit.toLocaleString("en-US", {
            minimumFractionDigits: 2,
          }),
          profit_percentage: (
            (item.profit / (userWallet.account_size_id?.limit || 1)) *
            100
          ).toLocaleString("en-US", {
            minimumFractionDigits: 2,
          }),
        });
      }
      return acc;
    }, []);

    groupedData.sort((a, b) => parseFloat(b.profit_percentage) - parseFloat(a.profit_percentage));

    const topResults = groupedData.slice(0, 3);

    return responseHelper.sendResponse(
      res,
      "Challenge requests fetched successfully.",
      topResults
    );
  } catch (error) {
    console.error("Error in getWinner:", error);
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

exports.getBestAccount = async (req, res) => {
  try {
    const accountSizeFilter = req.body.account_size || 0;
    const isFilter = req.body.is_filter || 0;

    // Fetch trades with necessary filters
    let trades = await Trade.find({
      profit: { $gt: 0 },
      position: "close",
    })
      .populate({
        path: "user_wallet_id",
        model: "UserWallet",
        match: { account_status: "real" },
        populate: [
          { path: "user_id", model: "User" },
          { path: "account_size_id", model: "AccountSize" },
        ],
      })
      .populate({
        path: "symbol_id",
        select: "name",
      });


    if (isFilter === 1 && accountSizeFilter !== 0) {
      trades = trades.filter(
        (trade) =>
          trade.user_wallet_id?.account_size_id?.limit === parseFloat(accountSizeFilter)
      );
    }

    // Aggregate and group trades
    const groupTrades = groupAndAggregateSummaryTrades(trades, 0, 10);

    // Return the response
    return res.status(200).json({
      success: 0,
      data: groupTrades,
      message: "Leaderboard data retrieved successfully.",
    });
  } catch (err) {
    console.error("Error in getBestAccount:", err);
    return res.status(500).json({
      success: 2,
      message: "Server Error",
      error: err.message,
    });
  }
};

function groupAndAggregateSummaryTrades(trades, skip = 0, limit = null) {
  const groupedData = {};

  trades.forEach((trade) => {
    const userWalletID = trade.user_wallet_id?.id;

    if (!userWalletID) {
      return;
    }

    const accountSizeLimit = trade.user_wallet_id?.account_size_id?.limit || 0;
    const accountBalance = trade.user_wallet_id?.balance || 0;
    const firstName = trade.user_wallet_id?.user_id?.first_name || "Unknown";
    const lastName = trade.user_wallet_id?.user_id?.last_name || "Unknown";
    const countryCode = trade.user_wallet_id?.user_id?.country_code || "";

    if (!groupedData[userWalletID]) {
      groupedData[userWalletID] = {
        profit: 0,
        id: userWalletID,
        first_name: firstName,
        last_name: lastName,
        account_balance: accountBalance,
        account_size: accountSizeLimit,
        symbol_name: trade.symbol_id?.name || "Unknown",
        open_price: trade.open_price || 0,
        close_price: trade.close_price || 0,
        close_date: trade.close_date ? trade.close_date.toISOString() : null,
        // country: countryCode,
        side: trade.side || null,
      };
    }

    const profit = accountBalance > accountSizeLimit
      ? accountBalance - accountSizeLimit
      : 0;
    const profitPercentage = accountSizeLimit > 0
      ? (profit / accountSizeLimit) * 100
      : 0;

    groupedData[userWalletID].profit = profit > 0
      ? profit.toLocaleString("en-US", { minimumFractionDigits: 2 })
      : "0.00";
    groupedData[userWalletID].profit_percentage = profitPercentage > 0
      ? profitPercentage.toFixed(2)
      : "0.00";
  });

  let groupedArray = Object.values(groupedData).filter(
    (item) => parseFloat(item.profit.replace(/,/g, "")) > 0
  );
  groupedArray.sort((a, b) =>
    parseFloat(b.profit_percentage) - parseFloat(a.profit_percentage)
  );

  if (skip > 0) {
    groupedArray = groupedArray.slice(skip);
  }

  if (limit !== null) {
    groupedArray = groupedArray.slice(0, limit);
  }

  return groupedArray;
}

exports.getWinnerList = async (req, res) => {
  try {
    const trades = await Trade.find({
      profit: { $ne: 0 },
    })
      .populate({
        path: "user_wallet_id",
        populate: [
          {
            path: "user_id",
            model: "User",
          },
          {
            path: "account_size_id",
            model: "AccountSize",
          },
        ],
      })
      .populate("symbol_id", "name")
      .lean();

    const groupedData = trades.reduce((acc, trade) => {
      const walletId = trade.user_wallet_id._id.toString();
      if (!acc[walletId]) {
        acc[walletId] = {
          user: trade.user_wallet_id.user_id,
          user_wallet: trade.user_wallet_id,
          account_size: trade.user_wallet_id.account_size_id,
          symbol: trade.symbol_id,
          totalProfit: 0,
        };
      }
      acc[walletId].totalProfit += trade.profit;
      return acc;
    }, {});

    const leaderBoardData = Object.values(groupedData)
      .sort((a, b) => b.totalProfit - a.totalProfit)
      .slice(0, 3);

    const formattedData = leaderBoardData.map((item) => ({
      user_id: item.user._id,
      first_name: item.user.first_name,
      last_name: item.user.last_name,
      country_code: item.user.country_code,
      account_balance: item.user_wallet.balance,
      account_size_limit: item.account_size.limit,
      total_profit: item.totalProfit.toFixed(2),
      symbol_name: item.symbol_id.name,
    }));


    return responseHelper.sendResponse(res, "Challenge requests fetched successfully.", formattedData);
  } catch (error) {
    console.error("Error in getWinnerList:", error);
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};
async function getFastestEvolution() {
  const fastestEvolutionData = await userWallet.findOne({}).sort({ createdAt: 1 });
  return fastestEvolutionData;
}
// Best Account in Profit API calling.....//
exports.getBestAccountInProfit = async (req, res) => {
  try {
    const { account_size } = req.query;

    let query = {
      profit: { $ne: 0 },
      position: "close",
    };

    // Apply account size filter if provided
    if (accountSizeFilter && accountSizeFilter !== 0) {
      query = {
        ...query,
        "user_wallet_id.account_size_id.limit": parseInt(account_size, 10),
      };
    }

    const trades = await Trade.find(query)
      .populate({
        path: "user_wallet",
        populate: [
          {
            path: "user_id",
            model: "User",
          },
          {
            path: "account_size_id",
            model: "AccountSize",
          },
        ],
      })
      .populate("symbol_id", "name")
      .lean();

    const groupedData = trades.reduce((acc, trade) => {
      const walletId = trade.user_wallet_id._id.toString();
      if (!acc[walletId]) {
        acc[walletId] = {
          user: trade.user_wallet_id.user_id,
          user_wallet: trade.user_wallet_id,
          account_size: trade.user_wallet_id.account_size_id,
          symbol: trade.symbol_id,
          totalProfit: 0,
        };
      }
      acc[walletId].totalProfit += trade.profit;
      return acc;
    }, {});

    const leaderBoardData = Object.values(groupedData)
      .sort((a, b) => b.totalProfit - a.totalProfit)
      .slice(0, 10);

    const formattedData = leaderBoardData.map((item) => ({
      user_id: item.user._id,
      first_name: item.user.first_name,
      last_name: item.user.last_name,
      country_code: item.user.country_code,
      account_balance: item.user_wallet.balance,
      account_size: item.account_size.limit,
      // account_size: userWallet.account_size || 0,
      total_profit: item.totalProfit.toFixed(2),
      symbol_name: item.symbol_id.name,
    }));

    return responseHelper.sendResponse(res, "Top accounts fetched successfully.", formattedData);
  } catch (error) {
    console.error("Error in getBestAccountInProfit:", error);
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

exports.getAccountSizeData = async (req, res) => {
  try {
    const accountSizeData = await AccountSize.find({ status: "active" })
      .sort({ limit: 1 })
      .exec();

    return responseHelper.sendResponse(
      res,
      "Challenge requests fetched successfully.",
      accountSizeData
    );
  } catch (error) {
    // Handle server errors
    console.error("Error in getAccountSizeData:", error);
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};


exports.getLeaderBoardFirstBlockList = async (req, res) => {
  try {
    const trades = await Trade.find({
      profit: { $ne: 0 },
      position: "close",
    })
      .populate({
        path: "user_wallet_id",
        match: { account_status: "real" },
        select: "balance account_size_id account_status user_id account_number",
        populate: [
          {
            path: "user_id",
            select: "first_name last_name email",
          },
          {
            path: "account_size_id",
            select: "limit",
          },
        ],
      })
      .lean();

    const groupedData = trades.reduce((acc, trade) => {
      const userWallet = trade.user_wallet_id;

      if (userWallet && userWallet.account_size_id) {
        const totalProfit = userWallet.balance - userWallet.account_size_id.limit;
        const totalProfitTrades = trade.profit > 0 ? 1 : 0;
        const totalTrades = 1;

        acc.push({
          totalProfitTrades,
          total_trade: totalTrades,
          user_name: `${userWallet.user_id.first_name} ${userWallet.user_id.last_name}`,
          email: userWallet.user_id.email,
          account_size: userWallet.account_size_id.limit,
          balance: userWallet.balance,
          account_number: userWallet.account_number,
          total_profit: totalProfit > 0 ? totalProfit.toFixed(2) : totalProfit.toString(),
          win_ratio: ((totalProfitTrades / totalTrades) * 100).toFixed(2),
        });
      }
      return acc;
    }, []);

    const highestWinRatio = groupedData.sort((a, b) => b.win_ratio - a.win_ratio)[0] || null;

    const payouts = await Payouts.find({ payment_status: "approved" })
      .populate({
        path: "user_wallet_id",
        populate: [
          {
            path: "user_id",
            select: "first_name last_name",
          },
          {
            path: "account_size_id",
            select: "limit",
          },
        ],
      })
      .lean();

    const groupedPayouts = payouts.reduce((acc, payout) => {
      const userWallet = payout.user_wallet_id;

      if (userWallet) {
        acc.push({
          user_name: `${userWallet.user_id.first_name} ${userWallet.user_id.last_name}`,
          account_size: userWallet.account_size_id.limit,
          newpayout: payout.amount.toFixed(2),
        });
      }
      return acc;
    }, []);

    const highestPayout = groupedPayouts.sort((a, b) => b.total_payout - a.total_payout)[0] || null;

    const fastestEvolutionData = await getFastestEvolution();

    const data = {
      highest_win_ratio: highestWinRatio || {
        totalProfitTrades: 0,
        total_trade: 0,
        user_name: "",
        email: "",
        account_size: 0,
        balance: 0,
        account_number: 0,
        total_profit: "0.00",
        win_ratio: "0.00",
      },
      highest_payout: highestPayout || {
        user_name: "",
        account_size: "0",
        newpayout: "0.00",
      },
      fastest_evolution: fastestEvolutionData?.fastestTime || "0d 0h 0m 0s",
      other_fastest_evalution_data: 0,
    };


    return responseHelper.sendResponse(res, "Data fetched successfully.", data);
  } catch (error) {
    console.error("Error in getLeaderBoardFirstBlockList:", error);
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};
