const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const Admin = require("../../../models/Admin");
const express = require("express");
const { error } = require("winston");

exports.index = async (req, res) => {
    const email = req.cookies.admin_email || "";
    const password = req.cookies.admin_password || "";
    const remember = req.cookies.admin_remember || false;

    res.render("admin/auth/login", { email, password, remember });
};


exports.login = async (req, res) => {
    try {
        const { email, password, remember } = req.body;

        // Validate input
        if (!email || !password) {
            return res.status(400).json({ error: "Email and password are required." });
        }

        // Find admin by email
        const admin = await Admin.findOne({ email });
        if (!admin) {
            return res.status(401).json({ error: "These credentials do not match." });
        }

        // Check password
        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(401).json({ error: "These credentials do not match." });
        }

        // Generate JWT token
        const token = jwt.sign({ id: admin.id, email: admin.email }, process.env.JWT_SECRET, {
            expiresIn: "12h",
        });

        // Remove password cookies (because passwords should NOT be stored in cookies)
        res.clearCookie("admin_password");

        // Redirect based on email
        return res.json({ token, redirect: email === "salesreport@fundedfirm.com" ? "/admin/sales-report" : "/admin/dashboard" });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: "Server error" });
    }
};

exports.logout = async (req, res) => {
    try {
        // Clear authentication cookies
        res.clearCookie("token");
        res.clearCookie("admin_token");
        res.clearCookie("admin_email");
        res.clearCookie("admin_password");
        res.clearCookie("admin_remember");

        return res.status(200).json({ success: 1, message: "Logout successful" });
    } catch (error) {
        return res.status(500).json({ success: 0, message: "Server error", error: error.message });
    }
};
