const moment = require('moment');
const Payouts = require('../../../models/Payouts');
const UserWallet = require('../../../models/UserWallet');
const AccountSize = require('../../../models/AccountSize');
const PaymentMethod = require('../../../models/PaymentMethod');


exports.index = async (req, res) => {
    try {
        const accountSizes = await AccountSize.find()
            .select('_id user_id account_type_id user_wallet_id created_at updated_at')
            .sort({ limit: 'asc' });

        const paymentMethods = await PaymentMethod.find().sort({ name: 'asc' });

        // Format the account sizes' limits
        accountSizes.forEach(accountSize => {
            accountSize.formatted_limit = formatNumber(accountSize.limit);
        });

        res.render('admin.report.index', { accountSizes, paymentMethods });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getData = async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const startDate = start_date ? moment(start_date, 'MM/DD/YYYY').startOf('day').toDate() : null;
        const endDate = end_date ? moment(end_date, 'MM/DD/YYYY').endOf('day').toDate() : null;

        let userWalletQuery = UserWallet.find({ account: 'mt5', mt5_type: { $ne: 'real' }, account_request_id: { $ne: null } });
        let payoutQuery = Payouts.find({ payment_status: 'approved' });
        let payoutAffiliateQuery = Payouts.find({ payment_status: 'approved', payout_type: 'affiliate' });

        if (startDate && endDate) {
            userWalletQuery = userWalletQuery.where('created_at').gte(startDate).lte(endDate);
            payoutQuery = payoutQuery.where('created_at').gte(startDate).lte(endDate);
            payoutAffiliateQuery = payoutAffiliateQuery.where('created_at').gte(startDate).lte(endDate);
        }

        const userWalletData = await userWalletQuery;
        const payoutData = await payoutQuery;
        const payoutAffiliateData = await payoutAffiliateQuery;

        const totalSales = userWalletData.length;
        const totalWithdraw = payoutData.reduce((sum, payout) => sum + payout.amount, 0);
        const totalAffiliate = payoutAffiliateData.reduce((sum, payout) => sum + payout.amount, 0);

        res.json({
            totalSales,
            totalWithdraw,
            totalAffiliate
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.mydata = async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const startDate = start_date ? moment(start_date, 'YYYY-MM-DD').startOf('day').toDate() : null;
        const endDate = end_date ? moment(end_date, 'YYYY-MM-DD').endOf('day').toDate() : null;

        let userWalletQuery = UserWallet.find({ account: 'mt5', mt5_type: { $ne: 'real' }, account_request_id: { $ne: null } }).populate('accountSize accountRequest.paymentMethod');
        let payoutQuery = Payouts.find({ payment_status: 'approved' });
        let affiliateQuery = Payouts.find({ payment_status: 'approved', payout_type: 'affiliate' });

        if (startDate && endDate) {
            userWalletQuery = userWalletQuery.where('created_at').gte(startDate).lte(endDate);
            payoutQuery = payoutQuery.where('created_at').gte(startDate).lte(endDate);
            affiliateQuery = affiliateQuery.where('created_at').gte(startDate).lte(endDate);
        }



        const userWallets = await userWalletQuery;
        const payouts = await payoutQuery;
        const affiliates = await affiliateQuery;

        const dateCounts = groupByDate(userWallets, AccountSize);
        const payoutsByDate = groupByDate(payouts);
        const affiliatesByDate = groupByDate(affiliates);

        const paymentMethodCounts = groupByPaymentMethod(userWallets);

        const allDates = generateAllDates(startDate, endDate, dateCounts, payoutsByDate, affiliatesByDate, paymentMethodCounts, AccountSize, PaymentMethod);

        res.json({ dateCounts: allDates });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.export = async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const startDate = start_date ? moment(start_date, 'YYYY-MM-DD').startOf('day').toDate() : null;
        const endDate = end_date ? moment(end_date, 'YYYY-MM-DD').endOf('day').toDate() : null;

        let userWalletQuery = UserWallet.find({ account: 'mt5', mt5_type: { $ne: 'real' }, account_request_id: { $ne: null } }).populate('accountSize.accountType accountRequest.paymentMethod');
        let payoutQuery = Payouts.find({ payment_status: 'approved' });
        let affiliateQuery = Payouts.find({ payment_status: 'approved', payout_type: 'affiliate' });
        if (startDate && endDate) {
            userWalletQuery = userWalletQuery.where('created_at').gte(startDate).lte(endDate);
            payoutQuery = payoutQuery.where('created_at').gte(startDate).lte(endDate);
            affiliateQuery = affiliateQuery.where('created_at').gte(startDate).lte(endDate);
        }

        const userWallets = await userWalletQuery;
        const payouts = await payoutQuery;
        const affiliates = await affiliateQuery;

        const csvData = [];
        const headers = generateCsvHeaders(AccountSize, PaymentMethod);
        csvData.push(headers);

        const dateCounts = groupByDate(userWallets, AccountSize);
        const payoutsByDate = groupByDate(payouts);
        const affiliatesByDate = groupByDate(affiliates);
        const paymentMethodCounts = groupByPaymentMethod(userWallets);

        generateCsvRows(csvData, startDate, endDate, dateCounts, payoutsByDate, affiliatesByDate, paymentMethodCounts, AccountSize, PaymentMethod);

        const filename = `sales_report_${moment().format('YYYYMMDD_HHmmss')}.csv`;
        const fileContent = arrayToCsv(csvData);

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(fileContent);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const formatNumber = (number) => {
    return number >= 1000 ? `${(number / 1000).toFixed(0)}k` : number;
};

const groupByDate = (items, AccountSize = null) => {
    return items.reduce((result, item) => {
        const date = moment(item.created_at).format('YYYY-MM-DD');
        if (!result[date]) result[date] = [];
        result[date].push(item);

        if (AccountSize) {
            const accountSize = item.accountSize;
            if (!result[date][accountSize.id]) result[date][accountSize.id] = { count: 0, priceSum: 0 };
            result[date][accountSize.id].count++;
            result[date][accountSize.id].priceSum += accountSize.price;
        }

        return result;
    }, {});
};

const groupByPaymentMethod = (userWallets) => {
    return userWallets.reduce((result, wallet) => {
        const paymentMethodId = wallet.accountRequest.payment_method_id;
        if (!result[paymentMethodId]) result[paymentMethodId] = { count: 0, priceSum: 0 };
        result[paymentMethodId].count++;
        result[paymentMethodId].priceSum += wallet.accountSize.price;
        return result;
    }, {});
};

const generateAllDates = (startDate, endDate, dateCounts, payoutsByDate, affiliatesByDate, paymentMethodCounts, AccountSize, PaymentMethod) => {
    const allDates = {};
    for (let date = moment(startDate); date.isBefore(endDate); date.add(1, 'days')) {
        const formattedDate = date.format('YYYY-MM-DD');
        allDates[formattedDate] = {
            count: dateCounts[formattedDate]?.total_count || 0,
            payout: payoutsByDate[formattedDate] || 0,
            affiliate: affiliatesByDate[formattedDate] || 0,
        };

        AccountSize.forEach(accountSize => {
            allDates[formattedDate][`account_size_${accountSize.id}`] = dateCounts[formattedDate]?.[accountSize.id] || '-';
        });

        PaymentMethod.forEach(paymentMethod => {
            allDates[formattedDate][`payment_method_${paymentMethod.id}`] = paymentMethodCounts[formattedDate]?.[paymentMethod.id]?.count || '-';
        });
    }
    return allDates;
};

const generateCsvHeaders = (AccountSize, PaymentMethod) => {
    const headers = ['Date', 'Total Sales', 'Total Withdraw', 'Total Affiliate'];
    AccountSize.forEach(accountSize => {
        const formattedLimit = formatNumber(accountSize.limit);
        headers.push(`${formattedLimit} (${accountSize.accountType.step})`);
    });
    PaymentMethod.forEach(paymentMethod => {
        headers.push(`${paymentMethod.name}`);
    });
    return headers;
};

const generateCsvRows = (csvData, startDate, endDate, dateCounts, payoutsByDate, affiliatesByDate, paymentMethodCounts, AccountSize, PaymentMethod) => {
    for (let date = moment(startDate); date.isBefore(endDate); date.add(1, 'days')) {
        const row = [];
        const formattedDate = date.format('YYYY-MM-DD');
        row.push(formattedDate);

        row.push(dateCounts[formattedDate]?.total_count || 0);
        row.push(payoutsByDate[formattedDate] || 0);
        row.push(affiliatesByDate[formattedDate] || 0);

        AccountSize.forEach(accountSize => {
            row.push(dateCounts[formattedDate]?.[accountSize.id]?.count || '-');
        });

        PaymentMethod.forEach(paymentMethod => {
            row.push(paymentMethodCounts[formattedDate]?.[paymentMethod.id]?.count || '-');
        });

        csvData.push(row);
    }
};

const arrayToCsv = (data) => {
    return data.map(row => row.join(',')).join('\n');
};
