
const AccountRequest = require('../../../models/AccountRequest');
const User = require('../../../models/User');
const Currency = require('../../../models/Currency');
const UserWallet = require('../../../models/UserWallet');
const TradeGroup = require('../../../models/TradeGroup');
const Mt5Service = require('../../../services/mt5Service');
const mailService = require('../../../services/emailService');
const Leverage = require('../../../models/Leverage');
const PasswordHelper = require('../../../helpers/PasswordHelper');
const { Op } = require('sequelize');
const mt5Service = new Mt5Service();
const moment = require('moment');
const mongoose = require('mongoose');
const logger = require('../../../helpers/logger');


exports.index = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;
        const search = req.query.search || '';

        // Search filter logic
        const searchFilter = search
            ? {
                $or: [
                    { 'user_id.first_name': { $regex: search, $options: 'i' } },
                    { 'user_id.last_name': { $regex: search, $options: 'i' } },
                    { 'user_id.email': { $regex: search, $options: 'i' } },
                ],
            }
            : {};

        const [accountRequests, totalCount] = await Promise.all([
            AccountRequest.find(searchFilter)
                .populate({
                    path: 'user_id',
                    select: 'email first_name last_name',
                })
                .sort({ created_at: -1 })
                .skip(skip)
                .limit(limit),
            AccountRequest.countDocuments(searchFilter),
        ]);

        res.json({
            success: true,
            data: accountRequests,
            total: totalCount,
            page,
            limit,
        });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server Error', error: err.message });
    }
};

// exports.index = async (req, res) => {
//     try {
//         const page = parseInt(req.query.page) || 1;
//         const limit = parseInt(req.query.limit) || 10;
//         const search = req.query.search || "";

//         const match = {};

//         if (search) {
//             match.$or = [
//                 { first_name: { $regex: search, $options: "i" } },
//                 { last_name: { $regex: search, $options: "i" } },
//                 { email: { $regex: search, $options: "i" } },
//                 { transaction_id: { $regex: search, $options: "i" } },
//             ];
//         }

//         const query = AccountRequest.find(match)
//             .populate({
//                 path: "user_id",
//                 model: "User",
//                 select: "first_name last_name email phone country country_code country_name",
//             })
//             .populate("account_type_id", "name")
//             .populate("account_size_id", "name")
//             .populate("platform_id", "name")
//             .populate("payment_method_id", "name")
//             .populate("country_id", "name")
//             .populate("coupon_id", "code")
//             .sort({ created_at: -1 })
//             .skip((page - 1) * limit)
//             .limit(limit);

//         const [data, total] = await Promise.all([
//             query.exec(),
//             AccountRequest.countDocuments(match),
//         ]);
//         res.json({
//             success: true,
//             message: "Account Requests fetched successfully",
//             data,
//             pagination: {
//                 total,
//                 page,
//                 limit,
//                 pages: Math.ceil(total / limit),
//             },
//         });

//     } catch (err) {
//         console.error("AccountRequest fetch error:", err);
//         res.status(500).json({
//             success: false,
//             message: "Server Error",
//         });
//     }
// };


exports.show = async (req, res) => {
    try {
        const accountRequest = await AccountRequest.findOne({ _id: req.params.id })
            .populate({
                path: 'user_id',
                select: 'email first_name last_name'
            })
            .populate({
                path: 'payment_method_id',
                select: '_id name status image deposit_address qr_code_image account_name account_number bank_name ifsc_code'
            })
            .populate({
                path: 'account_type_id',
                select: '_id name step created_at updated_at'
            })
            .populate({
                path: 'account_size_id',
                select: '_id name limit min_trade_days profit_target max_overall_loss max_daily_loss price status created_at updated_at',
                populate: {
                    path: 'account_type_id',
                    select: '_id name step created_at updated_at'
                }
            })
            .lean();

        if (!accountRequest) {
            return res.status(404).json({ success: false, message: "Account request not found" });
        }

        res.json({ success: true, data: accountRequest });

    } catch (err) {
        console.error("Error fetching account request:", err.message);
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
}




exports.approve = async (req, res) => {
    try {
        const { status, comment } = req.body;
        const application = await AccountRequest.findById(req.params.id)
            .populate('account_type_id')
            .populate('account_size_id');

        if (!application) {
            return res.status(404).json({ success: false, message: "Request not found" });
        }

        if (application.account_status !== 'pending') {
            return res.status(400).json({ success: false, message: "Request already processed" });
        }

        const user = await User.findById(application.user_id);
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }

        if (status === 'approved') {
            const currency = await Currency.findOne({ code: 'USD' });
            if (!currency) {
                return res.status(400).json({ success: false, message: "Currency not found" });
            }

            const startAmount = application.account_size_id?.limit || 0; // Ensure it's defined
            const leverage = await Leverage.findOne({ value: '100' });
            const tradeGroup = await TradeGroup.findOne();
            if (!tradeGroup) {
                return res.status(500).json({ success: false, message: "Trade group not found" });
            }

            const getSteps = application.account_type_id?.step === "1 step" ? "S1" :
                application.account_type_id?.step === "2 step" ? "S2" : "HF";

            let accountName = `${application.first_name}-FundedFirm-${getSteps}`;
            if (application.account_type_id?.step === '2 step') {
                accountName += '/P1';
            }

            const iPassword = PasswordHelper.generateRandomPassword(12);
            const mPassword = PasswordHelper.generateRandomPassword(12);

            const mt5AccountData = {
                accountid: 0,
                type: 0,
                platform: 0,
                currency: currency.name,
                server: "",
                group: tradeGroup.name,
                name: accountName,
                email: user.email,
                phone: user.phone_number,
                country: application.address_country_name || '',
                city: application.city,
                address: "",
                balance: 0,
                mPassword,
                iPassword,
                leverage: leverage ? leverage.value : 100
            };

            // Create MT5 Account
            const response = await mt5Service.createAccount(mt5AccountData);
            if (!response || !response.user) {
                return res.status(500).json({ success: false, message: "Error creating MT5 account" });
            }

            // Prepare Wallet Data
            const input = {
                user_id: application.user_id,
                mt5_type: 'demo',
                title: application.title,
                first_name: application.first_name,
                last_name: application.last_name,
                city: application.city,
                postal_code: application.postal_code,
                address_country_id: application.address_country_id,
                country_id: application.country_id,
                account_type_id: application.account_type_id?._id || application.account_type_id,
                account_size_id: application.account_size_id?._id || application.account_size_id,
                not_us_residence: application.not_us_residence,
                platform_id: application.platform_id,
                payment_method_id: application.payment_method_id,
                account: 'mt5',
                account_status: 'not_passed',
                account_request_id: application._id,
                currency: currency.name,
                currency_id: currency._id,
                favourite: false,
                fiat: false,
                enabled: true,
                status: 'active',
                balance: parseFloat(startAmount),
                available_balance: parseFloat(startAmount),
                on_hold_balance: 0.0,
                equity: parseFloat(startAmount),
                free_funds: parseFloat(startAmount),
                credit: 0,
                archived: false,
                leverage_id: leverage?._id || null,
                approve_datetime: new Date(),
                account_number: response.user.accountid,
                code: response.user.accountid,
                investor_password: response.user.iPassword,
                master_password: response.user.mPassword,
            };

            // Deposit Balance to MT5
            const balanceDepositInMT5 = {
                loginid: response.user.accountid,
                amount: input.balance,
                txnType: 0,
                description: '',
                comment: 'DEPOSIT - CRM',
            };
            await mt5Service.updateBalance(balanceDepositInMT5);

            // Create User Wallet
            const userWallet = new UserWallet(input);
            await userWallet.save();

            // Send Approval Email (Ensure mailService is defined)
            if (typeof mailService !== "undefined") {
                await mailService.sendApprovalEmail(user.email, input.account_number, input.master_password, input.investor_password);
            }

            application.account_status = status;
            await application.save();

            return res.json({ success: true, message: "Account approved successfully" });
        } else {
            application.account_status = status;
            await application.save();

            // Send Rejection Email
            if (typeof mailService !== "undefined") {
                await mailService.sendRejectionEmail(user.email, comment);
            }

            return res.json({ success: true, message: "Account rejected successfully" });
        }
    } catch (err) {
        console.error("Error processing approval:", err);
        return res.status(500).json({ success: false, message: "Error processing approval", error: err.message });
    }
};

exports.data = async (req, res) => {
    try {
        // Get DataTables draw parameter (optional)
        const draw = req.query.draw || "1";
        // Pagination parameters: page (default 1) and limit (default 10)
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;
        // Get search term; trim it and treat empty string as undefined
        const searchQuery = req.query.search && req.query.search.trim();

        // Base query: Only non-rejected records
        const baseQuery = { account_status: { $ne: 'rejected' } };

        // If no search term is provided, use native pagination with skip/limit
        if (!searchQuery) {
            // Count matching records
            const totalRecords = await AccountRequest.countDocuments(baseQuery);

            // Query the database with skip and limit
            let applications = await AccountRequest.find(baseQuery)
                .populate({
                    path: 'user_id',
                    select: 'email first_name last_name'
                })
                .sort({ created_at: -1 })
                .skip(skip)
                .limit(limit);

            // Map each document to add top-level fields for DataTables display
            applications = applications.map((app, idx) => {
                const appObj = app.toObject({ virtuals: true });
                if (appObj.user_id) {
                    appObj.user_email = appObj.user_id.email || "-";
                    const fullName = `${appObj.user_id.first_name || ""} ${appObj.user_id.last_name || ""}`.trim();
                    appObj.user = fullName || "-";
                } else {
                    appObj.user_email = "-";
                    appObj.user = "-";
                }
                // Add a row index
                appObj.DT_RowIndex = skip + idx + 1;
                return appObj;
            });

            return res.json({
                draw,
                recordsTotal: totalRecords,
                recordsFiltered: totalRecords,
                totalPages: Math.ceil(totalRecords / limit),
                data: applications
            });
        }

        // When a search term exists, use an aggregation pipeline for filtering and pagination.
        const search = searchQuery.toLowerCase();
        const aggregationPipeline = [
            { $match: baseQuery },
            {
                $lookup: {
                    from: 'users', // ensure this matches your actual collection name for users
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            { $unwind: { path: '$user', preserveNullAndEmptyArrays: true } },
            // Add fields for easier search and display
            {
                $addFields: {
                    user_email: { $ifNull: ["$user.email", "-"] },
                    user: {
                        $trim: {
                            input: {
                                $concat: [
                                    { $ifNull: ["$user.first_name", ""] },
                                    " ",
                                    { $ifNull: ["$user.last_name", ""] }
                                ]
                            }
                        }
                    }
                }
            },
            // Filter by search term on several fields
            {
                $match: {
                    $or: [
                        { account_status: { $regex: search, $options: 'i' } },
                        { user_email: { $regex: search, $options: 'i' } },
                        { user: { $regex: search, $options: 'i' } },
                        { created_at: { $regex: search, $options: 'i' } }
                    ]
                }
            },
            { $sort: { created_at: -1 } },
            // Facet to get both paginated data and the total count
            {
                $facet: {
                    data: [
                        { $skip: skip },
                        { $limit: limit }
                    ],
                    totalCount: [
                        { $count: "count" }
                    ]
                }
            }
        ];

        const results = await AccountRequest.aggregate(aggregationPipeline);
        const data = results[0].data;
        const totalRecords = results[0].totalCount[0] ? results[0].totalCount[0].count : 0;

        // Add DT_RowIndex field to each document
        const dataWithIndex = data.map((item, idx) => {
            item.DT_RowIndex = skip + idx + 1;
            return item;
        });

        return res.json({
            draw,
            recordsTotal: totalRecords,
            recordsFiltered: totalRecords,
            totalPages: Math.ceil(totalRecords / limit),
            data: dataWithIndex
        });
    } catch (err) {
        return res.status(500).json({
            draw: req.query.draw || "1",
            recordsTotal: 0,
            recordsFiltered: 0,
            totalPages: 0,
            data: [],
            error: err.message
        });
    }
};



exports.accountBreach = async (req, res) => {
    const { userWalletID, type } = req.body;

    try {
        const result = await accountBreachCallingFunction(mt5Service, userWalletID, type);
        if (result === 1) {
            return res.status(200).json({ success: 1, message: 'Account disabled successfully.' });
        }
        return res.status(404).json({ success: 0, message: 'User wallet not found or already disabled.' });
    } catch (err) {
        logger.error('Failed to account breach: ' + err.message);
        return res.status(500).json({ success: 0, message: 'Server Error' });
    }
};

async function accountBreachCallingFunction(mt5Service, userWalletID, type) {
    const userWallet = await UserWallet.findOne({
        _id: new mongoose.Types.ObjectId(userWalletID),
        account: 'mt5',
        status: 'active',
        account_status: { $ne: 'disabled' },
    }).populate('accountSize');

    if (!userWallet) {
        logger.warn('User wallet not found or already disabled');
        return 0;
    }

    // Date range
    const endDate = moment().add(1, 'day');
    const startDate = moment(endDate).subtract(720, 'hours');

    const mt5AccountData = {
        loginId: userWallet.account_number,
        startDate: startDate.format('YYYY-MM-DD HH:mm:ss'),
        endDate: endDate.format('YYYY-MM-DD HH:mm:ss'),
    };

    const allTrades = await mt5Service.getPosition(mt5AccountData);
    logger.info(`History of ${userWallet.account_number}`);

    let tradeCount = 0;
    let disabledTradeCount = 0;

    if (allTrades?.openPositions?.length) {
        const closeTradePromises = allTrades.openPositions
            .filter(r => r.type === 'BUY' || r.type === 'SELL')
            .map(async (r) => {
                const closeData = {
                    loginid: r.loginid,
                    positionId: r.positionid,
                    symbol: r.symbol,
                    volume: r.lotsize,
                    price: r.price,
                    type: r.type,
                    tp: r.tp,
                    sl: r.sl,
                    comment: 'Close Trade',
                };

                const response = await mt5Service.closeOpenTrade(closeData);
                logger.info(closeData);
                logger.info(response);

                if (response?.deal?.dealResult?.retCode === 'MT_RET_REQUEST_DONE') {
                    return true;
                } else {
                    logger.warn(`Trade close error ${r.position_id}`);
                    return false;
                }
            });

        const results = await Promise.all(closeTradePromises);
        tradeCount = results.length;
        disabledTradeCount = results.filter(Boolean).length;
    }

    // Disable MT5 Account
    const disableResponse = await mt5Service.setTradeDisable({
        loginId: userWallet.account_number,
        flag: true,
    });

    if (disableResponse?.retCode === 'MT_RET_OK') {
        const result = await UserWallet.findByIdAndUpdate(userWalletID, {
            account_status: 'disabled',
        });

        if (result) {
            const user = await User.findById(userWallet.user_id);
            await sendNotificationEmail(user, userWallet.account_number, type);
            return 1;
        } else {
            logger.error('Failed to update user wallet');
        }
    }

    return 1;
}

async function sendNotificationEmail(user, accountNumber, type) {
    const subjects = {
        daily: 'Account Violation - Daily Drawdown',
        max: 'Account Violation - Overall Drawdown',
        all: 'Account Violation - Hedging Breach',
    };

    const messages = {
        msg1:
            'We regret to inform you that you have violated one of our trading terms, which has resulted in the loss of your challenge. We understand that trading is a complex and ever-changing market, and setbacks are common. Please don’t feel discouraged. We encourage you to continue learning and growing as a trader.',
        msg2:
            'We encourage you to work on your strategy with a demo account and once you feel comfortable please come back and try us out again!',
    };

    const violations = {
        daily: 'Max Daily Drawdown',
        max: 'Max Overall Drawdown',
        all: 'Breached due to hedging',
    };

    if (!subjects[type]) {
        logger.error('Invalid breach type');
        return;
    }

    try {
        await mailService(
            user.email,
            subjects[type],
            {
                accountNumber,
                subject: subjects[type],
                msg1: messages.msg1,
                msg2: messages.msg2,
                violation: violations[type],
            },
            'accountDisabled' // Template name
        );
        logger.info(`Disabled account email sent to ${user.email}`);
    } catch (err) {
        logger.error('Failed to send email: ' + err.message);
    }
}





// restart manager....//
exports.restartManager = async (req, res) => {
    try {
        const response = await Mt5Service.restartManager();

        res.json({ success: 0, message: 'Manager restarted successfully' });
    } catch (err) {
        res.status(500).send('Error restarting manager');
    }
};
