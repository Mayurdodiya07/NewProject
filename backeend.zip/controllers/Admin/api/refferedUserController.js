const User = require('../../../models/User');
const UserWallet = require('../../../models/UserWallet');
const AccountSize = require('../../../models/AccountSize');
const AccountType = require('../../../models/AccountType');
// const { paginate } = require('../../../utils/paginate');


// exports.index = async (req, res) => {
//     try {
//         const users = await User.find().populate({ path: "referred_by", model: "User", select: "first_name last_name email" })


//         res.json({ success: true, users });
//     } catch (error) {
//         console.error("Error fetching referred users:", error);
//         res.status(500).json({ success: false, message: "Server Error", error: error.message });
//     }
// };
// exports.index = async (req, res) => {
//     try {
//         const page = parseInt(req.query.page) || 1;
//         const limit = parseInt(req.query.limit) || 10;
//         const skip = (page - 1) * limit;

//         const totalUsers = await User.countDocuments();

//         const users = await User.find()
//             .skip(skip)
//             .limit(limit)
//             .populate({ path: "referred_by", model: "User", select: "first_name last_name email" });

//         // Calculate referral_count and account_count for each user
//         const usersWithCounts = await Promise.all(users.map(async (user) => {
//             const referralCount = await User.countDocuments({ referred_by: user._id });
//             const accountCount = await UserWallet.countDocuments({
//                 user_id: user._id,
//                 account: { $ne: 'wallet' }
//             });

//             return {
//                 ...user.toObject(),
//                 referral_count: referralCount,
//                 account_count: accountCount,
//             };
//         }));

//         const totalPages = Math.ceil(totalUsers / limit);

//         res.json({
//             success: true,
//             users: usersWithCounts,
//             totalUsers,
//             totalPages,
//             currentPage: page,
//         });

//     } catch (error) {
//         console.error("Error fetching users with referral and account count:", error);
//         res.status(500).json({
//             success: false,
//             message: "Server Error",
//             error: error.message
//         });
//     }
// };
exports.index = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        let filter = {};

        if (req.query.dateRange) {
            const [startDate, endDate] = req.query.dateRange.split(" - ");

            // Convert to "YYYY-MM-DD" for comparison
            const start = new Date(startDate.split("/").reverse().join("-"));
            const end = new Date(endDate.split("/").reverse().join("-"));
            end.setDate(end.getDate() + 1); // Include end date

            filter.created_at = { $gte: start, $lt: end };
        }

        const totalUsers = await User.countDocuments(filter);

        const users = await User.find(filter)
            .skip(skip)
            .limit(limit)
            .populate({
                path: "referred_by",
                model: "User",
                select: "first_name last_name email",
            });

        const usersWithCounts = await Promise.all(
            users.map(async (user) => {
                const referralCount = await User.countDocuments({ referred_by: user._id });
                const accountCount = await UserWallet.countDocuments({
                    user_id: user._id,
                    account: { $ne: "wallet" },
                });

                return {
                    ...user.toObject(),
                    referral_count: referralCount,
                    account_count: accountCount,
                };
            })
        );

        const totalPages = Math.ceil(totalUsers / limit);

        res.json({
            success: true,
            users: usersWithCounts,
            totalUsers,
            totalPages,
            currentPage: page,
        });

    } catch (error) {
        console.error("Error fetching users with filters:", error);
        res.status(500).json({
            success: false,
            message: "Server Error",
            error: error.message,
        });
    }
};


exports.show = async (req, res) => {
    try {
        const userId = req.params.id;
        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ error: 'User not found' });

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const referrals = await User.find({ referred_by: user._id, account: { $ne: 'wallet' } })
            .sort({ first_name: 1 }) // Default sorting
            .skip(skip)
            .limit(limit);

        const totalReferrals = await User.countDocuments({ referred_by: user._id });

        const walletIds = referrals.map(ref => ref._id);
        const wallets = await UserWallet.find({ user_id: { $in: walletIds }, account: { $ne: 'wallet' } });

        const referralsWithWallets = referrals.map(referral => {
            const wallet = wallets.find(w => w.user_id.toString() === referral._id.toString());
            return {
                id: referral._id,
                name: `${referral.first_name} ${referral.last_name}`,
                emailId: referral.email,
                accNumber: wallet?.account_number || 'N/A',
                accSize: wallet?.accountSize?.limit || 'N/A',
            };
        });

        res.json({
            referralsWithWallets,
            totalPages: Math.ceil(totalReferrals / limit),
            currentPage: page,
            totalItems: totalReferrals
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
    }
};


exports.getReferredUserData = async (req, res) => {
    try {
        const userId = req.params.id;
        const user = await User.findById(userId);
        if (!user) return res.status(404).send({ error: 'User not found' });

        // Query referred users with wallets
        let referralsQuery = UserWallet.find({
            user_id: { $in: await User.find({ referred_by: user._id }).distinct('_id') },
            account: { $ne: 'wallet' },
        }).populate('user').populate('accountSize');

        // Sorting logic
        const sortColumn = req.body.order?.[0]?.column || 0;
        const sortDirection = req.body.order?.[0]?.dir || 'asc';
        const columns = ['first_name', 'email', 'account_number', 'account_size'];

        if (sortColumn === 1) {
            referralsQuery = referralsQuery.sort({ 'user.first_name': sortDirection });
        } else if (sortColumn === 2) {
            referralsQuery = referralsQuery.sort({ 'user.email': sortDirection });
        } else if (sortColumn === 3) {
            referralsQuery = referralsQuery.sort({ account_number: sortDirection });
        } else if (sortColumn === 4) {
            referralsQuery = referralsQuery.sort({ 'accountSize.limit': sortDirection });
        }

        // Search handling
        if (req.body.search?.value) {
            const searchTerm = req.body.search.value;
            referralsQuery = referralsQuery.find({
                $or: [
                    { 'user.first_name': { $regex: searchTerm, $options: 'i' } },
                    { 'user.last_name': { $regex: searchTerm, $options: 'i' } },
                    { account_number: { $regex: searchTerm, $options: 'i' } },
                    { 'accountSize.limit': { $regex: searchTerm, $options: 'i' } },
                ],
            });
        }

        // Pagination
        const { page, limit } = paginate(req);
        const referrals = await referralsQuery.skip((page - 1) * limit).limit(limit);
        const totalCount = await referralsQuery.countDocuments();

        const data = referrals.map((wallet, index) => ({
            DT_RowIndex: index + 1,
            referred_user: `${wallet.user.first_name} ${wallet.user.last_name}`,
            email: wallet.user.email,
            account_number: wallet.account_number,
            account_size: wallet.accountSize ? wallet.accountSize.limit : 'N/A',
        }));

        res.json({
            data,
            recordsTotal: totalCount,
            recordsFiltered: totalCount,
        });
    } catch (error) {
        res.status(500).send({ error: 'Server Error' });
    }
};

exports.account = async (req, res) => {
    try {
        const userId = req.params.id;
        const user = await User.findById(userId);
        if (!user) return res.status(404).send({ error: 'User not found' });

        res.render('admin/referred-user/account', { user, id: userId });
    } catch (error) {
        res.status(500).send({ error: 'Server Error' });
    }
};
exports.dataNew = async (req, res) => {
    try {
        const { start_date: startDate, end_date: endDate } = req.query;

        // Find users without a referrer and with clients
        let query = User.find({ referred_by: null }).where('clients').exists(true);

        if (startDate && endDate) {
            query = query.where('created_at').gte(new Date(startDate)).lte(new Date(endDate));
        }

        const applications = await query.exec();

        const data = await Promise.all(
            applications.map(async (application, index) => {
                const referralCount = await User.countDocuments({ referred_by: application._id });

                const wallets = await UserWallet.find({ user_id: { $in: await User.find({ referred_by: application._id }).distinct('_id') } })
                    .where('account').ne('wallet')
                    .where('created_at').gte(new Date(startDate)).lte(new Date(endDate))
                    .exec();

                const walletPriceSum = await wallets.reduce(async (sum, wallet) => {
                    const accountSize = await AccountSize.findById(wallet.account_size_id);
                    if (!accountSize) return sum;

                    const accountType = await AccountType.findById(accountSize.account_type_id);
                    if (!accountType) return sum;

                    const percentage = accountType.step === '1 step' ? 10 : accountType.step === '2 step' ? 15 : 0;
                    return sum + accountSize.price * (percentage / 100);
                }, Promise.resolve(0));

                return {
                    id: application._id,
                    first_name: application.first_name,
                    last_name: application.last_name,
                    email: application.email,
                    referral_count: referralCount,
                    account_count: wallets.length,
                    wallet_price_sum: await walletPriceSum,
                };
            })
        );

        res.json({
            draw: req.body.draw,
            recordsTotal: data.length,
            recordsFiltered: data.length,
            data,
        });
    } catch (error) {
        res.status(500).json({ error: 'Server Error', details: error.message });
    }
};

exports.data = async (req, res) => {
    try {
        const { start_date: startDate, end_date: endDate } = req.query;

        // Base query: users without referrers and excluding "wallet" accounts
        let query = User.find({ referred_by: null, account: { $ne: 'wallet' } }).where('clients').exists(true);

        // Date range filter
        if (startDate && endDate) {
            query = query.where('created_at').gte(new Date(startDate)).lte(new Date(endDate));
        }

        // Search filter
        if (req.body.search?.value) {
            const search = req.body.search.value;
            query = query.where({
                $or: [
                    { first_name: new RegExp(search, 'i') },
                    { last_name: new RegExp(search, 'i') },
                    { email: new RegExp(search, 'i') },
                    {
                        $expr: {
                            $regexMatch: {
                                input: { $concat: ['$first_name', ' ', '$last_name'] },
                                regex: search,
                                options: 'i',
                            },
                        },
                    },
                ],
            });
        }

        const applications = await query.exec();

        // Referral, wallet counts, and wallet price sums
        const data = await Promise.all(
            applications.map(async (application, index) => {
                const referrals = await User.find({
                    referred_by: application._id,
                    account: { $ne: 'wallet' },
                });

                const wallets = await UserWallet.find({
                    user_id: { $in: referrals.map((r) => r._id) },
                    account: { $ne: 'wallet' },
                    account: 'mt5',
                    mt5_type: { $ne: 'real' },
                    $or: [
                        { parent_user_wallet_id: { $exists: false } },
                        { parent_user_wallet_id: '' },
                        { parent_user_wallet_id: 'null' },
                    ],
                })
                    .where('created_at')
                    .gte(new Date(startDate))
                    .lte(new Date(endDate))
                    .exec();

                const walletPriceSum = wallets.reduce(async (sum, wallet) => {
                    const accountSize = await AccountSize.findById(wallet.account_size_id);
                    if (!accountSize) return sum;

                    const accountType = await AccountType.findById(accountSize.account_type_id);
                    if (!accountType) return sum;

                    const percentage = accountType.step === '1 step' ? 10 : accountType.step === '2 step' ? 15 : 0;
                    return sum + accountSize.price * (percentage / 100);
                }, 0);

                return {
                    id: application._id,
                    DT_RowIndex: req.body.start + index + 1,
                    first_name: application.first_name,
                    last_name: application.last_name,
                    email: application.email,
                    referral_count: referrals.length,
                    account_count: wallets.length,
                    wallet_price_sum: walletPriceSum,
                    created_at: application.created_at,
                    action: `<a href="/admin/referred-user/${application._id}">View</a>`,
                };
            })
        );

        // Sorting
        const columns = ['created_at', 'first_name', 'email', 'referral_count', 'account_count', 'wallet_price_sum'];
        if (req.body.order) {
            const orderColumn = columns[req.body.order[0].column];
            const orderDirection = req.body.order[0].dir === 'asc' ? 1 : -1;
            data.sort((a, b) => (a[orderColumn] > b[orderColumn] ? orderDirection : -orderDirection));
        } else {
            data.sort((a, b) => b.created_at - a.created_at);
        }

        // Pagination
        const totalRecords = data.length;
        const perPage = parseInt(req.body.length, 10) || 10;
        const offset = parseInt(req.body.start, 10) || 0;
        const paginatedData = data.slice(offset, offset + perPage);

        return res.json({
            draw: req.body.draw,
            recordsTotal: totalRecords,
            recordsFiltered: totalRecords,
            data: paginatedData,
        });
    } catch (error) {
        res.status(500).json({ error: 'Server Error', details: error.message });
    }
};
