const News = require('../../../models/News');
const NewsCurrency = require('../../../models/NewsCurrency');
const Country = require('../../../models/Country');
const { validationResult } = require('express-validator');
const moment = require('moment');
const mongoose = require('mongoose');


// // Get all news
// exports.index = async (req, res) => {
//     res.render('admin/news/index');
// };


exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "", startDate, endDate } = req.query;
        const query = { deleted_at: null };

        // Search filter
        if (search) {
            query.$or = [
                { event_type: { $regex: search, $options: "i" } },
                { description: { $regex: search, $options: "i" } }
            ];
        }

        // Date range filter using moment
        if (startDate && endDate) {
            const start = moment(startDate, 'YYYY-MM-DD').startOf('day').toDate();
            const end = moment(endDate, 'YYYY-MM-DD').endOf('day').toDate();

            query.created_at = {
                $gte: start,
                $lte: end
            };
        }

        const totalRecords = await News.countDocuments(query);
        const newsData = await News.find(query)
            .populate("news_currency", "name code short_code")
            .sort({ created_at: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit))
            .lean();

        res.json({
            data: newsData,
            pagination: {
                total: totalRecords,
                page: parseInt(page),
                limit: parseInt(limit),
                totalPages: Math.ceil(totalRecords / limit)
            }
        });
    } catch (error) {
        console.error("News Index Error:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};


// Show single news item
exports.show = async (req, res) => {
    try {
        const news = await News.findById(req.params.id).populate("news_currency", "name code short_code");
        if (!news) return res.status(404).json({ error: "News not found" });

        res.json(news);
    } catch (error) {
        console.error("Error fetching news:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};


// Fetch news data with filters
exports.data = async (req, res) => {
    try {
        let query = { deleted_at: { $exists: false } };

        if (req.query.start_date && req.query.end_date) {
            query.date = {
                $gte: new Date(req.query.start_date),
                $lte: new Date(req.query.end_date)
            };
        }

        const news = await News.find(query).sort({ _id: -1 });

        res.json({
            data: news.map(item => ({
                ...item._doc,
                impact: item.impact.replace("_", " "),
                actual: item.actual.replace("_", " "),
                action: `
                    <a href="/admin/news/${item.id}" title="View">View</a>
                    <a href="/admin/news/edit/${item.id}" title="Edit">Edit</a>
                    <a href="#" onclick="deleteNews('${item.id}')" title="Delete">Delete</a>
                `
            }))
        });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

// Add news form
exports.add = async (req, res) => {
    try {
        const currencies = await NewsCurrency.find();
        res.json({ currencies });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


exports.store = async (req, res) => {
    try {
        // Validate request data
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        // Destructure request body
        const { event_type, currency_id, previous, forecast, actual, status, impact, description, date } = req.body;

        // Ensure currency_id is a valid ObjectId
        if (!currency_id || !mongoose.Types.ObjectId.isValid(currency_id)) {
            return res.status(400).json({ message: "Invalid currency_id" });
        }

        // Create a new News record
        const news = new News({
            event_type,
            currency_id: new mongoose.Types.ObjectId(currency_id),
            previous,
            forecast,
            actual,
            status,
            impact,
            description,
            date
        });

        await news.save(); // Save news to database

        res.status(201).json({ message: "News added successfully!", news });
    } catch (error) {
        res.status(500).json({ message: "Server Error: " + error.message });
    }
};


// Edit news form
exports.edit = async (req, res) => {
    try {
        const news = await News.findById(req.params.id);
        const newscurrency = await NewsCurrency.find();
        if (!news) return res.status(404).json({ message: "News not found" });

        res.json({
            news,
            newscurrency
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update news item
exports.update = async (req, res) => {
    try {
        const news = await News.findById(req.params.id);
        if (!news) return res.status(404).json({ message: "News not found" });

        Object.assign(news, req.body);
        await news.save();

        res.json({ message: "News updated successfully", news });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


// Restore soft deleted news
exports.restore = async (req, res) => {
    try {
        const news = await News.findOneWithDeleted({ _id: req.params.id });
        if (!news) return res.status(404).send('News not found');

        news.deleted_at = null;
        await news.save();
        res.redirect('/admin/news');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

// Soft delete news
exports.destroy = async (req, res) => {
    try {
        const news = await News.findById(req.params.id);
        if (!news) return res.status(404).json({ error: "News not found" });

        news.deleted_at = new Date();
        await news.save();

        return res.json({ success: "News deleted successfully" });
    } catch (error) {
        return res.status(500).json({ error: error.message || "Failed to delete news" });
    }
};

// Permanently delete news
exports.forceDelete = async (req, res) => {
    try {
        await News.findByIdAndDelete(req.params.id);
        res.redirect('/admin/news');
    } catch (error) {
        res.status(500).send(error.message);
    }
};


// updated
// const News = require('../../../models/News');
// const NewsCurrency = require('../../../models/NewsCurrency');
// const { validationResult } = require('express-validator');
// const mongoose = require('mongoose');

// // List news with pagination and search
// exports.index = async (req, res) => {
//     try {
//         const { page = 1, limit = 10, search = "" } = req.query;
//         const query = { deleted_at: null };

//         if (search) {
//             query.$or = [
//                 { event_type: { $regex: search, $options: "i" } },
//                 { description: { $regex: search, $options: "i" } }
//             ];
//         }

//         const totalRecords = await News.countDocuments(query);
//         const newsData = await News.find(query)
//             .populate("news_currency", "name code short_code")
//             .sort({ created_at: -1 })
//             .skip((page - 1) * limit)
//             .limit(parseInt(limit))
//             .lean();

//         res.json({
//             data: newsData,
//             totalPages: Math.ceil(totalRecords / limit),
//             currentPage: parseInt(page),
//         });
//     } catch (error) {
//         res.status(500).json({ message: "Internal Server Error" });
//     }
// };

// // Show a single news item
// exports.show = async (req, res) => {
//     try {
//         const news = await News.findById(req.params.id).populate("news_currency", "name code short_code");
//         if (!news) return res.status(404).json({ error: "News not found" });

//         res.json(news);
//     } catch (error) {
//         res.status(500).json({ error: "Internal Server Error" });
//     }
// };

// // Filtered data for UI (e.g., date range)
// exports.data = async (req, res) => {
//     try {
//         let query = { deleted_at: null };

//         if (req.query.start_date && req.query.end_date) {
//             query.date = {
//                 $gte: new Date(req.query.start_date),
//                 $lte: new Date(req.query.end_date)
//             };
//         }

//         const news = await News.find(query).sort({ created_at: -1 });

//         res.json({
//             data: news.map(item => ({
//                 ...item._doc,
//                 impact: item.impact?.replace("_", " "),
//                 actual: item.actual?.replace("_", " "),
//                 action: `
//                     <a href="/admin/news/${item._id}" title="View">View</a>
//                     <a href="/admin/news/edit/${item._id}" title="Edit">Edit</a>
//                     <a href="#" onclick="deleteNews('${item._id}')" title="Delete">Delete</a>
//                 `
//             }))
//         });
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// };

// // Add news (fetch currencies for form)
// exports.add = async (req, res) => {
//     try {
//         const currencies = await NewsCurrency.find();
//         res.json({ currencies });
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// };

// // Store new news entry
// exports.store = async (req, res) => {
//     try {
//         const errors = validationResult(req);
//         if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

//         const { event_type, currency_id, previous, forecast, actual, status, impact, description, date } = req.body;

//         if (!currency_id || !mongoose.Types.ObjectId.isValid(currency_id)) {
//             return res.status(400).json({ message: "Invalid currency_id" });
//         }

//         const news = new News({
//             event_type,
//             currency_id: new mongoose.Types.ObjectId(currency_id),
//             previous,
//             forecast,
//             actual,
//             status,
//             impact,
//             description,
//             date
//         });

//         await news.save();

//         res.status(201).json({ message: "News added successfully!", news });
//     } catch (error) {
//         res.status(500).json({ message: "Server Error: " + error.message });
//     }
// };

// // Edit news item (get data)
// exports.edit = async (req, res) => {
//     try {
//         const news = await News.findById(req.params.id);
//         const newscurrency = await NewsCurrency.find();

//         if (!news) return res.status(404).json({ message: "News not found" });

//         res.json({ news, newscurrency });
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// };

// // Update news
// exports.update = async (req, res) => {
//     try {
//         const news = await News.findById(req.params.id);
//         if (!news) return res.status(404).json({ message: "News not found" });

//         Object.assign(news, req.body);
//         await news.save();

//         res.json({ message: "News updated successfully", news });
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// };


// // Soft Delete
// exports.destroy = async (req, res) => {
//     try {
//         const news = await News.findById(req.params.id);
//         if (!news) return res.status(404).json({ message: 'News not found' });

//         news.deleted_at = new Date();
//         await news.save({ validateBeforeSave: false }); // ✅ Prevent schema errors

//         res.status(200).json({ message: 'News deleted successfully' });
//     } catch (error) {
//         console.error("Delete Error:", error);
//         res.status(500).json({ message: 'Server Error' });
//     }
// };


// // Restore
// exports.restore = async (req, res) => {
//     try {
//         const news = await News.findOne({ _id: req.params.id, deleted_at: { $exists: true } });
//         if (!news) return res.status(404).json({ message: 'News not found' });

//         news.deleted_at = undefined;
//         await news.save();

//         res.status(200).json({ message: 'News restored successfully' });
//     } catch (error) {
//         res.status(500).json({ message: 'Server Error' });
//     }
// };

// // Force Delete
// exports.forceDelete = async (req, res) => {
//     try {
//         await News.findByIdAndDelete(req.params.id);
//         res.status(200).json({ message: 'News permanently deleted successfully' });
//     } catch (error) {
//         res.status(500).json({ message: 'Server Error' });
//     }
// };
