exports.index = async (req, res) => {
    const models = {
        "Account Request": "AccountRequest",
        "Real Account Request": "RealAccountRequest",
        "User Wallet": "UserWallet",
        "Payouts": "Payouts",
        "User": "User",
        "Trade": "Trade",
        "Payment Method": "PaymentMethod",
        "Account Size": "AccountSize",
        "Account Type": "AccountType",
        "News Calendar": "News",
        "News Currency": "NewsCurrency",
        "Notification": "Notification",
        "Country": "Country",
        "Currency": "Currency",
    };

    res.render("/delete/index", { models });
};

exports.delete = async (req, res) => {
    const { model, id } = req.body;

    const validModels = [
        "AccountRequest",
        "RealAccountRequest",
        "UserWallet",
        "Payouts",
        "User",
        "Trade",
        "PaymentMethod",
        "AccountSize",
        "AccountType",
        "News",
        "NewsCurrency",
        "Notification",
        "Country",
        "Currency",
    ];

    if (!validModels.includes(model)) {
        return res.redirect("back").with("error", "Invalid model selected");
    }

    try {
        const Model = require(`./models/${model}`);
        const record = await Model.findByPk(id);
        if (!record) {
            return res.redirect("back").with("error", "Record not found");
        }
        await record.destroy();
        res.redirect("back").with("success", "Record deleted successfully");
    } catch (error) {
        console.error(error);
        res.redirect("back").with("error", "An error occurred while deleting");
    }
};

exports.getModelData = async (req, res) => {
    const { model, id } = req.body;

    try {
        const Model = require(`./models/${model}`);
        const record = await Model.findByPk(id);

        if (!record) {
            return res.status(404).json({ error: "Record not found" });
        }

        const data = record.toJSON();
        let output = '<div class="table-responsive"><table class="table table-bordered">';

        for (const key in data) {
            output += `<tr><td>${key}</td><td>${data[key]}</td></tr>`;
        }

        output += "</table></div>";

        res.json(output);
    } catch (error) {
        console.error(error);
        res.status(400).json({ error: "Invalid model selected" });
    }
};
