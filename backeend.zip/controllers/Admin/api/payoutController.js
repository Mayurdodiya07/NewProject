const moment = require('moment');
const { Op } = require('sequelize');
const User = require('../../../models/User');
const UserWallet = require('../../../models/UserWallet');
const Payouts = require('../../../models/Payouts');
const Trade = require('../../../models/Trade');
const PaymentMethod = require('../../../models/PaymentMethod');
const BalanceHistory = require('../../../models/AccountSize');
const sendEmail = require('../../../services/emailService');
const mongoose = require('mongoose');


// exports.index = async (req, res) => {
//     try {
//         const payouts = await Payouts.find()
//             .populate({
//                 path: 'user',
//                 select: 'first_name last_name email'
//             })
//             .populate({
//                 path: 'payment_method_id',
//                 model: 'PaymentMethod'
//             })
//             .populate({
//                 path: 'user_wallet_id',
//                 model: 'UserWallet'
//             })
//             .sort({ createdAt: -1 });

//         res.json({ success: true, data: payouts });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ success: false, message: 'Server Error' });
//     }
// };
exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "" } = req.query;

        const query = {};

        if (search) {
            query.$or = [
                { payment_status: { $regex: search, $options: 'i' } },
                { payout_type: { $regex: search, $options: 'i' } },
            ];
        }

        const totalItems = await Payouts.countDocuments(query);

        const payouts = await Payouts.find(query)
            .populate({
                path: 'user',
                select: 'first_name last_name email'
            })
            .populate({
                path: 'payment_method_id',
                model: 'PaymentMethod'
            })
            .populate({
                path: 'user_wallet_id',
                model: 'UserWallet'
            })
            .sort({ createdAt: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));

        res.json({
            success: true,
            data: payouts,
            totalItems,
            currentPage: parseInt(page),
            totalPages: Math.ceil(totalItems / limit),
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Server Error' });
    }
};



//show 
exports.show = async (req, res) => {
    try {
        const { id } = req.params;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({ message: 'Invalid ID format' });
        }
        const accountRequest = await Payouts.findById(id)
            .populate('user')
            .populate('paymentMethod')
            .populate({ path: 'user_wallet_id', model: 'UserWallet' });

        if (!accountRequest) {
            return res.status(404).json({ message: 'Account request not found' });
        }

        // Fetch referral users
        const referralCodeUserFind = await User.find({
            referred_by: accountRequest.user._id
        }).populate({
            path: 'wallets',
            populate: {
                path: 'account_type_id',
                model: 'AccountType'
            },
            match: {
                account: 'mt5',
                mt5_type: { $ne: 'real' },
                $or: [
                    { parent_user_wallet_id: null },
                    { parent_user_wallet_id: '' },
                    { parent_user_wallet_id: 'null' }
                ]
            },
            options: { sort: { createdAt: 1 } }
        });


        let totalSum = 0;
        const step1 = 10;
        const step2 = 15;

        referralCodeUserFind.forEach(user => {
            user.wallets.forEach(wallet => {
                const step = wallet.accountType?.step;
                if (step === '1 step') {
                    totalSum += parseFloat(wallet.accountSize.price) * (step1 / 100);
                } else if (step === '2 step') {
                    totalSum += parseFloat(wallet.accountSize.price) * (step2 / 100);
                }
            });
        });

        // Get total trades for the user_wallet_id
        let totalProfit = 0;
        if (accountRequest.user_wallet_id) {
            const userWallet = await UserWallet.findById(accountRequest.user_wallet_id)
                .populate({ path: 'account_size_id', model: 'AccountSize' });

            if (userWallet) {
                const initial_balance = userWallet.accountSize?.limit || 0;
                const current_balance = userWallet.balance;
                totalProfit = current_balance - initial_balance;

                if (totalProfit <= 0) totalProfit = 0;

                const daysSinceCreation = moment().diff(moment(userWallet.createdAt), 'days');
                let maxProfitWithdrawal = totalProfit * 0.9;

                if (daysSinceCreation >= 60 && daysSinceCreation < 90) {
                    maxProfitWithdrawal = totalProfit * 0.95;
                } else if (daysSinceCreation >= 90) {
                    maxProfitWithdrawal = totalProfit;
                }

                totalProfit = maxProfitWithdrawal;
            }
        }

        // Get total affiliate paid
        const totalAffiliatePaidResult = await Payouts.aggregate([
            { $match: { payment_status: 'approved', payout_type: 'affiliate', user_id: accountRequest.user._id } },
            { $group: { _id: null, total: { $sum: "$amount" } } }
        ]);
        const totalAffiliatePaid = totalAffiliatePaidResult.length ? totalAffiliatePaidResult[0].total : 0;

        // Get total amount paid for trading accounts
        const totalPaidResult = await Payouts.aggregate([
            { $match: { payment_status: 'approved', payout_type: 'trading_account', user_wallet_id: accountRequest.user_wallet_id } },
            { $group: { _id: null, total: { $sum: "$amount" } } }
        ]);
        const totalPaid = totalPaidResult.length ? totalPaidResult[0].total : 0;

        // Calculate remaining amount
        const remainAmount = Math.max(totalProfit - totalPaid, 0);
        const totalAffiliateBalance = accountRequest.payout_type === 'affiliate' ? totalSum : 0;

        res.json({
            accountRequest,
            totalProfit,
            totalPaid,
            remainAmount,
            totalAffiliatePaid,
            totalAffiliateBalance
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error', error: err.message });
    }
};

exports.data = async (req, res) => {
    try {
        const { search, order, start, length, draw } = req.query;

        let query = {
            include: [
                { model: User, as: 'user', attributes: ['first_name', 'last_name'] },
                { model: PaymentMethod, as: 'paymentMethod', attributes: ['name'] },
            ],
            where: {},
            order: [],
            limit: length,
            offset: start,
            attributes: ['id', 'user_id', 'payout_type', 'payment_method_id', 'status', 'amount', 'payment_status', 'created_at'],
        };

        if (search && search.value) {
            const searchTerm = search.value.toLowerCase();
            query.where[Op.or] = [
                { payment_status: { [Op.like]: `%${searchTerm}%` } },
                { amount: { [Op.like]: `%${searchTerm}%` } },
                { payout_type: { [Op.like]: `%${searchTerm}%` } },
                sequelize.where(
                    sequelize.fn('concat', sequelize.col('user.first_name'), ' ', sequelize.col('user.last_name')),
                    {
                        [Op.like]: `%${searchTerm}%`,
                    }
                ),
            ];
        }
        if (order && order[0] && order[0].column) {
            const columns = ['created_at', 'user.first_name', 'amount', 'payment_status', 'payment_method_id', 'status'];
            const orderColumn = columns[order[0].column];
            const orderDirection = order[0].dir;
            query.order = [[sequelize.col(orderColumn), orderDirection]];
        } else {
            query.order = [['created_at', 'DESC']];
        }

        // Fetch paginated data
        const payouts = await Payouts.findAndCountAll(query);

        const data = payouts.rows.map((payout, index) => {
            payout.DT_RowIndex = parseInt(start) + index + 1;
            payout.payout_type = payout.payout_type ? payout.payout_type.replace('_', ' ').toUpperCase() : 'TRADING ACCOUNT';
            payout.created_at_formatted = moment(payout.created_at).format('DD-MM-YYYY HH:mm');

            payout.payment_method = payout.paymentMethod ? payout.paymentMethod.name : 'N/A';

            payout.action = '';
            return payout;
        });

        res.json({
            draw: parseInt(draw),
            recordsTotal: payouts.count,
            recordsFiltered: payouts.count,
            data,
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};
exports.approve = async (req, res) => {
    try {
        const application = await Payouts.findOne({
            where: { id: req.params.id },
            include: ['user', 'paymentMethod', 'user_wallet']
        });

        if (!application) return res.status(404).send('Payout not found');

        application.payment_status = req.body.payment_status;
        application.approve_datetime = req.body.payment_status === 'approved' ? moment().toDate() : null;

        if (await application.save()) {
            const user = await User.findByPk(application.user_id);
            const userWallet = await UserWallet.findByPk(application.user_wallet_id);

            if (req.body.payment_status === 'approved') {
                if (userWallet) {
                    const initial_balance = parseFloat(userWallet.accountSize.limit);
                    const resetAccountAmount = userWallet.balance - initial_balance;

                    userWallet.balance -= resetAccountAmount;
                    userWallet.available_balance -= resetAccountAmount;

                    const balanceDepositInMT5 = {
                        loginid: userWallet.account_number,
                        amount: resetAccountAmount,
                        txnType: 1,
                        description: '',
                        comment: 'PAYOUT - CRM'
                    };

                    // Update balance in MT5 (Assuming an external service)
                    await updateBalanceInMT5(balanceDepositInMT5);

                    await BalanceHistory.destroy({
                        where: { user_wallet_id: application.user_wallet_id }
                    });

                    await userWallet.save();
                }

                // Send approval email
                await sendEmail(user.email, 'Payout Approved', 'Payout request has been approved.');
            } else {
                // Send rejection email
                await sendEmail(user.email, 'Payout Rejected', 'Your payout request was rejected.');
            }

            res.redirect(`/admin/payout/show/${req.params.id}`);
        } else {
            res.status(400).send('Failed to update payout status');
        }
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.destroy = async (req, res) => {
    try {
        const { id } = req.params; // Corrected to 'id' (not _id)

        // Validate ObjectId
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({ success: false, message: "Invalid Payout ID" });
        }

        // Use soft delete instead of permanent deletion
        const payout = await Payouts.findByIdAndUpdate(id, { deleted_at: new Date() }, { new: true });

        if (!payout) {
            return res.status(404).json({ success: false, message: "Payout not found" });
        }

        res.status(200).json({ success: true, message: "Payout deleted successfully" });
    } catch (err) {
        res.status(500).json({ success: false, message: "Failed to delete Payout", error: err.message });
    }
};




// exports.show = async (req, res) => {
//     try {
//         const accountRequest = await Payouts.findOne({
//             where: { id: req.params.id },
//             include: ['user', 'paymentMethod', 'user_wallet']
//         });

//         if (!accountRequest) {
//             return res.status(404).send('Account request not found');
//         }

//         const referralCodeUserFind = await User.findAll({
//             include: [{
//                 model: UserWallet,
//                 as: 'wallets',
//                 where: {
//                     account: 'mt5',
//                     mt5_type: { [Op.ne]: 'real' },
//                     [Op.or]: [
//                         { parent_user_wallet_id: { [Op.is]: null } },
//                         { parent_user_wallet_id: '' },
//                         { parent_user_wallet_id: 'null' }
//                     ]
//                 },
//                 order: [['createdAt', 'ASC']]
//             }],
//             where: {
//                 referred_by: accountRequest.user_id
//             }
//         });

//         let totalSum = 0;
//         const step1 = 10;
//         const step2 = 15;

//         referralCodeUserFind.forEach(user => {
//             user.wallets.forEach(wallet => {
//                 if (wallet.accountType.step === '1 step') {
//                     totalSum += parseFloat(wallet.accountSize.price) * (step1 / 100);
//                 } else if (wallet.accountType.step === '2 step') {
//                     totalSum += parseFloat(wallet.accountSize.price) * (step2 / 100);
//                 } else if (wallet.accountType.step === 'HFT') {
//                     totalSum += 0;
//                 }
//             });
//         });

//         const totalTradePerWalletID = await Trade.findAll({
//             where: { position: 'close', user_wallet_id: accountRequest.user_wallet_id }
//         });

//         let totalProfit = 0;
//         if (accountRequest.user_wallet_id) {
//             const userWallet = await UserWallet.findByPk(accountRequest.user_wallet_id);
//             const initial_balance = userWallet.accountSize.limit;
//             const current_balance = userWallet.balance;
//             totalProfit = current_balance - initial_balance;

//             if (totalProfit <= 0) totalProfit = 0;

//             const daysSinceCreation = moment().diff(moment(userWallet.createdAt), 'days');
//             let maxProfitWithdrawal = totalProfit * 0.9;

//             if (daysSinceCreation >= 60 && daysSinceCreation < 90) {
//                 maxProfitWithdrawal = totalProfit * 0.95;
//             } else if (daysSinceCreation >= 90 && daysSinceCreation < 120) {
//                 maxProfitWithdrawal = totalProfit;
//             } else if (daysSinceCreation >= 120) {
//                 maxProfitWithdrawal = totalProfit;
//             }

//             totalProfit = maxProfitWithdrawal;
//         }

//         const totalAffiliateBalance = accountRequest.payout_type === 'affiliate' ? totalSum : 0;
//         const totalAffiliatePaid = await Payouts.sum('amount', {
//             where: {
//                 payment_status: 'approved',
//                 payout_type: 'affiliate',
//                 user_id: accountRequest.user_id
//             }
//         });

//         const totalPaid = await Payouts.sum('amount', {
//             where: {
//                 payment_status: 'approved',
//                 payout_type: 'trading_account',
//                 user_wallet_id: accountRequest.user_wallet_id
//             }
//         });

//         const remainAmount = (totalProfit - totalPaid) > 0 ? totalProfit - totalPaid : 0;
//         res.render('admin/payout/show', {
//             accountRequest,
//             totalProfit,
//             totalPaid,
//             remainAmount,
//             totalAffiliatePaid,
//             totalAffiliateBalance
//         });

//     } catch (err) {
//         res.status(500).send('Server Error');
//     }
// };