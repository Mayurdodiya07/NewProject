const PromoCode = require("../../../models/PromoCode");



exports.index = async (req, res) => {
    try {
        const promoCodes = await PromoCode.find({ deleted_at: null }).sort({ created_at: -1 });

        res.status(200).json({ data: promoCodes });
    } catch (error) {
        console.error("Error fetching promo codes:", error);
        res.status(500).json({ error: error.message || "Server error" });
    }
};


// exports.data = async (req, res) => {
//     try {
//         const { page = 1, limit = 10, search = "" } = req.query;
//         const pageNumber = parseInt(page, 10);
//         const limitNumber = parseInt(limit, 10);

//         if (isNaN(pageNumber) || isNaN(limitNumber)) {
//             return res.status(400).json({ success: false, message: "Invalid pagination parameters" });
//         }

//         const query = search ? { name: { $regex: search, $options: "i" } } : {};
//         const total = await PromoCode.countDocuments(query);

//         const promoCodes = await PromoCode.find(query)
//             .skip((pageNumber - 1) * limitNumber)
//             .limit(limitNumber)
//             .sort({ created_at: -1 });

//         res.json({
//             success: true,
//             data: promoCodes,
//             totalPages: Math.ceil(total / limitNumber),
//             currentPage: pageNumber,
//         });
//     } catch (error) {
//         console.error("Error fetching promo codes:", error.message);
//         res.status(500).json({ success: false, message: "Internal Server Error" });
//     }
// };

exports.data = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "" } = req.query;
        const pageNumber = parseInt(page, 10);
        const limitNumber = parseInt(limit, 10);

        if (isNaN(pageNumber) || isNaN(limitNumber)) {
            return res.status(400).json({ success: false, message: "Invalid pagination parameters" });
        }

        const query = search
            ? {
                $or: [
                    { name: { $regex: search, $options: "i" } },
                    { code: { $regex: search, $options: "i" } },
                    { type: { $regex: search, $options: "i" } },
                ],
            }
            : {};

        const totalItems = await PromoCode.countDocuments(query);

        const promoCodes = await PromoCode.find(query)
            .sort({ createdAt: -1 }) // make sure your schema uses `timestamps`
            .skip((pageNumber - 1) * limitNumber)
            .limit(limitNumber);

        res.json({
            success: true,
            data: promoCodes,
            totalItems,
            totalPages: Math.ceil(totalItems / limitNumber),
            currentPage: pageNumber,
        });
    } catch (error) {
        console.error("Error fetching promo codes:", error.message);
        res.status(500).json({ success: false, message: "Internal Server Error" });
    }
};



exports.add = async (req, res) => {
    res.render("admin/promo-code/add");
};

exports.store = async (req, res) => {
    try {
        const { name, type, code, discount_in_rupees, discount_in_pr, starting_date, ending_date } = req.body;

        // Validate required fields
        if (!name || !type || !code || !starting_date || !ending_date) {
            return res.status(400).json({ error: "Required fields are missing" });
        }

        // Convert date strings to Date objects
        const startingDateParsed = new Date(starting_date);
        const endingDateParsed = new Date(ending_date);

        // Ensure discount values are numbers
        const discountInRupees = discount_in_rupees ? parseFloat(discount_in_rupees) : 0;
        const discountInPercentage = discount_in_pr ? parseFloat(discount_in_pr) : 0;

        // Create and save promo code
        const promoCode = await PromoCode.create({
            name,
            type,
            code,
            discount_in_rupees: discountInRupees,
            discount_in_pr: discountInPercentage,
            starting_date: startingDateParsed,
            ending_date: endingDateParsed
        });

        res.status(201).json({ message: "Promo code added successfully", data: promoCode });
    } catch (error) {
        console.error("Error in store function:", error);
        res.status(500).json({ error: error.message || "Server error" });
    }
};

exports.edit = async (req, res) => {
    try {
        const promoCode = await PromoCode.findById(req.params.id);
        if (!promoCode) return res.status(404).json({ error: "Promo Code not found" });

        res.status(200).json({ data: promoCode });
    } catch (error) {
        res.status(500).json({ error: "Server error" });
    }
};

exports.update = async (req, res) => {
    try {
        const { id } = req.params;
        const promoCode = await PromoCode.findByIdAndUpdate(id, req.body, { new: true });

        if (!promoCode) return res.status(404).json({ error: "Promo Code not found" });

        res.status(200).json({ message: "Promo Code updated successfully", data: promoCode });
    } catch (error) {
        console.error("Error in update function:", error);
        res.status(500).json({ error: "Server error" });
    }
};


exports.destroy = async (req, res) => {
    try {
        await PromoCode.findByIdAndDelete(req.params.id);
        res.json({ success: "Promo Code deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: "Failed to delete Promo Code" });
    }
};