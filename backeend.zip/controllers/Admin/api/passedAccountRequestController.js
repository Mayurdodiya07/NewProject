const { Mt5Service, MetaService } = require('../../../services/mt5Service');
const PassedAccountRequest = require('../../../models/PassedAccountRequest');
const UserWallet = require('../../../models/UserWallet');
const Currency = require('../../../models/Currency');
const User = require('../../../models/User');
const Leverage = require('../../../models/Leverage');
const TradeGroup = require('../../../models/TradeGroup');
const Mail = require('../../../services/emailService');
const formatDate = require('../../../helpers/dateHelper');
const generateRandomPassword = require('../../../helpers/PasswordHelper');
const Trade = require('../../../models/Trade');
const Payouts = require('../../../models/Payouts');



// exports.index = async (req, res) => {
//     try {
//         const passedChallenges = await PassedAccountRequest.find()
//             .populate({ path: 'user_id', select: 'email first_name last_name' })
//             .sort({ created_at: -1 });

//         if (!passedChallenges || passedChallenges.length === 0) {
//             return res.json({ success: true, data: [] });
//         }

//         const userIds = passedChallenges.map(req => req.user_id?.toString()).filter(Boolean);
//         const userWallets = await UserWallet.find({ user_id: { $in: userIds } }).select('user_id account_number balance');

//         const walletMap = Object.fromEntries(userWallets.map(wallet => [wallet.user_id.toString(), wallet]));

//         const responseData = passedChallenges.map(req => ({
//             ...req.toObject(),
//             user_wallet: walletMap[req.user_id?.toString()] || null
//         }));

//         res.json({ success: true, data: responseData });
//     } catch (err) {
//         res.status(500).json({ success: false, message: "Server Error", error: err.message });
//     }
// };
exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "" } = req.query;
        const skip = (parseInt(page) - 1) * parseInt(limit);

        const searchRegex = new RegExp(search, 'i'); // Case-insensitive search

        // Build search query
        const query = search
            ? {
                $or: [
                    { email: searchRegex },
                    { status: searchRegex },
                    { account_number: searchRegex },
                ]
            }
            : {};

        // Find total count for pagination
        const total = await PassedAccountRequest.countDocuments(query);

        // Fetch paginated results
        const passedChallenges = await PassedAccountRequest.find(query)
            .populate({ path: 'user_id', select: 'email first_name last_name' })
            .sort({ created_at: -1 })
            .skip(skip)
            .limit(parseInt(limit));

        const userIds = passedChallenges.map(req => req.user_id?._id?.toString()).filter(Boolean);

        const userWallets = await UserWallet.find({ user_id: { $in: userIds } }).select('user_id account_number balance');
        const walletMap = Object.fromEntries(userWallets.map(wallet => [wallet.user_id.toString(), wallet]));

        const responseData = passedChallenges.map(req => ({
            ...req.toObject(),
            user_wallet: walletMap[req.user_id?._id?.toString()] || null
        }));

        return res.json({
            success: true,
            data: responseData,
            total,
            page: parseInt(page),
            limit: parseInt(limit)
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};


exports.show = async (req, res) => {
    const { id } = req.params;

    try {
        // Fetch PassedAccountRequest and populate related user and userWallet
        const passedAccountRequest = await PassedAccountRequest.findById(id)
            .populate('user')
            .populate('userWallet');

        if (!passedAccountRequest) {
            return res.status(404).json({ error: 'Passed Account Request not found' });
        }

        // Fetch UserWallet and populate accountSize
        const accountRequest = await UserWallet.findById(passedAccountRequest.user_wallet_id)
            .populate({
                path: 'account_size_id',
                select: 'limit'
            });

        if (!accountRequest) {
            return res.status(404).json({ error: 'User Wallet not found' });
        }

        // Calculate profit
        const accountLimit = accountRequest?.account_size_id?.limit || 0;
        const balance = accountRequest?.balance || 0;
        const profit = Math.max(0, parseFloat(balance) - parseFloat(accountLimit));
        const profitMake = (profit * 30) / 100;

        // Fetch trades that meet the profit criteria
        const trades = await Trade.find({
            user_wallet_id: passedAccountRequest.user_wallet_id,
            profit: { $gte: profitMake }
        }).populate('user');

        res.render('admin.passed-challenge-requests.show', {
            PassedaccountRequest: passedAccountRequest,
            accountRequest,
            profitMake,
            trades
        });

    } catch (error) {
        console.error('Error fetching Passed Account Request:', error);
        res.status(500).json({ error: 'Failed to load the passed challenge request' });
    }
};



exports.actionOnPassedAccount = async (req, res) => {
    const { id, userWalletID, type } = req.body;

    try {
        const accountRequest = await PassedAccountRequest.findById(id);
        const userWallet = await UserWallet.findById(userWalletID).populate('user accountSize accountType');

        if (type === 'passed') {
            const currency = await Currency.findOne({ code: 'USD' });
            const startAmount = userWallet.accountSize.limit;

            let input = {
                parent_user_wallet_id: userWallet.id,
                user_id: userWallet.user_id,
                mt5_type: 'demo',
                title: userWallet.title,
                first_name: userWallet.first_name,
                last_name: userWallet.last_name,
                city: userWallet.city,
                postal_code: userWallet.postal_code,
                address_country_id: userWallet.address_country_id,
                country_id: userWallet.country_id,
                account_type_id: userWallet.account_type_id,
                account_size_id: userWallet.account_size_id,
                not_us_residence: userWallet.not_us_residence,
                platform_id: userWallet.platform_id,
                payment_method_id: userWallet.payment_method_id,
                account: 'mt5',
                account_status: 'not_passed',
                account_request_id: null,
                currency: currency.name,
                currency_id: currency.id,
                favourite: false,
                fiat: false,
                enabled: true,
                status: 'active',
                balance: startAmount,
                available_balance: startAmount,
                on_hold_balance: 0.0,
                equity: startAmount,
                free_funds: startAmount,
                credit: 0,
                archived: false
            };

            const leverageValue = await Leverage.findOne({ value: '100' });
            const iPassword = generateRandomPassword(12);
            const mPassword = generateRandomPassword(12);
            const tradeGroupName = (await TradeGroup.findOne()).name;

            const accountName = `${userWallet.first_name}-Fundedfim-${userWallet.accountType.step === "1 step" ? "S1" : (userWallet.accountType.step === "2 step" ? "S2" : "HF")}`;
            if (userWallet.accountType.step === '2 step') accountName += '/P2';

            const mt5AccountData = {
                accountid: 0,
                type: 0,
                platform: 0,
                currency: currency.name,
                server: "",
                group: tradeGroupName,
                name: accountName,
                email: userWallet.user.email,
                phone: userWallet.user.phone_number,
                country: userWallet.address_country_name,
                city: userWallet.city,
                address: "",
                balance: 0,
                mPassword: iPassword,
                iPassword: mPassword,
                leverage: leverageValue.value
            };

            const response = await Mt5Service.createAccount(mt5AccountData);

            if (response.user && response.user.accountid !== 0) {
                userWallet.account_status = 'passed';
                userWallet.passed_datetime = new Date();
                input.account_number = response.user.accountid;
                input.code = response.user.accountid;
                input.investor_password = response.user.iPassword;
                input.master_password = response.user.mPassword;

                await Mt5Service.updateBalance({
                    loginid: response.user.accountid,
                    amount: input.balance,
                    txnType: 0,
                    description: '',
                    comment: 'DEPOSIT - CRM',
                });

                const newUserWallet = await UserWallet.create(input);
                const createdUserWallet = await UserWallet.findById(newUserWallet.id).populate('accountType');
                const user = await User.findById(userWallet.user_id);

                userWallet.account_status = 'passed';
                userWallet.passed_datetime = new Date();
                await userWallet.save();
                accountRequest.account_status = 'passed';
                await accountRequest.save();

                const message = "Congratulations your challenge step1 has been achieved profit target! Now you can proceed for step2 challenge.";
                await Mail.send(new ChallengePassedMail(message, createdUserWallet.account_number, createdUserWallet.master_password));

                res.json({ message: 'Account has been passed and mail sent to user' });
            } else {
                res.json({ message: 'Not created account because of incorrect MT5 Response' });
            }
        } else if (type === 'breach') {
            const userWallet = await UserWallet.findOne({
                _id: userWalletID,
                account: 'mt5',
                status: 'active',
                account_status: { $ne: 'disabled' }
            }).populate('accountSize');

            if (!userWallet) {
                return res.json({ message: 'User wallet not found or already disabled' });
            }

            // Close all trades
            const endDate = new Date();
            endDate.setDate(endDate.getDate() + 1);
            const startDate = new Date();
            startDate.setHours(startDate.getHours() - 720);

            const allTrades = await Mt5Service.getPosition({
                loginId: userWallet.account_number,
                startDate: formatDate(startDate),
                endDate: formatDate(endDate)
            });

            let tradeCount = 0;
            let disabledTradeCount = 0;

            if (allTrades.openPositions) {
                for (const trade of allTrades.openPositions) {
                    if (['BUY', 'SELL'].includes(trade.type)) {
                        tradeCount++;
                        const response = await Mt5Service.closeOpenTrade({
                            loginid: trade.loginid,
                            positionId: trade.positionid,
                            symbol: trade.symbol,
                            volume: trade.lotsize,
                            price: trade.price,
                            type: trade.type,
                            tp: trade.tp,
                            sl: trade.sl,
                            comment: 'Close Trade',
                        });

                        if (response && response.deal && response.deal.dealResult.retCode === 'MT_RET_REQUEST_DONE') {
                            disabledTradeCount++;
                        }
                    }
                }
            }

            // Disable MT5 account
            const disableResponse = await Mt5Service.setTradeDisable({ loginId: userWallet.account_number, flag: true });

            if (disableResponse.retCode === 'MT_RET_OK') {
                await UserWallet.updateOne({ _id: userWalletID }, { account_status: 'disabled', disable_rule: '30% rule breach', disable_date: new Date() });

                accountRequest.account_status = 'Breached';
                await accountRequest.save();
                const user = await User.findById(userWallet.user_id);

                await Mail.send(new RuleBreachMail(user.first_name + ' ' + user.last_name, userWallet.account_number));

                res.json({ message: 'Account has been disabled due to rule breach' });
            } else {
                res.json({ message: 'Failed to disable the account' });
            }
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Something went wrong while processing the action' });
    }
};
exports.approve = async (req, res) => {
    const { id } = req.params;

    try {
        // Find the application by ID and populate the userWallet
        const application = await PassedAccountRequest.findById(id).populate('userWallet');

        if (!application) {
            return res.status(404).json({ message: 'Application not found' });
        }

        // If the application status is already 'approved', no need to approve it again
        if (application.account_status === 'approved') {
            return res.json({ message: 'Application has already been approved' });
        }

        // Update the account status to 'approved'
        application.account_status = 'approved';
        application.approved_datetime = new Date();

        // Save the application after updating the status
        await application.save();

        // Fetch additional details like user wallet data, etc.
        const userWallet = application.userWallet;

        // Send any relevant notification or perform other operations (e.g., create a new account)
        // For example, you can use mail notifications here like in previous logic

        res.json({ message: 'Application has been approved', application });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Something went wrong while approving the application' });
    }
};

exports.pendingRequest = async (req, res) => {
    try {
        const application = await PassedAccountRequest.findById(req.params.id).populate('userWallet');
        console.log(application);
        res.json(application);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Something went wrong while fetching the request.' });
    }
};

// Data (Fetch paginated data with search filter)
exports.data = async (req, res) => {
    try {
        const { search, length, start, draw } = req.query;

        let query = PassedAccountRequest.find()
            .populate('user')
            .populate('userWallet')
            .select('_id user_id account_status user_wallet_id created_at')
            .sort({ _id: -1 });

        if (search && search.value) {
            const searchValue = search.value.toLowerCase();
            query = query.or([
                { account_status: { $regex: searchValue, $options: 'i' } },
                { 'userWallet.first_name': { $regex: searchValue, $options: 'i' } },
                { 'userWallet.last_name': { $regex: searchValue, $options: 'i' } },
                { 'user.email': { $regex: searchValue, $options: 'i' } },
                { 'userWallet.account_number': parseInt(searchValue) }
            ]);
        }

        const perPage = length || 10;
        const page = Math.floor((start || 0) / perPage) + 1;

        const applications = await query.skip((page - 1) * perPage).limit(perPage);

        const data = applications.map((application, index) => {
            let actions = `
                <a href="/admin/passed-challenge-requests/show/${application._id}" class="common-action-btn" title="View">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                    </svg>
                </a>
            `;
            if (application.account_status === 'pending') {
                actions += ` <button class="common-action-btn approve-request" data-id="${application._id}" title="Approve"><i class="fas fa-check"></i></button>`;
            }

            return {
                DT_RowIndex: parseInt(start) + index + 1,
                id: application._id,
                account_status: application.account_status,
                created_at: application.created_at.toISOString(),
                user: application.userWallet ? `${application.userWallet.first_name} ${application.userWallet.last_name}` : '-',
                user_email: application.user ? application.user.email : '-',
                user_wallet: application.userWallet ? application.userWallet.account_number : '-',
                action: actions
            };
        });

        res.json({
            draw: parseInt(draw),
            recordsTotal: await PassedAccountRequest.countDocuments(),
            recordsFiltered: await PassedAccountRequest.countDocuments(query),
            data,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Something went wrong while fetching the data.' });
    }
};

// Destroy (Delete request by ID)
exports.destroy = async (req, res) => {
    try {
        const application = await PassedAccountRequest.findByIdAndDelete(req.params.id);
        if (!application) {
            return res.status(404).json({ error: 'Request not found.' });
        }
        res.json({ message: 'Request deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Something went wrong while deleting the request.' });
    }
};
