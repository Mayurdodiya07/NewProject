const UserWallet = require('../../../models/UserWallet');
const User = require("../../../models/User");
const moment = require('moment');
const ExcelJS = require('exceljs');

exports.index = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search || "";
        const startDate = req.query.startDate;
        const endDate = req.query.endDate;

        const query = {
            account_status: "disabled"
        };

        if (search) {
            query["$or"] = [
                { first_name: { $regex: search, $options: "i" } },
                { last_name: { $regex: search, $options: "i" } },
                { email: { $regex: search, $options: "i" } }
            ];
        }

        if (startDate && endDate) {
            query.created_at = {
                $gte: new Date(startDate + "T00:00:00Z"),
                $lte: new Date(endDate + "T23:59:59Z")
            };
        }

        const total = await UserWallet.countDocuments(query);

        const disabledAccounts = await UserWallet.find(query)
            .populate('user_id')
            .populate({
                path: "account_type_id",
                model: "AccountType",
                select: "_id name step created_at updated_at"
            })
            .skip((page - 1) * limit)
            .limit(limit)
            .sort({ created_at: -1 })
            .lean();

        res.status(200).json({
            data: disabledAccounts,
            pagination: {
                total,
                page,
                limit,
                totalPages: Math.ceil(total / limit)
            }
        });
    } catch (err) {
        console.error("Error fetching disabled accounts:", err);
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};

exports.show = async (req, res) => {
    try {
        const accountRequest = await UserWallet.findById(req.params.id)
            .populate("user_id", "first_name last_name email")
            .populate("account_type_id", "name step")
            .populate("leverage_id", "name value status")
            .populate({
                path: "account_size_id",
                model: "AccountSize",
                select: "name limit min_trade_days profit_target max_overall_loss max_daily_loss price status"
            });

        if (!accountRequest) {
            return res.status(404).json({ success: false, message: "Account not found" });
        }

        res.status(200).json({ success: true, data: accountRequest });
    } catch (error) {
        console.error("Error fetching account request:", error);
        res.status(500).json({ success: false, message: "Server error", error: error.message });
    }
};

exports.exportToExcel = async (req, res) => {
    try {
        let { search, start_date, end_date } = req.query;
        let query = { account_status: 'disabled' };

        if (start_date && end_date) {
            query.updated_at = {
                $gte: moment(start_date).startOf('day').toDate(),
                $lte: moment(end_date).endOf('day').toDate(),
            };
        }

        if (search) {
            const regex = new RegExp(search, 'i');
            query.$or = [
                { account_number: regex },
                { mt5_type: regex },
                { status: regex },
                { disable_rule: regex },
            ];
        }

        const wallets = await UserWallet.find(query)
            .populate({
                path: 'user_id',
                select: 'first_name last_name email phone'
            })
            .populate({
                path: 'account_type_id',
                select: 'name'
            })
            .populate({
                path: 'account_size_id',
                select: 'name'
            })
            .sort({ updated_at: -1 });

        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Disabled Accounts');

        worksheet.columns = [
            { header: 'Name', key: 'name', width: 20 },
            { header: 'Email', key: 'email', width: 25 },
            { header: 'Phone', key: 'phone', width: 20 },
            { header: 'Account Number', key: 'account_number', width: 20 },
            { header: 'Account Type', key: 'account_type', width: 20 },
            { header: 'Account Size', key: 'account_size', width: 15 },
            { header: 'Disabled Reason', key: 'disabled_reason', width: 30 },
            { header: 'Disabled At', key: 'disabled_at', width: 20 },
        ];

        wallets.forEach(wallet => {
            worksheet.addRow({
                name: `${wallet.user_id?.first_name || ''} ${wallet.user_id?.last_name || ''}`,
                email: wallet.user_id?.email || '',
                phone: wallet.user_id?.phone || '',
                account_number: wallet.account_number || '',
                account_type: wallet.account_type_id?.name || '',
                account_size: wallet.account_size_id?.name || '',
                disabled_reason: wallet.disable_rule || '',
                disabled_at: moment(wallet.updated_at).format('YYYY-MM-DD HH:mm'),
            });
        });
        const filter = req.query.filter || "all";

        if (filter === "today") {
            query.updated_at = {
                $gte: moment().startOf('day').toDate(),
                $lte: moment().endOf('day').toDate()
            };
        }

        else if (filter === "week") {
            query.updated_at = {
                $gte: moment().startOf('week').toDate(),
                $lte: moment().endOf('week').toDate()
            };
        } else if (filter === "month") {
            query.updated_at = {
                $gte: moment().startOf('month').toDate(),
                $lte: moment().endOf('month').toDate()
            };
        }

        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', 'attachment; filename=disabled-accounts.xlsx');
        await workbook.xlsx.write(res);
        res.end();
    } catch (error) {
        console.error('Export Error:', error);
        res.status(500).json({ message: 'Failed to export Excel file' });
    }
};

// Data ...
exports.data = async (req, res) => {
    try {
        let { start_date, end_date, search, order, start = 0, length = 10 } = req.query;
        start = parseInt(start);
        length = parseInt(length);

        let query = { account_status: 'disabled' };

        if (start_date && end_date) {
            query.updated_at = {
                $gte: moment(start_date).startOf('day').toDate(),
                $lte: moment(end_date).endOf('day').toDate(),
            };
        }

        if (search) {
            search = search.toLowerCase();
            query.$or = [
                { account_status: new RegExp(search, 'i') },
                { account_number: search },
                { mt5_type: new RegExp(search, 'i') },
                { status: new RegExp(search, 'i') },
                { disable_rule: new RegExp(search, 'i') },
                { 'user.first_name': new RegExp(search, 'i') },
                { 'user.last_name': new RegExp(search, 'i') },
                { 'user.email': new RegExp(search, 'i') },
                { 'user.phone': new RegExp(search, 'i') }
            ];
        }

        let sort = {};
        if (order && order.length > 0) {
            const columns = ['', 'user_name', 'email', 'phone', 'account_number', 'mt5_type', 'status', 'disable_rule', 'updated_at'];
            const orderColumn = columns[order[0].column] || 'updated_at';
            const orderDirection = order[0].dir === 'asc' ? 1 : -1;
            sort[orderColumn] = orderDirection;
        } else {
            sort['updated_at'] = -1;
        }

        const totalRecords = await UserWallet.countDocuments(query);
        const filteredRecords = await UserWallet.find(query)
            .populate('user')
            .sort(sort)
            .skip(start)
            .limit(length);

        const data = filteredRecords.map((account, index) => ({
            DT_RowIndex: start + index + 1,
            user_name: account.user ? `${account.user.first_name} ${account.user.last_name}` : '-',
            email: account.user ? account.user.email : '-',
            phone: account.user ? account.user.phone : '-',
            account_number: account.account_number,
            status: account.status,
            action: `<a href="/admin/disabled-accounts/${account._id}" class="btn btn-sm btn-primary">View</a>`,
        }));

        res.json({
            draw: parseInt(req.query.draw),
            recordsTotal: totalRecords,
            recordsFiltered: totalRecords,
            data,
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
