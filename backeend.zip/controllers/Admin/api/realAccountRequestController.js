const RealAccountRequest = require('../../../models/RealAccountRequest');
const moment = require("moment");
const UserWallet = require('../../../models/UserWallet');
const Trade = require('../../../models/Trade');
const Leverage = require('../../../models/Leverage');
const Currency = require('../../../models/Currency');
const Mailer = require('../../../services/emailService');
// const { generateRandomPassword } = require("../../../helpers/passwordHelper");
const Carbon = require('carbon');
const User = require("../../../models/User");
const TradeGroup = require("../../../models/TradeGroup");
const Mt5Service = require('../../../services/mt5Service');
const PasswordHelper = require("../../../helpers/PasswordHelper");
const mt5Service = new Mt5Service();
const logger = require("../../../helpers/logger");


exports.index = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search || '';
        const sortField = req.query.sortField || 'createdAt';
        const sortOrder = req.query.sortOrder === 'asc' ? 1 : -1;

        const skip = (page - 1) * limit;

        // Search on user's first_name
        const users = await User.find({
            first_name: { $regex: search, $options: 'i' }
        }).select('_id');

        const userIds = users.map(u => u._id);

        const total = await RealAccountRequest.countDocuments({
            user_id: { $in: userIds }
        });

        const realAccountRequests = await RealAccountRequest.find({
            user_id: { $in: userIds }
        })
            .populate({ path: 'user_id', select: 'email first_name last_name' })
            .sort({ [sortField]: sortOrder })
            .skip(skip)
            .limit(limit);

        const userWallets = await UserWallet.find({
            user_id: { $in: realAccountRequests.map(req => req.user_id?._id).filter(Boolean) }
        }).select('user_id account_number balance');

        const walletMap = Object.fromEntries(
            userWallets.map(wallet => [wallet.user_id.toString(), wallet])
        );

        const responseData = realAccountRequests.map(req => ({
            ...req.toObject(),
            user_wallet: walletMap[req.user_id?._id?.toString()] || null
        }));

        res.json({
            success: true,
            data: responseData,
            pagination: {
                total,
                page,
                limit,
                totalPages: Math.ceil(total / limit)
            }
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: "Server Error",
            error: err.message
        });
    }
};

exports.show = async (req, res) => {
    try {
        const { id } = req.params;

        const realAccountRequest = await RealAccountRequest.findById(id)
            .populate({
                path: 'user_id',
                select: 'first_name last_name email phone_number'
            })
            .populate({
                path: 'payment_method_id',
                select: '_id name status image deposit_address qr_code_image account_name account_number bank_name ifsc_code'
            })
            .populate({
                path: 'account_type_id',
                select: '_id name step created_at updated_at'
            })
            .populate({
                path: 'account_size_id',
                select: '_id name limit min_trade_days profit_target max_overall_loss max_daily_loss price status created_at updated_at',
                populate: {
                    path: 'account_type_id',
                    select: '_id name step created_at updated_at'
                }
            })
            .lean();

        if (!realAccountRequest) {
            return res.status(404).json({ success: false, message: "Real Account Request not found" });
        }

        // Fetch user wallet and populate user details
        const userWallet = await UserWallet.findOne({ user_id: realAccountRequest.user_id?._id })
            .populate({
                path: 'user_id',
                select: 'email first_name last_name phone_number city country address postal_code'
            })
            .populate({
                path: 'account_size_id', // Use this if the reference exists
                select: '_id name limit'
            })
            .lean();

        let profit = 0;
        let profitMake = 0;

        if (userWallet && userWallet.account_size_id) {
            const accountLimit = parseFloat(userWallet.account_size_id.limit) || 0;
            const accountBalance = parseFloat(userWallet.balance) || 0;
            profit = accountBalance > accountLimit ? accountBalance - accountLimit : 0;
            profitMake = profit > 0 ? (profit * 30) / 100 : 0;
        }

        // Find trades where profit is greater than or equal to profitMake
        const trades = await Trade.find({
            user_wallet_id: realAccountRequest.user_wallet_id,
            position: "close",
            profit: { $gte: profitMake },
        }).populate("user");

        return res.json({
            success: true,
            data: {
                ...realAccountRequest,
                user_wallet: userWallet || null,
                profit,
                profitMake,
                trades,
            }
        });

    } catch (error) {
        console.error("Error in show:", error);
        return res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
};

exports.actionOnPassedAccount = async (req, res) => {
    try {
        const { id, type } = req.body;


        if (!id) return res.status(400).json({ message: "Application ID is missing" });

        // Fetch RealAccountRequest (Removed .lean() to allow updates)
        const application = await RealAccountRequest.findById(id)
            .populate({
                path: "user_id",
                model: "User",
                select: "first_name last_name email phone_number",
            });

        if (!application) return res.status(404).json({ message: "Application not found" });


        const correctUserWalletId = application.user_wallet_id;

        if (!correctUserWalletId) {
            return res.status(404).json({ message: "User Wallet ID not linked to Application" });
        }


        const userWallet = await UserWallet.findById(correctUserWalletId)
            .populate({
                path: "user_id",
                select: "email first_name last_name phone_number city country address postal_code",
            })
            .populate("account_type_id account_size_id");

        if (!userWallet) return res.status(404).json({ message: "User Wallet not found" });


        const user = await User.findById(application.user_id);
        if (!user) return res.status(404).json({ message: "User not found" });


        if (type === "approved") {
            const currency = await Currency.findOne({ code: "USD" });
            if (!currency) return res.status(404).json({ message: "Currency not found" });

            const startAmount = userWallet.account_size_id ? userWallet.account_size_id.limit : 0;

            const leverageValue = await Leverage.findOne({ value: "100" });
            if (!leverageValue) return res.status(404).json({ message: "Leverage not found" });

            const tradeGroup = await TradeGroup.findOne({ status: "active", deleted_at: null });
            if (!tradeGroup) return res.status(404).json({ message: "Trade Group not found" });


            const iPassword = generateRandomPassword(12);
            const mPassword = generateRandomPassword(12);
            const step = userWallet.account_type_id.step;
            const stepCode = step === "1 step" ? "S1" : step === "2 step" ? "S2" : "HF";
            const accountName = `${userWallet.first_name}-FundedFirm-${stepCode}`;

            const mt5AccountData = {
                accountid: 0,
                type: 0,
                platform: 0,
                currency: currency.name,
                server: "",
                group: tradeGroup.name,
                name: accountName,
                email: user.email,
                phone: user.phone_number,
                country: userWallet.country,
                city: userWallet.city,
                address: userWallet.address,
                balance: 0,
                mPassword,
                iPassword,
                leverage: leverageValue.value,
            };

            const response = await mt5Service.createAccount(mt5AccountData);

            logger.info(response);

            if (response && response.user) {
                const input = {
                    user_id: application.user_id,
                    mt5_type: "real",
                    title: userWallet.title,
                    first_name: userWallet.first_name,
                    last_name: userWallet.last_name,
                    city: userWallet.city,
                    postal_code: userWallet.postal_code,
                    address_country_id: userWallet.address_country_id,
                    country_id: userWallet.country_id,
                    account_type_id: userWallet.account_type_id,
                    account_size_id: userWallet.account_size_id,
                    not_us_residence: userWallet.not_us_residence,
                    platform_id: userWallet.platform_id,
                    payment_method_id: userWallet.payment_method_id,
                    account: "mt5",
                    account_status: "real",
                    account_request_id: application.id,
                    currency: currency.name,
                    currency_id: currency.id,
                    favourite: false,
                    fiat: false,
                    enabled: true,
                    status: "active",
                    balance: startAmount,
                    available_balance: startAmount,
                    on_hold_balance: 0.0,
                    equity: startAmount,
                    free_funds: startAmount,
                    credit: 0,
                    archived: false,
                    leverage_id: leverageValue.id,
                    account_number: response.user.accountid,
                    code: response.user.accountid,
                    investor_password: response.user.iPassword,
                    master_password: response.user.mPassword,
                };

                await mt5Service.updateBalance({
                    loginid: response.user.accountid,
                    amount: input.balance,
                    txnType: 0,
                    description: "",
                    comment: "DEPOSIT - CRM",
                });

                const createdUserWallet = await UserWallet.create(input);
                application.account_status = "approved";
                await application.save();

                const message = "Congratulations! Your real account request has been approved!";
                await Mailer.sendRealAccountApprovalMail(user.email, message, createdUserWallet.account_number, createdUserWallet.master_password);

                return res.json({ message: "Account has been approved and mail sent to user" });
            }
            return res.status(500).json({ message: "Something went wrong!" });
        }

        if (type === "breach") {
            if (!application.user_wallet_id) {
                return res.status(404).json({ message: "User Wallet ID is missing for this application" });
            }

            const userWallet = await UserWallet.findById(application.user_wallet_id);
            if (!userWallet || userWallet.account !== "mt5" || userWallet.status !== "active") {
                return res.status(404).json({ message: "User wallet not valid for disabling" });
            }

            // Ensure user exists
            const user = await User.findById(application.user_id);
            if (!user) return res.status(404).json({ message: "User not found" });

            // Fetch open trades
            const endDate = new Date();
            const startDate = new Date();
            startDate.setHours(startDate.getHours() - 720);

            const allTrades = await mt5Service.getPosition({
                loginId: userWallet.account_number,
                startDate: startDate.toISOString(),
                endDate: endDate.toISOString(),
            });

            let tradeCount = 0;
            let disabledTradeCount = 0;

            if (allTrades?.openPositions?.length) {
                for (const trade of allTrades.openPositions) {
                    if (trade.type === "BUY" || trade.type === "SELL") {
                        tradeCount++;

                        const closeResponse = await mt5Service.closeOpenTrade({
                            loginId: trade.loginId,
                            positionId: trade.positionId,
                            symbol: trade.symbol,
                            volume: trade.lotsize,
                            price: trade.price,
                            type: trade.type,
                            tp: trade.tp,
                            sl: trade.sl,
                            comment: "Close Trade",
                        });

                        if (closeResponse?.deal?.dealResult?.retCode === "MT_RET_REQUEST_DONE") {
                            disabledTradeCount++;
                        } else {
                            console.error("Failed to close trade", trade.positionid);
                        }
                    }
                }
            }
            // Disable Account in MT5
            const disableResponse = await mt5Service.setTradeDisable({
                loginId: userWallet.account_number,
                flag: true
            });

            console.log("MT5 Disable Response:", JSON.stringify(disableResponse, null, 2));
            if (disableResponse?.retCode === "MT_RET_OK") {
                await UserWallet.findByIdAndUpdate(application.user_wallet_id, {
                    account_status: "disabled",
                    disable_rule: "30% rule breach",
                    disable_date: new Date(),
                });

                application.account_status = "Breached";
                await application.save();

                await sendEmail(
                    user.email,
                    "Account Disabled",
                    `Your trading account ${userWallet.account_number} has been disabled due to a breach.`
                );

                return res.json({ message: "Account has been disabled" });
            }

            return res.status(500).json({ message: "Failed to disable account in MT5" });
        }


        return res.status(400).json({ message: "Invalid action type" });
    } catch (error) {
        console.error("Error in actionOnPassedAccount:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};


function generateRandomPassword(length) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

// POST /admin/real-challenge-requests/approve/:id
exports.approve = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, comment } = req.body;
        const application = await RealAccountRequest.findById(id).populate("userWallet");
        if (!application) {
            return res.status(404).json({ error: "Application not found" });
        }
        const user = await User.findById(application.user_id);
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        if (status === "approved") {
            const currency = await Currency.findOne({ code: "USD" });
            const startAmount = application.userWallet.accountSize.limit;
            const leverageValue = await Leverage.findOne({ value: 100 });
            const tradeGroup = await TradeGroup.findOne({ type: "active" });
            const iPassword = PasswordHelper.generateRandomPassword(12);
            const mPassword = PasswordHelper.generateRandomPassword(12);
            const step = application.userWallet.accountType && application.userWallet.accountType.step;
            const accountName = `${application.userWallet.first_name}-Fundedfim-${step === "1 step" ? "S1" : "S2"}`;
            const mt5AccountData = {
                accountid: 0,
                type: 0,
                platform: 0,
                currency: currency.name,
                group: tradeGroup.name,
                name: accountName,
                email: user.email,
                phone: user.phone_number,
                country: application.userWallet.address_country_name,
                city: application.userWallet.city,
                address: "",
                balance: 0,
                mPassword,
                iPassword,
                leverage: leverageValue.value
            };

            const response = await mt5Service.createAccount(mt5AccountData);
            if (!response || !response.user) {
                console.error("MT5 Account creation failed");
                return res.status(500).json({ message: "Error creating MT5 account" });
            }
            const userWalletData = {
                user_id: application.user_id,
                account_number: response.user.accountid,
                code: response.user.accountid,
                investor_password: response.user.iPassword,
                master_password: response.user.mPassword,
                balance: startAmount,
                available_balance: startAmount,
                equity: startAmount,
                free_funds: startAmount,
                leverage_id: leverageValue._id,
                status: "active",
                archived: false,
            };

            const newWallet = await UserWallet.create(userWalletData);
            if (newWallet) {
                application.account_status = "approved";
                await application.save();
                // Using Mailer service to send email; adjust as needed
                await Mailer.sendRealAccountRequestApprovedMail(user.email, response.user.accountid, response.user.master_password);
                return res.status(200).json({ success: "Challenge request approved successfully" });
            } else {
                return res.status(500).json({ error: "Failed to create user wallet" });
            }
        } else {
            application.account_status = "rejected";
            await application.save();
            await Mailer.sendAllRequestRejectMail(user.email, comment, "Real account request rejected");
            return res.status(200).json({ success: "Challenge request rejected successfully" });
        }
    } catch (error) {
        console.error("Error in approve:", error);
        return res.status(500).json({ error: "An error occurred" });
    }
};

exports.pendingRequest = async (req, res) => {
    try {
        const application = await RealAccountRequest.findById(req.params.id)
            .populate('user')
            .populate('userWallet');
        if (!application) {
            return res.status(404).json({ error: "Application not found" });
        }

        // Ensure 'account_status' is included in the response
        return res.json({
            data: {
                _id: application._id,
                user: application.user,
                userWallet: application.userWallet,
                account_status: application.account_status
            }
        });
    } catch (err) {
        console.error("Error in pendingRequest:", err);
        return res.status(500).json({ error: err.message });
    }
};

exports.data = async (req, res) => {
    try {
        const { search, length, start, draw } = req.query;

        let query = RealAccountRequest.find()
            .populate({
                path: 'user',
                model: 'User', // Ensure correct model reference
                select: 'email first_name last_name'
            })
            .populate({
                path: 'user_Wallet',
                select: 'account_number'
            })
            .sort({ _id: -1 });

        if (search && search.value) {
            const searchValue = search.value.toLowerCase();
            query = query.or([
                { account_status: { $regex: searchValue, $options: 'i' } },
                { 'user.first_name': { $regex: searchValue, $options: 'i' } },
                { 'user.last_name': { $regex: searchValue, $options: 'i' } },
                { 'user.email': { $regex: searchValue, $options: 'i' } },
                { 'userWallet.account_number': parseInt(searchValue) || 0 }
            ]);
        }

        const perPage = parseInt(length, 10) || 10;
        const page = Math.floor(parseInt(start, 10) / perPage) + 1;
        const applications = await query.skip((page - 1) * perPage).limit(perPage);
        const totalRecords = await RealAccountRequest.countDocuments();

        return res.json({
            draw: draw || "1",
            recordsTotal: totalRecords,
            recordsFiltered: totalRecords,
            data: applications
        });
    } catch (err) {
        console.error("Error in data:", err);
        return res.status(500).json({ error: err.message });
    }
};
exports.destroy = async (req, res) => {
    try {
        const { id } = req.params;
        const realAccountRequest = await RealAccountRequest.findByIdAndDelete(id);

        if (!realAccountRequest) {
            return res.status(404).json({ success: false, message: 'Request not found' });
        }

        return res.json({ success: true, message: 'Request deleted successfully' });
    } catch (error) {
        return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
    }
};


