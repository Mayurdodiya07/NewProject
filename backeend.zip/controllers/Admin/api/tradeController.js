const Trade = require('../../../models/Trade');
const User = require('../../../models/User');
const { trade } = require('./accountController');
const mongoose = require('mongoose');
const moment = require("moment");
const RealAccountRequest = require("../../../models/RealAccountRequest");
const UserWallet = require("../../../models/UserWallet");
const accountSize = require("../../../models/AccountSize");
const Symbol = require("../../../models/Symbol");
const BalanceHistory = require("../../../models/BalanceHistory");
// // iindex start ..
// exports.index = async (req, res) => {
//     res.render('admin/trades/index');
// };


exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "", position = "all" } = req.query;
        const skip = (parseInt(page) - 1) * parseInt(limit);
        const query = {};

        // Search logic
        if (search) {
            const searchRegex = new RegExp(search, "i");
            query.$or = [
                { side: searchRegex },
                { entry: searchRegex },
                { profit_loss: searchRegex },
            ];
        }

        // Position filter logic
        if (position === "open") {
            query.close_price = null;
        } else if (position === "close") {
            query.close_price = { $ne: null };
        }

        // Count for pagination
        const totalRecords = await Trade.countDocuments(query);
        const totalPages = Math.ceil(totalRecords / limit);

        // Fetch paginated and populated data
        const trades = await Trade.find(query)
            .populate("user_id", "first_name last_name email")
            .populate("symbol_id", "name")
            .populate("user_wallet_id", "balance")
            .skip(skip)
            .limit(parseInt(limit))
            .sort({ created_at: -1 });

        // Format
        const formattedTrades = trades.map(trade => ({
            _id: trade._id,
            user: trade.user_id,
            side: trade.side,
            profit_loss: trade.profit_loss,
            open_price: trade.open_price,
            open_date_formattad: trade.open_date_formattad,
            close_price: trade.close_price || "-",
            close_date_formattad: trade.close_date_formattad || "",

        }));

        res.json({
            data: formattedTrades,
            currentPage: Number(page),
            totalPages,
            totalRecords,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


exports.show = async (req, res) => {
    try {
        // Validate if ID is a valid ObjectId
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: 'Invalid Trade ID format' });
        }

        const trade = await Trade.findById(req.params.id)
            .populate('user_id', 'first_name last_name email name image country_name country_code phone_number')
            .populate('user_wallet_id') // Get all user_wallet data
            .populate('symbol_id', 'name')
            .select('_id user_id user_wallet_id lots trade_id profit loss open_price close_price side reversal open_date close_date position_id deal_id created_at');

        if (!trade) {
            return res.status(404).json({ message: 'Trade not found' });
        }

        res.status(200).json({ success: true, data: trade });

    } catch (error) {
        console.error('Error fetching trade:', error);
        res.status(500).json({ message: 'Server Error', error: error.message });
    }
};

// controllers/TradeApiController.js

exports.getTradeDashboardDetails = async (req, res) => {
    try {
        const userWalletID = req.body.userWalletID;

        // Fetch challenge info and populate account details
        const challengeInfo = await UserWallet.findById(userWalletID)
            .populate("account_type_id")
            .populate("account_size_id");

        if (
            !challengeInfo.account_size_id ||
            !challengeInfo.account_size_id.max_daily_loss
        ) {
            return res.status(400).json({
                success: 0,
                message: "Account size data is incomplete.",
            });
        }

        // Fetch start and end trade periods
        const startTradePeriod = await Trade.find({ user_wallet_id: userWalletID })
            .sort({ created_at: 1 })
            .limit(1);
        const endTradePeriod = await Trade.find({ user_wallet_id: userWalletID })
            .sort({ created_at: -1 })
            .limit(1);

        // Fetch profit and loss data
        const trades = await Trade.find({
            user_wallet_id: userWalletID,
            position: "close",
        }).select("profit loss");
        // const sumProfit = trades.reduce(
        //   (acc, trade) => acc + parseFloat(trade.profit || 0),
        //   0
        // );
        // const sumProfit = trades.reduce((sum, trade) => sum + parseFloat(trade.profit || 0), 0);
        // console.log("Total Profit:", sumProfit);
        // const sumLoss = trades.reduce(
        //   (acc, trade) => acc + parseFloat(trade.loss || 0),
        //   0
        // );
        const countTrades = trades.length;

        const sumProfit =
            countTrades > 0
                ? trades.reduce(
                    (sum, trade) => sum + parseFloat(trade.profit || 0),
                    0
                ) / countTrades
                : 0;

        const sumLoss =
            countTrades > 0
                ? trades.reduce((sum, trade) => sum + parseFloat(trade.loss || 0), 0) /
                countTrades
                : 0;

        const winTrades = trades.filter((trade) => parseFloat(trade.profit) > 0);
        const lossTrades = trades.filter((trade) => parseFloat(trade.loss) > 0);

        const winAverage = sumProfit / (winTrades.length || 1);
        const lossAverage = sumLoss / (trades.length || 1);
        const winRatio = (winTrades.length / (trades.length || 1)) * 100;

        const equity = challengeInfo.equity || 0;
        const dailyMaxLossLimit =
            (parseFloat(challengeInfo.account_size_id.max_daily_loss) / 100) * equity;
        const maxOverallLossLimit =
            (parseFloat(challengeInfo.account_size_id.max_overall_loss) / 100) *
            equity;
        const profitTarget =
            (parseFloat(challengeInfo.account_size_id.profit_target) / 100) *
            (challengeInfo.account_size_id.limit || 0);

        const makeOverAllLossPercentage =
            (sumLoss / (maxOverallLossLimit || 1)) * 100;
        const makeDailyLossPercentage = 0; // Placeholder; calculate daily loss based on your data
        const makeOverAllProfitPercentage =
            (sumProfit / (sumProfit + sumLoss || 1)) * 100;

        const maxTradingDays =
            parseInt(challengeInfo.account_size_id.min_trade_days, 10) || 0;
        const countMaxTradingDaysLeft = Math.max(
            0,
            maxTradingDays - (startTradePeriod.length > 0 ? 1 : 0)
        );
        const countMaxTradingDaysLeftPercentage =
            (countMaxTradingDaysLeft / maxTradingDays) * 100;

        const response = {
            success: 0,
            data: {
                challengeInfo,
                account_typeqqq: challengeInfo.account_type,
                startPeriodDate: startTradePeriod[0] || null,
                endPeriodDate: endTradePeriod[0] || null,
                winAverage,
                lossAverage,
                totalProfit: sumProfit,
                totalLoss: sumLoss,
                winRatio,
                dailyMaxLossLimit,
                maxOverallLossLimit,
                profitTarget,
                dailyMaxThreadShold: equity - dailyMaxLossLimit,
                maxOverallLossThreadShold: equity - maxOverallLossLimit,
                makeOverAllLossPercentage,
                makeDailyLossPercentage,
                makeOverAllProfitPercentage,
                maxTradingDays,
                countMaxTradingDaysLeft,
                countMaxTradingDaysLeftPercentage,
                minBalance: challengeInfo.account_size_id.min_balance || null,
                maxBalance: challengeInfo.account_size_id.max_balance || null,
                minEquity: challengeInfo.account_size_id.min_equity || null,
                maxEquity: challengeInfo.account_size_id.max_equity || null,
                checkRealAccountIsCreated: challengeInfo.checkRealAccountIsCreated || 0,
                checkRealAccountIsRejected:
                    challengeInfo.checkRealAccountIsRejected || 0,
                checkRealAccountIsApproved:
                    challengeInfo.checkRealAccountIsApproved || 0,
                remainDailyLoss: dailyMaxLossLimit - sumLoss,
                remainMaxLoss: maxOverallLossLimit - sumLoss,
                remainMaxProfit: profitTarget - sumProfit,
                showCertificate: challengeInfo.showCertificate || 0,
            },
            message: "Trade History get successfully.",
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: 1,
            message: "Server error",
            error: error.message,
        });
    }
};
exports.getRealTimeDataForAccountDetail = async (req, res) => {
    try {
        const { user_wallet_id } = req.body;

        // Validate request data
        if (!user_wallet_id) {
            return res.status(400).json({
                success: 2,
                message: "Invalid request parameters: user_wallet_id is required.",
            });
        }

        // Fetch wallet data with related account info
        const challengeInfo = await UserWallet.findById(user_wallet_id)
            .populate("account_type_id")
            .populate("account_size_id");

        if (!challengeInfo) {
            return res
                .status(404)
                .json({ success: 2, message: "User wallet not found." });
        }

        const today = moment().startOf("day");
        const balanceHistory = await BalanceHistory.findOne({
            user_wallet_id,
            created_at: { $lt: today.toDate() },
        })
            .sort({ created_at: -1 })
            .exec();

        const equity = challengeInfo.equity || 0;
        const balance = challengeInfo.balance || 0;

        const limit = balanceHistory
            ? balanceHistory.equity
            : challengeInfo.account_size_id.limit || 0;
        const dailyLossLimit =
            challengeInfo.balance *
            (challengeInfo.account_size_id.max_daily_loss / 100) || 0;
        const overallLossLimit =
            challengeInfo.account_size_id.limit *
            (challengeInfo.account_size_id.max_overall_loss / 100) || 0;

        const maxLossDifference =
            parseFloat(challengeInfo.account_size_id.limit) - parseFloat(equity) || 0;
        const dailyLossDifference = limit - balance || 0;

        let totalDailyLoss = dailyLossDifference < 0 ? 0 : dailyLossDifference;
        let totalOverAllLoss = maxLossDifference < 0 ? 0 : maxLossDifference;

        if (challengeInfo.account_status === "disabled") {
            totalDailyLoss = limit - balance;
            totalOverAllLoss = challengeInfo.account_size_id.limit - balance;
        }

        const remainDailyLoss =
            totalDailyLoss <= 0
                ? dailyLossLimit
                : dailyLossLimit < totalDailyLoss
                    ? 0
                    : dailyLossLimit - totalDailyLoss;

        const remainOverAllLoss =
            totalOverAllLoss <= 0
                ? overallLossLimit
                : overallLossLimit < totalOverAllLoss
                    ? 0
                    : overallLossLimit - totalOverAllLoss;

        // Threshold calculations
        const dailyThreadshold = equity - dailyLossLimit || 0;
        const overAllThreadshold =
            challengeInfo.account_size_id.limit - overallLossLimit || 0;

        // Loss percentages
        const totalDailyLossPercentage =
            totalDailyLoss <= 0
                ? 0
                : totalDailyLoss > dailyLossLimit
                    ? 100
                    : (totalDailyLoss / dailyLossLimit) * 100;

        const totalOverAllLossPercentage =
            totalOverAllLoss <= 0
                ? 0
                : totalOverAllLoss > overallLossLimit
                    ? 100
                    : (totalOverAllLoss / overallLossLimit) * 100;

        // Response data format (Updated to match the desired structure)
        const data = {
            dailyLoss: dailyLossLimit,
            overallLoss: totalOverAllLoss,
            totalDailyLoss: totalDailyLoss,
            totalOverAllLoss: totalOverAllLoss,
            accountStatus: challengeInfo.account_status,
            balance: balance,
            equity: equity,
            dailyLossLimit: dailyLossLimit,
            overallLossLimit: overallLossLimit,
            remainDailyLoss: remainDailyLoss,
            remainOverAllLoss: remainOverAllLoss,
            dailyThreadshold: dailyThreadshold,
            overAllThreadshold: overAllThreadshold,
            totalDailyLossPercentage: totalDailyLossPercentage,
            totalOverAllLossPercentage: totalOverAllLossPercentage,
        };

        return res.status(200).json({
            success: 0,
            message: "Account details retrieved successfully.",
            data,
        });
    } catch (error) {
        console.error("Error in getRealTimeDataForAccountDetail:", error);
        return res
            .status(500)
            .json({ success: 2, message: "Server error.", error: error.message });
    }
};



exports.data = async (req, res) => {
    try {
        let query = Trade.find()
            .populate('user')
            .select('_id user_id user_wallet_id profit loss open_date close_date side open_price close_price created_at')
            .sort({ _id: -1 });

        if (req.query.position && req.query.position !== 'all') {
            query = query.where('position', req.query.position);
        }

        const trades = await query.exec();

        // Convert trades into DataTables format
        const data = trades.map((trade, index) => ({
            index: index + 1,
            _id: trade._id,
            user: trade.user ? `${trade.user.first_name} ${trade.user.last_name}` : '',
            profit: trade.profit,
            loss: trade.loss,
            open_date: trade.open_date,
            close_date: trade.close_date,
            side: trade.side,
            open_price: trade.open_price,
            close_price: trade.close_price,
            action: `<a href="/admin/trades/${trade._id}" class="common-action-btn" title="View">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                        </svg>
                    </a>`
        }));

        res.json({
            data
        });
    } catch (error) {
        res.status(500).json({ error: 'Server Error' });
    }
};
