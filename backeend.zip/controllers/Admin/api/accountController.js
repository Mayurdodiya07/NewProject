const mongoose = require('mongoose');
const UserWallet = require('../../../models/UserWallet');
const User = require('../../../models/User');
const Trade = require('../../../models/Trade');
const nodemailer = require('nodemailer');
// const logger = require('../../../helpers/logger');


exports.index = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search || "";

        const query = {};

        // Search by user name or wallet address
        if (search) {
            query.$or = [
                { wallet_address: { $regex: search, $options: "i" } },
            ];
        }

        const totalItems = await UserWallet.countDocuments(query);
        const challenges = await UserWallet.find(query)
            .skip((page - 1) * limit)
            .limit(limit)
            .populate({ path: "user", strictPopulate: false })
            .sort({ createdAt: -1 })
            .lean();


        res.status(200).json({
            data: challenges,
            currentPage: page,
            totalItems,
            totalPages: Math.ceil(totalItems / limit)
        });

    } catch (err) {
        console.error("Error fetching challenges:", err);
        res.status(500).json({ error: err.message });
    }
};


// 2. Get challenge data (all records)
exports.data = async (req, res) => {
    try {
        const challenges = await UserWallet.find().populate('userDetails').lean();
        res.status(200).json({ data: challenges });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


exports.trade = async (req, res) => {
    const { id } = req.params;

    try {
        const trades = await Trade.find({ user_wallet_id: id })
            .populate('user_wallet_id')
            .populate('user_id', 'first_name last_name email')
            .populate('symbol_id', 'name')
            .select('_id user_id user_wallet_id lots trade_id profit loss open_price close_price side reversal open_date close_date position_id deal_id created_at');

        res.status(200).json({ success: true, data: trades });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};


// 4. Get trade data for a specific challenge
exports.tradeData = async (req, res) => {
    const { id } = req.params;
    try {
        const trades = await Trade.find({ userWallet: id }).populate('userWallet');

        if (!trades.length) {
            return res.status(404).json({ message: 'No trades found for this challenge' });
        }

        res.status(200).json({ data: trades });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// 5. Approve a specific challenge

exports.approve = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        // Find the application by ID
        const application = await UserWallet.findById(id);
        if (!application) {
            return res.status(404).json({ error: 'Challenge not found!' });
        }

        // Validate status
        if (status !== 'active' && status !== 'inactive') {
            return res.status(400).json({ error: 'Invalid status value!' });
        }

        // Update the status
        application.status = status;
        await application.save();

        return res.status(200).json({ success: 'Challenge status updated successfully.' });

    } catch (error) {
        return res.status(500).json({ error: 'Failed to update challenge status.', details: error.message });
    }
};

// 6. Show specific challenge details
exports.show = async (req, res) => {
    const { id } = req.params;
    try {
        const challenge = await UserWallet.findById(id).populate('userDetails');

        if (!challenge) {
            return res.status(404).json({ message: 'Challenge not found' });
        }

        res.status(200).json({ data: challenge });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// 7. Show a copy of specific challenge details
exports.showCopy = async (req, res) => {
    const { id } = req.params;
    try {
        const challenge = await UserWallet.findById(id).populate('userDetails');

        if (!challenge) {
            return res.status(404).json({ message: 'Challenge not found' });
        }

        res.status(200).json({ data: { ...challenge.toObject(), isCopy: true } });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


// update status 
exports.updateStatus = async (req, res) => {
    const { id } = req.params;
    const { account_status } = req.body;

    try {
        const application = await UserWallet.findById(id).populate('user_id');

        if (!application) {
            return res.status(404).json({ error: 'Challenge request not found!' });
        }

        // Validate account_status
        if (account_status !== 'passed') {
            return res.status(400).json({ error: 'Invalid account status value!' });
        }

        // Update account_status field
        application.account_status = account_status;
        await application.save();

        // Send email notification if status is passed
        if (application.user_id && application.user_id.email) {
            const message = "Congratulations! Your challenge has been passed. Now you can proceed to apply for a real account.";

            const transporter = nodemailer.createTransport({
                host: process.env.MAIL_HOST,
                port: process.env.MAIL_PORT,
                secure: process.env.MAIL_PORT == 465,
                auth: {
                    user: process.env.MAIL_USERNAME,
                    pass: process.env.MAIL_PASSWORD
                }
            });

            const mailOptions = {
                from: `"${process.env.MAIL_FROM_NAME}" <${process.env.MAIL_FROM_ADDRESS}>`,
                to: application.user_id.email,
                subject: 'Challenge Passed - Next Step',
                text: message
            };

            try {
                await transporter.sendMail(mailOptions);
                console.log(`Email sent successfully to ${application.user_id.email}`);
            } catch (error) {
                console.error('Failed to send email:', error);
            }
        }

        return res.json({ success: 'Challenge request status updated successfully.' });

    } catch (error) {
        console.error('Error updating challenge request status:', error);
        return res.status(500).json({ error: 'Failed to update challenge request status.' });
    }
};


// 9. Show trade details for a specific challenge

exports.showTrade = async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: 'Invalid Trade ID format' });
        }

        const trade = await Trade.findById(req.params.id)
            .populate('user_id', 'first_name last_name email name image country_name country_code phone_number')
            .populate('user_wallet_id')
            .populate('symbol_id', 'name')
            .select('_id user_id user_wallet_id lots trade_id profit loss open_price close_price side reversal open_date close_date position_id deal_id created_at');

        if (!trade) {
            return res.status(404).json({ message: 'Trade not found' });
        }

        res.status(200).json({ success: true, data: trade });
    } catch (error) {
        console.error('Error fetching trade:', error);
        res.status(500).json({ message: 'Server Error', error: error.message });
    }
};


// 10. Toggle status of a specific challenge
exports.toggleStatus = async (req, res) => {
    const { id } = req.params;

    try {
        const challenge = await UserWallet.findById(id).populate('userDetails');

        if (!challenge) {
            return res.status(404).json({ message: 'Challenge not found' });
        }

        challenge.status = challenge.status === 'active' ? 'inactive' : 'active';
        await challenge.save();

        res.status(200).json({ message: 'Status toggled', data: challenge });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

