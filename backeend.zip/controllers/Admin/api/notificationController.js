const express = require('express');
const Notification = require('../../../models/Notification');
const NotificationHelper = require('../../../helpers/NotificationHelper');


exports.unreadCount = async (req, res) => {
    try {
        const count = await Notification.countDocuments({ is_read: false });
        res.json({ count });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// exports.index = (req, res) => {
//     res.render('admin/notification/index');
// };

exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "" } = req.query;
        const skip = (page - 1) * limit;

        const query = {};

        if (search) {
            query.$or = [
                { notification_type: { $regex: search, $options: 'i' } },
                { 'user_id.first_name': { $regex: search, $options: 'i' } },
                { 'user_id.last_name': { $regex: search, $options: 'i' } },
            ];
        }

        const total = await Notification.countDocuments(query);

        const notifications = await Notification.find(query)
            .populate('user_id', 'first_name last_name email title')
            .sort({ createdAt: -1 })
            .skip(Number(skip))
            .limit(Number(limit))
            .lean();

        res.json({
            data: notifications,
            totalPages: Math.ceil(total / limit),
            currentPage: Number(page),
            totalItems: total,
        });
    } catch (error) {
        console.error("Error in notifications:", error);
        res.status(500).json({ message: error.message });
    }
};


exports.data = async (req, res) => {
    try {
        const searchValue = req.query.search?.value?.toLowerCase() || '';
        const length = parseInt(req.query.length, 10) || 10;
        const start = parseInt(req.query.start, 10) || 0;
        const page = Math.floor(start / length) + 1;

        const query = Notification.find()
            .populate('user', 'first_name last_name email')
            .sort({ _id: -1 });

        if (searchValue) {
            query.where({
                $or: [
                    { notification_type: { $regex: searchValue, $options: 'i' } },
                    {
                        user: {
                            $elemMatch: {
                                $or: [
                                    { first_name: { $regex: searchValue, $options: 'i' } },
                                    { last_name: { $regex: searchValue, $options: 'i' } }
                                ]
                            }
                        }
                    }
                ]
            });
        }

        const totalRecords = await Notification.countDocuments(query);
        const notifications = await query.skip(start).limit(length);

        const data = notifications.map((notification, index) => {
            const userName = notification.user
                ? `${notification.user.first_name} ${notification.user.last_name}`
                : '-';
            return {
                DT_RowIndex: start + index + 1,
                user_name: userName,
                notification_type: notification.notification_type,
                action: getAction(notification)
            };
        });

        res.json({
            draw: parseInt(req.query.draw, 10) || 1,
            recordsTotal: totalRecords,
            recordsFiltered: totalRecords,
            data
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

function getAction(notification) {
    if (!notification || !notification.notification_type || !notification.action_id) {
        return "/admin";
    }

    const routes = {
        challange_request: `/admin/challenge-requests/${notification.action_id}`,
        real_account_request: `/admin/real-challenge-requests/${notification.action_id}`,
        payout_request: `/admin/payout/${notification.action_id}`
    };

    return routes[notification.notification_type] || "/admin";
}




// exports.dataold = async (req, res) => {
//     try {
//         await Notification.updateMany({}, { is_read: true });

//         const applications = await Notification.find()
//             .populate('user', 'first_name last_name')
//             .sort({ _id: -1 })
//             .select('_id user_id notification_type action_id');

//         const data = applications.map((notification, index) => {
//             return {
//                 index: index + 1,
//                 notification_type: notification.notification_type.replace(/_/g, ' ').toUpperCase(),
//                 action: getAction(notification)
//             };
//         });

//         res.json({
//             draw: parseInt(req.query.draw, 10) || 1,
//             recordsTotal: applications.length,
//             recordsFiltered: applications.length,
//             data
//         });
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };