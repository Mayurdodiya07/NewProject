
const NewsCurrency = require('../../../models/NewsCurrency');
const { validationResult } = require('express-validator');

// // Index route
// exports.index = async (req, res) => {
//     res.render('admin.news-currencies.index');
// };

// Fetch paginated news currencies

exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "", startDate, endDate } = req.query;


        const query = {
            deleted_at: null,
            ...(search ? { name: { $regex: search, $options: "i" } } : {}),
        };
        if (startDate && endDate) {
            query.date = {
                $gte: new Date(startDate),
                $lte: new Date(endDate + "T23:59:59Z")
            };
        }

        const total = await NewsCurrency.countDocuments(query);
        const data = await NewsCurrency.find(query)
            .sort({ created_at: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit))
            .lean();

        const pagination = {
            total,
            page: parseInt(page),
            limit: parseInt(limit),
            totalPages: Math.ceil(total / limit),
        };

        res.status(200).json({
            success: true,
            data,
            pagination,
        });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal Server Error" });
    }
};

// Data route 
exports.data = async (req, res) => {
    try {
        const news_currencies = await NewsCurrency.find().sort({ _id: -1 });
        let filteredCurrencies = news_currencies;

        // Apply search filter
        if (req.query.search && req.query.search.value) {
            const searchValue = req.query.search.value.toLowerCase();
            filteredCurrencies = news_currencies.filter(currency =>
                currency.name.toLowerCase().includes(searchValue) ||
                currency.short_code.toLowerCase().includes(searchValue) ||
                currency.code.toLowerCase().includes(searchValue)
            );
        }

        const data = filteredCurrencies.map((currency, index) => ({
            index: index + 1,
            name: currency.name,
            code: currency.code,
            short_code: currency.short_code,
            action: `
                <a href="/admin/news-currencies/edit/${currency._id}" class="common-action-btn" title="Edit">
                    <svg>...</svg>
                </a>
                <a href="#" class="common-action-btn" data-toggle="modal" data-target="#delete_modal" data-id="${currency._id}" title="Delete" onclick="confirmDelete(event)">
                    <svg>...</svg>
                </a>`
        }));

        res.json({
            draw: req.query.draw || 1,
            recordsTotal: news_currencies.length,
            recordsFiltered: filteredCurrencies.length,
            data: data
        });

    } catch (error) {
        res.status(500).json({ error: 'Server Error: ' + error.message });
    }
};

// exports.add = (req, res) => {
//     res.render('admin.news-currencies.add');
// };
// API controller for adding news currency
exports.add = async (req, res) => {
    try {
        const currencies = await NewsCurrency.find({}, "name code short_code status");
        res.status(200).json(currencies);
    } catch (error) {
        res.status(500).json({ message: "Error fetching news currencies", error: error.message });
    }
};


exports.store = async (req, res) => {
    try {

        const { name, code, short_code, status } = req.body;

        if (!name || !code || !short_code || !status) {
            return res.status(400).json({ message: "All fields are required!" });
        }

        // Ensure `short_code` is always a string
        if (typeof short_code !== "string") {
            return res.status(400).json({ message: "Short Code must be a string" });
        }

        const newCurrency = new NewsCurrency({ name, code, short_code, status });
        await newCurrency.save();

        res.status(201).json({
            message: "News Currency added successfully",
            data: newCurrency,
        });
    } catch (error) {
        res.status(500).json({ error: "Error adding News Currency: " + error.message });
    }
};



exports.edit = async (req, res) => {
    try {
        // Fetch the NewsCurrency using the ID from URL parameters
        const news_currency = await NewsCurrency.findById(req.params.id).exec();

        if (!news_currency) {
            return res.status(404).json({ error: 'Currency not found' });
        }

        // Send the news currency data to the frontend
        res.status(200).json(news_currency);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching News Currency: ' + error.message });
    }
};



exports.update = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const { name, code, short_code, status } = req.body;

        // Fetch the NewsCurrency using the ID from URL parameters
        const news_currency = await NewsCurrency.findById(req.params.id).exec();
        if (!news_currency) {
            return res.status(404).json({ error: 'Currency not found' });
        }

        // Update the fields with the provided data or keep existing values
        news_currency.name = name || news_currency.name;
        news_currency.code = code || news_currency.code;
        news_currency.short_code = short_code || news_currency.short_code;
        news_currency.status = status || news_currency.status;

        // Save the updated currency data
        await news_currency.save();

        // Send the updated data as the response
        res.status(200).json({ message: 'News Currency updated successfully', data: news_currency });
    } catch (error) {
        res.status(500).json({ error: 'Error updating News Currency: ' + error.message });
    }
};

exports.destroy = async (req, res) => {
    try {
        const newsCurrency = await NewsCurrency.findByIdAndDelete(req.params.id);
        if (!newsCurrency) return res.status(404).json({ error: "Currency not found" });

        res.json({ success: "News Currency deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: "Failed to delete News Currency: " + error.message });
    }
};
