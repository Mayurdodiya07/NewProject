const User = require('../../../models/User');
const AccountRequest = require('../../../models/AccountRequest');
const RealAccountRequest = require('../../../models/RealAccountRequest');
const UserWallet = require('../../../models/UserWallet');
const Payouts = require('../../../models/Payouts');
const Trade = require('../../../models/Trade');
const PaymentMethod = require('../../../models/PaymentMethod');
const AccountSize = require('../../../models/AccountSize');
const News = require('../../../models/News');
const NewsCurrency = require('../../../models/NewsCurrency');
const Notification = require('../../../models/Notification');


exports.index = async (req, res) => {
    try {
        const userCount = await User.countDocuments();
        const challengeRequestsCount = await AccountRequest.countDocuments();
        const realchallengeRequestsCount = await RealAccountRequest.countDocuments();
        const challengeCount = await UserWallet.countDocuments();
        const payoutsCount = await Payouts.countDocuments();
        const payoutsRequestCount = await Payouts.countDocuments();
        const usersCount = await User.countDocuments();
        const tradesCount = await Trade.countDocuments();
        const paymentMethodsCount = await PaymentMethod.countDocuments();
        const accountSizeCount = await AccountSize.countDocuments();
        const newsCalenderCount = await News.countDocuments();
        const newsCurrenciesCount = await NewsCurrency.countDocuments();
        const disabledAccountsCount = await UserWallet.countDocuments({ account_status: 'disabled' });
        const notificationCount = await Notification.countDocuments();

        // Leaderboard count: distinct users with closed positions
        const leaderboardResult = await Trade.aggregate([
            { $match: { position: 'close' } },
            { $group: { _id: '$user_id' } },
            { $count: 'distinct_user_count' }
        ]);
        const leaderboardCount = leaderboardResult.length > 0 ? leaderboardResult[0].distinct_user_count : 0;
        // const leaderboardResult = await Trade.aggregate([
        //     { $match: { position: 'close' } },
        //     { $group: { _id: '$user_id' } },
        //     { $count: 'distinct_user_count' }
        // ]);
        // const leaderboardCount = leaderboardResult.length > 0 ? leaderboardResult[0].distinct_user_count : 0;


        return res.json({
            userCount,
            challengeRequestsCount,
            realchallengeRequestsCount,
            challengeCount,
            payoutsCount,
            payoutsRequestCount,
            usersCount,
            tradesCount,
            paymentMethodsCount,
            leaderboardCount,
            newsCalenderCount,
            newsCurrenciesCount,
            disabledAccountsCount,
            notificationCount,
            accountSizeCount
        });
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }
};

