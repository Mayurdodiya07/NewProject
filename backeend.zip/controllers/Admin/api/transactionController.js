const UserWallet = require('../../../models/UserWallet');
const Transaction = require('../../../models/Transaction');
const Mt5Service = require('../../../services/mt5Service');
const { Op } = require('sequelize');

exports.index = async (req, res) => {
    try {
        res.render('admin/transactions/index');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

exports.show = async (req, res) => {
    const id = req.params.id;
    try {
        const transaction = await Transaction.findOne({
            where: { id },
            include: ['userWallet', 'toUserWallet'],
        });

        if (!transaction) {
            return res.status(404).send('Transaction not found');
        }

        res.render('admin/transactions/show', { transaction });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

exports.approve = async (req, res) => {
    const id = req.params.id;
    const { transaction_status } = req.body;

    try {
        const transaction = await Transaction.findOne({
            where: { id },
            include: ['user'],
        });

        if (!transaction) {
            return res.status(404).send({ error: 'Transaction not found!' });
        }

        const { transfer_type, amount, user_wallet_id, to_user_wallet_id, type } = transaction;

        if (transaction_status === 'done') {
            const userWallet = await UserWallet.findByPk(user_wallet_id);

            if (!userWallet) {
                return res.status(404).send({ error: 'Wallet not found!' });
            }

            switch (transfer_type) {
                case 'deposit':
                    userWallet.balance += amount;
                    userWallet.available_balance += amount;

                    if (type === 'mt5') {
                        const response = await Mt5Service.updateBalance({
                            loginid: userWallet.account_number,
                            amount,
                            txnType: 0,
                        });

                        if (!response) {
                            return res.status(500).send({ error: 'Failed to update MT5 balance' });
                        }
                        userWallet.equity = userWallet.balance;
                    }

                    await userWallet.save();
                    break;

                case 'withdraw':
                    if (amount > userWallet.balance) {
                        return res.status(400).send({ error: 'Not enough balance' });
                    }

                    userWallet.balance -= amount;
                    userWallet.available_balance -= amount;

                    if (type === 'mt5') {
                        const response = await Mt5Service.updateBalance({
                            loginid: userWallet.account_number,
                            amount,
                            txnType: 1,
                        });

                        if (!response) {
                            return res.status(500).send({ error: 'Failed to update MT5 balance' });
                        }
                        userWallet.equity = userWallet.balance;
                    }

                    await userWallet.save();
                    break;

                case 'transfer':
                    const toUserWallet = await UserWallet.findByPk(to_user_wallet_id);

                    if (!toUserWallet) {
                        return res.status(404).send({ error: 'Recipient wallet not found' });
                    }

                    if (amount > userWallet.balance) {
                        return res.status(400).send({ error: 'Insufficient funds for transfer' });
                    }

                    userWallet.balance -= amount;
                    userWallet.available_balance -= amount;
                    toUserWallet.balance += amount;
                    toUserWallet.available_balance += amount;

                    if (userWallet.account === 'mt5') {
                        const responseFrom = await Mt5Service.updateBalance({
                            loginid: userWallet.account_number,
                            amount,
                            txnType: 1,
                        });

                        if (!responseFrom) {
                            return res.status(500).send({ error: 'Failed to update MT5 balance' });
                        }
                        userWallet.equity = userWallet.balance;
                    }

                    if (toUserWallet.account === 'mt5') {
                        const responseTo = await Mt5Service.updateBalance({
                            loginid: toUserWallet.account_number,
                            amount,
                            txnType: 0,
                        });

                        if (!responseTo) {
                            return res.status(500).send({ error: 'Failed to update recipient MT5 balance' });
                        }
                        toUserWallet.equity = toUserWallet.balance;
                    }

                    await userWallet.save();
                    await toUserWallet.save();
                    break;

                default:
                    return res.status(400).send({ error: 'Invalid transfer type' });
            }
        }

        transaction.transaction_status = transaction_status;
        await transaction.save();

        res.redirect(`/admin/transactions/${id}`).send('Status updated successfully');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

exports.data = async (req, res) => {
    try {
        const transactions = await Transaction.findAll({
            include: ['user'],
        });

        const filteredTransactions = transactions.filter((transaction) => {
            const search = req.query.search?.value || '';
            return (
                transaction.status.includes(search) ||
                transaction.transaction_status.includes(search) ||
                transaction.transfer_type.includes(search) ||
                transaction.createdAt.includes(search) ||
                (transaction.user &&
                    (transaction.user.first_name.includes(search) || transaction.user.last_name.includes(search)))
            );
        });

        res.json({ data: filteredTransactions });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};
