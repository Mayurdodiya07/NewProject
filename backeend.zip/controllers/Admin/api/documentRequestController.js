const User = require('../../../models/User');
const Application = require('../../../models/Application');
const Document = require('../../../models/Document');
const VerificationLevel = require('../../../models/VerificationLevel');
const { Op } = require('sequelize');
const { application } = require('express');

exports.index = async (req, res) => {
    try {
        res.render('admin/document-requests/index');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
};
exports.show = async (req, res) => {
    try {
        const { id } = req.params;
        const documentRequest = await Application.findByPk(id, {
            include: [{
                association: 'documents',
                include: ['documentType']
            }]
        });

        if (!documentRequest) {
            return res.status(404).send('Document request not found');
        }

        res.render('admin/document-requests/show', { documentRequest });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
}; exports.approve = async (req, res) => {
    try {
        const { id } = req.params;
        const application = await Application.findByPk(id, {
            include: ['documents']
        });

        if (!application) {
            return res.status(404).json({ error: 'Application not found!' });
        }

        const documents = application.documents;
        if (!documents || documents.length === 0) {
            return res.status(404).json({ error: 'Application documents not found!' });
        }

        await Promise.all(documents.map(async (document) => {
            await document.update({ approved: true });

            await Document.create({
                document_type_id: document.document_type_id,
                user_id: application.user_id,
                application_id: document.application_id,
                status: 'approved',
                file: document.file,
            });
        }));

        application.status = 'approved';
        await application.save();

        const verificationLevel = await VerificationLevel.findOne({ where: { index: 1 } });
        if (verificationLevel) {
            const user = await User.findByPk(application.user_id);
            if (user) {
                user.verification_level_id = verificationLevel.id;
                await user.save();
            }
        }

        res.json({ success: 'Request approved successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
    }
};

exports.data = async (req, res) => {
    try {
        const applications = await Application.findAll({ include: ['user'] });

        // Filtering
        const { search } = req.query;
        let filteredApplications = applications;
        if (search) {
            filteredApplications = applications.filter((application) => {
                const fullName = `${application.user.first_name} ${application.user.last_name}`.toLowerCase();
                return application.status.toLowerCase().includes(search.toLowerCase()) ||
                    fullName.includes(search.toLowerCase());
            });
        }

        const result = filteredApplications.map((application, index) => ({
            id: application.id,
            user: application.user,
            status: application.status,
            created_at_formatted: application.createdAt, // Adjust formatting as needed
            action: `
                <a href="/admin/document-requests/${application.id}" class="common-action-btn" title="View">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178c.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                    </svg>
                </a>
                ${application.status === 'pending' ? `
                    <button class="common-action-btn approve-request" data-id="${application.id}" title="Approve">
                        <i class="fas fa-check"></i>
                    </button>` : ''}
            `
        }));

        res.json({ data: result });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
};

