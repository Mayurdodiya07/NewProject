const moment = require('moment');
const UserWallet = require('../../../models/UserWallet');
const User = require('../../../models/User');
const AccountType = require('../../../models/AccountType');


exports.index = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search || "";

        const query = {
            account_status: 'passed'
        };

        if (search) {
            const orConditions = [
                { mt5_type: { $regex: search, $options: 'i' } }
            ];

            if (!isNaN(search)) {
                orConditions.push({ account_number: parseInt(search) });
            }

            query.$or = orConditions;
        }


        const totalCount = await UserWallet.countDocuments(query);

        const passedAccounts = await UserWallet.find(query)
            .populate({
                path: 'userDetails',
                select: 'title first_name last_name email',
            })
            .populate({
                path: 'account_type_id',
                model: 'AccountType',
                select: '_id name step created_at updated_at',
            })
            .sort({ created_at: -1 }) // Optional: newest first
            .skip((page - 1) * limit)
            .limit(limit)
            .lean();

        res.status(200).json({
            data: passedAccounts,
            pagination: {
                total: totalCount,
                page,
                limit,
                totalPages: Math.ceil(totalCount / limit)
            }
        });
    } catch (err) {
        // console.error("Error fetching passed accounts:", err);
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};


exports.data = async (req, res) => {
    try {
        let applications = UserWallet.find({ account_status: 'passed' })
            .populate('user')
            .sort({ _id: -1 });

        if (req.query.date_range) {
            const { date_range } = req.query;
            let startDate, endDate;

            switch (date_range) {
                case 'today':
                    startDate = moment().startOf('day');
                    endDate = moment().endOf('day');
                    break;
                case 'week':
                    startDate = moment().startOf('week');
                    endDate = moment().endOf('week');
                    break;
                case 'month':
                    startDate = moment().startOf('month');
                    endDate = moment().endOf('month');
                    break;
                default:
                    startDate = null;
                    endDate = null;
            }

            if (startDate && endDate) {
                applications = applications.where('updated_at').gte(startDate).lte(endDate);
            }
        }

        applications = await applications.exec();

        // Pagination and search filter
        const searchQuery = req.query.search ? req.query.search.toLowerCase() : '';
        const filteredApplications = applications.filter(app => {
            const fullName = app.user ? `${app.user.first_name} ${app.user.last_name}`.toLowerCase() : '';
            return (
                (app.account_number && app.account_number.toLowerCase().includes(searchQuery)) ||
                (app.mt5_type && app.mt5_type.toLowerCase().includes(searchQuery)) ||
                fullName.includes(searchQuery) ||
                moment(app.updated_at).format('YYYY-MM-DD HH:mm:ss').includes(searchQuery)
            );
        });

        // Pagination logic
        const page = parseInt(req.query.page) || 1;
        const pageSize = parseInt(req.query.pageSize) || 10;
        const paginatedData = filteredApplications.slice((page - 1) * pageSize, page * pageSize);

        res.json({
            data: paginatedData,
            total: filteredApplications.length,
            page,
            pageSize
        });

    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err });
    }
};
