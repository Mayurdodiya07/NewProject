const PromoApplied = require('../../../models/PromoApplied');

exports.add = async (req, res) => {
    res.render('admin/promo-applied/add');
};

exports.store = async (req, res) => {
    try {
        const { user_id, code } = req.body;

        if (!user_id || !code) {
            return res.status(400).json({ error: 'user_id and code are required' });
        }

        await PromoApplied.create({ user_id, code });

        return res.redirect('/admin/promo-code?success=Promo Code added successfully');
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Server error' });
    }
};
