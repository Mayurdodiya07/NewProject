const bcrypt = require('bcryptjs');
const ExchangeRate = require('../../../models/ExchangeRate');
const User = require('../../../models/User');
const UserWallet = require('../../../models/UserWallet');
const UserAccount = require('../../../models/UserAccount');
const Admin = require('../../../models/Admin');

exports.index = async (req, res) => {
    try {
        const convertCurrencyData = await ExchangeRate.findOne({ from_currency: 'USD', to_currency: 'INR' });
        const users = await User.find();
        const userWallets = await UserWallet.find();
        const firstUserAccount = await UserAccount.findOne();

        res.render('admin/settings/index', {
            convertCurrencyData,
            users,
            userWallets,
            firstUserAccount
        });

    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

exports.changeCurrencyRate = async (req, res) => {
    try {
        const { to_currency_rate } = req.body;
        if (!to_currency_rate) {
            return res.status(400).json({ error: 'To currency rate is required' });
        }

        await ExchangeRate.findOneAndUpdate(
            { from_currency: 'USD', to_currency: 'INR' },
            { from_currency_rate: 1, to_currency_rate },
            { upsert: true, new: true }
        );

        res.redirect('back');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};


exports.changePassword = async (req, res) => {
    try {
        const { current_password, new_password, new_password_confirmation } = req.body;

        if (!current_password || !new_password || !new_password_confirmation) {
            return res.status(400).json({ error: "All fields are required" });
        }

        if (new_password !== new_password_confirmation) {
            return res.status(400).json({ error: "New password confirmation does not match" });
        }

        if (!req.admin) {
            return res.status(401).json({ error: "Unauthorized: Admin not found" });
        }

        const admin = req.admin;

        // Compare current password
        const isMatch = await bcrypt.compare(current_password, admin.password);
        if (!isMatch) {
            return res.status(400).json({ error: "Current password is incorrect" });
        }

        // Hash new password
        hashedPassword = await bcrypt.hash(new_password, 10);
        await Admin.findByIdAndUpdate(admin.id, { password: hashedPassword }, { new: true });

        res.json({ message: "Password changed successfully" });
    } catch (error) {
        console.error("Error in changePassword:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};
exports.manageUserAccount = async (req, res) => {
    try {
        const { user_id, user_wallet_id, account_size, payout_percentage, username } = req.body;

        if (!account_size || !payout_percentage || !username) {
            return res.status(400).json({ error: 'Required fields are missing' });
        }

        await UserAccount.deleteMany({});

        const userAccount = new UserAccount({
            user_id,
            user_wallet_id,
            account_size,
            payout_percentage,
            username
        });

        await userAccount.save();
        res.redirect('back');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

exports.data = async (req, res) => {
    try {
        const [convertCurrencyData, users, userWallets, firstUserAccount] = await Promise.all([
            ExchangeRate.findOne({ from_currency: 'USD', to_currency: 'INR' }),
            User.find().limit(100),
            UserWallet.find().limit(100),
            UserAccount.findOne().populate('user_id').populate('user_wallet_id')
        ]);

        res.json({
            convertCurrencyData,
            users,
            userWallets,
            firstUserAccount
        });
    } catch (error) {
        console.error("Error fetching data:", error.message, error.stack);
        res.status(500).json({ error: 'Internal Server Error', details: error.message });
    }
};
