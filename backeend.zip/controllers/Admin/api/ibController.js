const IbRequest = require('../../../models/IbRequest');
const User = require('../../../models/User');
const Currency = require('../../../models/Currency');
const UserWallet = require('../../../models/UserWallet');

exports.index = async (req, res) => {
    res.render('admin/ib/index');
};

exports.show = async (req, res) => {
    try {
        const ibRequest = await IbRequest.findById(req.params.id)
            .populate('user')
            .populate('partner_program');

        if (!ibRequest) {
            return res.status(404).json({ error: 'IB request not found' });
        }

        res.render('admin/ib/show', { ibRequest });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.approve = async (req, res) => {
    try {
        const ibRequest = await IbRequest.findById(req.params.id).populate('user');
        if (!ibRequest) {
            return res.status(404).json({ error: 'IB request not found' });
        }

        if (req.body.status === 'approved') {
            ibRequest.user.is_ib = true;
            ibRequest.user.ib_request = 'approved';

            const currency = await Currency.findOne({ code: 'USD' });
            if (currency) {
                await UserWallet.create({
                    user_id: ibRequest.user._id,
                    balance: 0.0,
                    available_balance: 0.0,
                    on_hold_balance: 0.0,
                    currency: currency.name,
                    currency_id: currency._id,
                    code: currency.code,
                    favourite: false,
                    fiat: false,
                    enabled: true,
                    status: 'active',
                    account: 'ib'
                });
            }

            await ibRequest.user.save();
        }

        if (req.body.status === 'rejected') {
            ibRequest.user.is_ib = false;
            ibRequest.user.ib_request = null;
            await ibRequest.user.save();
        }

        ibRequest.status = req.body.status;
        await ibRequest.save();

        res.redirect(`/admin/ib/show/${req.params.id}`);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.data = async (req, res) => {
    try {
        let ibRequests = await IbRequest.find().populate('user');

        if (req.query.search) {
            const search = req.query.search.toLowerCase();
            ibRequests = ibRequests.filter(ib =>
                ib.status.toLowerCase().includes(search) ||
                (ib.user && (
                    ib.user.first_name.toLowerCase().includes(search) ||
                    ib.user.last_name.toLowerCase().includes(search)
                ))
            );
        }

        res.json({ data: ibRequests });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};
