const express = require("express");
const AccountSize = require('../../../models/AccountSize');
const AccountType = require('../../../models/AccountType');
const { validationResult } = require('express-validator');

exports.index = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search?.trim() || "";

        const isNumeric = !isNaN(search);
        const matchConditions = [];

        if (search) {
            matchConditions.push(
                { name: { $regex: search, $options: "i" } },
                { "account_type.name": { $regex: search, $options: "i" } },
                { "account_type.step": { $regex: search, $options: "i" } }
            );

            if (isNumeric) {
                matchConditions.push(
                    { limit: Number(search) },
                    { price: search }
                );
            }
        }

        const query = matchConditions.length > 0 ? { $or: matchConditions } : {};

        const aggregatePipeline = [
            {
                $addFields: {
                    account_type_id: { $toObjectId: "$account_type_id" }
                }
            },
            {
                $lookup: {
                    from: "account_types",
                    localField: "account_type_id",
                    foreignField: "_id",
                    as: "account_type"
                }
            },
            { $unwind: { path: "$account_type", preserveNullAndEmptyArrays: true } },
            { $match: query },
            { $sort: { created_at: -1 } },
            {
                $facet: {
                    metadata: [{ $count: "total" }],
                    data: [
                        { $skip: (page - 1) * limit },
                        { $limit: limit },
                        {
                            $project: {
                                _id: 1,
                                name: 1,
                                limit: 1,
                                price: 1,
                                created_at: 1,
                                updated_at: 1,
                                account_type_id: {
                                    _id: "$account_type._id",
                                    name: "$account_type.name",
                                    step: "$account_type.step"
                                }
                            }
                        }
                    ]
                }
            }
        ];

        const results = await AccountSize.aggregate(aggregatePipeline);
        const accountSizes = results[0]?.data || [];
        const total = results[0]?.metadata[0]?.total || 0;

        res.status(200).json({
            success: true,
            data: accountSizes,
            total,
            page,
            limit
        });

    } catch (err) {
        console.error("Account Size Fetch Error:", err.message);
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};

exports.show = async (req, res) => {
    try {
        const accountsize = await AccountSize.findById(req.params.id)
            .select("_id account_type_id limit name min_trade_days profit_target max_overall_loss max_daily_loss status price")
            .populate({
                path: "account_type_id",  // Correct population field
                model: "AccountType",
                select: "_id name step created_at updated_at"
            });

        if (!accountsize) return res.status(404).json({ success: false, message: "Account Size not found" });

        res.json({ success: true, data: accountsize });
    } catch (error) {
        console.error("Error fetching account size details:", error);
        res.status(500).json({ success: false, message: "Server Error", error: error.message });
    }
};


exports.data = async (req, res) => {
    try {
        let accountsize = await AccountSize.find({ deleted_at: null }).sort({ _id: -1 });

        accountsize = accountsize.map(account => ({
            ...account.toObject(),
            impact: account.impact ? account.impact.replace("_", " ") : "",
            action: `<a href="/admin/account-size/${account._id}" class="common-action-btn" title="View">View</a>`
        }));

        res.json({ data: accountsize });
    } catch (error) {
        res.status(500).send("Server Error: " + error.message);
    }
};


exports.add = async (req, res) => {
    const accounttype = await AccountType.find();
    res.render("admin/account-size/add", { accounttype });
};

exports.store = async (req, res) => {
    try {
        const { name, account_type_id, limit, min_trade_days, profit_target, profit_target_phase2, status, max_overall_loss, max_daily_loss, price } = req.body;

        if (!name || !account_type_id || !limit || !min_trade_days || !profit_target || !status || !max_overall_loss || !max_daily_loss || !price) {
            return res.status(400).send("All required fields must be filled");
        }

        const newAccountSize = new AccountSize({
            name, account_type_id, limit, min_trade_days, profit_target, profit_target_phase2, status, max_overall_loss, max_daily_loss, price
        });

        await newAccountSize.save();
        res.redirect("/admin/account-size");
    } catch (error) {
        res.status(500).send("Server Error: " + error.message);
    }
};

exports.edit = async (req, res) => {
    try {
        const accountsize = await AccountSize.findById(req.params.id);
        if (!accountsize) return res.status(404).send("Account Size not found");

        const accounttype = await AccountType.find();
        res.render("admin/account-size/edit", { accountsize, accounttype });
    } catch (error) {
        res.status(500).send("Server Error: " + error.message);
    }
};

exports.update = async (req, res) => {
    try {
        const accountsize = await AccountSize.findById(req.body.id);
        if (!accountsize) return res.status(404).send("Account Size not found");

        Object.keys(req.body).forEach(key => {
            if (req.body[key] !== undefined) {
                accountsize[key] = req.body[key];
            }
        });

        await accountsize.save();
        res.redirect("/admin/account-size");
    } catch (error) {
        res.status(500).send("Server Error: " + error.message);
    }
};

exports.restore = async (req, res) => {
    try {
        const accountsize = await AccountSize.findById(req.params.id);
        if (!accountsize) return res.status(404).send("Account Size not found");

        accountsize.deleted_at = null;
        await accountsize.save();

        res.redirect("/admin/account-size");
    } catch (error) {
        res.status(500).send("Server Error: " + error.message);
    }
};

exports.destroy = async (req, res) => {
    try {
        const accountsize = await AccountSize.findById(req.params.id);
        if (!accountsize) return res.status(404).send("Account Size not found");

        await AccountSize.findByIdAndDelete(req.params.id);
        res.redirect("/admin/account-size");
    } catch (error) {
        res.status(500).send("Server Error: " + error.message);
    }
};

exports.forceDelete = async (req, res) => {
    try {
        const accountsize = await AccountSize.findById(req.params.id);
        if (!accountsize) return res.status(404).send("Account Size not found");

        await AccountSize.findByIdAndRemove(req.params.id);
        res.redirect("/admin/account-size");
    } catch (error) {
        res.status(500).send("Server Error: " + error.message);
    }
};
