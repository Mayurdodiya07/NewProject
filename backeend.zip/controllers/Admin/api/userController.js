const bcrypt = require("bcrypt");
const User = require('../../../models/User');
// const Trade = require('../../../models/Trade');
const UserWallet = require('../../../models/UserWallet');
const Country = require('../../../models/Country');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const path = require('path');
const multer = require('multer');



// Configure multer storage for photo uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/photos/user/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});
exports.upload = multer({ storage });

// Configure nodemailer transporter (update with your SMTP settings)
const transporter = nodemailer.createTransport({
    host: 'smtp.example.com',
    port: 587,
    secure: false,
    auth: {
        user: 'your_email@example.com',
        pass: 'your_password'
    }
});

exports.index = async (req, res) => {
    try {
        let { page, limit, search } = req.query;
        page = parseInt(page) || 1;
        limit = parseInt(limit) || 10;
        const skip = (page - 1) * limit;

        // Create a search filter
        let filter = {};
        if (search) {
            filter = {
                $or: [
                    { first_name: { $regex: search, $options: 'i' } },
                    { last_name: { $regex: search, $options: 'i' } },
                    { email: { $regex: search, $options: 'i' } },
                ]
            };
        }

        // Fetch users with pagination and search
        const users = await User.find(filter).skip(skip).limit(limit).sort({ created_at: -1 });
        const totalUsers = await User.countDocuments(filter);

        res.json({
            success: true,
            data: users,
            pagination: {
                total: totalUsers,
                page,
                limit,
                totalPages: Math.ceil(totalUsers / limit)
            }
        });

    } catch (err) {
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};

// GET /admin/user/data
exports.data = async (req, res) => {
    try {
        // Example: fetch all users for DataTables (adapt query and pagination as needed)
        const users = await User.find().exec();
        // Prepare response with necessary fields
        const data = users.map((user, index) => ({
            DT_RowIndex: index + 1,
            ...user.toObject(),
            action: `<a href="/admin/user/show/${user._id}" class="common-action-btn">View</a>`
        }));
        res.json({
            draw: Number(req.query.draw) || 1,
            recordsTotal: users.length,
            recordsFiltered: users.length,
            data
        });
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// PUT /admin/user/approve/:id
exports.approve = async (req, res) => {
    try {
        // Implement your approval logic here.
        // For example, find the user by id and update an "approved" flag.
        const user = await User.findById(req.params.id).exec();
        if (!user) return res.status(404).json({ error: 'User not found' });

        user.approved = true; // or toggle value based on your business logic
        await user.save();
        res.json({ success: 'User approved successfully', user });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// GET /admin/user/add

exports.add = async (req, res) => {
    try {
        const countries = await Country.find({ deleted_at: null }).sort({ name: 1 }).exec();
        res.json({ success: true, data: { countries } });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};

// POST /admin/user/store
exports.store = async (req, res) => {
    try {
        console.log("Received data:", req.body);
        if (req.file) console.log("Uploaded file:", req.file);

        // Hash password only if it's provided
        let hashedPassword = req.body.password ? await bcrypt.hash(req.body.password, 10) : null;

        const newUser = new User({
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            password: hashedPassword,
            phone: req.body.phone_number,
            photo: req.file ? `/photos/user/${req.file.filename}` : '',
            country: req.body.country,
            city: req.body.city,
            status: req.body.status,
        });

        await newUser.save();
        res.json({ success: true, message: "User created successfully", user: newUser });
    } catch (err) {
        console.error("Error in /store:", err);
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};



exports.edit = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).exec();
        if (!user) return res.status(404).json({ success: false, message: "User not found" });

        const countries = await Country.find({ deleted_at: null }).sort({ name: 1 }).exec();

        res.json({ success: true, data: { user, countries } });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};


// PATCH /admin/user/update/:id
exports.update = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).exec();
        if (!user) return res.status(404).json({ success: false, message: "User not found" });

        user.first_name = req.body.first_name;
        user.last_name = req.body.last_name;
        if (req.body.password && req.body.password !== '') {
            user.password = req.body.password;
        }
        user.phone = req.body.phone_number;
        user.city = req.body.city;
        user.country = req.body.country;
        if (req.body.email_verified_at && !user.email_verified_at) {
            user.email_verified_at = new Date();
        }
        user.status = req.body.status;

        await user.save();

        return res.status(200).json({ success: true, message: "User updated successfully", user });
    } catch (err) {
        return res.status(500).json({ success: false, message: `Server Error: ${err.message}` });
    }
};


exports.account = async (req, res) => {
    try {
        const userWallets = await UserWallet.find({ user_id: req.params.id })
            .populate('user_id')
            .lean();

        if (!userWallets.length) {
            return res.status(404).json({ message: 'No wallets found for this user' });
        }

        res.status(200).json({ data: userWallets });
    } catch (err) {
        console.error('Error fetching user wallets:', err);
        res.status(500).json({ error: err.message });
    }
};




// GET /admin/user/export-users
exports.export = async (req, res) => {
    try {
        const users = await User.find().exec();
        // Implement your Excel export logic here, using a package like exceljs
        res.json({ message: 'Excel export functionality to be implemented', users });
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// GET /admin/user/account-data/:id
exports.accountData = async (req, res) => {
    try {
        const accounts = await UserWallet.find({ user_id: req.params.id })
            .select('_id user_id account_number status mt5_type created_at')
            .populate('user')
            .exec();

        let data = accounts;
        if (req.query.search && req.query.search.value) {
            const search = req.query.search.value.toLowerCase();
            data = accounts.filter(account => {
                const userFullName = account.user ? `${account.user.first_name} ${account.user.last_name}`.toLowerCase() : '';
                return (
                    account.status.toLowerCase().includes(search) ||
                    account.account_number?.toLowerCase().includes(search) ||
                    account.mt5_type?.toLowerCase().includes(search) ||
                    (userFullName && userFullName.includes(search)) ||
                    (account.created_at && account.created_at.toString().toLowerCase().includes(search))
                );
            });
        }

        const formattedData = data.map(account => {
            let actions = `<a href="/admin/user/account/showaccount/${account._id}" class="common-action-btn" title="View">View</a>`;
            if (account.status === 'Active') {
                actions += ` <button class="common-action-btn approve-request" data-id="${account._id}" title="Active"><i class="fas fa-check"></i></button>`;
            }
            return { ...account.toObject(), action: actions };
        });

        res.json({
            draw: Number(req.query.draw) || 1,
            recordsTotal: accounts.length,
            recordsFiltered: formattedData.length,
            data: formattedData
        });
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// GET /admin/user/account/showaccount/:id
exports.showAccount = async (req, res) => {
    try {
        const { id } = req.params;

        const accountRequest = await UserWallet.findById(id)
            .populate({
                path: 'user_id',
                select: 'first_name last_name email phone_number city country address postal_code'
            })
            .populate({
                path: 'account_size_id',
                select: '_id name limit min_trade_days profit_target max_overall_loss max_daily_loss price status created_at updated_at',
                populate: {
                    path: 'account_type_id',
                    select: '_id name step created_at updated_at'
                }
            })
            .lean();

        if (!accountRequest) {
            return res.status(404).json({ success: false, message: "Account Request not found" });
        }

        return res.json({ success: true, data: accountRequest });

    } catch (error) {
        console.error("Error in showAccount:", error);
        return res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
};

// POST /admin/user/toggle-status/:id
exports.toggleStatus = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).exec();
        if (!user) return res.status(404).json({ error: 'User not found' });

        user.status = user.status === 'Active' ? 'Inactive' : 'Active';
        await user.save();

        res.json({ success: 'Status updated successfully', status: user.status });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.toggleVerified = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).exec();
        if (!user) return res.status(404).json({ error: 'User not found' });

        if (user.email_verified_at) {
            user.email_verified_at = null;
            user.verification_token = null;
        } else {
            const verificationToken = crypto.randomBytes(30).toString('hex');
            user.verification_token = verificationToken;
            const verificationUrl = `${process.env.FRONT_URL}/email/verify/${verificationToken}`;

            const transporter = nodemailer.createTransport({
                host: process.env.MAIL_HOST,
                port: process.env.MAIL_PORT,
                secure: false,
                auth: {
                    user: process.env.MAIL_USERNAME,
                    pass: process.env.MAIL_PASSWORD,
                },
                tls: {
                    rejectUnauthorized: false,
                },
            });

            const mailOptions = {
                from: `"${process.env.MAIL_FROM_NAME}" <${process.env.MAIL_FROM_ADDRESS}>`,
                to: user.email,
                subject: 'Verify Your Email',
                text: `Click here to verify your email: ${verificationUrl}`,
                html: `<p>Click <a href="${verificationUrl}">here</a> to verify your email.</p>`,
            };
            try {
                await transporter.sendMail(mailOptions);
            } catch (emailErr) {
                console.error('Failed to send email:', emailErr);
                return res.status(500).json({ error: 'Failed to send verification email' });
            }
        }

        await user.save();

        res.json({
            success: 'Email verification status updated successfully',
            email_verified_at: user.email_verified_at ? "Verified" : "Not Verified",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
};


// POST /admin/user/toggle-affiliate/:id
exports.toggleAffiliate = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).exec();
        if (!user) return res.status(404).json({ error: 'User not found' });
        user.is_affiliate = (user.is_affiliate == '1') ? '0' : '1';
        await user.save();
        res.json({ success: 'Affiliate updated successfully', is_affiliate: user.is_affiliate });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// GET /admin/user/show/:id
exports.show = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).populate('country').exec();
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.json({ data: user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
};
