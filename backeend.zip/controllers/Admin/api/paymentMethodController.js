const PaymentMethod = require("../../../models/PaymentMethod");
const Currency = require("../../../models/Currency");
const { validationResult } = require("express-validator");
const multer = require("multer");
const path = require("path");
// exports.index = async (req, res) => {
//     try {
//         res.render("admin/payment-methods/index");
//     } catch (error) {
//         res.status(500).json({ error: "Server error" });
//     }
// };

exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "" } = req.query;
        const query = search ? { name: { $regex: search, $options: "i" } } : {};

        const totalItems = await PaymentMethod.countDocuments(query);
        const paymentMethods = await PaymentMethod.find(query)
            .populate('currency_id', 'name code')
            .sort({ sequence: 1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));

        res.json({
            data: paymentMethods,
            pagination: {
                total: totalItems,
                page: Number(page),
                limit: Number(limit),
                totalPages: Math.ceil(totalItems / limit)
            }
        });
    } catch (error) {
        console.error("Error fetching payment methods:", error);
        res.status(500).json({ error: "Server error" });
    }
};



exports.show = async (req, res) => {
    try {
        const paymentMethod = await PaymentMethod.findById(req.params.id).populate('currency_id', 'name code');
        if (!paymentMethod) return res.status(404).json({ error: "Payment Method not found" });

        res.json(paymentMethod);
    } catch (error) {
        console.error("Error fetching payment method:", error);
        res.status(500).json({ error: "Server error" });
    }
};

exports.data = async (req, res) => {
    try {
        const paymentMethods = await PaymentMethod.find()
            .populate("currency_id", "name code") // Ensure currency_id is populated
            .sort({ _id: -1 });

        res.json({
            data: paymentMethods.map((paymentMethod) => ({
                ...paymentMethod._doc,
                impact: paymentMethod.impact.replace("_", " ").toUpperCase(),
                action: `
                    <a href="/admin/payment-methods/${paymentMethod._id}" class="common-action-btn" title="View">View</a>
                    <a href="/admin/payment-methods/edit/${paymentMethod._id}" class="common-action-btn" title="Edit">Edit</a>
                    <a href="/admin/payment-methods/delete/${paymentMethod._id}" class="common-action-btn" title="Delete" onclick="return confirmDelete(event)">Delete</a>
                `,
            })),
        });

    } catch (error) {
        res.status(500).json({ error: "Server error" });
    }
};

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/paymentmethods/");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    },
});
const upload = multer({ storage });

exports.add = async (req, res) => {
    try {
        const currencies = await Currency.find({}, "name code");
        res.json({ currencies });
    } catch (error) {
        console.error("Database Fetch Error:", error);
        res.status(500).json({ error: "Server error", details: error.message });
    }
};

exports.store = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const {
            name,
            currency_id,
            lower_limit,
            upper_limit,
            fee,
            processing_time,
            account_name,
            account_number,
            bank_name,
            branch,
            upi_id,
            ifsc_code,
            deposit_address,
            sequence,
            status,
        } = req.body;

        const image = req.files?.image ? `/uploads/paymentmethods/${req.files.image[0].filename}` : "";
        const qr_code_image = req.files?.qr_code_image ? `/uploads/paymentmethods/${req.files.qr_code_image[0].filename}` : "";

        const newPaymentMethod = new PaymentMethod({
            name,
            currency_id,
            lower_limit,
            upper_limit,
            fee,
            processing_time,
            account_name,
            account_number,
            bank_name,
            branch,
            upi_id,
            ifsc_code,
            deposit_address,
            sequence,
            status,
            image,
            qr_code_image,
        });

        await newPaymentMethod.save();
        res.status(201).json({ message: "Payment Method added successfully!", paymentMethod: newPaymentMethod });
    } catch (error) {
        res.status(500).json({ error: "Server error" });
    }
};
exports.edit = async (req, res) => {
    try {
        const paymentMethod = await PaymentMethod.findById(req.params.id);
        const currencies = await Currency.find();

        if (!paymentMethod) {
            return res.status(404).json({ error: "Payment Method not found" });
        }

        res.status(200).json({ paymentMethod, currencies });
    } catch (error) {
        console.error("Error fetching payment method:", error);
        res.status(500).json({ error: "Server error" });
    }
};

exports.update = async (req, res) => {
    try {
        const paymentMethod = await PaymentMethod.findById(req.params.id);
        if (!paymentMethod) return res.status(404).json({ error: "Payment Method not found" });

        Object.assign(paymentMethod, req.body);
        if (req.file) {
            paymentMethod.image = `/uploads/${req.file.filename}`;
        }

        await paymentMethod.save();
        res.status(200).json({ message: "Payment Method updated successfully!", paymentMethod });
    } catch (error) {
        console.error("Error updating payment method:", error);
        res.status(500).json({ error: "Server error" });
    }
};


exports.destroy = async (req, res) => {
    try {
        const paymentMethod = await PaymentMethod.findByIdAndDelete(req.params.id);
        if (!paymentMethod) return res.status(404).json({ error: "Payment Method not found" });

        res.json({ success: "Payment Method deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: "Failed to delete Payment Method" });
    }
};
