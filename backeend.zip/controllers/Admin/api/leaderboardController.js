const moment = require('moment');
const UserWallet = require('../../../models/UserWallet');
const { Types } = require('mongoose');
const { formatDate } = require('../../../helpers/FormatHelper');

// exports.index = async (req, res) => {
//     try {
//         res.render('admin/leaderboard/index');
//     } catch (error) {
//         console.error(error);
//         res.status(500).send('Internal Server Error');
//     }
// };

exports.index = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = "" } = req.query;

        const query = {};

        if (search) {
            query.$or = [
                { first_name: { $regex: search, $options: "i" } },
                { last_name: { $regex: search, $options: "i" } },
                { account_number: { $regex: search, $options: "i" } },
            ];
        }

        const totalRecords = await UserWallet.countDocuments(query);

        const leaderboard = await UserWallet.find(query)
            .populate({
                path: "user_id",
                select: "first_name last_name email"
            })
            .sort({ balance: -1 })
            .skip((page - 1) * parseInt(limit))
            .limit(parseInt(limit));

        res.status(200).json({
            data: leaderboard,
            pagination: {
                total: totalRecords,
                page: parseInt(page),
                limit: parseInt(limit),
                totalPages: Math.ceil(totalRecords / limit)
            }
        });
    } catch (error) {
        res.status(500).json({ error: "Server error" });
    }
};


exports.data = async (req, res) => {
    try {
        const dateRange = req.query.date_range;
        const search = req.query.search || '';
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;

        let startDate = null;
        let endDate = null;

        // Define date range
        if (dateRange) {
            switch (dateRange) {
                case 'today':
                    startDate = moment().startOf('day').toDate();
                    endDate = moment().endOf('day').toDate();
                    break;
                case 'week':
                    startDate = moment().startOf('week').toDate();
                    endDate = moment().endOf('week').toDate();
                    break;
                case 'month':
                    startDate = moment().startOf('month').toDate();
                    endDate = moment().endOf('month').toDate();
                    break;
                case 'year':
                    startDate = moment().startOf('year').toDate();
                    endDate = moment().endOf('year').toDate();
                    break;
                case 'all':
                default:
                    break;
            }
        }

        // Filter real wallets
        let wallets = await UserWallet.find({ account_status: 'real' })
            .populate('accountSize')
            .populate('user')
            .lean();

        // Apply search filter
        if (search) {
            const searchLower = search.toLowerCase();
            wallets = wallets.filter((wallet) => {
                const user = wallet.user || {};
                return (
                    user.first_name?.toLowerCase().includes(searchLower) ||
                    user.last_name?.toLowerCase().includes(searchLower) ||
                    user.email?.toLowerCase().includes(searchLower) ||
                    wallet.account_number?.toString().includes(searchLower)
                );
            });
        }

        // Calculate profit and get highest profit per user
        const walletProfits = {};

        wallets.forEach((wallet) => {
            const userId = wallet.user_id?.toString();
            const balance = wallet.balance || 0;
            const limit = wallet.accountSize?.limit || 0;
            const profit = balance - limit;

            if (profit > 0) {
                if (!walletProfits[userId] || profit > walletProfits[userId].total_profit) {
                    walletProfits[userId] = {
                        user_id: userId,
                        account_number: wallet.account_number,
                        total_profit: profit,
                        user: wallet.user,
                    };
                }
            }
        });

        const sorted = Object.values(walletProfits).sort((a, b) => b.total_profit - a.total_profit);
        const total = sorted.length;

        const paginated = sorted.slice((page - 1) * limit, page * limit);

        const response = paginated.map((item, index) => ({
            id: item.user_id,
            name: `${item.user.first_name} ${item.user.last_name}`,
            account_number: item.account_number,
            balance: item.total_profit,
        }));

        return res.json({
            data: response,
            pagination: {
                total,
                totalPages: Math.ceil(total / limit),
                currentPage: page,
                limit,
            }
        });

    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};


exports.show = async (req, res) => {
    try {
        const { id } = req.params;

        // Find the wallet entry by ID
        const wallet = await UserWallet.findById(id)
            .populate('accountSize')
            .populate('user')
            .lean();

        if (!wallet) {
            return res.status(404).json({ message: 'Wallet not found' });
        }

        // Format response to include necessary details
        const response = {
            user: wallet.user
                ? `${wallet.user.first_name} ${wallet.user.last_name}`
                : '-',
            account_number: wallet.account_number,
            balance: wallet.balance,
            account_limit: wallet.accountSize ? wallet.accountSize.limit : 0,
            account_status: wallet.account_status,
            profit: wallet.balance - (wallet.accountSize ? wallet.accountSize.limit : 0),
        };

        res.json(response);
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

exports.approve = async (req, res) => {
    try {
        const { id } = req.params;

        // Find the wallet entry by ID
        const wallet = await UserWallet.findById(id);

        if (!wallet) {
            return res.status(404).json({ message: 'Wallet not found' });
        }

        // Update the wallet's status or approval flag
        wallet.approved = true; // Assuming an "approved" field exists
        await wallet.save();

        res.json({ message: 'Wallet approved successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};


// formated data
// exports.index = async (req, res) => {
//     try {
//         const { page = 1, limit = 10, search = "" } = req.query;

//         const query = {};

//         if (search) {
//             query.$or = [
//                 { first_name: { $regex: search, $options: "i" } },
//                 { last_name: { $regex: search, $options: "i" } }
//             ];
//         }

//         const totalRecords = await UserWallet.countDocuments(query);

//         const leaderboard = await UserWallet.find(query)
//             .populate("user_id", "first_name last_name email")
//             .populate("account_size_id", "limit")
//             .sort({ balance: -1 })
//             .skip((page - 1) * limit)
//             .limit(parseInt(limit))
//             .lean();

//         // Format data
//         const formattedLeaderboard = leaderboard.map((wallet, index) => ({
//             DT_RowIndex: index + 1,
//             user_id: wallet.user_id?._id,
//             user: wallet.user_id ? `${wallet.user_id.first_name} ${wallet.user_id.last_name}` : '-',
//             wallet_id: wallet._id,
//             account_number: wallet.account_number,
//             profit: wallet.balance - (wallet.account_size_id?.limit || 0),
//             total_profit: wallet.balance - (wallet.account_size_id?.limit || 0),
//         }));

//         res.status(200).json({
//             data: formattedLeaderboard,
//             totalPages: Math.ceil(totalRecords / limit),
//             currentPage: parseInt(page),
//         });
//     } catch (error) {
//         console.error("Error fetching leaderboard:", error);
//         res.status(500).json({ error: "Server error" });
//     }
// };
// exports.data = async (req, res) => {
//     try {
//         const dateRange = req.query.date_range;
//         let startDate = null, endDate = null;

//         if (dateRange) {
//             const now = moment();
//             if (dateRange === 'today') {
//                 startDate = now.startOf('day').toDate();
//                 endDate = now.endOf('day').toDate();
//             } else if (dateRange === 'week') {
//                 startDate = now.startOf('week').toDate();
//                 endDate = now.endOf('week').toDate();
//             } else if (dateRange === 'month') {
//                 startDate = now.startOf('month').toDate();
//                 endDate = now.endOf('month').toDate();
//             } else if (dateRange === 'year') {
//                 startDate = now.startOf('year').toDate();
//                 endDate = now.endOf('year').toDate();
//             }
//         }

//         const matchStage = { account_status: 'real' };

//         if (startDate && endDate) {
//             matchStage.created_at = { $gte: startDate, $lte: endDate };
//         }

//         const userWallets = await UserWallet.find(matchStage)
//             .populate('account_size_id', 'limit')
//             .populate('user_id', 'first_name last_name')
//             .lean();

//         const walletProfits = {};

//         userWallets.forEach(wallet => {
//             const userId = wallet.user_id?._id;
//             const balance = wallet.balance;
//             const limit = wallet.account_size_id?.limit || 0;
//             const profit = balance - limit;

//             if (profit > 0) {
//                 if (!walletProfits[userId] || profit > walletProfits[userId].total_profit) {
//                     walletProfits[userId] = {
//                         user_id: userId,
//                         wallet_id: wallet._id,
//                         total_profit: profit,
//                         account_number: wallet.account_number,
//                         user: wallet.user_id ? `${wallet.user_id.first_name} ${wallet.user_id.last_name}` : '-'
//                     };
//                 }
//             }
//         });

//         const sortedProfits = Object.values(walletProfits).sort((a, b) => b.total_profit - a.total_profit);

//         const response = sortedProfits.map((profit, index) => ({
//             DT_RowIndex: index + 1,
//             user_id: profit.user_id,
//             user: profit.user,
//             account_number: profit.account_number,
//             profit: profit.total_profit,
//             total_profit: profit.total_profit,
//             wallet_id: profit.wallet_id
//         }));

//         res.json({ data: response });
//     } catch (error) {
//         console.error(error);
//         res.status(500).send('Internal Server Error');
//     }
// };
// exports.show = async (req, res) => {
//     try {
//         const { id } = req.params;

//         const wallet = await UserWallet.findById(id)
//             .populate('account_size_id', 'limit')
//             .populate('user_id', 'first_name last_name')
//             .lean();

//         if (!wallet) {
//             return res.status(404).json({ message: 'Wallet not found' });
//         }

//         const response = {
//             user_id: wallet.user_id?._id,
//             user: wallet.user_id ? `${wallet.user_id.first_name} ${wallet.user_id.last_name}` : '-',
//             wallet_id: wallet._id,
//             account_number: wallet.account_number,
//             balance: wallet.balance,
//             account_limit: wallet.account_size_id?.limit || 0,
//             account_status: wallet.account_status,
//             profit: wallet.balance - (wallet.account_size_id?.limit || 0),
//         };

//         res.json(response);
//     } catch (error) {
//         console.error(error);
//         res.status(500).send('Internal Server Error');
//     }
// };
// exports.approve = async (req, res) => {
//     try {
//         const { id } = req.params;

//         const wallet = await UserWallet.findById(id);

//         if (!wallet) {
//             return res.status(404).json({ message: 'Wallet not found' });
//         }

//         wallet.approved = true; // Assuming an "approved" field exists
//         await wallet.save();

//         res.json({ message: 'Wallet approved successfully' });
//     } catch (error) {
//         console.error(error);
//         res.status(500).send('Internal Server Error');
//     }
// };
