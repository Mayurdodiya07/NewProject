const AccountSize = require("../models/AccountSize");

exports.index = async (req, res) => {
  try {
    let query = AccountSize.find();

    // Filter by account_type_id if present in query
    if (req.query.account_type_id && req.query.account_type_id !== '') {
      query = query.where('account_type_id').equals(req.query.account_type_id);
    }

    if (req.query.type && req.query.type !== '') {
      query = query.where('type').equals(req.query.type);
    }

    // Sorting
    if (req.query.order && (req.query.order === 'asc' || req.query.order === 'desc')) {
      query = query.sort({ id: req.query.order }); // Change 'id' if necessary
    } else {
      query = query.sort({ limit: 'asc' });
    }

    // Pagination (skip + limit)
    let perPage = 20; // Default number of records per page
    let page = req.query.page || 1; // Default page number (1)
    if (req.query.per_page && req.query.per_page !== '') {
      perPage = parseInt(req.query.per_page, 10);
    }

    // Apply skip for pagination
    const skip = (page - 1) * perPage;

    query = query.skip(skip).limit(perPage);

    // Execute the query and get the results
    const accountSizes = await query.exec();

    // Get the total count for pagination
    const totalCount = await AccountSize.countDocuments(query.getFilter());

    // Send success response with pagination info
    return res.status(200).json({
      success: 0,
      message: 'Account sizes retrieved successfully.',
      data: accountSizes,
      pagination: {
        totalCount,
        currentPage: page,
        perPage,
        totalPages: Math.ceil(totalCount / perPage),
      },
    });
  } catch (error) {
    // Error handling
    return res.status(500).json({
      success: 1,
      message: 'Server Error',
      error: error.message,
    });
  }
};
