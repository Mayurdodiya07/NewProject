const Platform = require("../models/Platform");

exports.index = async (req, res) => {
  try {
    // Start with the query to select 'id', 'name', and 'step' columns
    let query = Platform.find({}, 'id name step');

    // Filter by 'type' if provided
    if (req.body.type && req.body.type !== '') {
      query = query.where('type').equals(req.body.type);
    }

    // Handle sorting by 'id' or 'name'
    if (req.body.order && (req.body.order === 'asc' || req.body.order === 'desc')) {
      query = query.sort({ id: req.body.order });
    } else {
      query = query.sort({ name: 'asc' });
    }

    // Pagination logic
    let platforms;
    if (req.body.nopaginate && req.body.nopaginate === '1') {
      // If 'nopaginate' is set, return all records without pagination
      platforms = await query.exec();
    } else {
      // Apply pagination if 'nopaginate' is not set
      let perPage = 20;
      if (req.body.per_page && req.body.per_page !== '') {
        perPage = parseInt(req.body.per_page, 10);
      }

      let page = parseInt(req.body.page) || 1;
      const skip = (page - 1) * perPage;

      platforms = await query.skip(skip).limit(perPage).exec();

      // Get the total count for pagination
      const totalCount = await Platform.countDocuments(query.getFilter());

      return res.json({
        success: 0,
        message: 'Platform fetched successfully.',
        data: platforms,
        pagination: {
          totalCount,
          currentPage: page,
          perPage,
          totalPages: Math.ceil(totalCount / perPage),
        },
      });
    }

    return res.json({
      success: 0,
      message: 'Platform fetched successfully.',
      data: platforms,
    });

  } catch (err) {
    return res.status(500).json({
      success: 2,
      message: 'Server Error.',
      error: err.message,
    });
  }
};
