const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const Acquisition = require("../models/Acquisition");
const generateReferralCode = require("../controllers/affliateController");
const Wallet = require('../models/Wallet');
const UserWallet = require("../models/UserWallet");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const moment = require("moment");
const { PhoneNumberUtil, PhoneNumberFormat } = require('google-libphonenumber');
const { parsePhoneNumberFromString } = require('libphonenumber-js');
const PasswordResetToken = require("../models/PasswordResetToken");
const { validationResult, body } = require("express-validator");
const VerificationLevel = require("../models/VerificationLevel");
const UserDevice = require('../models/UserDevice');

const {

  sendVerificationEmail,
  sendForgotPasswordEmail,
} = require("../services/emailService");


const {
  sendResponse,
  sendError,
  sendServerError,
} = require("../utils/responseHelper");
const Country = require("../models/Country");

// Register a new user
exports.register = async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      email,
      phone,
      password,
      confirm_password,
      ref,
      city,
      address,
      postal_code,
      country_id,
      device_id,
      ip_address,
      location,
    } = req.body;

    if (!first_name || !last_name || !email || !phone || !password || !confirm_password) {
      return sendError(res, "All fields are required");
    }

    if (password !== confirm_password) {
      return sendError(res, "Passwords do not match");
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return sendError(res, "User already exists");
    }

    const phoneUtil = PhoneNumberUtil.getInstance();
    let parsedPhone;

    try {
      parsedPhone = phoneUtil.parseAndKeepRawInput(phone, country_id || 'US');
    } catch {
      return sendError(res, "Invalid phone number format");
    }

    if (!phoneUtil.isValidNumber(parsedPhone)) {
      return sendError(res, "Invalid phone number");
    }
    const phone_country = phoneUtil.getRegionCodeForNumber(parsedPhone);
    const phone_prefix = `+${parsedPhone.getCountryCode()}`;
    const phone_without_prefix = `${parsedPhone.getNationalNumber()}`;


    const existingPhoneUser = await User.findOne({
      phone_country,
      phone_prefix,
      phone: phone_without_prefix,
    });

    if (existingPhoneUser) {
      return sendError(res, "The phone has already been taken.");
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const verificationToken = crypto.randomBytes(32).toString("hex");

    const verificationLevel = await VerificationLevel.findOne();

    const newUser = {
      first_name,
      last_name,
      email,
      password: hashedPassword,
      phone: phone_without_prefix,
      phone_country,
      phone_prefix,
      verification_token: verificationToken,
      status: "Active",
      city: city || null,
      address: address || null,
      postal_code: postal_code || null,
      country_id: country_id || null,
      verification_level_id: verificationLevel ? verificationLevel._id : null,
      is_affiliate: false,
      referred_by: null,
    };

    if (ref) {
      const referrer = await User.findOne({ referral_code: ref });
      if (referrer) {
        newUser.referred_by = referrer._id;
      }
    }

    //new user //
    const user = await User.create(newUser);

    if (ref) {
      const referrer = await User.findOne({ referral_code: ref });
      if (referrer) {
        referrer.referral_click_count = (referrer.referral_click_count || 0) + 1;
        await referrer.save();

        await Acquisition.create({
          user_id: referrer._id,
          client_id: user._id,
          device_id: device_id || "unknown",
          ip_address: ip_address || req.ip,
          location: location || "unknown",
          link: `${process.env.FRONT_URL}/register?ref=${referrer.referral_code}`,
        });
      }
    }

    // Add  wallets //
    const defaultWallets = await Wallet.find({ default: true }).sort({ sequence: 1 });
    if (!defaultWallets || defaultWallets.length === 0) {
      return sendError(res, "No default wallets found in the database.");
    }

    for (const wallet of defaultWallets) {
      await UserWallet.create({
        user_id: user._id,
        wallet_id: wallet._id,
        balance: wallet.default_balance || 0,
        available_balance: wallet.default_balance || 0,
        on_hold_balance: 0.0,
        currency: wallet.currency,
        code: wallet.code,
        status: wallet.status || "active",
      });
    }

    // Send email ... user..// 
    const verificationLink = `${process.env.FRONT_URL}/email/verify/${verificationToken}`;
    try {
      await sendVerificationEmail(user.email, verificationLink);
    } catch (error) {
      console.error("Failed to send verification email:", error.message);
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    // add this if admin user==admin connection 
    // const token = jwt.sign(
    //   { userId: user._id, role: user.role },
    //   "your_secret_key",
    //   { expiresIn: "1h" }
    // );

    // add this logic if county_name not find 
    // const country = await Country.findOne({
    //   _id: user.country_id,
    //   deleted_at: { $eq: null }, // Check for soft delete
    // });

    // user.country_name = country ? country.name : "Unknown";
    // user.country_flag = user.phone_country
    //   ? `${process.env.BASE_URL}/storage/countries/${user.phone_country.toLowerCase()}.png`
    //   : null;
    // user.phone_number = `${user.phone_prefix}${user.phone}`;
    const country = await Country.findById(user.country_id);
    user.country_name = country ? country.name : "Unknown";
    user.country_flag = user.phone_country
      ? `${process.env.BASE_URL}/storage/countries/${user.phone_country.toLowerCase()}.png`
      : null;
    user.phone_number = `${user.phone_prefix}${user.phone}`;

    const responseData = {
      id: user._id,
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      token,
      verification_token: user.verification_token,
      status: user.status,
      phone_number: user.phone_number,
      city: user.city,
      country: user.country_id,
      country_flag: user.country_flag,
      verified: false,
      image: user.image,
    };

    return sendResponse(
      res,
      "Registration successful. We have sent you an email verification link. Please check your email.",
      responseData
    );
  } catch (error) {
    console.error("Error during registration:", error);
    return sendServerError(res, "Server error", error.message);
  }
};

exports.confirmRegistration = async (req, res) => {
  try {
    const { token } = req.query;

    const user = await User.findOne({ verification_token: token });
    if (!user) {
      return sendError(res, "Invalid or expired verification token");
    }

    user.verified = true;
    user.email_verified_at = new Date();
    user.verification_token = null;
    await user.save();

    return sendResponse(res, "Email verified successfully. You can now log in.");
  } catch (error) {
    console.error("Error confirming registration:", error);
    return sendServerError(res, "Something went wrong. Please try again.", error.message);
  }
};


// Send forgot password link
exports.sendForgotPasswordLink = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return sendError(res, "Email is required");
    }

    const user = await User.findOne({ email });
    if (!user) {
      return sendError(res, "User not found");
    }

    const resetToken = crypto.randomBytes(32).toString("hex");
    const resetLink = `${process.env.FRONT_URL}/reset-password/${resetToken}`;

    const resetTokenEntry = new PasswordResetToken({
      email: user.email,
      token: resetToken,
      created_at: new Date(),
    });

    await resetTokenEntry.save();
    const emailSent = await sendForgotPasswordEmail(user.email, resetLink);

    if (!emailSent) {
      return sendServerError(
        res,
        "Failed to send forgot password email",
        "Email send error"
      );
    }

    return sendResponse(
      res, "Password reset link has been sent to your email."
    );
  } catch (error) {
    console.error("Error sending forgot password link:", error);
    return sendServerError(res, "Server error", error.message);
  }
};

// Reset password
exports.resetPassword = async (req, res) => {
  try {
    const { token, password, password_confirmation } = req.body;

    if (!token || !password || !password_confirmation) {
      return sendError(res, "Token, password, and confirmation are required");
    }

    if (password !== password_confirmation) {
      return sendError(res, "Passwords do not match");
    }

    const resetTokenEntry = await PasswordResetToken.findOne({ token });
    // console.log("Reset Token Entry:", resetTokenEntry);

    if (!resetTokenEntry) {
      return sendError(res, "Invalid or expired token");
    }

    if (!resetTokenEntry.created_at) {
      return sendError(res, "Token creation date is invalid");
    }

    const tokenAge =
      (Date.now() - new Date(resetTokenEntry.created_at).getTime()) /
      (1000 * 60 * 60);

    if (tokenAge > 1) {
      await resetTokenEntry.deleteOne();
      return sendError(res, "Token has expired");
    }

    const user = await User.findOne({ email: resetTokenEntry.email });
    if (!user) {
      return sendError(res, "User not found");
    }

    user.password = await bcrypt.hash(password, 10);
    await user.save();
    await resetTokenEntry.deleteOne(); // Remove token after successful reset

    return sendResponse(res, "Password reset successfully.");
  } catch (error) {
    console.error("Error in resetPassword:", error);
    return sendServerError(res, "Internal server error", error.message);
  }
};

//user login //

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;


    if (!email || !password) {
      return sendError(res, "Email and password are required");
    }

    const user = await User.findOne({ email });

    if (!user) {
      return sendError(res, "User not found");
    }

    if (!user.email_verified_at) {
      return sendError(res, "Account is not verified yet");
    }

    if (!user.created_at) {
      return sendError(res, "Account creation failed. Please contact support.");
    }

    let hashToCompare = user.password;
    if (user.password.startsWith("$2y$")) {
      hashToCompare = user.password.replace("$2y$", "$2a$");
    }
    const isPasswordValid = await bcrypt.compare(password, hashToCompare);
    if (!isPasswordValid) {
      return sendError(res, "Invalid password");
    }


    const token = jwt.sign({ user_id: user._id }, process.env.JWT_SECRET);
    const userResponse = user.toObject();
    userResponse.token = token;


    const userDevice = new UserDevice({
      user_id: user._id,
      device_id: req.body.device_id,
      ip_address: req.ip,
      latitude: req.body.latitude,
      longitude: req.body.longitude,
      login_at: new Date(),
    });

    await userDevice.save();

    return res.status(200).json({
      success: 0,
      message: "User logged in successfully.",
      data: userResponse,
    });
  } catch (error) {
    console.error("Error during login:", error);
    sendServerError(res, "Server error", error.message);
  }
};
// add if need it  MD //
// const rateLimit = require('express-rate-limit');
// const loginLimiter = rateLimit({
//   windowMs: 15 * 60 * 1000, // 15 minutes
//   max: 10, // Limit each IP to 10 login requests per windowMs
//   message: "Too many login attempts. Try again later."
// });
// app.use('/login', loginLimiter);



exports.logout = async (req, res) => {
  try {
    req.logout();
    req.session = null;
    return res.status(200).json({
      message: "Successfully logged out",
    });
  } catch (error) {
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

exports.refresh = async (req, res) => {
  try {
    const token = req.headers["authorization"];

    if (!token) {
      return res.status(401).json({
        success: 2,
        message: "No token provided",
      });
    }

    const bearerToken = token.replace("Bearer ", "");

    jwt.verify(bearerToken, process.env.JWT_SECRET, async (err, decoded) => {
      if (err) {
        return res.status(401).json({
          success: 2,
          message: "Invalid or expired token",
        });
      }

      const user = await User.findById(decoded.userId);
      if (!user) {
        return res.status(404).json({
          success: 2,
          message: "User not found",
        });
      }

      const refreshedToken = jwt.sign(
        { userId: user._id },
        process.env.JWT_SECRET,
        { expiresIn: "1h" }
      );

      return res.status(200).json({
        user,
        authorisation: {
          token: refreshedToken,
          type: "Bearer",
        },
      });
    });
  } catch (err) {
    return res.status(500).json({
      success: 2,
      message: "Server Error",
      error: err.message,
    });
  }
};
