const multer = require("multer");
const path = require("path");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const AccountRequest = require("../models/AccountRequest");
const { validationResult } = require("express-validator");
const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
const UserWallet = require("../models/UserWallet");
const PassedAccountRequest = require("../models/PassedAccountRequest");
const NotificationHelper = require("../helpers/NotificationHelper");
const RealAccountRequest = require("../models/RealAccountRequest");


const storage = multer.memoryStorage();

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif"];
    if (!allowedTypes.includes(file.mimetype)) {
      return cb(new Error("Invalid file type"), false);
    }
    cb(null, true);
  },
}).single("screenshot");

const index = async (req, res) => {
  try {
    let accountRequests = AccountRequest.find()
      .select(
        "id type user_id status title first_name last_name street city postal_code address_country_id country_id account_type_id account_size_id not_us_residence platform_id payment_method_id amount transaction_id screenshot"
      )
      .populate("payment_method_id account_type_id account_size_id")
      .where("account_status")
      .ne("approved");
    // Apply filters
    if (req.body.type && req.body.type !== "all") {
      accountRequests = accountRequests
        .where("accountType.name")
        .equals(req.body.type);
    }

    if (req.body.step && req.body.step !== "all") {
      accountRequests = accountRequests
        .where("accountType.step")
        .equals(req.body.step);
    }

    if (req.body.account_status !== "approved") {
      accountRequests = accountRequests.where("account_status").ne("approved");
    }

    if (req.body.user_id && req.body.user_id !== "") {
      accountRequests = accountRequests
        .where("user_id")
        .equals(req.body.user_id);
    }

    if (req.body.transaction_type && req.body.transaction_type !== "") {
      accountRequests = accountRequests
        .where("transaction_type")
        .equals(req.body.transaction_type);
    }

    if (req.body.transfer_type && req.body.transfer_type !== "") {
      accountRequests = accountRequests
        .where("transfer_type")
        .equals(req.body.transfer_type);
    }

    if (req.body.payment_method_id && req.body.payment_method_id !== "") {
      accountRequests = accountRequests
        .where("payment_method_id")
        .equals(req.body.payment_method_id);
    }

    if (req.body.user_wallet_id && req.body.user_wallet_id !== "") {
      accountRequests = accountRequests
        .where("user_wallet_id")
        .equals(req.body.user_wallet_id);
    }

    if (req.body.currency_id && req.body.currency_id !== "") {
      accountRequests = accountRequests
        .where("currency_id")
        .equals(req.body.currency_id);
    }

    if (req.body.transaction_status && req.body.transaction_status !== "") {
      accountRequests = accountRequests
        .where("transaction_status")
        .equals(req.body.transaction_status);
    }

    // Order results
    if (
      req.body.order &&
      (req.body.order === "asc" || req.body.order === "desc")
    ) {
      accountRequests = accountRequests.sort({ id: req.body.order });
    } else {
      accountRequests = accountRequests.sort({ created_at: -1 });
    }

    // Pagination
    if (req.body.nopaginate == "1") {
      accountRequests = await accountRequests.exec();
    } else {
      const page = parseInt(req.body.page) || 1;
      const perPage = parseInt(req.body.per_page) || 20;
      const skip = (page - 1) * perPage;

      accountRequests = accountRequests.skip(skip).limit(perPage);
      const total = await AccountRequest.countDocuments();
      const totalPages = Math.ceil(total / perPage);

      accountRequests = await accountRequests.exec();

      // Add sequence number based on pagination
      accountRequests.forEach((item, index) => {
        item.sequence = (page - 1) * perPage + index + 1;
      });

      // Add pagination data
      const pagination = {
        totalItems: total,
        totalPages: totalPages,
        currentPage: page,
        perPage: perPage,
      };

      return res.status(200).json({
        success: 0,
        message: "Challenge requests retrieved successfully.",
        data: accountRequests,
        pagination: pagination,
      });
    }

    // Send response for non-paginated results
    return res.status(200).json({
      success: 0,
      message: "Challenge requests retrieved successfully.",
      data: accountRequests,
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

const store = async (req, res) => {
  // Process file upload with multer
  upload(req, res, async (err) => {
    if (err) {
      console.error("Upload Error:", err);
      return res.status(400).json({
        success: 2,
        message: `File Upload Error: ${err.message}`,
        error: err,
      });
    }

    try {
      // Validate required fields
      const requiredFields = [
        "user_id",
        "country_id",
        "account_type_id",
        "platform_id",
        "account_size_id",
        "not_us_residence",
        "title",
        "first_name",
        "last_name",
        "street",
        "city",
        "address_country_id",
        "postal_code",
        "payment_method_id",
        "amount",
        "transaction_id",
      ];

      const missingFields = requiredFields.filter((field) => !req.body[field]);

      if (missingFields.length > 0) {
        return res.status(400).json({
          success: 2,
          message: "Validation Error.",
          error: `Missing required fields: ${missingFields.join(", ")}`,
        });
      }

      // Validate that 'amount' is a valid number
      if (isNaN(parseFloat(req.body.amount))) {
        return res.status(400).json({
          success: 2,
          message: "Validation Error.",
          error: "Amount must be a valid number.",
        });
      }

      // Check if the user exists
      const user = await User.findById(req.body.user_id);
      if (!user) {
        return res.status(400).json({
          success: 2,
          message: "Validation Error.",
          error: "User not found",
        });
      }

      // Prepare account request data
      const input = {
        ...req.body,
        account_status: "pending",
        status: "active",
        amount: parseFloat(req.body.amount),
        discount: req.body.discount ? parseFloat(req.body.discount) : null,
      };

      // Create a new account request
      const accountRequest = new AccountRequest(input);
      await accountRequest.save();

      // If file is uploaded, send it to Laravel API
      if (req.file) {
        const formData = new FormData();
        formData.append("screenshot", req.file.buffer, {
          filename: req.file.originalname,
          contentType: req.file.mimetype
        });
        try {
          const response = await axios.post(
            "https://fundedfirmbackend.pmcommu.in/api/upload-sc",
            formData,
            { headers: formData.getHeaders() }
          );
          if (response.data.success === 0 && response.data.data && response.data.data.file_url) {
            const fileUrl = response.data.data.file_url;
            accountRequest.screenshot = fileUrl;
            await accountRequest.save();
          } else {

            return res.status(500).json({
              success: 2,
              message: "Failed to upload the image to Laravel. Missing file_url.",
              error: response.data.message || "Unknown error",
            });
          }
        } catch (uploadError) {
          return res.status(500).json({
            success: 2,
            message: "Failed to upload image to Laravel.",
            error: uploadError.message,
          });
        }
      }
      // Respond with the created account request
      return res.status(200).json({
        success: 0,
        message: "Challenge request sent successfully.",
        data: accountRequest,
      });
    } catch (err) {
      console.error("Server Error:", err);
      return res.status(500).json({
        success: 2,
        message: "Server Error.",
        error: err.message,
      });
    }
  });
};
const getChallengeDetails = async (req, res) => {
  try {
    // Validation
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({
        success: 2,
        message: "Validation Error.",
        errors: errors.array(),
      });
    }

    const { id } = req.body;
    let challenges = await UserWallet.findById(id)
      .populate({ path: "user_id", model: "User", as: "user" })
      .populate({
        path: "account_type_id",
        model: "AccountType",
        as: "account_type",
      });
    if (!challenges) {
      return res.status(404).json({
        success: 2,
        message: "Challenge not found.",
      });
    }
    // Success response
    return res.status(200).json({
      success: 0,
      message: "Challenge details fetched successfully.",
      data: challenges,
    });
  } catch (error) {
    // Error response
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};
const sendPassedAccountRequest = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessage = errors
        .array()
        .map((err) => err.msg)
        .join(" ");
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: [errorMessage] },
      });
    }

    const { user_id, user_wallet_id } = req.body;

    // Check if the user exists
    const user = await User.findById(user_id);
    if (!user) {
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: ["User not found"] },
      });
    }

    // Check if the user wallet exists
    const wallet = await UserWallet.findById(user_wallet_id);
    if (!wallet) {
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: ["User wallet not found"] },
      });
    }

    // Create the passed account request
    const input = {
      ...req.body,
      account_status: "pending",
      status: "active",
    };

    const transaction = await PassedAccountRequest.create(input);

    if (transaction) {
      // Send notification
      await NotificationHelper.sendNotification(
        user_id,
        "passed_account_request",
        transaction.id
      );
      return res.json({
        success: 0,
        message: "Passed account request sent successfully.",
        data: transaction,
      });
    } else {
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: ["Real account request not created"] },
      });
    }
  } catch (error) {
    return res.json({
      success: 2,
      message: "Server Error.",
      data: { error: error.message },
    });
  }
};

const sendRealAccountRequest = async (req, res) => {
  try {
    const { user_id, user_wallet_id } = req.body;

    // Validation
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessage = errors
        .array()
        .map((err) => err.msg)
        .join(" ");
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: [errorMessage] },
      });
    }

    // Check if user exists
    const user = await User.findById(user_id);
    if (!user) {
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: ["User not found"] },
      });
    }

    // Prepare input data
    const input = {
      ...req.body,
      account_status: "pending",
      status: "active",
    };

    // Create real account request
    const transaction = new RealAccountRequest(input);
    await transaction.save();

    // Send notification
    await NotificationHelper.sendNotification(
      user_id,
      "real_account_request",
      transaction._id
    );

    return res.json({
      success: 0,
      message: "Real account request sent successfully.",
      data: transaction,
    });
  } catch (error) {
    // console.error("Error in sendRealAccountRequest:", error);
    return res.json({
      success: 2,
      message: "Server Error.",
      data: { error: error.message },
    });
  }
};

module.exports = {
  index,
  store,
  getChallengeDetails,
  sendPassedAccountRequest,
  sendRealAccountRequest,
};
