const { validationResult } = require('express-validator');
const PromoCode = require('../models/PromoCode'); // Assuming you have a PromoCode model
const AccountRequest = require('../models/AccountRequest'); // Assuming you have an AccountRequest model
const moment = require('moment'); // For date comparisons

exports.validatePromoCode = async (req, res) => {
    try {
        // Validate the request body
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ success: 2, errors: errors.array() });
        }

        const { user_id, code } = req.body;

        if (!code) {
            return res.status(400).json({ success: 2, message: 'Validation Error.', errors: ['Code is required'] });
        }

        // Find the promo code in the database
        const promoCode = await PromoCode.findOne({ code });
        if (!promoCode) {
            return res.status(400).json({ success: 2, message: 'Validation Error.', errors: ['Invalid Promo Code'] });
        }

        const currentDate = moment();
        const endingDate = promoCode.ending_date;

        // Check if the promo code has expired
        if (endingDate && currentDate.isAfter(endingDate)) {
            return res.status(400).json({ success: 2, message: 'Promo code has expired.' });
        }

        const userId = user_id || req.user.id; // Assuming `req.user` contains the authenticated user's details

        // Check if the promo code has already been used by the user
        const promoApplied = await AccountRequest.findOne({ coupon_code: code, user_id: userId });
        if (promoApplied) {
            return res.status(400).json({ success: 2, message: 'Promo code has already been used by you.' });
        }

        // Prepare the response data
        const response = {
            id: promoCode._id,
            promo_code: promoCode.code,
            discount_in_rupees: promoCode.discount_in_rupees,
        };

        return res.status(200).json({ success: 0, message: 'Promo code is valid.', data: response });
    } catch (error) {
        return res.status(500).json({ success: 2, message: 'Please Apply Code.', error: error.message });
    }
};
