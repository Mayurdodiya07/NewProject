const User = require("../models/User");
const DocumentType = require('../models/DocumentType');
const DocumentGroup = require('../models/DocumentGroup');

exports.getVerifiedDocuments = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            const errorMessage = errors.array().map(err => err.msg).join(' ');
            return res.json({
                success: 2,
                message: 'Validation Error.',
                data: { error: [errorMessage] },
            });
        }

        const userId = req.body.user_id;
        const user = await User.findById(userId)
            .populate({
                path: 'documents',
                populate: {
                    path: 'documentType',
                    populate: {
                        path: 'documentGroup',
                    },
                },
            });

        if (!user) {
            return res.json({
                success: 2,
                message: 'User profile not found!',
                data: null,
            });
        }

        const documents = user.documents;
        return res.json({
            success: 0,
            message: 'Documents get successfully.',
            data: documents,
        });
    } catch (error) {
        return res.json({
            success: 2,
            message: 'Server Error.',
            data: { error: error.message },
        });
    }
};
