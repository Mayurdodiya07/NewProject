const bcrypt = require("bcryptjs");
const mongoose = require('mongoose');
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Payouts = require("../models/Payouts");
const { validationResult } = require("express-validator");
const { log } = require("winston");

const generateReferralCode = () => {
  let code = Math.random().toString(36).substr(2, 15);
  return code;
};

exports.getReferralLink = async (req, res) => {
  try {
    const { user_id } = req.body;
    if (!user_id) {
      return res
        .status(400)
        .json({ error: ["Validation Error. User ID is required."] });
    }
    const user = await User.findById(user_id);
    if (!user) {
      return res.status(404).json({ error: ["User not found"] });
    }
    if (!user.referral_code) {
      user.referral_code = generateReferralCode();
      await user.save();
    }

    // Create referral link
    const referralLink = `${process.env.FRONT_URL}/register?ref=${user.referral_code}`;

    return res.status(200).json({
      success: 0,
      data: {
        referral_link: referralLink,
        message: "Referral link get successfully.",
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: ["Server Error", error.message] });
  }
};


exports.getAffiliateDetails = async (req, res) => {
  try {
    const userId = req.body.user_id;
    if (!userId) {
      return res.status(400).json({
        success: 2,
        data: { message: ["Validation Error. User ID is required."] },
      });
    }

    // Find user by user_id
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: 2,
        data: { message: ["User not found"] },
      });
    }

    // Find all users who have referred by the current user (userId)
    const referralCodeUserFind = await User.find({ referred_by: userId })
      .populate({
        path: "wallets",
        match: { account: 'mt5' },
        populate: [
          { path: "account_type_id" },
          { path: "account_size_id" }
        ]
      })
      .exec();
    const usersWithWallets = referralCodeUserFind.filter(user => user.wallets && user.wallets.length > 0);

    // If no referral users found, return the response with 0 values
    if (!Array.isArray(usersWithWallets) || usersWithWallets.length === 0) {
      return res.status(200).json({
        success: 0,
        data: {
          referralCodeUserFind: [],
          countOfUser: 0,
          totalEarned: 0,
          totalPaidOut: 0,
          percentageBasedOnCountUser: 0
        },
        message: "No referral users found",
      });
    }

    let totalSum = 0;
    let totalPaidOut = 0; 
    let countOfUser = 0;
    const step1 = 10;
    const step2 = 15;

    usersWithWallets.forEach((referralUser) => {
      if (referralUser.wallets.length > 0) {
        referralUser.wallets.forEach((wallet) => {
          if (wallet.account_size_id) {
            let calculatedValue = 0;

            if (wallet.account_type_id.step === "1 step") {
              calculatedValue = parseFloat(wallet.account_size_id.price) * (step1 / 100);
              totalSum += calculatedValue;
              totalPaidOut += calculatedValue;  
              countOfUser++;
            } else if (wallet.account_type_id.step === "2 step") {
              calculatedValue = parseFloat(wallet.account_size_id.price) * (step2 / 100);
              totalSum += calculatedValue;
              totalPaidOut += calculatedValue;  
              countOfUser++;
            }
          }
        });
      }
    });

    const percentageBasedOnCountUser = countOfUser > 0 ? (totalSum / countOfUser) : 0;  

    const data = {
      referralCodeUserFind: usersWithWallets,
      countOfUser,
      totalEarned: totalSum,
      totalPaidOut,  
      percentageBasedOnCountUser,  
    };

    return res.status(200).json({
      success: 0,
      data: data,
      message: "Affiliate data retrieved successfully.",
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: 2,
      data: { message: ["Server Error", error.message] },
    });
  }
};

const sumOfAffiliateBalance = async (referralCodeUserFind) => {
  let totalSum = 0;
  const step1 = 10;
  const step2 = 15;
  const hft = 0;

  for (const user of referralCodeUserFind) {
    if (user.wallets && Array.isArray(user.wallets)) {
      for (const wallet of user.wallets) {
        let calculatedValue = 0;

        if (wallet.account_type && wallet.account_size && wallet.account_size.price) {
          if (wallet.account_type.step === '1 step') {
            calculatedValue = parseFloat(wallet.account_size.price) * (step1 / 100);
            totalSum += calculatedValue;
          } else if (wallet.account_type.step === '2 step') {
            calculatedValue = parseFloat(wallet.account_size.price) * (step2 / 100);
            totalSum += calculatedValue;
          } else if (wallet.account_type.step === 'HFT') {
            calculatedValue = 0;
            totalSum += calculatedValue;
          }
        }
      }
    }
  }

  return totalSum;
};

// Main function to get affiliate balance
exports.getAffiliateBalance = async (req, res) => {
  try {
    // Validation: check if user_id exists and is valid
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: 2,
        data: { error: errors.array().map(err => err.msg).join(' ') }
      });
    }

    const { user_id } = req.body;
    const user = await User.findById(user_id);

    if (!user) {
      return res.status(404).json({
        success: 2,
        data: { error: 'User not found' }
      });
    }

    // Find referral users with specific wallet conditions
    const referralCodeUserFind = await User.find({
      referred_by: user_id,
    })
      .populate({
        path: "wallets",
        match: { account: 'mt5' },
        populate: [
          { path: "account_type_id" },
          { path: "account_size_id" }
        ]
      })
      .exec();

    const countOfUser = referralCodeUserFind.length;

    // Calculate the total affiliate balance
    const totalEarned = await sumOfAffiliateBalance(referralCodeUserFind);

    // Fetch approved payouts for the user
    const payouts = await Payouts.aggregate([
      { $match: { user_id, payout_type: 'affiliate', payment_status: 'approved' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);
    const totalPaidOut = payouts.length > 0 ? payouts[0].total : 0;

    // Calculate percentage based on count of users
    const percentangeBaseOnCountUser = countOfUser > 0 ? (totalEarned / countOfUser) * 100 / totalEarned : 0;

    // Final affiliate balance (totalEarned - totalPaidOut)
    const finalAmount = totalEarned - totalPaidOut;

    // Return the response with the updated structure
    return res.status(200).json({
      success: 0,
      data: {
        countOfUser,
        percentangeBaseOnCountUser,
        totalEarned,
        totalPaidOut,
        amount: finalAmount
      },
      message: 'Affiliate data fetched successfully'
    });

  } catch (error) {
    console.error('Error in getAffiliateBalance:', error);
    return res.status(500).json({
      success: 2,
      data: { error: 'Server Error', message: error.message }
    });
  }
};

// Check if affiliate is available for a given user
exports.checkAffiliateAvailable = async (req, res) => {
  try {
    const { user_id } = req.body;
    const checkAffiliate = await User.findById(user_id);

    const checkIfAffiliate = checkAffiliate && checkAffiliate.is_affiliate === 0 ? 1 : 0;

    if (checkIfAffiliate) {
      return res.status(200).json({ success: 0, data: 1, message: 'Affiliate data retrieved successfully.' });
    } else {
      return res.status(200).json({ success: 0, data: 0, message: 'Affiliate data retrieved successfully.' });
    }
  } catch (error) {
    return res.status(500).json({ success: 2, message: 'An error occurred.', error: error.message });
  }
};

// exports.checkAffiliateAvailable = async (req, res) => {
//   try {
//     const { user_id } = req.body;
//     const checkAffiliate = await User.findById(user_id);

//     const checkIfAffiliate = checkAffiliate && checkAffiliate.is_affiliate === 0 ? 1 : 0;

//     // Log the data in the same structure
//     console.log({
//       user_id,
//       checkIfAffiliate,
//     });

//     if (checkIfAffiliate) {
//       return res.status(200).json({ success: 0, data: 1, message: 'Affiliate data retrieved successfully.' });
//     } else {
//       return res.status(200).json({ success: 0, data: 0, message: 'Affiliate data retrieved successfully.' });
//     }
//   } catch (error) {
//     return res.status(500).json({ success: 2, message: 'An error occurred.', error: error.message });
//   }
// };
// exports.getAffiliateBalance = async (req, res) => {
  //   try {
    //     const { user_id } = req.body;
    //     if (!user_id) {
      //       return res.status(400).json({
        //         success: 2,
        //         data: { message: ["Validation Error. User ID is required."] },
        //       });
        //     }
        
        // console.loggetAffiliateBalance);
//     const user = await User.findById(user_id);
//     if (!user) {
//       return res.status(404).json({
//         success: 2,
//         data: { message: ["User not found"] },
//       });
//     }

//     // Aggregation pipeline to find referred users with wallet conditions
//     const referralCodeUserFind = await User.aggregate([
//       {
//         $match: { referred_by: user_id },
//       },
//       {
//         $lookup: {
//           from: "wallets", // Wallet collection
//           localField: "_id",
//           foreignField: "user_id",
//           as: "wallets",
//           pipeline: [
//             { $match: { account: "mt5", mt5_type: { $ne: "real" } } },
//             {
//               $match: {
//                 $or: [
//                   { parent_user_wallet_id: { $in: [null, "", "null"] } },
//                 ],
//               },
//             },
//             {
//               $lookup: {
//                 from: "accountSizes", // Account sizes collection
//                 localField: "account_size_id", // Assuming wallet has account_size_id reference
//                 foreignField: "_id",
//                 as: "accountSize",
//               },
//             },
//           ],
//         },
//       },
//       {
//         $unwind: "$wallets", // Flatten the wallets array
//       },
//       {
//         $project: {
//           referred_by: 1,
//           wallets: {
//             account: 1,
//             mt5_type: 1,
//             accountSize: { name: 1, limit: 1, price: 1 },
//           },
//         },
//       },
//     ]);

//     // Get the total earned amount
//     const totalEarned = sumOfAffiliateBalance(referralCodeUserFind);

//     // Calculate the total paid out from Payouts
//     const payoutGet = await Payouts.find({
//       payout_type: "affiliate",
//       payment_status: "approved",
//       user_id,
//     });

//     const totalPaidOut =
//       payoutGet.length > 0 && totalEarned > 0
//         ? payoutGet.reduce((sum, payout) => sum + payout.amount, 0)
//         : 0;

//     // Prepare the response data
//     const data = {
//       referralCodeUserFind,
//       countOfUser: referralCodeUserFind.length,
//       percentangeBaseOnCountUser: 15, // Static value based on countOfUser logic
//       totalEarned,
//       totalPaidOut,
//     };

//     return res.status(200).json({
//       success: 0,
//       data,
//       message: "Affiliate data retrieved successfully.",
//     });
//   } catch (error) {
//     console.error(error);
//     return res.status(500).json({
//       success: 2,
//       data: { message: ["Server Error", error.message] },
//     });
//   }
// };
