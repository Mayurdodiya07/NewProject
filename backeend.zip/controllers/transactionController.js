const { validationResult } = require("express-validator");
const User = require("../models/User");
const Transaction = require("../models/Transaction");
const NotificationHelper = require("../helpers/NotificationHelper");
const path = require("path");
const fs = require("fs");

exports.index = async (req, res) => {
  try {
    const {
      type,
      user_id,
      transaction_type,
      transfer_type,
      payment_method_id,
      user_wallet_id,
      currency_id,
      transaction_status,
      order,
      nopaginate,
      per_page = 20,
      page = 1,
    } = req.query;

    // Initialize query
    let query = Transaction.find(
      {},
      "id type user_id transaction_type transfer_type payment_method_id user_wallet_id currency_id amount transaction_id screenshot transaction_status status updated_at created_at created_at_formattad"
    ).populate("paymentMethod");

    // Apply filters
    if (type) query = query.where("type").equals(type);
    if (user_id) query = query.where("user_id").equals(user_id);
    if (transaction_type)
      query = query.where("transaction_type").equals(transaction_type);
    if (transfer_type)
      query = query.where("transfer_type").equals(transfer_type);
    if (payment_method_id)
      query = query.where("payment_method_id").equals(payment_method_id);
    if (user_wallet_id)
      query = query.where("user_wallet_id").equals(user_wallet_id);
    if (currency_id) query = query.where("currency_id").equals(currency_id);
    if (transaction_status)
      query = query.where("transaction_status").equals(transaction_status);

    // Apply ordering
    const sortOrder =
      order && (order === "asc" || order === "desc") ? order : "desc";
    query = query.sort({ created_at: sortOrder });

    // Handle pagination or fetch all
    if (nopaginate == "1") {
      const transactions = await query.exec();
      return res.json({
        success: 0,
        message: "Transactions retrieved successfully.",
        data: transactions,
      });
    } else {
      const pageNumber = parseInt(page, 10) || 1;
      const pageSize = parseInt(per_page, 10) || 20;

      const transactions = await query
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize)
        .exec();

      // Add sequence field
      transactions.forEach((item, index) => {
        item.sequence = (pageNumber - 1) * pageSize + index + 1;
      });

      const total = await Transaction.countDocuments(query.getFilter());
      const response = {
        data: transactions,
        total,
        per_page: pageSize,
        current_page: pageNumber,
        last_page: Math.ceil(total / pageSize),
      };

      return res.json({
        success: 0,
        message: "Transactions retrieved successfully.",
        data: response,
      });
    }
  } catch (error) {
    console.error("Error in index:", error);
    return res.json({
      success: 2,
      message: "Server Error.",
      data: { error: error.message },
    });
  }
};
exports.store = async (req, res) => {
  try {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessage = errors
        .array()
        .map((err) => err.msg)
        .join(" ");
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: [errorMessage] },
      });
    }

    const {
      user_id,
      user_wallet_id,
      type,
      transaction_type,
      transfer_type,
      currency_id,
      payment_method_id,
      amount,
      transaction_id,
      mt5,
    } = req.body;

    // Check if the user exists
    const user = await User.findById(user_id);
    if (!user) {
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: ["User not found"] },
      });
    }

    // Prepare transaction data
    const input = {
      user_id,
      user_wallet_id,
      type,
      transaction_type,
      transfer_type,
      currency_id,
      payment_method_id,
      amount: parseFloat(amount),
      transaction_id,
      transaction_status: "pending",
      status: "active",
      mt5,
    };

    // Create transaction
    const transaction = await Transaction.create(input);
    if (transaction) {
      // Handle screenshot upload if provided
      if (req.file) {
        const file = req.file;
        const uploadPath = path.join(__dirname, "../uploads/transactions");

        // Ensure directory exists
        if (!fs.existsSync(uploadPath)) {
          fs.mkdirSync(uploadPath, { recursive: true });
        }

        const filePath = path.join(uploadPath, file.filename);
        fs.renameSync(file.path, filePath);

        // Save screenshot URL in the transaction
        transaction.screenshot = `/uploads/transactions/${file.filename}`;
        await transaction.save();
      }

      return res.json({
        success: 0,
        message: "Transaction deposit request sent successfully.",
        data: transaction,
      });
    } else {
      return res.json({
        success: 2,
        message: "Validation Error.",
        data: { error: ["Transaction deposit request not created"] },
      });
    }
  } catch (error) {
    console.error("Error in store:", error);
    return res.json({
      success: 2,
      message: "Server Error.",
      data: { error: error.message },
    });
  }
};

exports.storeWithdrawRequest = async (req, res) => {
  try {
    const {
      user_id,
      user_wallet_id,
      type,
      transaction_type,
      transfer_type,
      currency_id,
      payment_method_id,
      amount,
    } = req.body;

    // Validation
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessage = errors
        .array()
        .map((err) => err.msg)
        .join(" ");
      return res.json({
        success: 0,
        message: "Validation Error.",
        data: { error: [errorMessage] },
      });
    }

    // Check if user exists
    const user = await User.findById(user_id);
    if (!user) {
      return res.json({
        success: 0,
        message: "Validation Error.",
        data: { error: ["User not found"] },
      });
    }

    // Validate wallet
    const userWallet = await UserWallet.findOne({
      _id: user_wallet_id,
      status: "active",
      enabled: true,
    });
    if (!userWallet) {
      return res.json({
        success: 0,
        message: "Validation Error.",
        data: { error: ["Your wallet not found"] },
      });
    }

    // Check balance
    const walletBalance = parseFloat(userWallet.balance || 0);
    const requestAmount = parseFloat(amount || 0);
    if (requestAmount > walletBalance) {
      return res.json({
        success: 0,
        message: "Validation Error.",
        data: { error: ["Your wallet does not have enough balance"] },
      });
    }

    // Create transaction
    const transactionData = {
      user_id,
      user_wallet_id,
      type,
      transaction_type,
      transfer_type,
      currency_id,
      payment_method_id,
      amount: requestAmount,
      transaction_status: "pending",
      status: "active",
    };

    const transaction = new Transaction(transactionData);
    await transaction.save();

    // Handle screenshot upload if provided
    if (req.file) {
      const screenshotPath = `public/transactions/${Date.now()}_${req.file.originalname
        }`;
      const fullPath = path.join(__dirname, "..", screenshotPath);

      // Save the uploaded file
      fs.writeFileSync(fullPath, req.file.buffer);

      // Update transaction with screenshot URL
      transaction.screenshot = `/public/transactions/${path.basename(
        fullPath
      )}`;
      await transaction.save();
    }

    return res.json({
      success: 1,
      message: "Transaction withdraw request sent successfully.",
      data: transaction,
    });
  } catch (error) {
    console.error("Error in storeWithdrawRequest:", error);
    return res.json({
      success: 0,
      message: "Server Error.",
      data: { error: error.message },
    });
  }
};
