const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const challange = require("../models/AccountRequest");
const User = require("../models/User");
const UserWallet = require("../models/UserWallet");
const PhoneNumber = require("libphonenumber-js");
// const AccountType = require("../models/AccountType");
const { validationResult } = require("express-validator");

exports.profile = async (req, res) => {
  try {
    const { user_id } = req.body;

    if (!user_id) {
      return res.status(400).json({
        success: 2,
        message: "User ID is required",
      });
    }

    // Fetch user from the database using the ID
    const user = await User.findById(user_id);
    if (!user) {
      return res.status(404).json({
        success: 2,
        message: "User not found",
      });
    }

    // Convert user document to a plain object
    // const userResponse = user.toObject();
    // userResponse.id = userResponse._id.toString();

    // Respond with the user data
    res.status(200).json({
      success: 0,
      message: "User profile fetched successfully.",
      data: user,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({
      success: 2,
      message: "Server error",
    });
  }
};



exports.getUserVerificationLevel = async (req, res) => {
  try {
    // Validate request
    await body("user_id")
      .notEmpty()
      .withMessage("user_id is required")
      .run(req);
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      const errorMessage = errors
        .array()
        .map((err) => err.msg)
        .join(" ");
      return res.status(400).json({
        success: 2,
        message: "Validation Error.",
        errors: [errorMessage],
      });
    }

    const { user_id } = req.body;

    // Fetch user
    const user = await User.findOne({ _id: user_id });
    if (!user) {
      return res.status(404).json({
        success: 2,
        message: "User not found.",
      });
    }

    // Fetch verification data
    const verificationData = await VerificationLevel.findOne({
      _id: user.verification_level_id,
    });
    if (!verificationData) {
      return res.status(404).json({
        success: 2,
        message: "Verification level not found!",
      });
    }

    // Return success response
    return res.status(200).json({
      success: 0,
      message: "User verification level retrieved successfully.",
      data: verificationData,
    });
  } catch (error) {
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

// this file change auth to userController ........// MD
exports.challenges = async (req, res) => {
  try {
    let query = UserWallet.find()
      .populate({ path: "user_id", model: "User" })
      .populate({
        path: "account_type_id",
        model: "AccountType",
      });

    // Filters
    const filters = {
      account: 'mt5', // Default condition
      status: 'active', // Default condition
    };
    if (req.body.type && req.body.type !== "all")
      filters["accountType.name"] = req.body.type;
    if (req.body.step && req.body.step !== "all")
      filters["accountType.step"] = req.body.step;
    if (req.body.user_id) filters["user_id"] = req.body.user_id;
    if (req.body.account_status && req.body.account_status !== "all")
      filters["account_status"] = req.body.account_status;
    if (req.body.status && req.body.status !== "all")
      filters["status"] = req.body.status;

    query = query.where(filters);

    // Sorting
    const sortOrder = req.body.order === "desc" ? "desc" : "asc";
    query = query.sort({ name: sortOrder });

    // Pagination
    const perPage = parseInt(req.body.per_page) || 20;
    const page = parseInt(req.body.page) || 1;

    if (req.body.nopaginate == "1") {
      const challenges = await query.exec();
      const results = await Promise.all(
        challenges.map(async (wallet) => {
          // Calculate additional fields
          const noOfTrades = await wallet.no_of_trades;
          const daysTraded = await wallet.days_traded;

          // Format dates
          const createdAtFormatted = wallet.created_at
            ? new Date(wallet.created_at).toLocaleDateString()
            : null;
          const updatedAtFormatted = wallet.updated_at
            ? new Date(wallet.updated_at).toLocaleDateString()
            : null;
          const createdDateTimeFormatted = wallet.created_at
            ? new Date(wallet.created_at).toLocaleString()
            : null;

          return {
            ...wallet.toJSON(),
            no_of_trades: noOfTrades,
            days_traded: daysTraded,
            created_at_formattad: createdAtFormatted,
            updated_at_formattad: updatedAtFormatted,
            created_date_time_formattad: createdDateTimeFormatted,
          };
        })
      );

      return res.status(200).json({
        success: 0,
        message: "Challenges fetched successfully.",
        data: results,
      });
    }

    const challenges = await query
      .skip((page - 1) * perPage)
      .limit(perPage)
      .exec();

    const totalChallenges = await UserWallet.countDocuments(filters);

    const results = await Promise.all(
      challenges.map(async (wallet) => {
        // Calculate additional fields
        const noOfTrades = await wallet.no_of_trades;
        const daysTraded = await wallet.days_traded;

        // Format dates
        const createdAtFormatted = wallet.created_at
          ? new Date(wallet.created_at).toLocaleDateString()
          : null;
        const updatedAtFormatted = wallet.updated_at
          ? new Date(wallet.updated_at).toLocaleDateString()
          : null;
        const createdDateTimeFormatted = wallet.created_at
          ? new Date(wallet.created_at).toLocaleString()
          : null;

        return {
          ...wallet.toJSON(),
          no_of_trades: noOfTrades,
          days_traded: daysTraded,
          created_at_formattad: createdAtFormatted,
          updated_at_formattad: updatedAtFormatted,
          created_date_time_formattad: createdDateTimeFormatted,
        };
      })
    );

    return res.status(200).json({
      success: 0,
      message: "Challenges fetched successfully.",
      data: results,
      total: totalChallenges,
      per_page: perPage,
      current_page: page,
      total_pages: Math.ceil(totalChallenges / perPage),
    });
  } catch (error) {
    console.error("Error fetching challenges:", error);
    res.status(500).json({
      success: 1,
      message: "Server error",
      error: error.message,
    });
  }
};

exports.editProfile = async (req, res) => {
  try {
    // Validate user_id in request
    if (!req.body.user_id) {
      return res
        .status(400)
        .json({ error: ["Validation Error. User ID is required."] });
    }

    const user = await User.findById(req.body.user_id);
    if (!user) {
      return res.status(404).json({ error: ["User not found"] });
    }

    // Validate other fields
    const validationErrors = validationResult(req);
    if (!validationErrors.isEmpty()) {
      return res.status(400).json({ error: validationErrors.array() });
    }

    // Handle phone number validation and check if it is unique
    let phoneCountry = null;
    let phonePrefix = null;
    let phoneWithoutPrefix = null;

    if (req.body.phone) {
      const parsedPhone = PhoneNumber.parsePhoneNumberFromString(
        req.body.phone,
        req.body.phone_country
      );
      if (!parsedPhone || !parsedPhone.isValid()) {
        return res.status(400).json({ error: ["Invalid phone number"] });
      }
      phoneCountry = parsedPhone.country;
      phonePrefix = parsedPhone.countryCallingCode;
      phoneWithoutPrefix = parsedPhone.nationalNumber;

      const existingUserWithPhone = await User.findOne({
        phone_country: phoneCountry,
        phone_prefix: phonePrefix,
        phone: phoneWithoutPrefix,
        _id: { $ne: user._id },
      });
      if (existingUserWithPhone) {
        return res
          .status(400)
          .json({ error: ["The phone number is already taken."] });
      }
    }

    // Update user fields based on request body
    if (req.body.first_name) user.first_name = req.body.first_name;
    if (req.body.last_name) user.last_name = req.body.last_name;
    if (req.body.email) user.email = req.body.email;
    if (req.body.phone) {
      user.phone_country = phoneCountry;
      user.phone_prefix = phonePrefix;
      user.phone = phoneWithoutPrefix;
    }
    if (req.body.birthdate)
      user.birthdate = req.body.birthdate ? new Date(req.body.birthdate) : null;
    if (req.body.gender) user.gender = req.body.gender;
    if (req.body.address) user.address = req.body.address;
    if (req.body.city) user.city = req.body.city;
    if (req.body.state) user.state = req.body.state;
    if (req.body.country) user.country = req.body.country;
    if (req.body.country_id) user.country_id = req.body.country_id;
    if (req.body.postal_code) user.postal_code = req.body.postal_code;

    // Save user
    await user.save();

    // Optionally, return updated user with token
    const updatedUser = await User.findById(user._id);
    updatedUser.token = req.headers.authorization?.split(" ")[1]; // Assuming Bearer token is sent in Authorization header
    res.status(200).json({
      success: 0,
      message: "User profile updated successfully.",
      data: updatedUser,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: ["Server Error", error.message] });
  }
};

exports.changePassword = async (req, res) => {
  try {
    // Validation rules
    const { user_id, old_password, password, password_confirmation } = req.body;

    if (!user_id || !old_password || !password || !password_confirmation) {
      return res.status(400).json({
        success: 2,
        message: ["Validation Error. All fields are required."],
      });
    }

    if (password !== password_confirmation) {
      return res.status(400).json({
        success: 2,
        message: [
          "Check confirmation password it should be same with password",
        ],
      });
    }

    // Check if user exists
    const user = await User.findById(user_id);
    if (!user) {
      return res.status(404).json({ success: 2, message: ["Invalid user"] });
    }

    // Verify the old password
    const isOldPasswordValid = await bcrypt.compare(
      old_password,
      user.password
    );
    if (!isOldPasswordValid) {
      return res
        .status(400)
        .json({ success: 2, message: ["Old password is wrong"] });
    }

    // Hash and update the new password
    user.password = await bcrypt.hash(password, 10);
    user.otp = null; // Clear OTP after successful reset
    user.otp_expiry = null;

    // Save the updated user
    await user.save();
    res.status(200).json({
      success: 0,
      message: "User profile updated successfully.",
      data: user,
    });
    // Respond with success
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: ["Server Error", error.message] });
  }
};
