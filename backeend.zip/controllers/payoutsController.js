const mongoose = require("mongoose");
const { validationResult } = require("express-validator");
const moment = require("moment");
const PDFDocument = require("pdfkit");
const path = require("path");
const fs = require("fs");
const User = require("../models/User");
const UserWallet = require("../models/UserWallet");
const Payouts = require("../models/Payouts");
const AccountType = require("../models/AccountType");

const generateDynamicNumber = (recordCount) => {
  return recordCount.toString().padStart(5, "0");
};

exports.index = async (req, res) => {
  try {
    const {
      user_id,
      page = 1,
      per_page = 10,
      sort_field = "created_at", // Default sort field
      sort_direction = "desc",
    } = req.body;

    // Validate user_id
    if (!user_id) {
      return res.status(400).json({
        success: 2,
        message: "Validation Error.",
        error: ["user_id is required"],
      });
    }

    const userExists = await User.exists({ _id: user_id });
    if (!userExists) {
      return res.status(404).json({
        success: 2,
        message: "Validation Error.",
        error: ["user_id does not exist"],
      });
    }

    // Pagination parameters
    const skip = (page - 1) * per_page;
    const limit = parseInt(per_page);

    // Allowed fields for sorting
    const allowedFields = [
      "created_at",
      "amount",
      "reference_id",
      "close_date",
      "payment_status",
      "payout_type",
      "payment_method_id"
    ];

    // Validate sort field
    const sort = {};
    if (allowedFields.includes(sort_field)) {
      sort[sort_field] = sort_direction === "asc" ? 1 : -1;
    } else {
      return res.status(400).json({
        success: 2,
        message: "Invalid sort field.",
        error: [`The field "${sort_field}" is not sortable.`],
      });
    }

    // Query the database
    const payoutsQuery = Payouts.find({
      user_id,
      payment_status: { $ne: "pending" },
    })
      .sort(sort)
      .populate("user")
      .populate("paymentMethod")
      .populate("userWallet");

    const totalPayouts = await Payouts.countDocuments({
      user_id,
      payment_status: { $ne: "pending" },
    });

    const payouts = await payoutsQuery.skip(skip).limit(limit).exec();

    const lastPage = Math.ceil(totalPayouts / per_page);

    // Format the response data
    const formattedPayouts = payouts.map((payout) => ({
      reference_id: payout.reference_id,
      user_id: payout.user_id,
      payment_method: payout.paymentMethod,
      payment_wallet_address_id: payout.payment_wallet_address_id || null,
      account_holder_name: payout.account_holder_name,
      account_number: payout.account_number,
      account_ifsc_code: payout.account_ifsc_code,
      account_bank_name: payout.account_bank_name,
      amount: payout.amount,
      payout_type: payout.payout_type,
      status: payout.status,
      payment_status: payout.payment_status,
      user_wallet_id: payout.user_wallet_id || null,
      updated_at: payout.updated_at,
      created_at: payout.created_at,
      created_at_formattad: payout.created_at_formatted,
      updated_at_formattad: payout.updated_at_formatted,
      user: payout.user || null,
      user_wallet: payout.userWallet || null,
    }));

    const data = {
      total_payouts: totalPayouts,
      current_page: page,
      last_page: lastPage,
      per_page: per_page,
      data: formattedPayouts,
    };

    return res.status(200).json({
      success: 0,
      message: "Payouts fetched successfully.",
      data: data,
    });
  } catch (error) {
    console.error("Error fetching payouts:", error.message);
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

// Create Request of Payouts
exports.createRequestOfPayouts = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((err) => err.msg);
      return res.status(400).json({
        success: 2,
        message: "Validation Error.",
        errors: errorMessages,
      });
    }

    const { user_id, payout_type, payment_method_id, user_wallet_id, amount } =
      req.body;

    const user = await User.findById(user_id);
    if (!user) {
      return res
        .status(404)
        .json({ success: 2, message: "User not found." });
    }

    if (payout_type === "trading_account") {
      const lastApprovedPayout = await Payouts.findOne({
        user_id,
        user_wallet_id,
        payment_status: "approved",
      }).sort({ created_at: -1 });

      if (lastApprovedPayout) {
        const lastApprovedDate = moment(lastApprovedPayout.created_at);
        if (moment().diff(lastApprovedDate, "days") < 30) {
          return res.status(400).json({
            success: 2,
            message:
              "You cannot request a new payout. Please wait until 30 days have passed since your last approved payout request.",
          });
        }
      }
    }

    let adjustedAmount = amount;
    if (payout_type !== "affiliate") {
      const userWallet = await UserWallet.findById(user_wallet_id).populate(
        "accountSize"
      );
      if (!userWallet) {
        return res
          .status(404)
          .json({ success: 2, message: "User wallet not found." });
      }

      const initialBalance = userWallet.accountSize.limit;
      const profit = userWallet.balance - initialBalance;
      if (profit <= 0) {
        return res
          .status(400)
          .json({ success: 2, message: "There is no profit to withdraw." });
      }

      const accountAge = moment().diff(userWallet.created_at, "days");
      let maxProfitWithdrawal = 0.7 * profit;
      if (accountAge >= 60 && accountAge < 90)
        maxProfitWithdrawal = 0.8 * profit;
      else if (accountAge >= 90 && accountAge < 120)
        maxProfitWithdrawal = 0.9 * profit;
      else if (accountAge >= 120) maxProfitWithdrawal = profit;

      adjustedAmount = Math.min(amount, maxProfitWithdrawal);
    }

    const payoutCount = (await Payouts.countDocuments()) + 1;
    const newPayout = await Payouts.create({
      reference_id: generateDynamicNumber(payoutCount),
      user_id,
      payment_method_id,
      amount: adjustedAmount,
      payout_type,
      status: "active",
      payment_status: "pending",
      user_wallet_id,
    });

    return res.json({
      success: true,
      message: "Payout request added successfully.",
      data: newPayout,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ success: 2, message: "Server Error.", error: error.message });
  }
};

// Get Real User Wallet
exports.getRealUserWalletAccount = async (req, res) => {
  try {
    const { user_id, stepFilterValue } = req.body;

    const query = UserWallet.find({
      user_id,
      mt5_type: "real",
      created_at: { $lte: moment().subtract(30, "days").toDate() },
    }).select("id account_number");

    if (stepFilterValue !== "all")
      query.where({ account_type_id: stepFilterValue });

    const wallets = await query.exec();
    return res.json({
      success: true,
      message: "User wallet retrieved successfully.",
      data: wallets,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ success: 2, message: "Server Error.", error: error.message });
  }
};

// Download PDF  api calling ..//
exports.downloadPdf = async (req, res) => {
  try {
    const { type, payout_id, user_wallet_id } = req.body;

    let data;
    if (type === "payout") {
      data = await Payouts.findById(payout_id).populate("user");
    } else {
      data = await UserWallet.findById(user_wallet_id).populate([
        "user",
        "accountSize",
        "accountType",
      ]);
    }

    if (!data) {
      return res
        .status(404)
        .json({ success: 2, message: "Data not found." });
    }

    const pdf = new PDFDocument({ size: "A4", layout: "landscape" });
    const filePath = path.join(process.cwd(), `${type}_certificate.pdf`);

    const writeStream = fs.createWriteStream(filePath);

    pdf.pipe(writeStream);
    pdf.text(`Certificate for ${type}`, { align: "center" });
    pdf.end();

    writeStream.on("finish", () => {
      return res.json({
        success: 0,
        message: "PDF generated successfully.",
        download_link: `${type}_certificate.pdf`,
      });
    });
  } catch (error) {
    return res
      .status(500)
      .json({ success: 2, message: "Server Error.", error: error.message });
  }
};

exports.getAccountTypeList = async (req, res) => {
  try {
    const accountTypes = await AccountType.find();
    return res.status(200).json({
      success: 0,
      message: "Challenges retrieved successfully.",
      data: accountTypes,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ success: 2, message: "Server Error.", error: error.message });
  }
};
