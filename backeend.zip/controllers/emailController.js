const { sendEmail } = require("../services/emailService");

// Supervise email sending
exports.superviseEmail = async (req, res) => {
  try {
    const { to, subject, text, html } = req.body;

    // Validate input
    if (!to || !subject || !text) {
      return res.status(400).json({
        success: false,
        message: "Recipient, subject, and text are required",
      });
    }

    // Send email
    const emailSent = await sendEmail(to, subject, text, html || "");

    if (emailSent) {
      res.status(200).json({
        success: 0,
        message: "Email sent successfully!",
      });
    } else {
      res.status(500).json({
        success: 2,
        message: "Failed to send email. Please try again.",
      });
    }
  } catch (error) {
    console.error("Error supervising email:", error);
    res.status(500).json({ success: 2, message: "Server error" });
  }
};
