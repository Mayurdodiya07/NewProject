const AccountType = require("../models/AccountType"); // Import the AccountType model

exports.index = async (req, res) => {
  try {
    const { type, order, nopaginate, per_page } = req.body;
    let query = AccountType.find();
    if (type) {
      query = query.where("type").equals(type);
    }
    if (order && (order === "asc" || order === "desc")) {
      query = query.sort({ id: order });
    } else {
      query = query.sort({ name: "asc" });
    }
    if (nopaginate == "1") {
      query = query;
    } else {
      let page = parseInt(req.query.page) || 1;
      let perPage = parseInt(per_page) || 20;
      query = query.skip((page - 1) * perPage).limit(perPage);
    }
    const accountTypes = await query.exec();
    return res.json({
      success: 0,
      message: "Account types fetched successfully.",
      data: accountTypes,
    });
  } catch (err) {
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: err.message,
    });
  }
};
