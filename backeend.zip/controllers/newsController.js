const NewsCurrency = require("../models/NewsCurrency");
const News = require("../models/News");
const moment = require("moment");

exports.index = async (req, res) => {
  try {
    const query = News.find({ status: "active" });
    const currencyId = req.body.currency_id;
    const impactFilter = req.body.impact;
    const dayFilter = req.body.day;

    // Conditional population based on currencyId
    if (currencyId && currencyId !== "") {
      query.populate({
        path: "news_currency",
        match: { code: currencyId },
      });
    } else {
      query.populate("news_currency");
    }
    if (Array.isArray(impactFilter) && impactFilter.length > 0) {
      query.where("impact").in(impactFilter);
    }

    if (Array.isArray(dayFilter) && dayFilter.length > 0) {
      const dayConditions = dayFilter.map((date) => {
        const startOfDay = new Date(date);
        const endOfDay = new Date(date);
        endOfDay.setUTCHours(23, 59, 59, 999);
        return { date: { $gte: startOfDay, $lt: endOfDay } };
      });
      query.or(dayConditions);
    }
    const newsData = await query.exec();
    const filteredNewsData = newsData.filter(
      (item) => item.news_currency !== null
    );
    if (filteredNewsData.length === 0) {
      return res.status(200).json({
        success: 0,
        message: "No active news found for the provided filters.",
        data: [],
      });
    }

    const groupedData = filteredNewsData.reduce((result, item) => {
      const dateTimeKey =
        item.date.toISOString().split("T")[0] +
        " " +
        item.date.toISOString().split("T")[1].split(".")[0];

      if (!result[dateTimeKey]) {
        result[dateTimeKey] = {
          date: item.date,
          records: [],
        };
      }

      result[dateTimeKey].records.push(item);
      return result;
    }, {});
    const groupedArray = Object.values(groupedData);
    res.status(200).json({
      success: 0,
      message: "Active news with currency fetched successfully.",
      data: groupedArray,
    });
  } catch (error) {
    res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

exports.getCurrencyData = async (req, res) => {
  try {
    const newsCurrency = await NewsCurrency.find();
    return res.json({
      success: 0,
      message: "News currency retrieved successfully.",
      data: newsCurrency,
    });
  } catch (error) {
    // console.error("Error in getCurrencyData:", error);
    return res.json({
      success: 2,
      message: "Server Error.",
      data: { error: error.message },
    });
  }
};
