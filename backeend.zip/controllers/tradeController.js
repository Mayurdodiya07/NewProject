const moment = require("moment");
const Trade = require("../models/Trade");
const RealAccountRequest = require("../models/RealAccountRequest");
const UserWallet = require("../models/UserWallet");
const User = require("../models/User");
const accountSize = require("../models/AccountSize");
const Symbol = require("../models/Symbol");
const BalanceHistory = require("../models/BalanceHistory");
const dayjs = require("dayjs");
const utc = require("dayjs/plugin/utc");
dayjs.extend(utc);
// const Mt5Service = require("../services/mt5Service");
const {
  getTradeHistoryWithAccount,
  getAllUserOpenPositionData,
} = require("../services/emailService");
const responseHelper = require("../utils/responseHelper");
const {
  sendResponse,
  sendError,
  sendServerError,
} = require("../utils/responseHelper");
const { response } = require("express");



//Trade Data For Chart  caaling api....//
exports.getTradeDataForChart = async (req, res) => {
  try {
    const { filter_apply_value, user_wallet_id, start_date, end_date } =
      req.body;

    let profitData;

    // Fetch the trades based on the filter
    if (filter_apply_value === "today") {
      const today = moment().startOf("day").toDate();
      profitData = await Trade.aggregate([
        {
          $match: {
            user_wallet_id,
            profit: { $ne: 0 },
            position: "close",
            close_date: {
              $gte: today,
              $lt: moment(today).endOf("day").toDate(),
            },
          },
        },
      ]);
    } else if (filter_apply_value === "week") {
      const startOfWeek = moment().startOf("week").toDate();
      const endOfWeek = moment().endOf("week").toDate();
      profitData = await Trade.aggregate([
        {
          $match: {
            user_wallet_id,
            profit: { $ne: 0 },
            position: "close",
            close_date: { $gte: startOfWeek, $lte: endOfWeek },
          },
        },
      ]);
    } else if (filter_apply_value === "month") {
      const startOfMonth = moment().startOf("month").toDate();
      const endOfMonth = moment().endOf("month").toDate();
      profitData = await Trade.aggregate([
        {
          $match: {
            user_wallet_id,
            profit: { $ne: 0 },
            position: "close",
            close_date: { $gte: startOfMonth, $lte: endOfMonth },
          },
        },
      ]);
    } else if (filter_apply_value === "custom" && start_date && end_date) {
      profitData = await Trade.aggregate([
        {
          $match: {
            user_wallet_id,
            profit: { $ne: 0 },
            position: "close",
            close_date: {
              $gte: new Date(start_date),
              $lte: new Date(end_date),
            },
          },
        },
      ]);
    } else {
      profitData = await Trade.aggregate([
        {
          $match: {
            user_wallet_id,
            profit: { $ne: 0 },
            position: "close",
          },
        },
      ]);
    }

    const groupedData = monthGroupAndAggregateSummaryTrades(
      profitData,
      req.body
    );

    const sortedData = groupedData.sort((a, b) =>
      moment(a.date_formatted).isBefore(moment(b.date_formatted)) ? -1 : 1
    );

    res.status(200).json({
      success: 0,
      message: "Profit data fetched successfully.",
      data: { profitData: sortedData },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: 2,
      message: "Server error",
      error: error.message,
    });
  }
};

const monthGroupAndAggregateSummaryTrades = (trades, reqData) => {
  const groupedData = {};
  const startDate = moment(reqData.start_date);
  const endDate = moment(reqData.end_date);
  const today = moment();

  trades.forEach((trade) => {
    let created_at;

    // Ensure the date is formatted as "YYYY-MM-DD" (exact date)
    if (
      reqData.filter_apply_value === "today" ||
      reqData.filter_apply_value === "week"
    ) {
      created_at = moment(trade.close_date).format("YYYY-MM-DD");
    } else if (
      reqData.filter_apply_value === "custom" &&
      startDate.diff(endDate, "days") <= 7
    ) {
      created_at = moment(trade.close_date).format("YYYY-MM-DD");
    } else {
      created_at = moment(trade.close_date).format("YYYY-MM-DD"); // For exact day grouping
    }

    if (!groupedData[created_at]) {
      groupedData[created_at] = {
        date_formatted: created_at,
        profit: 0,
        loss: 0,
        lots: 0,
        total_trade: 0,
        date_diff: 0, // Initialize with 0
      };
    }

    // Aggregating profit, loss, lots, and total trade count
    groupedData[created_at].profit += trade.profit;
    groupedData[created_at].loss += trade.loss;
    groupedData[created_at].lots += trade.lots;
    groupedData[created_at].total_trade++;

    groupedData[created_at].date_diff = today.diff(
      moment(trade.close_date),
      "days"
    );
  });

  return Object.values(groupedData);
};

// exports.getCurrencyVolumn = async (req, res) => {
//   try {
//     const trades = await Trade.find({
//       user_wallet_id: req.body.user_wallet_id,
//       position: "close",
//     })
//       .populate({ path: "symbol_id", model: "Symbol" })
//       .sort({ close_date: -1 });
//     // console.log(trades[0].symbol_id.id);
//     const groupedTrades = trades.reduce((acc, trade) => {
//       const symbolId = trade.symbol_id.id;
//       console.log(symbolId);
//       if (!acc[symbolId]) {
//         acc[symbolId] = [];
//       }
//       acc[symbolId].push(trade);
//       return acc;
//     }, {});

//     const processedTrades = Object.keys(groupedTrades)
//       .slice(0, 7)
//       .map((symbolId) => {
//         const symbolTrades = groupedTrades[symbolId];
//         const symbolName = symbolTrades[0].symbol.name;
//         const totalLotSize = symbolTrades.reduce(
//           (sum, trade) => sum + trade.lots,
//           0
//         );
//         const formattedSymbol = symbolName.match(/.{1,3}/g).join("/");

//         return {
//           symbol: formattedSymbol,
//           total_lot_size: totalLotSize,
//         };
//       });

//     const data = { trades: processedTrades };
//     return res.status(200).json({
//       success: 0,
//       message: "Trade volume data retrieved successfully.",
//       data,
//     });
//   } catch (error) {
//     console.error(error);
//     return res
//       .status(500)
//       .json({ success: 2, message: "Server Error", error: error.message });
//   }
// };

// Export function to create a trade
exports.getCurrencyVolumn = async (req, res) => {
  try {
    const trades = await Trade.find({
      user_wallet_id: req.body.user_wallet_id,
      position: "close",
    })
      .populate({ path: "symbol_id", model: "Symbol" }) // Ensure `symbol_id` is populated
      .sort({ close_date: -1 }); // Sort by latest close date

    // if (!trades || trades.length === 0) {
    //   return res.status(404).json({
    //     success: 0,
    //     message: "No trades found for the given user wallet.",
    //   });
    // }

    // Group trades by `symbol_id`
    const groupedTrades = trades.reduce((acc, trade) => {
      const symbolId = trade.symbol_id && trade.symbol_id._id ? trade.symbol_id._id.toString() : null;
      if (!symbolId) return acc; // Skip if `symbol_id` is missing
      if (!acc[symbolId]) {
        acc[symbolId] = [];
      }
      acc[symbolId].push(trade);
      return acc;
    }, {});

    // Process top 7 grouped trades
    const processedTrades = Object.keys(groupedTrades)
      .slice(0, 7) // Limit to 7 groups
      .map((symbolId) => {
        const symbolTrades = groupedTrades[symbolId];
        const symbolName = symbolTrades[0]?.symbol_id?.name || "Unknown"; // Access symbol name
        const totalLotSize = symbolTrades.reduce(
          (sum, trade) => sum + (trade.lots || 0), // Sum up lot sizes
          0
        );
        const formattedSymbol = symbolName.match(/.{1,3}/g).join("/"); // Format symbol as AAA/BBB

        return {
          symbol: formattedSymbol,
          total_lot_size: totalLotSize,
        };
      });

    // Prepare the response data
    const data = { trades: processedTrades };

    return res.status(200).json({
      success: 0,
      message: "Trade volume data retrieved successfully.",
      data,
    });
  } catch (error) {
    console.error("Error in getCurrencyVolumn:", error);
    return res.status(500).json({
      success: 2,
      message: "Server Error",
      error: error.message,
    });
  }
};

exports.createTrade = async (req, res) => {
  try {
    // Validate request fields
    await check("user_id")
      .notEmpty()
      .withMessage("user_id is required")
      .bail()
      .custom(async (value) => {
        const userExists = await User.findById(value);
        if (!userExists) {
          throw new Error("User does not exist.");
        }
      })
      .run(req);

    await check("user_wallet_id")
      .notEmpty()
      .withMessage("user_wallet_id is required")
      .bail()
      .custom(async (value) => {
        const walletExists = await UserWallet.findById(value);
        if (!walletExists) {
          throw new Error("User wallet does not exist.");
        }
      })
      .run(req);

    await check("lots").notEmpty().withMessage("Lots are required.").run(req);
    await check("symbol_id")
      .notEmpty()
      .withMessage("symbol_id is required.")
      .run(req);
    await check("side").notEmpty().withMessage("Side is required.").run(req);
    await check("price").notEmpty().withMessage("Price is required.").run(req);

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessage = errors
        .array()
        .map((err) => err.msg)
        .join(" ");
      return res.status(400).json({
        success: 2,
        message: "Validation Error.",
        error: errorMessage,
      });
    }

    // Find user
    const user = await user_id.findById(req.body.user_id);
    if (!user) {
      return res
        .status(404)
        .json({ success: 2, message: "User not found." });
    }

    // Find user wallet
    const userWallet = await UserWallet.findById(req.body.user_wallet_id);
    if (!userWallet) {
      return res
        .status(404)
        .json({ success: 2, message: "User wallet not found." });
    }

    // Find symbol
    const symbol = await Symbol.findOne({ name: "GBPUSD" }); // Assuming static symbol lookup
    if (!symbol) {
      return res
        .status(404)
        .json({ success: 2, message: "Symbol not found." });
    }

    // Prepare MT5 account data for the trade
    const mt5AccountData = {
      loginid: userWallet.account_number,
      positionId: 0,
      symbol: symbol.name,
      volume: parseFloat(req.body.lots),
      price: req.body.price,
      type: req.body.side,
      tp: req.body.tp || null, // Optional field
      sl: req.body.sl || null, // Optional field
      comment: "Trade",
    };

    if (response?.deal?.dealResult?.retCode === "MT_RET_REQUEST_DONE") {
      const trade = response.deal.deal;
      return res.status(200).json({
        success: 0,
        message: "Trade added successfully.",
        data: trade,
      });
    } else {
      return res.status(400).json({
        success: 2,
        message: "Trade not created.",
        error: "MT5 API returned an error.",
      });
    }
  } catch (error) {
    console.error("Error creating trade:", error.message);
    return res
      .status(500)
      .json({ success: 2, message: "Server Error.", error: error.message });
  }
};

//  Open Positions List api  calling......//

exports.getOpenPositionsList = async (req, res) => {
  try {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    const { user_wallet_id, per_page = 10, page = 1 } = req.body;

    // Get the total trades count
    const totalTrades = await Trade.countDocuments({
      user_wallet_id,
      position: "open",
    });

    // Get the open positions for the current page
    const openPositions = await Trade.find({
      user_wallet_id,
      position: "open",
    })
      .sort({ open_date: -1 }) // Sort by open date descending
      .skip((page - 1) * per_page) // Pagination logic
      .limit(per_page); // Limit per page

    const lastPage = Math.ceil(totalTrades / per_page);

    // Prepare response data
    const data = {
      total_trades: totalTrades,
      current_page: page,
      last_page: lastPage,
      per_page,
      data: openPositions,
    };

    // Return the paginated response
    return responseHelper.sendResponse(
      res,
      "Trade History retrieved successfully.",
      data
    );
  } catch (error) {
    console.error("Error fetching open positions:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};
// Get-Trading-History-List MD api calling...//

exports.getTradingHistoryList = async (req, res) => {
  const { user_wallet_id, sort_field, sort_direction, page, per_page } =
    req.body;

  try {
    // Validation
    if (!user_wallet_id) {
      return sendError(res, "Validation Error", "user_wallet_id is required");
    }
    let sortField;
    if (sort_field === "type") {
      sortField = "side";
    } else if (sort_field === "open") {
      sortField = "open_price";
    } else {
      sortField = sort_field; // Use the provided sort_field if not "type" or "open"
    }
    const sortDirection = sort_direction === "desc" ? -1 : 1; // Convert to MongoDB sort value
    // Create query for trade history list
    const tradeHistoryQuery = Trade.find({
      position: "close",

      user_wallet_id: user_wallet_id,
    })
      // .select(
      //   "_id user_id lots ib_id user_wallet_id symbol_id trade_group_id trade_id trade_execution_date side position reversal profit loss open_price close_price stop_loss take_profit created_at open_date close_date commission swap"
      // )
      // .populate("user_id user_wallet_id symbol_id")
      .populate({ path: "user_id", model: "User" })
      .populate({ path: "user_wallet_id", model: "UserWallet" })
      .populate({ path: "symbol_id", model: "Symbol" })
      .sort({ [sortField]: sortDirection });

    // Get total count of records for pagination
    const totalTrades = await Trade.countDocuments({
      position: "close",
      user_wallet_id: user_wallet_id,
    });

    // Paginate the results
    const results = await tradeHistoryQuery
      .skip((page - 1) * per_page)
      .limit(per_page);

    // Calculate last page
    const lastPage = Math.ceil(totalTrades / per_page);

    // Prepare response data
    const data = {
      total_trades: totalTrades,
      current_page: page,
      last_page: lastPage,
      per_page: per_page,
      data: results,
    };

    // Return the response with the proper structure
    return res.status(200).json({
      success: 0,
      message: "Trade History fetched successfully", // Success message
      data: data,
    });
  } catch (error) {
    console.error("Error fetching trade history:", error.message);
    return sendServerError(res, "Server Error", error.message);
  }
};

// exports.getDailySummaryTradeList = async (req, res) => {
//   try {
//     // Validation
//     const { user_wallet_id, per_page = 10, page = 1 } = req.body;

//     // Fetch trades from the database
//     const tradeHistoryListData = await Trade.find({
//       user_wallet_id,
//       position: "close",
//     }).sort({ open_date: -1 }); // Sort by 'open_date' descending
//     // Aggregate data
//     const groupTrades = groupAndAggregateSummaryTrades(tradeHistoryListData);
//     console.log('out');

//     const totalTrades = groupTrades.length;
//     const lastPage = Math.ceil(totalTrades / per_page);
//     const results = groupTrades.slice((page - 1) * per_page, page * per_page);

//     // Return paginated response
//     const data = {
//       total_trades: totalTrades,
//       current_page: page,
//       last_page: lastPage,
//       per_page: parseInt(per_page),
//       data: results,
//     };

//     return sendResponse(res, "Trade History fetched successfully",data);
//   } catch (error) {
//     return sendServerError(res, "Server Error", error.message);
//   }
// };

const groupAndAggregateSummaryTrades = (trades) => {
  const groupedData = {};

  trades.forEach((trade) => {
    const createdAt = moment(trade.close_date).format("YYYY-MM-DD");

    if (!groupedData[createdAt]) {
      groupedData[createdAt] = {
        date_formatted: createdAt,
        profit: 0,
        loss: 0,
        lots: 0,
        total_trade: 0,
        trade_id: null,
      };
    }

    // Aggregate data
    groupedData[createdAt].profit += parseFloat(trade.profit);
    groupedData[createdAt].lots += parseFloat(trade.lots);
    groupedData[createdAt].loss += parseFloat(trade.loss);
    groupedData[createdAt].trade_id = trade.trade_id; // Assuming trade_id is unique per trade
    groupedData[createdAt].total_trade++;
  });

  // Convert to an array after aggregation
  return Object.values(groupedData);
};
exports.getDailySummaryTradeList = async (req, res) => {
  try {
    const {
      user_wallet_id,
      per_page = 10,
      page = 1,
      sort_field = "open_date",
      sort_direction = "desc",
    } = req.body;

    // Fetch trades from the database
    let tradeHistoryListData = await Trade.find({
      user_wallet_id,
      position: "close",
    });

    // Deduplicate trades
    tradeHistoryListData = tradeHistoryListData.filter(
      (value, index, self) =>
        index === self.findIndex((t) => t.trade_id === value.trade_id)
    );

    // Sort trades dynamically based on `sort_field` and `sort_direction`
    tradeHistoryListData = tradeHistoryListData.sort((a, b) => {
      const fieldA = a[sort_field];
      const fieldB = b[sort_field];

      // If date fields are involved, we should ensure they're compared as dates
      if (
        fieldA &&
        fieldB &&
        (sort_field === "open_date" || sort_field === "close_date")
      ) {
        const dateA = new Date(fieldA).getTime();
        const dateB = new Date(fieldB).getTime();

        return sort_direction === "desc" ? dateB - dateA : dateA - dateB;
      }

      // Default comparison for non-date fields (e.g., trade_id)
      if (fieldA > fieldB) {
        return sort_direction === "desc" ? -1 : 1;
      } else if (fieldA < fieldB) {
        return sort_direction === "desc" ? 1 : -1;
      }
      return 0;
    });

    // Aggregate trades after sorting
    const groupTrades = groupAndAggregateSummaryTrades(tradeHistoryListData);

    // Pagination logic
    const totalTrades = groupTrades.length;
    const lastPage = Math.ceil(totalTrades / per_page);
    const results = groupTrades.slice((page - 1) * per_page, page * per_page);

    const data = {
      total_trades: totalTrades,
      current_page: page,
      last_page: lastPage,
      per_page: parseInt(per_page),
      data: results,
    };

    return sendResponse(res, "Trade History fetched successfully", data);
  } catch (error) {
    return sendServerError(res, "Server Error", error.message);
  }
};

// GET-Daily- Summary- Trade-List MD API calling...//

// exports.getDailySummaryTradeList = async (req, res) => {
//   const { user_wallet_id, page, per_page } = req.body;

//   try {
//     // Validation
//     if (!user_wallet_id) {
//       return res.status(400).json({
//         success: 1,
//         message: "Validation Error: user_wallet_id is required.",
//       });
//     }

//     // Fetch trades filtered by user_wallet_id and position
//     const tradeHistoryListData = await Trade.find({
//       user_wallet_id,
//       position: "close",
//     })
//       .sort({ open_date: -1 })
//       .exec();

//     if (!tradeHistoryListData || tradeHistoryListData.length === 0) {
//       return res.status(200).json({
//         success: 0,
//         message: "No trades found for the specified wallet.",
//         data: {
//           total_trades: 0,
//           current_page: page,
//           last_page: 0,
//           per_page,
//           data: [],
//         },
//       });
//     }

//     // Group and aggregate trades
//     const groupAndAggregateSummaryTrades = (trades) => {
//       const grouped = {};
//       trades.forEach((trade) => {
//         const date = trade.open_date.toISOString().split("T")[0]; // Group by date
//         if (!grouped[date]) {
//           grouped[date] = {
//             date,
//             total_lots: 0,
//             total_profit: 0,
//             total_loss: 0,
//             trades: [],
//           };
//         }
//         grouped[date].total_lots += trade.lots || 0;
//         grouped[date].total_profit += trade.profit || 0;
//         grouped[date].total_loss += trade.loss || 0;
//         grouped[date].trades.push(trade);
//       });
//       return Object.values(grouped);
//     };

//     const groupedTrades = groupAndAggregateSummaryTrades(tradeHistoryListData);

//     // Pagination
//     const totalTrades = groupedTrades.length;
//     const results = groupedTrades.slice((page - 1) * per_page, page * per_page);
//     const lastPage = Math.ceil(totalTrades / per_page);

//     // Response structure
//     const data = {
//       total_trades: totalTrades,
//       current_page: page,
//       last_page: lastPage,
//       per_page,
//       data: results,
//     };

//     return res.status(200).json({
//       success: 0,
//       message: "Trade History fetched successfully.",
//       data,
//     });
//   } catch (error) {
//     console.error("Error fetching daily summary trade list:", error.message);
//     return res.status(500).json({
//       success: 1,
//       message: "Server Error.",
//       error: error.message,
//     });
//   }
// };

// GET-Data For Account Details Calender MD API calling...//

// exports.getDataForAccountDetailsCalender = async (req, res) => {
//   const { user_wallet_id, year, month } = req.body;

//   try {
//     // Validation
//     if (!user_wallet_id || !year || !month) {
//       return res.status(400).json({
//         success: 2,
//         message:
//           "Validation Error: user_wallet_id, year, and month are required.",
//       });
//     }

//     // Define the start and end dates of the specified month
//     const startDate = dayjs(`${year}-${month}-01`).startOf("month");
//     const endDate = dayjs(`${year}-${month}-01`).endOf("month");

//     // Query trades within the date range
//     const trades = await Trade.find({
//       user_wallet_id,
//       position: "close",
//       close_date: {
//         $gte: startDate.toDate(),
//         $lte: endDate.toDate(),
//       },
//     }).exec();

//     const dailyData = {};

//     for (
//       let date = startDate;
//       date.isBefore(endDate.add(1, "day"));
//       date = date.add(1, "day")
//     ) {
//       dailyData[date.format("YYYY-MM-DD")] = {
//         profit: 0,
//         loss: 0,
//         count: 0,
//       };
//     }

//     // Aggregate data from trades
//     trades.forEach((trade) => {
//       const date = dayjs(trade.close_date).format("YYYY-MM-DD");
//       if (dailyData[date]) {
//         dailyData[date].count++;
//         dailyData[date].profit += trade.profit || 0;
//         dailyData[date].loss += trade.loss || 0;
//       }
//     });

//     // Return the response
//     return res.status(200).json({
//       success: 0,
//       message: "Trade History fetched successfully.",
//       data: dailyData,
//     });
//   } catch (error) {
//     console.error(
//       `Error fetching data for user_wallet_id: ${user_wallet_id}, year: ${year}, month: ${month}`,
//       error.stack
//     );
//     return res.status(500).json({
//       success: 2,
//       message: "Server Error.",
//       error: error.message,
//     });
//   }
// };

exports.getDataForAccountDetailsCalender = async (req, res) => {
  const { user_wallet_id, year, month } = req.body;

  try {
    // Validation
    if (!user_wallet_id || !year || !month) {
      return res.status(400).json({
        success: 2,
        message:
          "Validation Error: user_wallet_id, year, and month are required.",
      });
    }

    // Define the start and end dates of the specified month in UTC
    const startDate = dayjs
      .utc(`${year}-${month}-01`)
      .startOf("month")
      .toDate();
    const endDate = dayjs.utc(`${year}-${month}-01`).endOf("month").toDate();

    // Query trades within the date range
    const trades = await Trade.find({
      user_wallet_id,
      position: "close",
      close_date: {
        $gte: startDate,
        $lte: endDate,
      },
    });

    // Initialize an array to hold data for each day
    const dailyData = {};

    // Iterate through each day of the month
    for (
      let date = dayjs.utc(startDate);
      date.isBefore(dayjs.utc(endDate).add(1, "day"));
      date = date.add(1, "day")
    ) {
      dailyData[date.format("YYYY-MM-DD")] = {
        profit: 0,
        loss: 0,
        count: 0,
      };
    }

    // Aggregate data from trades
    trades.forEach((trade) => {
      const tradeDate = dayjs.utc(trade.close_date).format("YYYY-MM-DD");
      if (dailyData[tradeDate]) {
        dailyData[tradeDate].count += 1;
        dailyData[tradeDate].profit += trade.profit || 0;
        dailyData[tradeDate].loss += trade.loss || 0;
      }
    });

    // Return the response
    return res.status(200).json({
      success: 0,
      message: "Trade History fetched successfully.",
      data: dailyData,
    });
  } catch (error) {
    console.error(
      `Error fetching data for user_wallet_id: ${user_wallet_id}, year: ${year}, month: ${month}`,
      error.stack
    );
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

// GET-Data-For-Account-Details-DateWise MD API calling....//

exports.getDataForAccountDetailsDateWise = async (req, res) => {
  const { user_wallet_id, select_date } = req.body;

  try {
    // Validation
    if (!user_wallet_id || !select_date) {
      return res.status(400).json({
        success: 2,
        message:
          "Validation Error: user_wallet_id and select_date are required.",
      });
    }

    // Query trades on the selected date
    const trades = await Trade.find({
      user_wallet_id,
      position: "close",
      close_date: {
        $gte: new Date(select_date).setHours(0, 0, 0, 0),
        $lte: new Date(select_date).setHours(23, 59, 59, 999),
      },
    })
      .populate("user_wallet_id")
      .exec();

    // Initialize data for the selected day
    const dailyData = {
      profit: 0,
      loss: 0,
      lots: 0,
      ending_balance: 0,
      count: 0,
    };

    // Aggregate data from trades
    trades.forEach((trade) => {
      dailyData.count++;
      dailyData.profit += trade.profit || 0;
      dailyData.loss += trade.loss || 0;
      dailyData.lots += trade.lots || 0;
      if (trade.user_wallet_id && trade.user_wallet_id.balance) {
        dailyData.ending_balance = trade.user_wallet_id.balance;
      }

      // if (trade.user_wallet && trade.user_wallet.balance) {
      //   dailyData.ending_balance = trade.user_wallet.balance;
      // }
    });

    // Return the response
    return res.status(200).json({
      success: 0,
      message: "Trade History fetched successfully.",
      data: dailyData,
    });
  } catch (error) {
    console.error(
      "Error fetching data for account details date-wise:",
      error.message
    );
    return res.status(500).json({
      success: 2,
      message: "Server Error.",
      error: error.message,
    });
  }
};

// Get- Real Time Data For Account Detail Md API Calling.....//

exports.getRealTimeDataForAccountDetail = async (req, res) => {
  try {
    const { user_wallet_id } = req.body;

    // Validate request data
    if (!user_wallet_id) {
      return res.status(400).json({
        success: 2,
        message: "Invalid request parameters: user_wallet_id is required.",
      });
    }

    // Fetch wallet data with related account info
    const challengeInfo = await UserWallet.findById(user_wallet_id)
      .populate("account_type_id")
      .populate("account_size_id");

    if (!challengeInfo) {
      return res
        .status(404)
        .json({ success: 2, message: "User wallet not found." });
    }

    const today = moment().startOf("day");
    const balanceHistory = await BalanceHistory.findOne({
      user_wallet_id,
      created_at: { $lt: today.toDate() },
    })
      .sort({ created_at: -1 })
      .exec();

    const equity = challengeInfo.equity || 0;
    const balance = challengeInfo.balance || 0;

    const limit = balanceHistory
      ? balanceHistory.equity
      : challengeInfo.account_size_id.limit || 0;
    const dailyLossLimit =
      challengeInfo.balance *
      (challengeInfo.account_size_id.max_daily_loss / 100) || 0;
    const overallLossLimit =
      challengeInfo.account_size_id.limit *
      (challengeInfo.account_size_id.max_overall_loss / 100) || 0;

    const maxLossDifference =
      parseFloat(challengeInfo.account_size_id.limit) - parseFloat(equity) || 0;
    const dailyLossDifference = limit - balance || 0;

    let totalDailyLoss = dailyLossDifference < 0 ? 0 : dailyLossDifference;
    let totalOverAllLoss = maxLossDifference < 0 ? 0 : maxLossDifference;

    if (challengeInfo.account_status === "disabled") {
      totalDailyLoss = limit - balance;
      totalOverAllLoss = challengeInfo.account_size_id.limit - balance;
    }

    const remainDailyLoss =
      totalDailyLoss <= 0
        ? dailyLossLimit
        : dailyLossLimit < totalDailyLoss
          ? 0
          : dailyLossLimit - totalDailyLoss;

    const remainOverAllLoss =
      totalOverAllLoss <= 0
        ? overallLossLimit
        : overallLossLimit < totalOverAllLoss
          ? 0
          : overallLossLimit - totalOverAllLoss;

    // Threshold calculations
    const dailyThreadshold = equity - dailyLossLimit || 0;
    const overAllThreadshold =
      challengeInfo.account_size_id.limit - overallLossLimit || 0;

    // Loss percentages
    const totalDailyLossPercentage =
      totalDailyLoss <= 0
        ? 0
        : totalDailyLoss > dailyLossLimit
          ? 100
          : (totalDailyLoss / dailyLossLimit) * 100;

    const totalOverAllLossPercentage =
      totalOverAllLoss <= 0
        ? 0
        : totalOverAllLoss > overallLossLimit
          ? 100
          : (totalOverAllLoss / overallLossLimit) * 100;

    // Response data format (Updated to match the desired structure)
    const data = {
      dailyLoss: dailyLossLimit,
      overallLoss: totalOverAllLoss,
      totalDailyLoss: totalDailyLoss,
      totalOverAllLoss: totalOverAllLoss,
      accountStatus: challengeInfo.account_status,
      balance: balance,
      equity: equity,
      dailyLossLimit: dailyLossLimit,
      overallLossLimit: overallLossLimit,
      remainDailyLoss: remainDailyLoss,
      remainOverAllLoss: remainOverAllLoss,
      dailyThreadshold: dailyThreadshold,
      overAllThreadshold: overAllThreadshold,
      totalDailyLossPercentage: totalDailyLossPercentage,
      totalOverAllLossPercentage: totalOverAllLossPercentage,
    };

    return res.status(200).json({
      success: 0,
      message: "Account details retrieved successfully.",
      data,
    });
  } catch (error) {
    console.error("Error in getRealTimeDataForAccountDetail:", error);
    return res
      .status(500)
      .json({ success: 2, message: "Server error.", error: error.message });
  }
};

// Get Analysis -Data MD api Calling..
exports.getAnalysisData = async (req, res) => {
  try {
    const { userWalletID } = req.body;
    // Fetch the closed trades for the given user wallet ID
    const analysisData = await Trade.find({
      user_wallet_id: userWalletID,
      position: "close",
    });

    const dates = analysisData.map((item) =>
      moment(item.close_date).format("YYYY-MM-DD")
    );

    // Unique days
    const uniqueDates = [...new Set(dates)];
    const numberOfDays = uniqueDates.length;

    // Total trades taken
    const totalTradesTaken = analysisData.length;

    // Average trades per day
    const averageTradesPerDay =
      totalTradesTaken > 0 ? Math.round(totalTradesTaken / numberOfDays) : 0;

    // Total lots used
    const totalLotsUsed = analysisData.reduce(
      (acc, trade) => acc + trade.lots,
      0
    );

    // Average lots used per trade
    const averageLotsUsed =
      totalTradesTaken > 0 ? totalLotsUsed / totalTradesTaken : 0;

    // Biggest win
    const biggestWin = Math.max(...analysisData.map((trade) => trade.profit));

    // Biggest loss (considering loss as positive)
    const biggestLoss = Math.max(...analysisData.map((trade) => trade.loss));

    // Group trades by date
    const groupedData = analysisData.reduce((acc, trade) => {
      const date = moment(trade.close_date).format("YYYY-MM-DD");
      if (!acc[date]) acc[date] = [];
      acc[date].push(trade);
      return acc;
    }, {});

    // Initialize counters for positive and negative days
    let positiveDaysCount = 0;
    let negativeDaysCount = 0;

    // Process each grouped day
    for (const date in groupedData) {
      let totalProfit = 0;
      let totalLoss = 0;

      // Calculate total profit and loss for each day
      groupedData[date].forEach((trade) => {
        if (trade.profit) totalProfit += parseFloat(trade.profit);
        if (trade.loss) totalLoss += parseFloat(trade.loss);
      });

      // Calculate net result
      const netResult = totalProfit - totalLoss;

      // Count positive or negative day
      if (netResult < 0) {
        negativeDaysCount++;
      } else {
        positiveDaysCount++;
      }
    }

    // Prepare the response data
    const data = {
      numberOfDays,
      totalTradesTaken,
      averageTradesPerDay,
      totalLotsUsed,
      averageLotsUsed,
      biggestWin,
      biggestLoss,
      positiveDays: positiveDaysCount,
      negativeDays: negativeDaysCount,
    };

    // Send the response using responseHelper
    return responseHelper.sendResponse(
      res,
      "Trade History fetched successfully.",
      data
    );
  } catch (error) {
    console.error(error);
    // Send server error using responseHelper
    return responseHelper.sendServerError(res, "Server Error", error.message);
  }
};

exports.updatePosition = async (req, res) => {
  try {
    // Define validation schema
    const schema = Joi.object({
      user_id: Joi.string().required(),
      user_wallet_id: Joi.string().required(),
      lots: Joi.number().required(),
      symbol_id: Joi.string().required(),
      trade_id: Joi.string().required(),
      price: Joi.number().required(),
      tp: Joi.number().allow(null, ""),
      sl: Joi.number().allow(null, ""),
    });

    // Validate request
    const { error, value } = schema.validate(req.body);
    if (error) {
      const errorMessage = error.details.map((err) => err.message).join(" ");
      return sendError(res, "Validation Error.", { error: [errorMessage] });
    }

    const {
      user_id,
      user_wallet_id,
      lots,
      symbol_id,
      trade_id,
      price,
      tp,
      sl,
    } = value;

    // Find user
    const user = await User.findById(user_id);
    if (!user) {
      return sendError(res, "Validation Error.", { error: ["User not found"] });
    }

    // Find user wallet
    const userWallet = await UserWallet.findById(user_wallet_id);
    if (!userWallet) {
      return sendError(res, "Validation Error.", {
        error: ["User wallet not found"],
      });
    }

    // Find trade
    const trade = await Trade.findById(trade_id);
    if (!trade) {
      return sendError(res, "Validation Error.", {
        error: ["Trade not found"],
      });
    }

    // Find symbol
    const symbol = await Symbol.findById(symbol_id);
    if (!symbol) {
      return sendError(res, "Validation Error.", {
        error: ["Symbol not found"],
      });
    }

    // Prepare data for MT5 API call
    const mt5AccountData = {
      loginid: userWallet.account_number,
      positionId: trade.position_id,
      positionById: 0,
      symbol: symbol.name,
      volume: parseFloat(lots),
      price: parseFloat(price),
      type: "2",
      tp: tp || 0,
      sl: sl || 0,
      comment: "Trade",
    };

    // Call MT5 API
    const response = await mt5Service.updatePosition(mt5AccountData);

    if (response && response.request) {
      const { request } = response;

      if (request.result && request.retCode === "MT_RET_OK") {
        const tradeResponse = request.tradeReuest;
        return sendResponse(
          res,
          tradeResponse,
          "Position updated successfully."
        );
      } else {
        return sendError(res, "Validation Error.", {
          error: ["Position not updated successfully."],
        });
      }
    } else {
      return sendError(res, "Validation Error.", {
        error: ["Position not updated successfully."],
      });
    }
  } catch (error) {
    logger.error("update_position", error);
    return sendServerError(res, "Server Error.", error.message);
  }
};
// Dashboard Details api calling...........//

exports.getDashboardDetails = async (req, res) => {
  try {
    const { userWalletID } = req.body;

    const challengeInfo = await UserWallet.findById(userWalletID).populate([
      "accountType",
      "accountSize",
    ]);

    const dataFromTrade = await Trade.find({
      user_wallet_id: userWalletID,
      position: "close",
    }).select("profit loss");

    const sumProfit =
      dataFromTrade.length > 0
        ? dataFromTrade.reduce(
          (acc, trade) => acc + parseFloat(trade.profit),
          0
        ) / dataFromTrade.length
        : 0;

    const sumLoss =
      dataFromTrade.length > 0
        ? dataFromTrade.reduce(
          (acc, trade) => acc + parseFloat(trade.loss),
          0
        ) / dataFromTrade.length
        : 0;

    const totalBalance = challengeInfo.balance;

    const forLossPercentage = await Trade.find({
      user_wallet_id: userWalletID,
      loss: { $ne: 0 },
      position: "close",
    });

    const totalLoss =
      forLossPercentage.length > 0
        ? forLossPercentage.reduce(
          (acc, trade) => acc + parseFloat(trade.loss),
          0
        )
        : 0;

    const allProfit =
      challengeInfo.balance > challengeInfo.accountSize.limit
        ? challengeInfo.balance - challengeInfo.accountSize.limit
        : 0;

    const dataForWinRatioCount = await Trade.find({
      user_wallet_id: userWalletID,
      position: "close",
      profit: { $gt: 0 },
    });

    const winRatio =
      dataFromTrade.length > 0
        ? (dataForWinRatioCount.length / dataFromTrade.length) * 100
        : 0;

    const data = {
      winAverage: sumProfit,
      account_number: challengeInfo.account_number,
      balance: challengeInfo.balance,
      lossAverage: sumLoss,
      totalProfit: allProfit,
      totalLoss: totalLoss,
      winRatio: winRatio,
    };

    return responseHelper.sendResponse(
      res,
      "Dashboard details fetched successfully.",
      data
    );
  } catch (error) {
    console.error("Error fetching dashboard details:", error);
    return responseHelper.sendServerError(res, "Server error.", error.message);
  }
};

exports.getTradeDashboardDetails = async (req, res) => {
  try {
    const userWalletID = req.body.userWalletID;

    // Fetch challenge info and populate account details
    const challengeInfo = await UserWallet.findById(userWalletID)
      .populate("account_type_id")
      .populate("account_size_id");

    if (
      !challengeInfo.account_size_id ||
      !challengeInfo.account_size_id.max_daily_loss
    ) {
      return res.status(400).json({
        success: 0,
        message: "Account size data is incomplete.",
      });
    }

    // Fetch start and end trade periods
    const startTradePeriod = await Trade.find({ user_wallet_id: userWalletID })
      .sort({ created_at: 1 })
      .limit(1);
    const endTradePeriod = await Trade.find({ user_wallet_id: userWalletID })
      .sort({ created_at: -1 })
      .limit(1);

    // Fetch profit and loss data
    const trades = await Trade.find({
      user_wallet_id: userWalletID,
      position: "close",
    }).select("profit loss");
    // const sumProfit = trades.reduce(
    //   (acc, trade) => acc + parseFloat(trade.profit || 0),
    //   0
    // );
    // const sumProfit = trades.reduce((sum, trade) => sum + parseFloat(trade.profit || 0), 0);
    // console.log("Total Profit:", sumProfit);
    // const sumLoss = trades.reduce(
    //   (acc, trade) => acc + parseFloat(trade.loss || 0),
    //   0
    // );
    const countTrades = trades.length;

    const sumProfit =
      countTrades > 0
        ? trades.reduce(
          (sum, trade) => sum + parseFloat(trade.profit || 0),
          0
        ) / countTrades
        : 0;

    const sumLoss =
      countTrades > 0
        ? trades.reduce((sum, trade) => sum + parseFloat(trade.loss || 0), 0) /
        countTrades
        : 0;

    const winTrades = trades.filter((trade) => parseFloat(trade.profit) > 0);
    const lossTrades = trades.filter((trade) => parseFloat(trade.loss) > 0);

    const winAverage = sumProfit / (winTrades.length || 1);
    const lossAverage = sumLoss / (trades.length || 1);
    const winRatio = (winTrades.length / (trades.length || 1)) * 100;

    const equity = challengeInfo.equity || 0;
    const dailyMaxLossLimit =
      (parseFloat(challengeInfo.account_size_id.max_daily_loss) / 100) * equity;
    const maxOverallLossLimit =
      (parseFloat(challengeInfo.account_size_id.max_overall_loss) / 100) *
      equity;
    const profitTarget =
      (parseFloat(challengeInfo.account_size_id.profit_target) / 100) *
      (challengeInfo.account_size_id.limit || 0);

    const makeOverAllLossPercentage =
      (sumLoss / (maxOverallLossLimit || 1)) * 100;
    const makeDailyLossPercentage = 0; // Placeholder; calculate daily loss based on your data
    const makeOverAllProfitPercentage =
      (sumProfit / (sumProfit + sumLoss || 1)) * 100;

    const maxTradingDays =
      parseInt(challengeInfo.account_size_id.min_trade_days, 10) || 0;
    const countMaxTradingDaysLeft = Math.max(
      0,
      maxTradingDays - (startTradePeriod.length > 0 ? 1 : 0)
    );
    const countMaxTradingDaysLeftPercentage =
      (countMaxTradingDaysLeft / maxTradingDays) * 100;

    const response = {
      success: 0,
      data: {
        challengeInfo,
        account_typeqqq: challengeInfo.account_type,
        startPeriodDate: startTradePeriod[0] || null,
        endPeriodDate: endTradePeriod[0] || null,
        winAverage,
        lossAverage,
        totalProfit: sumProfit,
        totalLoss: sumLoss,
        winRatio,
        dailyMaxLossLimit,
        maxOverallLossLimit,
        profitTarget,
        dailyMaxThreadShold: equity - dailyMaxLossLimit,
        maxOverallLossThreadShold: equity - maxOverallLossLimit,
        makeOverAllLossPercentage,
        makeDailyLossPercentage,
        makeOverAllProfitPercentage,
        maxTradingDays,
        countMaxTradingDaysLeft,
        countMaxTradingDaysLeftPercentage,
        minBalance: challengeInfo.account_size_id.min_balance || null,
        maxBalance: challengeInfo.account_size_id.max_balance || null,
        minEquity: challengeInfo.account_size_id.min_equity || null,
        maxEquity: challengeInfo.account_size_id.max_equity || null,
        checkRealAccountIsCreated: challengeInfo.checkRealAccountIsCreated || 0,
        checkRealAccountIsRejected:
          challengeInfo.checkRealAccountIsRejected || 0,
        checkRealAccountIsApproved:
          challengeInfo.checkRealAccountIsApproved || 0,
        remainDailyLoss: dailyMaxLossLimit - sumLoss,
        remainMaxLoss: maxOverallLossLimit - sumLoss,
        remainMaxProfit: profitTarget - sumProfit,
        showCertificate: challengeInfo.showCertificate || 0,
      },
      message: "Trade History get successfully.",
    };

    res.status(200).json(response);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: 1,
      message: "Server error",
      error: error.message,
    });
  }
};

// exports.getTradeDashboardDetails = async (req, res) => {
//   try {
//     const userWalletID = req.body.userWalletID;
//     const userId = req.body.user_id;

//     // Fetch challenge info and populate account details
//     const challengeInfo = await UserWallet.findById(userWalletID)
//       .populate("account_type_id", "type name")
//       .populate("account_size_id");

//     if (!challengeInfo.account_size_id || !challengeInfo.account_size_id.max_daily_loss) {
//       return res.status(400).json({
//         success: 0,
//         message: "Account size data is incomplete.",
//       });
//     }
//     // Fetch the start and end trade period
//     const startTradePeriod = await Trade.find({ user_wallet_id: userWalletID })
//       .sort({ created_at: 1 })
//       .limit(1);
//     const endTradePeriod = await Trade.find({ user_wallet_id: userWalletID })
//       .sort({ created_at: -1 })
//       .limit(1);

//     // Fetch profit and loss data
//     const dataFromTrade = await Trade.find({
//       user_wallet_id: userWalletID,
//       position: "close",
//     }).select("profit loss");

//     // Calculate sum of profit and loss
//     const sumProfit = dataFromTrade.reduce(
//       (acc, trade) => acc + parseFloat(trade.profit),
//       0
//     );
//     const sumLoss = dataFromTrade.reduce(
//       (acc, trade) => acc + parseFloat(trade.loss),
//       0
//     );
//     // Get total balance
//     const totalBalance = challengeInfo.balance;

//     // Calculate daily loss limits and thresholds
//     const dailyLossPercent =
//       parseFloat(challengeInfo.account_size_id.max_daily_loss) / 100;
//     const dailyMaxLossLimit = challengeInfo.equity * dailyLossPercent;
//     const dailyMaxThreshold = challengeInfo.equity - dailyMaxLossLimit;

//     // Calculate max overall loss limits
//     const maxLossPercent =
//       parseFloat(challengeInfo.account_size_id.max_overall_loss) / 100;
//     const maxOverallLossLimit = challengeInfo.equity * maxLossPercent;
//     const maxOverallLossThreshold = challengeInfo.equity - maxOverallLossLimit;

//     // Calculate profit target
//     const maxProfitPercent =
//       challengeInfo.parent_user_wallet_id &&
//         challengeInfo.parent_user_wallet_id !== ""
//         ? parseFloat(challengeInfo.account_size_id.profit_target_phase2) / 100
//         : parseFloat(challengeInfo.account_size_id.profit_target) / 100;
//     const profitTarget = challengeInfo.account_size_id.limit * maxProfitPercent;
//     // Get max trading days
//     const maxTradingDays = parseInt(
//       challengeInfo.account_size_id.min_trade_days
//     );

//     // Calculate overall loss percentage
//     const forLossPercentage = await Trade.find({
//       user_wallet_id: userWalletID,
//       loss: { $ne: 0 },
//       position: "close",
//     });
//     const totalLoss = forLossPercentage.reduce(
//       (acc, trade) => acc + trade.loss,
//       0
//     );
//     const makeOverallLossPercentage =
//       maxOverallLossLimit < totalLoss
//         ? 100
//         : (totalLoss / maxOverallLossLimit) * 100;

//     // Calculate daily loss percentage
//     const forDailyLossPercentage = await Trade.find({
//       user_wallet_id: userWalletID,
//       loss: { $ne: 0 },
//       position: "close",
//       close_date: moment().format("YYYY-MM-DD"),
//     });

//     const totalLossToday = forDailyLossPercentage.reduce(
//       (acc, trade) => acc + trade.loss,
//       0
//     );
//     const makeDailyLossPercentage =
//       dailyMaxLossLimit < totalLossToday
//         ? 100
//         : (totalLossToday / dailyMaxLossLimit) * 100;

//     // Prepare the response
//     res.status(200).json({
//       success: 0,
//       message: "Trade History get successfully.",
//       data: {

//         challengeInfo: challengeInfo,
//         startPeriodDate: startTradePeriod[0]?.created_at,
//         endPeriodDate: endTradePeriod[0]?.created_at,
//         winAverage:
//           sumProfit /
//           dataFromTrade.filter((trade) => parseFloat(trade.profit) > 0).length,
//         lossAverage: sumLoss / dataFromTrade.length,
//         totalProfit: sumProfit,
//         totalLoss: sumLoss,
//         winRatio:
//           (dataFromTrade.filter((trade) => parseFloat(trade.profit) > 0)
//             .length /
//             dataFromTrade.length) *
//           100,
//         dailyMaxLossLimit: dailyMaxLossLimit,
//         maxOverallLossLimit: maxOverallLossLimit,
//         profitTarget: profitTarget,
//         dailyMaxThreadShold: dailyMaxThreshold,
//         maxOverallLossThreadShold: maxOverallLossThreshold,
//         makeOverAllLossPercentage: makeOverallLossPercentage,
//         makeDailyLossPercentage: makeDailyLossPercentage,
//         makeOverAllProfitPercentage: (sumProfit / (sumProfit + sumLoss)) * 100,
//         maxTradingDays: maxTradingDays,
//         countMaxTradingDaysLeft:
//           maxTradingDays - (startTradePeriod.length > 0 ? 1 : 0),
//         countMaxTradingDaysLeftPercentage:
//           ((maxTradingDays - (startTradePeriod.length > 0 ? 1 : 0)) /
//             maxTradingDays) *
//           100,
//         minBalance: challengeInfo.account_size_id.min_balance,
//         maxBalance: challengeInfo.account_size_id.max_balance,
//         minEquity: challengeInfo.account_size_id.min_equity,
//         maxEquity: challengeInfo.account_size_id.max_equity,
//         checkRealAccountIsCreated: challengeInfo.checkRealAccountIsCreated,
//         checkRealAccountIsApproved: challengeInfo.checkRealAccountIsApproved,
//         checkRealAccountIsRejected: challengeInfo.checkRealAccountIsRejected,
//         remainDailyLoss: dailyMaxLossLimit - totalLossToday,
//         remainMaxLoss: maxOverallLossLimit - totalLoss,
//         remainMaxProfit: profitTarget - sumProfit,
//         showCertificate: challengeInfo.showCertificate,
//         // delete challengeInfo.account_size_id;
//       },
//     });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({
//       success: 1,
//       message: "Server error",
//       error: error.message,
//     });
//   }
// };

exports.getTradePerformanceMeter = async (req, res) => {
  try {
    const accountNumber = req.body.account_number;

    const userWallet = await UserWallet.findOne({
      account_number: accountNumber,
    })
      .populate("account_size_id")
      .exec();

    if (!userWallet) {
      return sendError(
        res,
        "User Wallet not found",
        "Invalid account_number provided."
      );
    }

    const accountSize = userWallet.account_size_id;
    if (!accountSize) {
      return sendError(
        res,
        "Account Size not available",
        "Account size information is missing."
      );
    }

    const totalLotSize = await getTotalLotSize(userWallet._id);

    const riskLevels = getRiskLevelsForAccountSize(accountSize.limit);

    const riskType = determineRiskType(
      accountSize.limit,
      totalLotSize,
      riskLevels
    );

    const multiplier = getMultiplierForAccountSize(accountSize.limit);

    const performancePercentage = calculatePerformancePercentage(
      accountSize.limit,
      totalLotSize,
      multiplier,
      riskType
    );
    const riskPercentage = calculateRiskPercentage(
      accountSize.limit,
      totalLotSize,
      riskType
    );

    const data = {
      accountSize: accountSize.limit,
      riskType: riskType,
      multiplier: multiplier,
      performancePercentage: performancePercentage,
      riskPercentage: riskPercentage,
      totalLotSize: totalLotSize,
    };

    return sendResponse(
      res,
      "Trade Performance Meter Data retrieved successfully",
      data
    );
  } catch (err) {
    console.error("Error fetching trade performance data:", err);
    return sendServerError(res, "Server Error", err.message);
  }
};

function getRiskLevelsForAccountSize(accountSize) {
  if (accountSize >= 200000) {
    return {
      low: [0.01, 4.0],
      medium: [4.0, 20.0],
      high: [20.0, 200.0],
    };
  } else if (accountSize >= 100000) {
    return {
      low: [0.01, 2.0],
      medium: [2.0, 10.0],
      high: [10.0, 100.0],
    };
  } else if (accountSize >= 50000) {
    return {
      low: [0.01, 0.5],
      medium: [0.5, 2.0],
      high: [2.0, 20.0],
    };
  } else if (accountSize >= 25000) {
    return {
      low: [0.01, 0.25],
      medium: [0.25, 1.0],
      high: [1.0, 10.0],
    };
  } else if (accountSize >= 15000) {
    return {
      low: [0.01, 0.15],
      medium: [0.15, 0.6],
      high: [0.6, 6.0],
    };
  } else {
    return {
      low: [0.01, 0.05],
      medium: [0.05, 0.2],
      high: [0.2, 2.0],
    };
  }
}

function determineRiskType(accountSize, totalLotSize, riskLevels) {
  if (totalLotSize >= riskLevels.high[0]) {
    return "high";
  } else if (totalLotSize >= riskLevels.medium[0]) {
    return "medium";
  } else {
    return "low";
  }
}

// function calculateRiskPercentage(accountSize, totalLotSize, riskType) {
//   const riskLevels = getRiskLevelsForAccountSize(accountSize);
//   const riskRange = riskLevels[riskType];

//   if (totalLotSize === 0) {
//     return 0;
//   }

//   const percentageRanges = {
//     low: [0, 33.33],
//     medium: [34.33, 66.66],
//     high: [67.66, 99.99],
//   };

//   if (totalLotSize <= riskRange[0]) {
//     return percentageRanges[riskType][0];
//   } else if (totalLotSize >= riskRange[1]) {
//     return percentageRanges[riskType][1];
//   } else {
//     const proportionalRisk = ((totalLotSize - riskRange[0]) / (riskRange[1] - riskRange[0])) * 100;
//     const minPercentage = percentageRanges[riskType][0];
//     const maxPercentage = percentageRanges[riskType][1];
//     const scaledRiskPercentage = minPercentage + (proportionalRisk / 100) * (maxPercentage - minPercentage);
//     return Math.min(100, scaledRiskPercentage);
//   }
// }

// Calculate risk percentage for a specific risk level
function calculateRiskPercentage(accountSize, totalLotSize, riskLevel) {
  const riskLevels = getRiskLevelsForAccountSize(accountSize);
  const riskRange = riskLevels[riskLevel];

  if (totalLotSize === 0) {
    return 0;
  }

  const percentageRanges = {
    low: [0, 33.33],
    medium: [34.33, 66.66],
    high: [67.66, 99.99],
  };

  if (totalLotSize <= riskRange[0]) {
    return percentageRanges[riskLevel][0];
  } else if (totalLotSize >= riskRange[1]) {
    return percentageRanges[riskLevel][1];
  } else {
    const proportionalRisk =
      ((totalLotSize - riskRange[0]) / (riskRange[1] - riskRange[0])) * 100;
    const minPercentage = percentageRanges[riskLevel][0];
    const maxPercentage = percentageRanges[riskLevel][1];
    const scaledRiskPercentage =
      minPercentage +
      (proportionalRisk / 100) * (maxPercentage - minPercentage);
    return Math.min(100, scaledRiskPercentage);
  }
}

function getMultiplierForAccountSize(accountSize) {
  if (accountSize >= 200000) {
    return 40;
  } else if (accountSize >= 100000) {
    return 20;
  } else if (accountSize >= 50000) {
    return 10;
  } else if (accountSize >= 25000) {
    return 5;
  } else if (accountSize >= 15000) {
    return 3;
  } else {
    return 1;
  }
}
async function getTotalLotSize(userWalletId) {
  const trades = await Trade.find({ user_wallet_id: userWalletId }).exec();

  if (!trades || trades.length === 0) {
    console.warn(`No trades found for user_wallet_id: ${userWalletId}`);
    return 0;
  }

  return trades.reduce((total, trade) => total + (trade.lots || 0), 0);
}

function calculatePerformancePercentage(
  accountSize,
  totalLotSize,
  multiplier,
  riskType
) {
  // Use the same logic as riskPercentage
  const riskLevels = getRiskLevelsForAccountSize(accountSize);
  const riskRange = riskLevels[riskType];
  const percentageRanges = {
    low: [0, 33.33],
    medium: [34.33, 66.66],
    high: [67.66, 99.99],
  };

  if (totalLotSize === 0) return 0;

  if (totalLotSize <= riskRange[0]) {
    return percentageRanges[riskType][0];
  } else if (totalLotSize >= riskRange[1]) {
    return percentageRanges[riskType][1];
  } else {
    const proportionalValue =
      ((totalLotSize - riskRange[0]) / (riskRange[1] - riskRange[0])) * 100;
    const minPercentage = percentageRanges[riskType][0];
    const maxPercentage = percentageRanges[riskType][1];
    return (
      minPercentage +
      (proportionalValue / 100) * (maxPercentage - minPercentage)
    );
  }
}
