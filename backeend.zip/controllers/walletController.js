const User = require("../models/User");
const UserWallet = require("../models/UserWallet");
const { validationResult } = require("express-validator");
const responseHelper = require("../utils/responseHelper");

//get User Wallet  apic calling...//
exports.getUserWallet = async (req, res) => {
  try {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    // Extract parameters from the request
    const { user_id, wallet_id } = req.body;

    // Find the user by ID
    const user = await User.findById(user_id);
    if (!user) {
      return responseHelper.sendError(res, "User profile not found!", null);
    }

    let userWallet;

    // Fetch the wallet based on wallet_id or fallback to default conditions
    if (wallet_id) {
      userWallet = await UserWallet.findOne({
        _id: wallet_id,
        user_id: user._id,
        status: "active",
        enabled: true,
      });
    } else {
      userWallet = await UserWallet.findOne({
        user_id: user._id,
        code: "USD",
        status: "active",
        enabled: true,
        account: { $ne: "mt5" },
      });
    }

    // Return the wallet or null if not found
    return responseHelper.sendResponse(
      res,
      "Wallet fetched successfully.",
      userWallet
    );
  } catch (error) {
    console.error("Error fetching user wallet:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

// User Wallets api calling ....//

exports.getUserWallets = async (req, res) => {
  try {
    // Validate user input
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    // Extract query parameters
    const userId = req.body.user_id;
    const type = req.body.type || "";
    const search = req.body.search || "";
    const hideZero = req.body.hide_zero || "";
    const sortField = req.body.sort || "sequence";
    const sortDirection = req.body.sort_order === "desc" ? "desc" : "asc";

    // Find the user and their wallets
    const user = await User.findById(userId)
      .populate({
        path: "wallets",
        match: {
          ...(type === "favourite" ? { favourite: true } : {}),
          ...(type === "fiat" ? { fiat: true } : {}),
          ...(hideZero === "1" ? { balance: { $gt: 0 } } : {}),
        },
        populate: {
          path: "wallet",
          match: {
            ...(search
              ? {

                $or: [
                  { name: { $regex: search, $options: "i" } },
                  { code: { $regex: search, $options: "i" } },
                  { id: { $regex: search, $options: "i" } },
                ],
              }

              : {}),
          },
        },
        options: {
          sort: { [sortField]: sortDirection },
        },
      })
      .exec();

    // Check if user exists
    if (!user) {
      return responseHelper.sendError(res, "User profile not found!", null);
    }

    // Extract wallets
    const wallets = user.wallets;

    // Return response
    return responseHelper.sendResponse(
      res,
      "Wallets fetched successfully.",
      wallets
    );
  } catch (error) {
    console.error("Error fetching wallets:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

// User Wallets GroupWise api calling ...............//

exports.getUserWalletsGroupWise = async (req, res) => {
  try {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    // Extract request parameters
    const userId = req.body.user_id;
    const type = req.body.type || "";
    const search = req.body.search || "";
    const hideZero = req.body.hide_zero || "";
    const sortField = req.body.sort || "sequence"; // Default sort field
    const sortDirection = req.body.sort_order === "desc" ? "desc" : "asc"; // Default sort direction

    // Fetch user and their wallets
    const user = await User.findById(userId)
      .populate({
        path: "wallets", // Assuming 'wallets' is a field in the User schema
        match: {
          ...(type === "favourite" ? { favourite: true } : {}),
          ...(type === "fiat" ? { fiat: true } : {}),
          ...(hideZero === "1" ? { balance: { $gt: 0 } } : {}),
        },
        populate: {
          path: "wallet", // Assuming 'wallet' is a reference field in wallets
          match: {
            ...(search
              ? {
                $or: [
                  { name: { $regex: search, $options: "i" } },
                  { code: { $regex: search, $options: "i" } },
                  { id: { $regex: search, $options: "i" } },
                ],
              }
              : {}),
          },
        },
        options: {
          sort: { [sortField]: sortDirection },
        },
      })
      .exec();

    // Check if user exists
    if (!user) {
      return responseHelper.sendError(res, "User profile not found!", null);
    }

    // Group wallets into labeled format
    const wallets = user.wallets;
    const data = [
      {
        label: "Wallet",
        items: wallets,
      },
    ];

    // Return response
    return responseHelper.sendResponse(
      res,
      "Wallets fetched successfully.",
      data
    );
  } catch (error) {
    console.error("Error fetching grouped wallets:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

// User Total WalletBalance api calling ..............//

exports.getUserTotalWalletBalance = async (req, res) => {
  try {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    // Extract user ID
    const userId = req.body.user_id;

    // Initialize response data
    const data = {
      total_balance: "0.00",
      currency: "USD",
    };

    // Fetch user by ID
    const user = await User.findById(userId);
    if (!user) {
      return responseHelper.sendError(res, "User profile not found!", null);
    }

    // Fetch all wallets for the user
    const wallets = await UserWallet.find({ user_id: userId });

    // Calculate the total balance if wallets are found
    if (wallets && wallets.length > 0) {
      const totalBalance = wallets.reduce(
        (sum, wallet) => sum + wallet.balance,
        0
      );
      data.total_balance = totalBalance.toFixed(2); // Format balance to 2 decimal places
    }

    // Return success response
    return responseHelper.sendResponse(
      res,
      "Wallet total fetched successfully.",
      data
    );
  } catch (error) {
    console.error("Error fetching total wallet balance:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

//Make WalletFavourite api calling................//

exports.makeWalletFavourite = async (req, res) => {
  try {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    // Extract request parameters
    const { user_id, wallet_id } = req.body;

    // Fetch user by ID
    const user = await User.findById(user_id);
    if (!user) {
      return responseHelper.sendError(res, "User profile not found!", null);
    }

    // Find the wallet for the user
    const wallet = await UserWallet.findOne({
      _id: wallet_id,
      user_id: user_id,
    });
    if (!wallet) {
      return responseHelper.sendError(
        res,
        "User wallet account not found!",
        null
      );
    }

    // Toggle favourite status
    wallet.favourite = !wallet.favourite;
    await wallet.save();

    // Prepare response data
    const data = { favourite: wallet.favourite };

    // Send success response
    return responseHelper.sendResponse(
      res,
      "Favourite status updated successfully.",
      data
    );
  } catch (error) {
    console.error("Error toggling favourite status:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

//User WalletDetails api calling...........//

exports.getUserWalletDetails = async (req, res) => {
  try {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    // Extract request parameters
    const { user_id, wallet_id } = req.body;

    // Fetch user by ID
    const user = await User.findById(user_id);
    if (!user) {
      return responseHelper.sendError(res, "User profile not found!", null);
    }

    // Fetch wallet details along with related transactions
    const wallet = await UserWallet.findById(wallet_id)
      .populate([
        {
          path: "transactions",
          populate: [{ path: "currency" }, { path: "paymentMethod" }],
          options: {
            sort: { created_at: -1 }, // Sort transactions by creation date in descending order
            limit: 3, // Limit to the last 3 transactions
          },
        },
        { path: "wallet" },
      ])
      .exec();

    if (!wallet) {
      return responseHelper.sendError(
        res,
        "User wallet account not found!",
        null
      );
    }

    // Send success response with wallet details
    return responseHelper.sendResponse(
      res,
      "Wallet details fetched successfully.",
      wallet
    );
  } catch (error) {
    console.error("Error fetching wallet details:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};

//User All Wallets api calling........//

exports.getUserAllWallets = async (req, res) => {
  try {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map((error) => error.msg);
      return responseHelper.sendError(res, "Validation Error.", errorMessages);
    }

    // Extract request parameters
    const {
      user_id,
      type,
      search,
      hide_zero,
      sort,
      sort_order,
      mt5_type,
      archived,
    } = req.body;

    // Determine sort field and direction
    let sortField = "account_number";
    if (sort && sort === "Name") {
      sortField = "code";
    } else if (sort && sort !== "Default") {
      sortField = sort.toLowerCase();
    }

    const sortDirection = sort_order === "desc" ? "desc" : "asc";

    // Fetch user and their wallets
    const user = await User.findById(user_id).populate({
      path: "wallets",
      match: {
        account: { $in: ["mt5", "wallet"] },
        ...(mt5_type
          ? mt5_type === "archived"
            ? { archived: true }
            : { mt5_type, archived: false }
          : {}),
        ...(archived !== undefined ? { archived } : {}),
        ...(type === "favourite" ? { favourite: true } : {}),
        ...(type === "fiat" ? { fiat: true } : {}),
        ...(hide_zero === "1" ? { balance: { $gt: 0 } } : {}),
      },
      populate: [
        { path: "currency" },
        { path: "product" },
        { path: "leverage" },
        { path: "accountType" },
        { path: "StartAmount" },
      ],
      options: {
        sort: { [sortField]: sortDirection },
      },
    });

    // Apply additional filters if needed
    if (user && search) {
      user.wallets = user.wallets.filter(
        (wallet) =>
          wallet.wallet &&
          (wallet.wallet.name.toLowerCase().includes(search.toLowerCase()) ||
            wallet.wallet.code.toLowerCase().includes(search.toLowerCase()) ||
            wallet.wallet.id.toLowerCase().includes(search.toLowerCase()))
      );
    }

    if (!user) {
      return responseHelper.sendError(res, "User profile not found!", null);
    }

    // Return user's wallets
    const wallets = user.wallets;
    return responseHelper.sendResponse(
      res,
      "MT5 accounts fetched successfully.",
      wallets
    );
  } catch (error) {
    console.error("Error fetching all wallets:", error.message);

    // Handle server error
    return responseHelper.sendServerError(res, "Server Error.", error.message);
  }
};
