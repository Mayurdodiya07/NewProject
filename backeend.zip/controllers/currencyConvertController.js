const ExchangeRate = require('../models/ExchangeRate');

exports.convertCurrency = async (req, res) => {
  try {
    // Fetch the exchange rate from USD to INR
    const convertCurrencyData = await ExchangeRate.findOne({
      from_currency: 'USD',
      to_currency: 'INR'
    });

    // If the exchange rate is found, use it, otherwise default to 83.76
    const inr = convertCurrencyData ? convertCurrencyData.to_currency_rate.toFixed(2) : 83.76;

    // Get the amount to be converted from the request
    const dollarAmount = parseFloat(req.body.amount);

    // Perform the conversion
    const convertedAmount = dollarAmount * inr;

    // Return the response with the converted amount
    return res.json({
      success: 0,
      message: 'Currency converted successfully.',
      data: convertedAmount
    });
  } catch (error) {
    // Handle any errors
    return res.status(500).json({
      success: 1,
      message: 'Server Error.',
      error: error.message
    });
  }
};
