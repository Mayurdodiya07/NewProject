// const multer = require("multer");
// const path = require("path");

// // Configure Multer Storage
// const storage = multer.diskStorage({
//     destination: (req, file, cb) => {
//         cb(null, "uploads/photos/account_requests"); // ✅ Ensure this folder exists
//     },
//     filename: (req, file, cb) => {
//         cb(null, Date.now() + path.extname(file.originalname));
//     },
// });

// // File Filter to Accept Images Only
// const fileFilter = (req, file, cb) => {
//     const allowedTypes = ["image/jpeg", "image/png", "image/gif"];
//     if (!allowedTypes.includes(file.mimetype)) {
//         return cb(new Error("Invalid file type. Only JPEG, PNG, and GIF are allowed."), false);
//     }
//     cb(null, true);
// };

// // Multer Upload Middleware
// const upload = multer({
//     storage: storage,
//     limits: { fileSize: 10 * 1024 * 1024 }, // ✅ Limit to 10MB
//     fileFilter: fileFilter,
// });

// module.exports = upload;
