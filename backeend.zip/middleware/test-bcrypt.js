// const bcrypt = require("bcrypt");

// // Change this to the password you're testing
// const enteredPassword = "123456";

// // Paste one of your stored hashed passwords from MongoDB here
// const storedHashedPassword = "$2a$10$M7lveNA5iRUsnx/xBj9NfO/3hPpV9L7lhKipOHUIaVdCTDD9J81wK";

// bcrypt.compare(enteredPassword, storedHashedPassword)
//     .then((isMatch) => {
//         console.log("Password Match Result:", isMatch);
//     })
//     .catch(err => console.error("Error:", err));
