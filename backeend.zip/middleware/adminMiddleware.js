
// const jwt = require('jsonwebtoken');
// const Admin = require('../models/Admin');
// const mongoose = require('mongoose');

// exports.Adminauthenticate = async (req, res, next) => {
//     try {
//         const token = req.headers['authorization']?.split(' ')[1];

//         if (!token) {
//             return res.status(401).json({ success: 0, message: 'Unauthorized: No token provided' });
//         }

//         // Decode the token
//         const decoded = jwt.verify(token, process.env.JWT_SECRET);

//         // Check if the admin exists
//         const admin = await Admin.findById(decoded.id).select("+password");

//         if (!admin) {
//             return res.status(401).json({ success: 0, message: 'Unauthorized: Admin not found' });
//         }

//         req.admin = admin;
//         // req.user = admin;
//         next();
//     } catch (error) {
//         // Handle different types of errors (e.g., token expired, JWT errors)
//         if (error instanceof jwt.TokenExpiredError) {
//             return res.status(401).json({ success: 0, message: 'Token expired, please login again' });
//         } else if (error instanceof jwt.JsonWebTokenError) {
//             return res.status(401).json({ success: 0, message: 'Invalid token' });
//         }

//         return res.status(500).json({ success: 0, message: 'Server error during authentication', error: error.message });
//     }
// };
// hello md //
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const mongoose = require('mongoose');



exports.Adminauthenticate = async (req, res, next) => {
    try {
        const token = req.headers['authorization']?.split(' ')[1];
        if (!token) {
            return res.status(401).json({ message: "Unauthorized: No token provided" });
        }


        // Decode the token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Check if the admin exists
        const admin = await Admin.findById(decoded.id).select("+password");

        if (!admin) {
            return res.status(401).json({ success: 0, message: 'Unauthorized: Admin not found' });
        }

        req.admin = admin;
        next();
    } catch (error) {
        if (error instanceof jwt.TokenExpiredError) {
            return res.status(401).json({ success: 0, message: 'Token expired, please login again' });
        } else if (error instanceof jwt.JsonWebTokenError) {
            return res.status(401).json({ success: 0, message: 'Invalid token' });
        }
        return res.status(500).json({ success: 0, message: 'Server error during authentication', error: error.message });
    }
};


