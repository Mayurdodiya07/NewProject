
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const mongoose = require('mongoose');

exports.authenticate = async (req, res, next) => {
  try {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) {
      console.log("No token provided");
      return res.status(401).json({
        success: 1,
        message: "Unauthorized: No token provided",
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = new mongoose.Types.ObjectId(decoded.user_id);

    // Use await or .then() without a callback
    const user = await User.findById(userId);
    if (!user) {
      console.log("User not found");
      return res.status(401).json({
        success: 1,
        message: "Unauthorized: User not found",
      });
    }

    req.user = user; // Attach user object to request
    next();
  } catch (error) {
    console.error("Authentication error:", error);
    return res.status(500).json({
      success: 1,
      message: "Server error during authentication",
      error: error.message,
    });
  }
};