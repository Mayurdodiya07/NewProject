const errorHandler = (err, req, res, next) => {
  // Log error details for debugging
  console.error("Error Stack:", err.stack);
  console.error("Error Message:", err.message);

  // Check if it's a validation error (you can expand this for other error types)
  if (err.name === "ValidationError") {
    return res.status(400).json({
      success: false,
      message: "Validation Error",
      errors: err.errors, // This will send specific validation error details
    });
  }

  // Check for duplicate key error (for example, if a user tries to register with an existing email/phone)
  if (err.code === 11000) {
    return res.status(400).json({
      success: false,
      message: "Duplicate key error", // You can tailor this based on your specific needs
      error: err.keyValue, // This will show the field that caused the duplication
    });
  }

  // General error handling for unexpected errors
  res.status(500).json({
    success: false,
    message: "Internal Server Error",
    error: err.message || "An unknown error occurred",
  });
};

module.exports = errorHandler;
