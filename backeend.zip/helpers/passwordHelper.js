const crypto = require('crypto');

class PasswordHelper {
    /**
     * Generate a random password with given length.
     * @param {number} length - Length of the password
     * @returns {string} - Generated password
     */
    static generateRandomPassword(length = 8) {
        // Define character sets
        const numbers = '0123456789';
        const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
        const symbols = '!@#$%^&*()-_=+{}[]';

        let password = '';
        let chars = '';

        // Add one random number
        password += numbers.charAt(Math.floor(Math.random() * numbers.length));
        chars += numbers;

        // Add one random uppercase letter
        password += uppercaseLetters.charAt(Math.floor(Math.random() * uppercaseLetters.length));
        chars += uppercaseLetters;

        // Add two random lowercase letters
        for (let i = 0; i < 2; i++) {
            password += lowercaseLetters.charAt(Math.floor(Math.random() * lowercaseLetters.length));
            chars += lowercaseLetters;
        }

        // Add one random symbol
        password += symbols.charAt(Math.floor(Math.random() * symbols.length));
        chars += symbols;

        // Fill the rest of the password with random characters
        const remainingLength = length - 5; // 5 because we already added 5 characters above
        for (let i = 0; i < remainingLength; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }

        // Shuffle the password
        // password = this.shuffleString(password);
        password = PasswordHelper.shuffleString(password);


        return password;
    }

    /**
     * Shuffle a string
     * @param {string} str - The string to shuffle
     * @returns {string} - The shuffled string
     */
    static shuffleString(str) {
        const array = str.split('');
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]]; // Swap elements
        }
        return array.join('');
    }
}

module.exports = PasswordHelper;
