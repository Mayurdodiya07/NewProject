const FormatHelper = {
  /**
   * Format a given amount.
   *
   * @param {number} amount - The amount to format.
   * @param {number} decimals - The number of decimal places (default is 2).
   * @returns {string} - The formatted amount.
   */
  formatAmount(amount, decimals = 2) {
    return Number(amount).toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  },

  /**
   * Format a given status by converting it to a readable string.
   *
   * @param {string} status - The status string to format.
   * @returns {string} - The formatted status string.
   */
  formatStatus(status) {
    return status
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  },

  /**
   * Format a given date to 'dd-mm-yyyy' format.
   *
   * @param {string|Date} date - The date to format.
   * @returns {string} - The formatted date.
   */
  formatDate(date) {
    const d = new Date(date);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  },

  /**
   * Format a given date to 'yyyy-mm-dd' format.
   *
   * @param {string|Date} date - The date to format.
   * @returns {string} - The formatted date.
   */
  formatDateYearBefore(date) {
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  },

  /**
   * Format a given date and time to 'dd-mm-yyyy HH:MM' format.
   *
   * @param {string|Date} date - The date and time to format.
   * @returns {string} - The formatted date and time.
   */
  formatDateTime(date) {
    const d = new Date(date);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  },

  // Add more helper methods here if needed
};

module.exports = FormatHelper;
