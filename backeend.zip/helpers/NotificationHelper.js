const Notification = require('../models/Notification'); // Adjust the path to your Notification model

/**
 * Notification Helper Class
 */
class NotificationHelper {
    /**
     * Send a notification to a user.
     * 
     * @param {String} userId - ID of the user receiving the notification.
     * @param {String} notificationType - Type of the notification (e.g., 'passed_account_request').
     * @param {String} actionId - ID related to the notification (optional).
     * @returns {Promise<void>} - Resolves when the notification is successfully created.
     */
    static async sendNotification(userId, notificationType, actionId = '') {
        try {
            await Notification.create({
                user_id: userId,
                notification_type: notificationType,
                action_id: actionId,
                is_read: '0', // Default unread status
            });
        } catch (error) {
            console.error(`Failed to send notification: ${error.message}`);
            throw new Error('Notification creation failed');
        }
    }
}

module.exports = NotificationHelper;