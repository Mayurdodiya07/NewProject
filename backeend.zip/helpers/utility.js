// // Format duration in days, hours, minutes, seconds
// exports.formatDuration = (seconds) => {
//     if (seconds <= 0) return '0d 0h 0m 0s';

//     const days = Math.floor(seconds / 86400);
//     const hours = Math.floor((seconds % 86400) / 3600);
//     const minutes = Math.floor((seconds % 3600) / 60);
//     const secs = seconds % 60;

//     return `${days}d ${hours}h ${minutes}m ${secs}s`;
// };
