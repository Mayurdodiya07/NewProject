// // Group and aggregate trades
// exports.groupAndAggregateSummaryTrades = (trades, skip = 0, limit = null) => {
//     const groupedData = {};

//     trades.forEach(trade => {
//         const userWalletID = trade.user_wallet.id;
//         const profit =
//             trade.user_wallet.accountSize.limit < trade.user_wallet.balance
//                 ? parseFloat(trade.user_wallet.balance) - parseFloat(trade.user_wallet.accountSize.limit)
//                 : 0;

//         if (profit > 0) {
//             groupedData[userWalletID] = groupedData[userWalletID] || {
//                 profit: 0,
//                 id: trade.user_wallet.id,
//                 first_name: trade.user_wallet.user.first_name,
//                 last_name: trade.user_wallet.user.last_name,
//                 account_balance: trade.user_wallet.balance,
//                 account_size: trade.user_wallet.accountSize.limit,
//                 symbol_name: trade.symbol.name,
//                 open_price: trade.open_price,
//                 close_price: trade.close_price,
//                 close_date: trade.close_date,
//                 country: trade.user_wallet.user.country_code,
//                 side: trade.side
//             };

//             groupedData[userWalletID].profit = profit.toFixed(2);
//         }
//     });

//     const result = Object.values(groupedData).sort((a, b) => b.profit - a.profit);

//     // Apply skip and limit
//     const slicedResult = result.slice(skip, limit ? skip + limit : result.length);
//     return slicedResult;
// };

// // Get wallet data with date difference
// exports.getWalletDataWithDateDifference = async () => {
//     const result = await UserWallet.aggregate([
//         { $match: { account: 'mt5' } },
//         {
//             $project: {
//                 id: 1,
//                 diff_in_seconds: {
//                     $divide: [{ $subtract: ['$approved_datetime', '$passed_datetime'] }, 1000]
//                 }
//             }
//         },
//         { $limit: 1 }
//     ]);

//     return result[0] || null;
// };
