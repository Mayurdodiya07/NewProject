const nodemailer = require("nodemailer");
require("dotenv").config();

// const transporter = nodemailer.createTransport({
//   host: process.env.MAIL_HOST,
//   port: process.env.MAIL_PORT,
//   secure: false,
//   tls: {
//     rejectUnauthorized: false,
//   },
//   auth: {
//     user: process.env.mail_username,
//     pass: process.env.MAIL_PASSWORD,
//   },
// });
const transporter = nodemailer.createTransport({
  host: process.env.MAIL_HOST,
  port: parseInt(process.env.MAIL_PORT),
  secure: false,
  auth: {
    user: process.env.MAIL_USERNAME,
    pass: process.env.MAIL_PASSWORD
  },
  tls: {
    rejectUnauthorized: false
  }
});

const sendRealAccountApprovalMail = async (to, message, account_number, masterPassword) => {
  const subject = "Real Account Approval";
  const htmlContent = `
    <p>Dear User,</p>
    <p>${message}</p>
    <p>Your account details:</p>
    <ul>
      <li><strong>Account Number:</strong> ${account_number}</li>
      <li><strong>Master Password:</strong> ${masterPassword}</li>
    </ul>
    <p>Best Regards,<br>Funded Firm Team</p>
  `;

  return await sendEmail(to, subject, htmlContent);
};



// Helper function to send an email
const sendEmail = async (to, subject, htmlContent) => {
  try {
    const mailOptions = {
      from: `"FundedFirm" <${process.env.mail_from_address}>`,
      to,
      subject,
      html: htmlContent,
    };

    // Send email
    await transporter.sendMail(mailOptions);
    console.log(`Email sent to ${to} with subject: ${subject}`);
    return true;
  } catch (error) {
    console.error("Error sending email:", error);
    return false;
  }
};

// Send verification email
const sendVerificationEmail = async (to, verificationLink) => {
  const subject = "Verify your email address";
  const htmlContent = `
    <div style="max-width:600px;margin:auto;border:4px solid #913515;border-radius:16px;overflow:hidden;">
          <div style="padding:20px;text-align:center;">
            <img src="https://yourlogo.com/logo.png" alt="App Logo" style="width:260px;margin:10px auto;">
            <h2>Email Verification</h2>
            <p>Welcome! Please confirm your email by clicking the button below:</p>
            <a href="${verificationLink}" style="color: white; background-color: #f6a500; text-decoration: none; padding: 10px 20px; border-radius: 50px; font-weight: 500;">Verify Email</a>
            <p>If you didn’t request this email, please ignore it.</p>
            <p>Regards,<br>App Team</p>
          </div>
        </div>
  `;
  return await sendEmail(to, subject, htmlContent);
};

// Reset password email function
const sendForgotPasswordEmail = async (to, resetLink) => {
  const subject = "Password Reset Request";
  const htmlContent = `
    <html>
      <head>
        <meta name="viewport" content="width=device-width">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      </head>
      <body style="background-color: #fff; font-family: segoe ui,'Lato', Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; line-height: 1.4; margin: 0; padding: 0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <div style="max-width:600px;margin:15px auto;border-spacing:0;background:white;padding:0px;border-radius:16px;overflow:hidden;border: 4px solid #913515;">
          <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="padding: 20px 15px 10px 15px;">
            <tbody>
              <tr>
                <td style="padding:0;text-align:left;border-collapse:collapse" align="left" valign="middle"> 
                  <a href="#" style="width: 100%;display: block;text-align: center;text-decoration:none;color:#ffffff;outline:0;outline:none;border:0;border:none;width: fit-content;margin: auto;" target="_blank">
                    <img src="https://fundedfirmcrmbackend.pmcommu.in/img/logo/logo2.png" alt="FundedFirm Logo" style="margin: 10px auto 0;text-align:center;border:0;outline:none;text-decoration:none;width:260px" align="middle" border="0">
                  </a>
                </td>
              </tr>
            </tbody>
          </table>
          
          <div style="padding: 0px 15px;margin-top: 15px;">
            <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="background: #f7f9fa;padding: 16px 16px 16px;border-radius: 8px;overflow: hidden;">
              <tbody>
                <tr>
                  <td align="left" valign="middle">
                    <div style="color:#000000;border-collapse:collapse;font-size:16px;font-weight:500">Dear Client!</div>
                    <div style="font-weight: 400;margin-top: 10px;margin-bottom: 10px; font-size: 16px;">You recently requested to reset your password.</div>
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="center" valign="top">
                    <a href="${resetLink}" style="
                      color: white; border-color: #e18f04; background-color: #f6a500; background-size: 150%;
                      background-position: left center; text-decoration: none; padding: 10px 15px;
                      font-size: 16px; border-radius: 100px; font-weight: 500; display: inline-block;
                      max-width: fit-content; align-items: center; line-height: 16px; letter-spacing: 0.3px;">Click here to reset</a>
                  </td> 
                </tr>
              </tbody>
            </table>
          </div>

          <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="padding: 0px 15px;">
            <tbody>
              <tr>
                <td style="border-collapse:collapse;padding:15px 0;background:#ffffff;max-width: 100%;">
                  <p style="padding:0;margin:0">In case of any query, please write to us at <a href="mailto:support@fundedfirm.com" style="color: #c26b0b;" target="_blank">support@fundedfirm.com</a></p>
                  <p style="padding:0;margin:0"><br>Best Regards,<br>Funded Firm Team</p>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `;
  return await sendEmail(to, subject, htmlContent);
};
const sendApprovalEmail = async (to, account_number, masterPassword, investorPassword) => {
  const subject = "Your Account Has Been Approved";
  const htmlContent = `
    <p>Dear User,</p>
    <p>Congratulations! Your account has been approved.</p>
    <p>Your account details:</p>
    <ul>
      <li><strong>Account Number:</strong> ${account_number}</li>
      <li><strong>Master Password:</strong> ${masterPassword}</li>
      <li><strong>Investor Password:</strong> ${investorPassword}</li>
    </ul>
    <p>Best Regards,<br>Funded Firm Team</p>
  `;

  return await sendEmail(to, subject, htmlContent);
};


module.exports = {
  sendVerificationEmail,
  sendForgotPasswordEmail,
  sendRealAccountApprovalMail,
  sendApprovalEmail,
};
