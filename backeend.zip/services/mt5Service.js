const https = require("https");
const axios = require("axios");
const logger = require("../helpers/logger"); // Import the Winston logger

class Mt5Service {
  constructor() {
    this.baseUrl = process.env.MT5_BASE_URL;
    this.username = process.env.MT5_USERNAME;
    this.password = process.env.MT5_PASSWORD;
  }

  /**
   * Make an HTTP request
   */
  async makeRequest(method, endpoint, data = {}, headers = {}) {
    try {
      const url = new URL(endpoint, this.baseUrl).href;

      const response = await axios({
        method,
        url,
        data: method === "GET" ? null : data,
        headers: {
          "Content-Type": "application/json",
          ...headers,
        },
        timeout: 10000, // 10 seconds timeout
      });

      return response.data;
    } catch (error) {
      logger.error(`MT5 API request failed: ${error.message}`);
      throw new Error(`MT5 API request failed: ${error.message}`);
    }
  }


  /**
   * Get authentication token from MT5 API
   */
  async getToken() {
    try {
      const response = await axios.post(
        "http://164.132.247.26:7500/Home/token",
        { userName: this.username, password: this.password },
        { headers: { "Content-Type": "application/json" } }
      );

      return response.data; // Ensure this contains `token`
    } catch (error) {
      logger.error(`MT5 API Token request failed: ${error.message}`);
      return null;
    }
  }


  /**
   * Wrapper for API calls requiring authentication
   */
  async securedRequest(method, endpoint, data = {}) {
    try {
      const tokenResponse = await this.getToken();
      if (!tokenResponse || !tokenResponse.token) {
        throw new Error("Unable to retrieve MT5 API token");
      }

      const headers = { Authorization: `Bearer ${tokenResponse.token}` };
      return await this.makeRequest(method, endpoint, data, headers);
    } catch (error) {
      logger.error(`MT5 secured request failed: ${error.message}`);
      return null;
    }
  }

  // Manager login
  async managerLogin(data) {
    return this.securedRequest("POST", "/Home/login", data);
  }

  // Create an MT5 account
  async createAccount(data) {
    return this.securedRequest("POST", "/Home/createAccount", data);
  }

  // Get account details
  async getAccount(accountId) {
    return this.securedRequest("GET", `/api/getAccount/${accountId}`);
  }

  // Update account details
  async updateAccount(accountId, data) {
    return this.securedRequest("POST", `/Home/updateAccount/${accountId}`, data);
  }

  // Update account password
  async updatePassword(data) {
    return this.securedRequest("POST", "/Home/updatePwd", data);
  }

  // Place a pending order
  async pendingOrder(data) {
    return this.securedRequest("POST", "/Home/pendingOrder", data);
  }

  // Update position details
  async updatePosition(data) {
    return this.securedRequest("POST", "/Home/updatePostion", data);
  }

  // Update account balance
  async updateBalance(data) {
    return this.securedRequest("POST", "/Home/balanceOP", data);
  }

  // Fetch trade history
  async getTradeHistory(data) {
    return this.securedRequest("POST", "/Home/tradehistory", data);
  }

  // Fetch group-wise trade history
  async getTradeHistoryGroupWise(data) {
    return this.securedRequest("POST", "/Home/tradehistoryByGroup", data);
  }

  // Fetch trade history for an account
  async getTradeHistoryWithAccount(data) {
    return this.securedRequest("POST", "/Home/tradehistory", data);
  }

  // Fetch symbol information
  async getSymbols(data) {
    return this.securedRequest("GET", `/Home/getSymbolInfo/${data.symbol}`);
  }

  // Fetch user information
  async getUserInfo(data) {
    return this.securedRequest("GET", `/Home/getUserInfo/${data.loginId}`);
  }

  // Fetch open positions for a user
  async getPosition(data) {
    return this.securedRequest("GET", `/Home/getPosition/${data.loginId}`);
  }

  // Disable trading for an account
  async setTradeDisable(data) {
    return this.securedRequest("POST", "/Home/tradeDisable", data);
  }

  // Open a trade
  async sendOpenTrade(data) {
    return this.securedRequest("POST", "/Home/sendOpenTrade", data);
  }

  // Close an open trade
  async closeOpenTrade(data) {
    return this.securedRequest("POST", "/Home/sendCloseTrade", data);
  }

  // Fetch all user information
  async getAllUserInfo() {
    return this.securedRequest("GET", "/Home/getAllAccountInfos");
  }

  // Fetch open positions for a group
  async getAllUserOpenPositionData() {
    return this.securedRequest("GET", "/Home/getPositionbyGroup/*");
  }
}

module.exports = Mt5Service;
