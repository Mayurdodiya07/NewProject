// responseHelper.js

exports.sendResponse = (res, message, data) => {
  return res.status(200).json({
    success: 0, //true || 0 change if need in code
    message: message,
    data: data,
  });
};

exports.sendError = (res, message, error) => {
  return res.status(400).json({
    success: 2,
    message: message,
    error: error,
  });
};

exports.sendServerError = (res, message, error) => {
  return res.status(500).json({
    success: 1,
    message: message,
    error: error,
  });
};
