const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import the helper

// Define the DailyReport schema
const dailyReportSchema = new Schema(
  {
    date: { type: Date, required: true },
    ib_id: { type: String, ref: 'User', required: true }, // Reference to Customer (Introducing Broker)
    lots_traded: { type: Number, default: 0 },
    profit: { type: Number, default: 0 },
    commission_rate: { type: Number, default: 0 },
    active_clients: { type: Number, default: 0 },
    total_deposits: { type: Number, default: 0 },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
    collection: 'daily_reports', // Explicit collection name
  }
);

// Virtual field for formatted date
dailyReportSchema.virtual('date_formattad').get(function () {
  return formatDateToDMY(this.updated_at || new Date());
});

// Overriding the toJSON method
dailyReportSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id;
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Export the model
module.exports = mongoose.model('DailyReport', dailyReportSchema);
