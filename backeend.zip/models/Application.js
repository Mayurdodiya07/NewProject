const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the Application Schema
const applicationSchema = new Schema(
  {
    user_id: { type: String, required: true, ref: 'User' }, // Foreign key reference to User
    type: { type: String, required: true },
    status: { type: String, required: true },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
    toJSON: { virtuals: true, transform: transformJSON }, // Enable virtuals in JSON
  }
);

// Virtual for formatted created_at (similar to Laravel's `getCreatedAtFormattedAttribute`)
applicationSchema.virtual('created_at_formatted').get(function () {
  return formatDate(this.created_at); // Use custom date formatting function
});

// Helper function for JSON transformation
function transformJSON(doc, ret) {
  if (ret._id) {
    ret.id = ret._id.toString();
    delete ret._id;
  }
  return ret;
}

// Helper function for formatting dates
function formatDate(date) {
  if (!date) return null;
  const d = new Date(date);
  return `${d.getDate().toString().padStart(2, '0')}.${(d.getMonth() + 1).toString().padStart(2, '0')}.${d.getFullYear()}`;
}

// Create and export the Application model
const Application = mongoose.model('Application', applicationSchema, 'applications'); // Collection name "applications"
module.exports = Application;
