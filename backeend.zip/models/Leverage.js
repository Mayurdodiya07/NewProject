const mongoose = require('mongoose');
const { Schema } = mongoose;

// Define the Leverage Schema
const LeverageSchema = new Schema(
  {
    name: { type: String, required: true },
    value: { type: String, required: true },
    deleted_at: { type: Date, default: null },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: 'leverages',
  }
);

// Override `toJSON` to include `id` instead of `_id` and avoid showing deleted records by default
LeverageSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Add Soft Delete Query Helpers
LeverageSchema.methods.softDelete = function () {
  this.deleted_at = new Date();
  return this.save();
};

// Static method to restore soft-deleted records
LeverageSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true });
};

// Export the model
module.exports = mongoose.model('Leverage', LeverageSchema);
