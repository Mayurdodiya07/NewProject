const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper');

// Define the schema for TradeGroup
const tradeGroupSchema = new mongoose.Schema({
  name: { type: String, required: true },
  status: { type: String, required: true },
}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Use custom timestamps
  collection: 'trade_group' // Collection name in snake_case
});

// Soft Deletes functionality: Add deleted_at field
tradeGroupSchema.add({
  deleted_at: { type: Date, default: null }
});

// Static method for soft delete (setting deleted_at)
tradeGroupSchema.statics.softDelete = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: new Date() });
};

// Method to check if the trade group is soft deleted
tradeGroupSchema.methods.isDeleted = function () {
  return this.deleted_at !== null;
};

// Convert Mongo _id to id and include virtual fields
tradeGroupSchema.methods.toJSON = function () {
  const obj = this.toObject();
  obj.id = obj._id.toString(); // Convert _id to id as string
  delete obj._id; // Remove the original _id field
  return obj;
};

// Define the model for the 'trade_group' collection
const TradeGroup = mongoose.model('TradeGroup', tradeGroupSchema, 'trade_groups');

module.exports = TradeGroup;
