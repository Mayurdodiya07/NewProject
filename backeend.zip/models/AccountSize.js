const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// AccountType model reference (for relationship)
const AccountType = require("./AccountType");

const AccountSizeSchema = new Schema(
  {
    name: { type: String, required: true },
    limit: { type: Number, required: true },
    account_type_id: { type: String, ref: "AccountType", required: true },
    min_trade_days: { type: Number, required: true },
    profit_target: { type: Number, required: true },
    profit_target_phase2: { type: Number, required: true },
    max_overall_loss: { type: Number, required: true },
    max_daily_loss: { type: Number, required: true },
    price: { type: Number, required: true },
    status: { type: String, required: true }
  },
  { timestamps: true, collection: "account_sizes" }
);

// Add a virtual field for 'id' (MongoDB uses '_id' by default)
AccountSizeSchema.virtual("id").get(function () {
  return this._id.toHexString();
});

// Format date (custom function for 'created_at_formattad' equivalent)
AccountSizeSchema.virtual("created_at_formattad").get(function () {
  const d = new Date(this.createdAt);
  return d.toLocaleString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
});


// AccountSizeSchema.virtual("account_type").get(async function () {
//   const accountType = await AccountType.findById(this.account_type_id);
//   return accountType ? accountType.name : "";
// });
AccountSizeSchema.virtual("account_type", {
  ref: "AccountType",
  localField: "account_type_id",
  foreignField: "_id",
  justOne: true,
});


// Get 'account_step' (equivalent to getAccountStepAttribute in PHP)

// AccountSizeSchema.virtual("account_step").get(async function () {

//   const accountType = await AccountType.findById(this.account_type_id);
//   return accountType ? accountType.step : "";
// });

// AccountSizeSchema.virtual("account_step").get(function () {
//   if (this.account_type_id) {
//     return this.account_type_id.step;  
//   }
//   return "No step defined"; 
// });

// Optionally, remove '_id' from the response when calling .toJSON()
AccountSizeSchema.set("toJSON", {
  virtuals: true,
  transform: function (doc, ret) {
    delete ret._id;
    return ret;
  },
});


// Optionally, remove '_id' from the response when calling .toJSON()
// AccountSizeSchema.set("toJSON", {
//   virtuals: true,
//   transform: function (doc, ret) {
//     delete ret._id;
//     return ret;
//   },
// });
AccountSizeSchema.set("toJSON", { virtuals: true });
AccountSizeSchema.set("toObject", { virtuals: true });


module.exports = mongoose.model("AccountSize", AccountSizeSchema);
