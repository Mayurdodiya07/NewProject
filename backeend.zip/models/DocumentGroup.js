const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import the date helper

const DocumentGroupSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    type: { type: String, required: true },
    caption: { type: String, required: true },
    description: { type: String, required: true },
    enabled: { type: Boolean, default: true },
  },
  { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },collection: 'document_groups', }
);

// Optional: Virtuals for formatted dates (if needed)
DocumentGroupSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at);
});

DocumentGroupSchema.virtual('updated_at_formatted').get(function () {
  return formatDateToDMY(this.updated_at);
});

// Reference relationship for related DocumentTypes
DocumentGroupSchema.virtual('document_types', {
  ref: 'DocumentType', // Reference to the DocumentType model
  localField: '_id', // Field in DocumentGroup
  foreignField: 'document_group_id', // Field in DocumentType
});

module.exports = mongoose.model('DocumentGroup', DocumentGroupSchema);
