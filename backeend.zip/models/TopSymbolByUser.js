const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import your date format helper

// Define the schema for TopSymbolByUser
const topSymbolByUserSchema = new mongoose.Schema({
  user_id: { type: String, required: true, ref: 'User' },  // Foreign key as a string
  symbol_id: { type: String, required: true, ref: 'Symbol' }, // Foreign key as a string
}, { 
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Using custom timestamps
  collection: 'top_symbol_by_user' // Use snake_case for collection name
});

// Virtual field to format the created_at date
topSymbolByUserSchema.virtual('created_at_formattad').get(function() {
  return formatDateToDMY(this.created_at); // Format the created_at field
});

// Soft Deletes functionality: Add deleted_at field
topSymbolByUserSchema.add({
  deleted_at: { type: Date, default: null }
});

// Static method for soft delete (setting deleted_at)
topSymbolByUserSchema.statics.softDelete = function(id) {
  return this.findByIdAndUpdate(id, { deleted_at: new Date() });
};

// Method to check if the symbol is soft deleted
topSymbolByUserSchema.methods.isDeleted = function() {
  return this.deleted_at !== null;
};

// Convert Mongo _id to id and include virtual field
topSymbolByUserSchema.methods.toJSON = function() {
  const obj = this.toObject();
  obj.id = obj._id.toString(); // Convert _id to id as string
  delete obj._id; // Remove the original _id field
  return obj;
};

// Define the model for the 'top_symbol_by_user' collection
const TopSymbolByUser = mongoose.model('TopSymbolByUser', topSymbolByUserSchema, 'top_symbol_by_user');

module.exports = TopSymbolByUser;
