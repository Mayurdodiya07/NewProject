const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper');

const DocumentTypeSchema = new Schema(
  {
    name: { type: String, required: true },
    status: { type: String, required: true },
    caption: { type: String },
    description: { type: String },
    example: { type: String },
    document_group_id: { type: String, ref: 'document_group' }, // Foreign key as string with ref
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Use custom timestamps
  }
);

// Add a virtual property to format dates using the helper
DocumentTypeSchema.virtual('formatted_created_at').get(function () {
  return formatDateToDMY(this.created_at);
});

DocumentTypeSchema.virtual('formatted_updated_at').get(function () {
  return formatDateToDMY(this.updated_at);
});

// Set the collection name explicitly
DocumentTypeSchema.set('collection', 'document_types');

// Override `toJSON` to include virtuals and replace `_id` with `id`
DocumentTypeSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Export the model
module.exports = mongoose.model('document_type', DocumentTypeSchema);
