const mongoose = require('mongoose');

const verificationLevelSchema = new mongoose.Schema(
    {
        index: { type: Number, required: true },
        caption: { type: String, required: true },
        description: { type: String },
        default: { type: Boolean, default: false },
        visible: { type: Boolean, default: true },
    },
    {
        timestamps: true, // Adds `createdAt` and `updatedAt` fields
        toJSON: { virtuals: true },
    }
);

// Transform `_id` to `id` in JSON response
verificationLevelSchema.set('toJSON', {
    transform: (doc, ret) => {
        ret.id = ret._id.toString();
        delete ret._id;
        return ret;
    },
});

// Export the model with a specific collection name
module.exports = mongoose.model('VerificationLevel', verificationLevelSchema, 'verification_levels');
