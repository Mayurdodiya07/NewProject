const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper');

const Schema = mongoose.Schema;

const userDeviceSchema = new Schema(
  {
    user_id: { type: String, ref: 'User', collection: 'users' },
    device_id: { type: String },
    ip_address: { type: String },
    location: { type: String },
    latitude: { type: String, default: null },
    longitude: { type: String, default: null },
    login_at: { type: Date, default: Date.now },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: 'user_devices',
  }
);

// Plugins
userDeviceSchema.plugin(require('mongoose-delete'), { overrideMethods: 'all' });


userDeviceSchema.virtual('created_dt_formatted').get(function () {
  return formatDateToDMY(this.created_at);
});

// Instance methods
userDeviceSchema.methods.toJSON = function () {
  const obj = this.toObject();
  obj.id = obj._id;
  delete obj._id;
  return obj;
};

module.exports = mongoose.model('UserDevice', userDeviceSchema);

