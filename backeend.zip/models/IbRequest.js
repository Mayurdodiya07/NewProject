const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateTime } = require('../helpers/dateHelper'); // Assuming the helper file is in this location

const IbRequestSchema = new Schema(
  {
    user_id: { 
      type: String, 
      required: true, 
      ref: 'user' // Reference to the user collection
    },
    partner_program_id: { 
      type: String, 
      required: true, 
      ref: 'partner_program' // Reference to the partner_program collection
    },
    status: { type: String, required: true },
    agree: { type: Boolean },
    is_experienced: { type: Boolean },
    previous_broker: { type: String },
    platforms: { type: String },
    website_link: { type: String },
    social_link: { type: String },
    messanger_link: { type: String },
    forumn_link: { type: String },
    other_link: { type: String },
    countries: { type: [String] },
    number_of_clients: { type: Number },
    additional_services: { type: String },
    other_additional_services: { type: String },
    language: { type: String },
    phone: { type: String },
    email: { type: String },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Add virtuals
IbRequestSchema.virtual('created_at_formattad').get(function () {
  return formatDateTime(this.created_at);
});

// Override `toJSON` to include `id` instead of `_id`
IbRequestSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});
IbRequestSchema.set('collection', 'ib_requests');
module.exports = mongoose.model('ib_request', IbRequestSchema);
