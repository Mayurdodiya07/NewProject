const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper'); // Importing the date formatting helper

// Define the PassedAccountRequest Schema
const PassedAccountRequestSchema = new Schema(
  {
    status: { type: String, required: true },
    user_id: { type: String, ref: 'User' },
    title: { type: String },
    first_name: { type: String },
    last_name: { type: String },
    street: { type: String },
    city: { type: String },
    postal_code: { type: String },
    address_country_id: { type: String }, // Foreign key as a string with ref to Country (if applicable)
    country_id: { type: String, ref: 'Country' }, // Foreign key as a string with ref to Country
    account_type_id: { type: String, ref: 'AccountType' }, // Foreign key as a string with ref to AccountType
    account_size_id: { type: String, ref: 'AccountSize' }, // Foreign key as a string with ref to AccountSize
    not_us_residence: { type: Boolean },
    platform_id: { type: String, ref: 'Platform' }, // Foreign key as a string with ref to Platform
    payment_method_id: { type: String, ref: 'PaymentMethod' }, // Foreign key as a string with ref to PaymentMethod
    amount: { type: Number },
    transaction_id: { type: String },
    screenshot: { type: String },
    account_status: { type: String },
    user_wallet_id: { type: String, ref: 'UserWallet' }, // Foreign key as a string with ref to UserWallet
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Virtual field for formatted 'created_at'
PassedAccountRequestSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at); // Using the provided helper for date formatting
});

// Override `toJSON` to include `id` instead of `_id` and avoid showing deleted records by default
PassedAccountRequestSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString(); // Replace `_id` with `id` for the JSON response
    ret.name = ret.first_name + " " + ret.last_name;
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Soft delete method
PassedAccountRequestSchema.methods.softDelete = function () {
  this.deleted_at = new Date(); // Set the deleted_at field to the current date
  return this.save();
};

// Restore a soft-deleted PassedAccountRequest
PassedAccountRequestSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true }); // Set `deleted_at` to null to restore the document
};

// Explicitly set the collection name (snake_case for two-word collection names)
PassedAccountRequestSchema.set('collection', 'passed_account_requests');

// Export the model
module.exports = mongoose.model('PassedAccountRequest', PassedAccountRequestSchema);
