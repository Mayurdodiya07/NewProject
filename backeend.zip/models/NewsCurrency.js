const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper');

// Define the NewsCurrency Schema
const NewsCurrencySchema = new Schema(
  {
    name: { type: String, required: true },
    short_code: { type: String, required: true },
    code: { type: String, required: true },
    status: { type: String, required: true },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Define a virtual getter for formatted created_at
NewsCurrencySchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at);
});

// Override `toJSON` to include `id` instead of `_id` and apply custom formatting
NewsCurrencySchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id; // Remove MongoDB _id field
    delete ret.__v; // Remove version field
    return ret;
  }
});

// Soft delete method
NewsCurrencySchema.methods.softDelete = function () {
  this.deleted_at = new Date(); // Set deleted_at to the current date
  return this.save();
};

// Restore method
NewsCurrencySchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true });
};

// Set the collection name to 'news_currencies' (with an underscore between words)
NewsCurrencySchema.set('collection', 'news_currencies');

// Export the model
module.exports = mongoose.model('NewsCurrency', NewsCurrencySchema);
