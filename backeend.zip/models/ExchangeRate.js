const mongoose = require('mongoose');
const { Schema } = mongoose;

const ExchangeRateSchema = new Schema(
  {
    from_currency: { type: String, required: true },
    to_currency: { type: String, required: true },
    from_currency_rate: { type: Number, required: true },
    to_currency_rate: { type: Number, required: true },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Set the collection name explicitly
ExchangeRateSchema.set('collection', 'exchange_rates');

// Override `toJSON` to include `id` instead of `_id`
ExchangeRateSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Export the model
module.exports = mongoose.model('exchange_rate', ExchangeRateSchema);
