const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import the date helper

// Define the Payouts Schema
const PayoutsSchema = new Schema(
  {
    reference_id: { type: String, required: true },
    user_id: { type: String, ref: 'User' }, // Foreign key as a string with ref to User model
    payout_type: { type: String, required: true },
    payment_method_id: { type: String, ref: 'PaymentMethod' }, // Foreign key as a string with ref to PaymentMethod model
    status: { type: String },
    payment_status: { type: String },
    payment_wallet_address_id: { type: String },
    account_holder_name: { type: String },
    account_number: { type: String },
    account_ifsc_code: { type: String },
    account_bank_name: { type: String },
    amount: { type: Number },
    admin_note: { type: String },
    approve_datetime: { type: Date }, // Cast to Date
    user_wallet_id: { type: String, ref: 'UserWallet' }, // Foreign key as a string with ref to UserWallet model
    deleted_at: { type: Date, default: null }, // Soft delete field

  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Virtual field for formatted 'created_at'
PayoutsSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at); // Using the provided helper for date formatting
});

// Virtual field for formatted 'updated_at'
PayoutsSchema.virtual('updated_at_formatted').get(function () {
  return formatDateToDMY(this.updated_at); // Using the provided helper for date formatting
});

// Soft delete method
PayoutsSchema.methods.softDelete = function () {
  this.deleted_at = new Date(); // Set the deleted_at field to the current date
  return this.save();
};

// Restore a soft-deleted Payout
PayoutsSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true }); // Set `deleted_at` to null to restore the document
};

// Define relationships using `ref`
PayoutsSchema.virtual('user', {
  ref: 'User',
  localField: 'user_id',
  foreignField: '_id',
  justOne: true, // Use justOne for a single related document
});

PayoutsSchema.virtual('paymentMethod', {
  ref: 'PaymentMethod',
  localField: 'payment_method_id',
  foreignField: '_id',
  justOne: true,
});

PayoutsSchema.virtual('userWallet', {
  ref: 'UserWallet',
  localField: 'user_wallet_id',
  foreignField: '_id',
  justOne: true,
});


PayoutsSchema.virtual('userAccount', {
  ref: 'UserAccount',
  localField: 'user_id',
  foreignField: 'user_id',
  justOne: true,
});

// Override `toJSON` to include `id` instead of `_id` and remove `_id` and `__v` from the response
PayoutsSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString(); // Replace `_id` with `id`
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Explicitly set the collection name (snake_case for two-word collection names)
PayoutsSchema.set('collection', 'payouts');

// Export the model
module.exports = mongoose.model('Payouts', PayoutsSchema);
