const mongoose = require("mongoose");
const mongooseDelete = require("mongoose-delete");
const moment = require("moment");
const Schema = mongoose.Schema;

// Define the AccountRequest schema
const AccountRequestSchema = new Schema(
  {
    status: { type: String },
    user_id: { type: String, ref: "User", required: true },
    title: { type: String },
    first_name: { type: String },
    last_name: { type: String },
    street: { type: String },
    city: { type: String },
    postal_code: { type: String },
    address_country_id: { type: String, required: true },
    country_id: { type: String, ref: "Country", required: true },
    account_type_id: { type: String, ref: "AccountType", required: true },
    account_size_id: { type: String, ref: "AccountSize", required: true },
    not_us_residence: { type: Boolean },
    platform_id: { type: String, ref: "Platform", required: true },
    payment_method_id: { type: String, ref: "PaymentMethod", required: true },
    amount: { type: Number, required: true },
    transaction_id: { type: String, required: true },
    screenshot: { type: String },
    account_status: { type: String, default: "pending" },
    coupon_id: { type: String, ref: "Coupon" },
    coupon_code: { type: String },
    discount: { type: Number, default: 0 },
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
    collection: "account_requests",
  }
);

// Add soft delete plugin
AccountRequestSchema.plugin(mongooseDelete, {
  overrideMethods: "all",
  deletedAt: true,
});

// Virtual for formatted created_at date
AccountRequestSchema.virtual("created_at_formattad").get(function () {
  return moment(this.created_at).format("YYYY-MM-DD HH:mm:ss"); // You can change the format as needed
});

// Virtual for country name (similar to the `getCountryNameAttribute` method in PHP)
AccountRequestSchema.virtual("country_name").get(function () {
  if (this.country_id) {
    return this.model("Country")
      .findById(this.country_id)
      .then((country) => (country ? country.name : ""));
  }
  return "";
});

// Define instance methods for additional logic (optional)
AccountRequestSchema.methods.toJSON = function () {
  const accountRequest = this.toObject();
  accountRequest.id = accountRequest._id.toString();
  delete accountRequest._id;
  // accountRequest.user = accountRequest.user_id;
  // accountRequest.user_id = accountRequest.user_id?._id;
  accountRequest.name = accountRequest.first_name +" "+ accountRequest.last_name;
  accountRequest.account_type = accountRequest.account_type_id;
  accountRequest.account_type_id = accountRequest.account_type_id?.id;
  accountRequest.payment_method = accountRequest.payment_method_id;
  accountRequest.payment_method_id = accountRequest.payment_method_id?._id;
  accountRequest.account_size_id = accountRequest.account_size_id.id;
  accountRequest.account_size = accountRequest.account_size_id;
  accountRequest.platform = accountRequest.platform_id;
  accountRequest.platform_id = accountRequest.platform_id.id;
  return accountRequest;
};

// Export the model
module.exports = mongoose.model("AccountRequest", AccountRequestSchema);
