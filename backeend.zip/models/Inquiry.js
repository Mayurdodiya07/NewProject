const mongoose = require('mongoose');
const { Schema } = mongoose;

// Define the Inquiry Schema
const InquirySchema = new Schema(
  {
    first_name: { type: String, required: true },
    last_name: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    message: { type: String, required: true },
    type: { type: String, required: true },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Override `toJSON` to include `id` instead of `_id` and avoid showing deleted records by default
InquirySchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    ret.name = ret.first_name + " " + ret.last_name;
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Add Soft Delete Query Helpers
InquirySchema.methods.softDelete = function () {
  this.deleted_at = new Date();
  return this.save();
};

InquirySchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true });
};

// Explicitly set the collection name
InquirySchema.set('collection', 'inquiries');

// Export the model
module.exports = mongoose.model('Inquiry', InquirySchema);
