const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the schema
const CountrySchema = new Schema(
  {
    name: { type: String, required: true }, // Country name
    iso2: { type: String, required: true, maxlength: 2 }, // 2-character ISO code
    iso3: { type: String, required: true, maxlength: 3 }, // 3-character ISO code
    deleted_at: { type: Date, default: null }, // Soft delete timestamp
  },
  { timestamps: true } // Automatically adds `createdAt` and `updatedAt` fields
);

// Virtual field for `id` (to replace `_id`)
CountrySchema.virtual('id').get(function () {
  return this._id.toString();
});

// Override `toJSON` and `toObject` methods to include `id` and exclude `_id`
CountrySchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: function (doc, ret) {
    ret.id = ret._id.toString();
    delete ret._id;
    return ret;
  },
});

CountrySchema.set('toObject', {
  virtuals: true,
  versionKey: false,
  transform: function (doc, ret) {
    ret.id = ret._id.toString();
    delete ret._id;
    return ret;
  },
});

// Soft delete plugin (if needed)
CountrySchema.methods.softDelete = function () {
  this.deleted_at = new Date();
  return this.save();
};

// Export the model
module.exports = mongoose.model('Country', CountrySchema);
