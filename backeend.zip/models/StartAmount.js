const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper'); // Helper function for date formatting

// Define the schema for StartAmount
const startAmountSchema = new mongoose.Schema({
  name: { type: String, required: true },
  value: { type: Number, required: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } }); // Use created_at and updated_at as field names

// Virtual field for formatted created_at
startAmountSchema.virtual('created_at_formattad').get(function() {
  return formatDateToDMY(this.created_at); // Use the helper to format the date
});

// SoftDeletes functionality: add deleted_at field for soft deletion
startAmountSchema.add({
  deleted_at: { type: Date, default: null }
});

// Static method for soft delete (setting deleted_at field)
startAmountSchema.statics.softDelete = function(id) {
  return this.findByIdAndUpdate(id, { deleted_at: new Date() });
};

// Method to check if the record is soft deleted
startAmountSchema.methods.isDeleted = function() {
  return this.deleted_at !== null;
};

// Convert Mongo _id to id and include virtual field
startAmountSchema.methods.toJSON = function() {
  const obj = this.toObject();
  obj.id = obj._id.toString();
  delete obj._id;
  return obj;
};

// Define the model with a collection name of "start_amounts"
const StartAmount = mongoose.model('StartAmount', startAmountSchema, 'start_amounts');
module.exports = StartAmount;
