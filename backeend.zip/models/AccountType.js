const mongoose = require('mongoose');
const { Schema } = mongoose;

const AccountTypeSchema = new Schema(
  {
    name: { type: String, required: true },
    step: { type: String, required: true }
  },
  {
    timestamps: true,
    collection: 'account_types'
  }
);

// Transform the response to include 'id' instead of '_id' by default
AccountTypeSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toHexString();
    delete ret._id;
    delete ret.__v;
    return ret;
  }
});

// Transform the response for lean queries too
AccountTypeSchema.set('toObject', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toHexString();
    delete ret._id;
    delete ret.__v;
    return ret;
  }
});

module.exports = mongoose.model('AccountType', AccountTypeSchema);
