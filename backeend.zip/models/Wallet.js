const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const WalletSchema = new Schema(
  {
    // name: { type: String, required: true, ref: 'User' },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    code: { type: String, required: true },
    default: { type: Boolean, default: false },
    sequence: { type: Number, default: 0 },
    image: { type: String, default: "" }, // Assuming image is a string URL
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
    collection: "wallets",
  }
);

// Virtual field for image URL
WalletSchema.virtual("imageUrl").get(function () {
  if (this.image === "") {
    return `${process.env.BASE_URL}/storage/photos/user/user.png`; // Use environment variable for base URL
  }
  return `${process.env.BASE_URL}${this.image}`;
});


// To return the document as a plain JavaScript object, including the virtual field
WalletSchema.set("toJSON", {
  virtuals: true,
  transform: (doc, ret) => {
    if (ret._id) {
      ret.id = ret._id.toString();
      delete ret._id;
    }
    return ret;
  },
});

// Soft deletes (mark as deleted instead of actually removing from the database)
WalletSchema.plugin(require("mongoose-delete"), { overrideMethods: "all" });

const Wallet = mongoose.model("Wallet", WalletSchema);

module.exports = Wallet;
