
const mongoose = require("mongoose");
const { Schema } = mongoose;
const FormatHelper = require("../helpers/FormatHelper");
const { formatDateTimeToDMY } = require('../helpers/dateHelper');
const Trade = require("./Trade");
const User = require("./User");

const UserWalletSchema = new Schema(
  {
    user_id: { type: String, required: true, ref: 'User' },
    wallet_id: { type: String, ref: "Wallet" },
    code: { type: String, required: true },
    balance: { type: Number },
    available_balance: { type: Number },
    on_hold_balance: { type: Number },
    currency: { type: String },
    favourite: { type: Boolean },
    fiat: { type: Boolean },
    enabled: { type: Boolean },
    status: { type: String },
    account: { type: String },
    account_number: { type: Number },
    mt5_type: { type: String },
    leverage_id: { type: String, ref: "Leverage" },
    currency_id: { type: String, ref: "Currency" },
    start_amount_id: { type: String, ref: "StartAmount" },
    // account_type: { type: String, ref: 'account_type' },
    account_type_id: { type: String, ref: 'AccountType' },
    account_size_id: { type: String, ref: 'AccountSize' },
    product_id: { type: String, ref: "Product" },
    equity: { type: Number },
    free_funds: { type: Number },
    credit: { type: Number },
    archived: { type: Boolean, default: false },
    master_password: { type: String },
    investor_password: { type: String },
    account_status: { type: String },
    title: { type: String },
    first_name: { type: String },
    last_name: { type: String },
    city: { type: String },
    postal_code: { type: String },
    address_country_id: { type: String },
    country_id: { type: String },
    not_us_residence: { type: Boolean },
    platform_id: { type: String },
    approve_datetime: { type: Date },
    passed_datetime: { type: Date },
    account_request_id: { type: String, ref: "AccountRequest" },
    margin: { type: Number },
    marginlevel: { type: Number },
    freemargin: { type: Number },
    closepnl: { type: Number },
    openpnl: { type: Number },
    target_profit_achieved: { type: Boolean, default: false },
    parent_user_wallet_id: { type: String },
    disable_date: { type: Date },
    disable_rule: { type: String },
    min_balance: { type: Number },
    max_balance: { type: Number },
    min_equity: { type: Number },
    max_equity: { type: Number },
    passed_account_request: { type: Boolean, default: false },
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
    collection: "user_wallets",
  }
);

// Virtual fields for formatted balances
UserWalletSchema.virtual("formatted_balance").get(function () {
  return FormatHelper.formatAmount(this.balance);
});

UserWalletSchema.virtual("formatted_available_balance").get(function () {
  return FormatHelper.formatAmount(this.available_balance);
});

UserWalletSchema.virtual("formatted_on_hold_balance").get(function () {
  return FormatHelper.formatAmount(this.on_hold_balance);
});

UserWalletSchema.virtual('created_at_formattad').get(function () {
  return formatDateTimeToDMY(this.created_at);
});

UserWalletSchema.virtual("front_link").get(function () {
  return `/wallet/${this.id}`;
});

UserWalletSchema.virtual("no_of_trades").get(async function () {
  return await Trade.countDocuments({
    user_wallet_id: this._id.toString(),
    position: "close",
  });
});



UserWalletSchema.virtual("userDetails", {
  ref: "User", // The model to populate from
  localField: "user_id", // Field in UserWalletSchema
  foreignField: "_id", // Field in UserSchema
  justOne: true, // Only a single user object
});

// UserWalletSchema.virtual("accountSize", {
//   ref: "AccountSize", // The model to populate from
//   localField: "_id", // Field in UserWalletSchema
//   foreignField: "account_size_id", // Field in UserSchema
//   justOne: true, // Only a single user object
// });

// UserWalletSchema.virtual("accountType", {
//   ref: "AccountType", // The model to populate from
//   localField: "_id", // Field in UserWalletSchema
//   foreignField: "account_size_id", // Field in UserSchema
//   justOne: true, // Only a single user object
// });

UserWalletSchema.virtual("days_traded").get(async function () {
  const trades = await Trade.find({
    user_wallet_id: this._id.toString(),
    position: "close",
  });
  const days = new Set(
    trades.map(
      (trade) => new Date(trade.close_date).toISOString().split("T")[0]
    )
  );
  return days.size;
});
// UserWalletSchema.virtual("account_size_limit").get(function () {
//   return this.account_size_id?.limit || 0;
// });

// Relationships
UserWalletSchema.methods.user = function () {
  return mongoose.model("User").findById(this.user_id);
};

UserWalletSchema.methods.wallet = function () {
  return mongoose.model("Wallet").findById(this.wallet_id);
};

UserWalletSchema.methods.trades = function () {
  return mongoose.model("Trade").find({ user_wallet_id: this._id });
};

UserWalletSchema.methods.toJSON = function () {
  const obj = this.toObject();
  obj.id = obj._id;
  obj.user = obj.user_id;
  obj.account_type = obj.account_type_id;
  obj.account_type_id = obj.account_type_id?.id;
  obj.user_id = obj.user_id?.id;
  obj.wallet = obj.wallet_id;
  obj.leverage = obj.leverage_id;
  obj.currency = obj.currency_id;
  obj.start_amount = obj.start_amount;
  obj.account_size = obj.account_size_id;
  obj.account_size_id = obj.account_size_id?.id;
  obj.product = obj.product_id;
  obj.created_date_time_formattad = this.created_at_formattad;
  obj.name = `${obj.first_name} ${obj.last_name}`;
  obj.account_request = obj.account_request_id;

  // Clean unnecessary fields
  delete obj._id;
  delete obj.__v;
  // delete obj.account_type_id;
  // delete obj.account_size_id;
  // delete obj.user_id;

  return obj;
};
UserWalletSchema.set('toJSON', { virtuals: true });
// UserWalletSchema.set('toObject', { virtuals: true });
const UserWallet = mongoose.model("UserWallet", UserWalletSchema);

module.exports = UserWallet;
