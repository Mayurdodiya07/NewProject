const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import the date helper

// Define the PaymentMethod Schema
const PaymentMethodSchema = new Schema(
  {
    currency_id: { type: String, ref: 'Currency' }, // Foreign key as a string with ref to Currency model
    name: { type: String, required: true },
    image: { type: String },
    lower_limit: { type: Number },
    upper_limit: { type: Number },
    status: { type: String },
    deposit_address: { type: String },
    qr_code_image: { type: String },
    sequence: { type: Number },
    fee: { type: Number },
    processing_time: { type: String },
    upi_id: { type: String },
    account_name: { type: String },
    account_number: { type: String },
    bank_name: { type: String },
    branch: { type: String },
    ifsc_code: { type: String },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Virtual field for formatted 'created_at'
PaymentMethodSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at); // Using the provided helper for date formatting
});

// Getter for image URL
PaymentMethodSchema.virtual('image_url').get(function () {
  if (this.image === '') {
    return `${process.env.BASE_URL}/storage/photos/user/user.png`;
  }
  return `${process.env.BASE_URL}${this.image}`;
});

// Getter for QR code image URL
PaymentMethodSchema.virtual('qr_code_image_url').get(function () {
  if (this.qr_code_image === '') {
    return `${process.env.BASE_URL}/storage/photos/user/user.png`;
  }
  return `${process.env.BASE_URL}${this.qr_code_image}`;
});

// Getter for currency name
PaymentMethodSchema.virtual('currency_name').get(async function () {
  if (this.currency_id > 0) {
    const currency = await mongoose.model('Currency').findById(this.currency_id); // Using Currency model
    return currency ? currency.code : '';
  }
  return '';
});
PaymentMethodSchema.methods.softDelete = function () {
  this.deleted_at = new Date();
  return this.save();
};
PaymentMethodSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true }); // Set `deleted_at` to null to restore the document
};
PaymentMethodSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});
PaymentMethodSchema.set('collection', 'payment_methods');
module.exports = mongoose.model('PaymentMethod', PaymentMethodSchema);
