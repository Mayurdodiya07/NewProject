const mongoose = require("mongoose");
const mongooseDelete = require("mongoose-delete");
const moment = require("moment");
const Schema = mongoose.Schema;
const PasswordResetTokenSchema = new Schema(
  {
    email: { type: String, required: true },
    token: { type: String, required: true },
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
    collection: "password_reset_tokens",
  }
);
module.exports = mongoose.model("PasswordResetToken", PasswordResetTokenSchema);
