const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper');

// Define the schema
const userSchema = new Schema(
  {
    first_name: { type: String, required: true },
    last_name: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    role: { type: String },
    phone_country: { type: String },
    phone_prefix: { type: String },
    phone: { type: String },
    photo: { type: String },
    birthdate: { type: Date },
    city: { type: String },
    state: { type: String },
    country: { type: String },
    country_id: { type: String, ref: 'countries' },
    postal_code: { type: String },
    address: { type: String },
    is_affiliate: { type: String },
    status: { type: String },
    provider: { type: String },
    provider_id: { type: String },
    gender: { type: String },
    verification_level_id: { type: String, ref: 'verification_levels' },
    is_ib: { type: Boolean },
    referral_code: { type: String },
    referred_by: { type: String, ref: 'users' },
    referral_click_count: { type: Number },
    lots_traded: { type: Number },
    ib_request: { type: String },
    previous_id: { type: String },
    data_imported_date: { type: Date },
    last_login_dt: { type: Date },
    manager: { type: String },
    email_verified_at: { type: Date },
    verification_token: { type: String },
    ip_address: { type: String },
    forgot_link: { type: String, default: '' },
    token: { type: String, default: '' },
    // country_flag: { type: String, default: '' },// MD commet  1/4
    verified: { type: Boolean, default: false },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: 'users',
  }
);

// Add soft deletes
userSchema.add({
  deleted_at: { type: Date, default: null },
});

// Virtuals for computed properties
userSchema.virtual('name').get(function () {
  return `${this.first_name} ${this.last_name}`;
});

// userSchema.virtual('image').get(function () {
//   if (!this.photo) {
//     return `${process.env.BASE_URL}/storage/photos/user/user.png`;
//   }
//   return `${process.env.BASE_URL}${this.photo}`;
// });
// MD Add this filed in 4/1 above code commet by md //

userSchema.virtual('country_flag').get(function () {
  return this.phone_country
    ? `${process.env.BASE_URL}/storage/countries/${this.phone_country.toLowerCase()}.png`
    : null;
});


userSchema.virtual('image').get(function () {
  return this.photo
    ? `${process.env.BASE_URL}${this.photo}`
    : `${process.env.BASE_URL}/storage/photos/user/user.png`;
});

// userSchema.virtual('country_name').get(async function () {
//   if (this.country) {
//     const Country = mongoose.model('Country');
//     const country = await Country.findById(this.country);
//     return country ? country.name : '';
//   }
//   return '';
// });
userSchema.virtual('country_name').get(function () {
  return this._country_name || ''; // Use an internal field for the country name
});
userSchema.post(['findOne', 'findById'], async function (doc) {
  if (doc && doc.country) {
    const Country = mongoose.model('Country');
    const country = await Country.findById(doc.country).select('name');
    doc._country_name = country ? country.name : '';
  }
});
// userSchema.virtual('country_code').get(async function () {
//   if (this.country) {
//     const Country = mongoose.model('Country');
//     const country = await Country.findById(this.country);
//     console.log(country.iso2);
//     return country ? country.iso2 : '';

//   }
//   return '';
// });
userSchema.post(['find', 'findOne', 'findById'], async function (docs) {
  // If multiple documents are returned, handle each document in the array
  if (Array.isArray(docs)) {
    for (const doc of docs) {
      if (doc.country) {
        const Country = mongoose.model('Country');
        const country = await Country.findById(doc.country).select('iso2');
        doc._country_code = country ? country.iso2 : '';
      }
    }
  } else if (docs && docs.country) {
    // For single document queries
    const Country = mongoose.model('Country');
    const country = await Country.findById(docs.country).select('iso2');
    docs._country_code = country ? country.iso2 : '';
  }
});

userSchema.virtual('country_code').get(function () {
  return this._country_code || ''; // Return the pre-fetched country code
});


// userSchema.virtual('phone_number').get(function () {
//   return `${this.phone_prefix}${this.phone}`;
// });
// md commet  1/4
userSchema.virtual('phone_number').get(function () {
  const phonePrefix = this.phone_prefix || '';
  const phoneNumber = this.phone || '';

  return `${phonePrefix}${phoneNumber}`;
});

userSchema.virtual('created_at_formattad').get(function () {
  return formatDateToDMY(this.created_at);
});

userSchema.virtual('wallets', {
  ref: 'UserWallet', // Ensure this points to the correct model
  localField: '_id',
  foreignField: 'user_id', // Make sure 'user' is the correct field in the Wallet model
});
// userSchema.virtual('wallets', {
//   ref: 'Wallet', // Correct model name
//   localField: '_id',
//   foreignField: 'user',
// });
userSchema.virtual('clients', {
  ref: 'users',
  localField: '_id',
  foreignField: 'referred_by',
});
userSchema.virtual('documents', {
  ref: 'Document',
  localField: '_id',
  foreignField: 'user_id',
});

// userSchema.virtual('documents', {
//   ref: 'documents',
//   localField: '_id',
//   foreignField: 'user_id',
// });

// userSchema.virtual('trades', {
//   ref: 'trades',
//   localField: '_id',
//   foreignField: 'user_id',
// });

userSchema.virtual('trades', {
  ref: 'Trade',
  localField: '_id',
  foreignField: 'user_id',
});

userSchema.virtual('transactions', {
  ref: 'Transaction',
  localField: '_id',
  foreignField: 'user_id',
});


// Override toJSON for custom output
userSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id;
    delete ret._id;
    delete ret._v;

    return ret;
  },

});
userSchema.set('toObject', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id;
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});
// Export the model
userSchema.set('toObject', { virtuals: true });
module.exports = mongoose.model('User', userSchema);
