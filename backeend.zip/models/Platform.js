const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import the date helper

// Define the Platform Schema
const PlatformSchema = new Schema(
  {
    name: { type: String, required: true },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Virtual field for formatted 'created_at'
PlatformSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at); // Using the provided helper for date formatting
});

// Virtual field for formatted 'updated_at'
PlatformSchema.virtual('updated_at_formatted').get(function () {
  return formatDateToDMY(this.updated_at); // Using the provided helper for date formatting
});

// Soft delete method
PlatformSchema.methods.softDelete = function () {
  this.deleted_at = new Date(); // Set the deleted_at field to the current date
  return this.save();
};

// Restore a soft-deleted Platform
PlatformSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true }); // Set `deleted_at` to null to restore the document
};

// Override `toJSON` to include `id` instead of `_id` and remove `_id` and `__v` from the response
PlatformSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString(); // Replace `_id` with `id`
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Explicitly set the collection name (snake_case for two-word collection names)
PlatformSchema.set('collection', 'platforms');

// Export the model
module.exports = mongoose.model('Platform', PlatformSchema);
