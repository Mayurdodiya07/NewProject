const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the ApplicationDocument Schema
const applicationDocumentSchema = new Schema(
  {
    document_type_id: { type: String, required: true, ref: 'DocumentType' }, // Foreign key reference to DocumentType
    application_id: { type: String, required: true, ref: 'Application' }, // Foreign key reference to Application
    file: { type: String, required: true }, // File path
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Use custom field names for timestamps
  }
);

// Virtual for document_url (URL to access the document file)
applicationDocumentSchema.virtual('document_url').get(function () {
  return `${process.env.BASE_URL || 'http://localhost'}/${this.file}`; // Use your base URL for file access
});

// Virtual for file extension (Extract file extension from the file path)
applicationDocumentSchema.virtual('file_ext').get(function () {
  if (this.file) {
    const filename = this.file.split('/').pop(); // Extract file name from the path
    const extension = filename.split('.').pop(); // Get the file extension
    return extension;
  }
  return '';
});

// Virtual for file_size (No size calculation logic implemented, return null for now)
applicationDocumentSchema.virtual('file_size').get(function () {
  return null; // You can implement actual file size calculation if required
});

// Add method for toJSON (similar to Laravel's toArray method)
applicationDocumentSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    if (ret._id) {
      ret.id = ret._id.toString();
      delete ret._id;
    }
    return ret;
  },
});

// Define relationships (Populate for foreign keys)
applicationDocumentSchema.populate('document_type_id', 'name'); // Populate 'document_type_id' with selected fields
applicationDocumentSchema.populate('application_id', 'type status'); // Populate 'application_id' with selected fields

// Model creation
const ApplicationDocument = mongoose.model('ApplicationDocument', applicationDocumentSchema, 'application_documents'); // Collection name "application_documents"

// Export model
module.exports = ApplicationDocument;
