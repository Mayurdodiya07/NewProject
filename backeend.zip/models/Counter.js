const mongoose = require('mongoose');
const { Schema } = mongoose;

// Define the Counter schema
const counterSchema = new Schema(
  {
    collection_name: { type: String, required: true },
    seq: { type: Number, default: 1, required: true },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: 'counters', // Explicitly set the collection name
  }
);

// Static method to get the next sequence
counterSchema.statics.getNextSequence = async function (name) {
  let counter = await this.findOne({ collection_name: name });

  if (!counter) {
    counter = await this.create({ collection_name: name, seq: 1 });
    return 1;
  }

  counter.seq += 1;
  await counter.save();

  return counter.seq;
};

// Create the Counter model
const Counter = mongoose.model('Counter', counterSchema);

module.exports = Counter;
