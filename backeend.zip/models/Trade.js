const mongoose = require("mongoose");
const { formatDateToDMY } = require("../helpers/dateHelper"); // Import the date formatting helper

// Define the schema for Trade
const tradeSchema = new mongoose.Schema(
  {
    user_id: { type: String, required: true, ref: "User" },
    lots: { type: Number, required: true },
    ib_id: { type: String, required: true, ref: "User" },
    user_wallet_id: { type: String, required: true, ref: "UserWallet" },
    symbol_id: { type: String, required: true, ref: "Symbol" },
    trade_group_id: { type: String, required: true, ref: "TradeGroup" },
    trade_id: { type: Number, required: true },
    trade_execution_date: { type: Date, required: true },
    side: { type: String, required: true },
    position: { type: String, required: true },
    reversal: { type: String, required: true },
    profit: { type: Number, required: true },
    loss: { type: Number, required: true },
    open_price: { type: Number, required: true },
    close_price: { type: Number, required: true },
    stop_loss: { type: Number, required: true },
    take_profit: { type: Number, required: true },
    open_date: { type: Date, required: true },
    close_date: { type: Date },
    commission: { type: Number, required: true },
    swap: { type: Number, required: true },
    position_id: { type: String, required: true },
    deal_id: { type: String, required: true },
    open_time: { type: String, required: true },
    price: { type: Number, required: true },
    entry: { type: String, required: true },
    lots_closed: { type: mongoose.Schema.Types.Decimal128, required: true },
    deleted_at: { type: Date, default: null },
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
  }
);

// Virtual field to calculate the difference in days between open_date and close_date
tradeSchema.virtual("date_diff").get(function () {
  if (this.open_date && this.close_date) {
    const diffTime = Math.abs(this.close_date - this.open_date);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
  return null;
});

// Virtual field to format the open_date // md spelling change
tradeSchema.virtual("open_date_formattad").get(function () {
  return formatDateToDMY(this.open_date);
});

// Virtual field to format the close_date  // md spelling change
tradeSchema.virtual("close_date_formattad").get(function () {
  return this.close_date ? formatDateToDMY(this.close_date) : null;
});

// Virtual field for profit/loss formatting
tradeSchema.virtual("profit_loss").get(function () {
  if (this.profit !== 0) {
    return "+" + this.profit;
  } else if (this.loss !== 0) {
    return "-" + this.loss;
  } else {
    return "0";
  }
});

// Static method for soft delete (setting deleted_at)
tradeSchema.statics.softDelete = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: new Date() });
};

// Method to check if the trade is soft deleted
tradeSchema.methods.isDeleted = function () {
  return this.deleted_at !== null;
};
// Convert Mongo _id to id and include virtual fields
tradeSchema.methods.toJSON = function () {
  const obj = this.toObject(); // Include virtual fields
  obj.id = obj._id; // Convert _id to id as string
  obj.symbol = obj.symbol_id; // Convert _id to id as string
  obj.symbol_id = obj.symbol_id?._id; // Convert _id to id as string
  obj.user = obj.user_id; // Convert _id to id as string
  obj.user_id = obj.user_id?._id; // Convert _id to id as string
  obj.user_wallet = obj.user_wallet_id; // Convert _id to id as string
  obj.user_wallet_id = obj.user_wallet_id?._id; // Convert _id to id as string
  delete obj._id; // Remove the original _id field
  return obj;
};

// Add population alias for user_wallet
// tradeSchema.virtual("user_wallet", {
//   ref: "UserWallet",
//   localField: "user_wallet_id",
//   foreignField: "_id",
//   justOne: true,
// });

// tradeSchema.virtual("symbol", {
//   ref: "Symbol",
//   localField: "symbol_id",
//   foreignField: "_id",
//   justOne: true,
// });

// Enable virtual fields in JSON and object responses
tradeSchema.set("toJSON", { virtuals: true });
tradeSchema.set("toObject", { virtuals: true });

// Define the model for the 'trade' collection
const Trade = mongoose.model("Trade", tradeSchema, "trades");

module.exports = Trade;
