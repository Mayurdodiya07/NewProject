const mongoose = require('mongoose');
const { Schema } = mongoose;

const FavSymbolSchema = new Schema(
  {
    user_id: { 
      type: String, 
      required: true, 
      ref: 'user' // Reference to the 'user' collection
    },
    symbol_id: { 
      type: String, 
      required: true, 
      ref: 'symbol' // Reference to the 'symbol' collection
    },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Set the collection name explicitly
FavSymbolSchema.set('collection', 'fav_symbols');

// Override `toJSON` to include `id` instead of `_id`
FavSymbolSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Export the model
module.exports = mongoose.model('fav_symbol', FavSymbolSchema);
