const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import your date format helper

// Define the schema for Symbol
const symbolSchema = new mongoose.Schema({
  name: { type: String, required: true },
  status: { type: String, required: true },
  trade_group_id: { type: mongoose.Schema.Types.ObjectId, ref: 'TradeGroup', required: true },
  symbol: { type: String, required: true },
  path: { type: String, required: true },
  description: { type: String, required: true },
  sector: { type: String, required: true },
  min: { type: Number, required: true },
  max: { type: Number, required: true },
  limit: { type: Number, required: true },
  margin: { type: Number, required: true },
  spread: { type: Number, required: true },
  spreaddef: { type: Number, required: true },
  commission: { type: Number, required: true },
  base_cur: { type: String, required: true },
  profit_cur: { type: String, required: true },
  margin_cur: { type: String, required: true },
  contract_size: { type: Number, required: true },
  stop_level: { type: Number, required: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } }); // Timestamps with custom field names

// Virtual field to format the created_at date
symbolSchema.virtual('created_at_formattad').get(function() {
  return formatDateToDMY(this.created_at); // Format the created_at field
});

// Soft Deletes functionality: Add deleted_at field
symbolSchema.add({
  deleted_at: { type: Date, default: null }
});

// Static method for soft delete (setting deleted_at)
symbolSchema.statics.softDelete = function(id) {
  return this.findByIdAndUpdate(id, { deleted_at: new Date() });
};

// Method to check if the symbol is soft deleted
symbolSchema.methods.isDeleted = function() {
  return this.deleted_at !== null;
};

// Convert Mongo _id to id and include virtual field
symbolSchema.methods.toJSON = function() {
  const obj = this.toObject();
  obj.id = obj._id; // Convert _id to id as string
  // delete obj._id; // Remove the original _id field
  return obj;
};

// Define the model for the 'symbols' collection
const Symbol = mongoose.model('Symbol', symbolSchema, 'symbols');

module.exports = Symbol;
