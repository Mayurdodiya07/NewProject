const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper');

const DocumentSchema = new mongoose.Schema(
  {
    document_type_id: { type: mongoose.Schema.Types.ObjectId, ref: 'document_type' },
    application_id: { type: mongoose.Schema.Types.ObjectId, ref: 'application' },
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    status: { type: String },
    file: { type: String },
  },
  { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } }
);

DocumentSchema.virtual('date_of_create').get(function () {
  return formatDateToDMY(this.created_at);
});

DocumentSchema.virtual('process_date').get(function () {
  return formatDateToDMY(this.created_at);
});

module.exports = mongoose.model('Document', DocumentSchema);
