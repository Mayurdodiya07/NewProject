const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper'); // Importing the date formatting helper

// Define the PartnerProgram Schema
const PartnerProgramSchema = new Schema(
  {
    name: { type: String, required: true },
    status: { type: String, required: true },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Virtual field for formatted 'created_at'
PartnerProgramSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at); // Using the provided helper for date formatting
});

// Override `toJSON` to include `id` instead of `_id` and avoid showing deleted records by default
PartnerProgramSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString(); // Replace `_id` with `id` for the JSON response
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Soft delete method
PartnerProgramSchema.methods.softDelete = function () {
  this.deleted_at = new Date(); // Set the deleted_at field to the current date
  return this.save();
};

// Restore a soft-deleted PartnerProgram
PartnerProgramSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true }); // Set `deleted_at` to null to restore the document
};

// Explicitly set the collection name (snake_case for two-word collection names)
PartnerProgramSchema.set('collection', 'partner_programs');

// Export the model
module.exports = mongoose.model('PartnerProgram', PartnerProgramSchema);
