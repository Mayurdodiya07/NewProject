const mongoose = require('mongoose');
const { Schema } = mongoose;

// Define the Currency schema
const currencySchema = new Schema(
  {
    name: { type: String, required: true },
    type: { type: String, required: true },
    code: { type: String, required: true },
    image: { type: String, default: '' },
    status: { type: String, required: true },
    rate_usd: { type: Number, required: true },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: 'currencies',
  }
);

// Virtual field for image_url
currencySchema.virtual('image_url').get(function () {
  if (!this.image || this.image === '') {
    return `${process.env.BASE_URL || ''}/storage/photos/user/user.png`;
  }
  return `${process.env.BASE_URL || ''}${this.image}`;
});

// Overriding the toJSON method to include virtuals and customize output
currencySchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Create and export the Currency model
const Currency = mongoose.model('Currency', currencySchema);

module.exports = Currency;
