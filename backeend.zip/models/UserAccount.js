const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper');

const Schema = mongoose.Schema;

const userAccountSchema = new Schema(
  {
    user_id: { type: String, ref: 'User', collection: 'users' },
    user_wallet_id: { type: String, ref: 'UserWallet', collection: 'user_wallets' },
    account_size: { type: String, ref: 'AccountSize', collection: 'account_sizes' },
    payout_percentage: { type: Number },
    username: { type: String },
  },
  {
    timestamps: true, // Automatically handles created_at and updated_at
    collection: 'user_accounts',
  }
);

userAccountSchema.plugin(require('mongoose-delete'), { overrideMethods: 'all' }); // for soft deletes

// Virtual fields
userAccountSchema.virtual('created_at_formattad').get(function () {
  return formatDateToDMY(this.created_at);
});

// Instance methods
userAccountSchema.methods.toJSON = function () {
  const obj = this.toObject();
  obj.id = obj._id;
  delete obj._id;
  return obj;
};

module.exports = mongoose.model('UserAccount', userAccountSchema);
