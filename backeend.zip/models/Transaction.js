const mongoose = require('mongoose');
const { formatDateToDMY } = require('../helpers/dateHelper'); // Import the date formatting helper

// Define the schema for the Transaction model
const transactionSchema = new mongoose.Schema({
  type: { type: String, required: true },
  transaction_type: { type: String, required: true },
  transfer_type: { type: String, required: true },
  user_id: { type: String, required: true, ref: 'User' }, // Foreign key (user_id as string, referencing User model)
  user_wallet_id: { type: String, required: true, ref: 'UserWallet' }, // Foreign key (user_wallet_id as string, referencing UserWallet model)
  currency_id: { type: String, required: true, ref: 'Currency' }, // Foreign key (currency_id as string, referencing Currency model)
  payment_method_id: { type: String, required: true, ref: 'PaymentMethod' }, // Foreign key (payment_method_id as string, referencing PaymentMethod model)
  amount: { type: Number, required: true }, // Amount as a number
  transaction_id: { type: String },
  transaction_status: { type: String, required: true },
  status: { type: String, required: true },
  screenshot: { type: String },
  to_user_id: { type: String, ref: 'User' },
  to_user_wallet_id: { type: String, ref: 'UserWallet' },
  account_holder_name: { type: String },
  account_number: { type: String },
  ifsc_code: { type: String },
  bank_name: { type: String },
  bank_address: { type: String },
  name: { type: String },
  usdt_wallet_address: { type: String },
  btc_wallet_address: { type: String },
  mt5: { type: String },

}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Use custom timestamps
  collection: 'transactions' // Collection name in snake_case
});

// Soft Deletes functionality: Add deleted_at field
transactionSchema.add({
  deleted_at: { type: Date, default: null }
});

// Static method for soft delete (setting deleted_at)
transactionSchema.statics.softDelete = function(id) {
  return this.findByIdAndUpdate(id, { deleted_at: new Date() });
};

// Method to check if the transaction is soft deleted
transactionSchema.methods.isDeleted = function() {
  return this.deleted_at !== null;
};

// Virtual fields to format the date and amount
transactionSchema.methods.getFormattedAmount = function() {
  return formatDateToDMY(this.amount); // Use helper to format amount
};

transactionSchema.methods.getDisplayTransactionStatus = function() {
  return this.transaction_status; // Can format or translate based on requirement
};

transactionSchema.methods.getCreatedAtFormatted = function() {
  return formatDateToDMY(this.created_at); // Format created_at using helper
};

// Convert Mongo _id to id and include virtual fields
transactionSchema.methods.toJSON = function() {
  const obj = this.toObject();
  obj.id = obj._id.toString(); // Convert _id to id as string
  delete obj._id; // Remove the original _id field
  return obj;
};

// Define the model for the 'transactions' collection
const Transaction = mongoose.model('Transaction', transactionSchema, 'transactions');

module.exports = Transaction;
