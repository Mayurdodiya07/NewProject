const mongoose = require('mongoose');
const { Schema } = mongoose;

// Define the Customer schema
const customerSchema = new Schema(
  {
    first_name: { type: String, required: true },
    last_name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, required: true },
    phone_country: { type: String, default: null },
    phone_prefix: { type: String, default: null },
    phone: { type: String, default: null },
    photo: { type: String, default: '' },
    birthdate: { type: Date },
    city: { type: String },
    state: { type: String },
    country: { type: String, ref: 'Country' }, // Reference to Country model
    postal_code: { type: String },
    address: { type: String },
    status: { type: String },
    provider: { type: String },
    provider_id: { type: String },
    gender: { type: String },
    verification_level_id: { type: String, ref: 'VerificationLevel' }, // Reference to VerificationLevel
    is_ib: { type: Boolean, default: false },
    referral_code: { type: String },
    referred_by: { type: String, ref: 'Customer' }, // Self-referencing field
    referral_click_count: { type: Number, default: 0 },
    lots_traded: { type: Number, default: 0 },
    ib_request: { type: Boolean, default: false },
    previous_id: { type: String },
    data_imported_date: { type: Date },
    last_login_dt: { type: Date },
    manager: { type: String, ref: 'Customer' }, // Reference to another customer
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
    collection: 'customers', // Explicit collection name
  }
);

// Virtual fields
customerSchema.virtual('name').get(function () {
  return `${this.first_name} ${this.last_name}`;
});

customerSchema.virtual('phone_number').get(function () {
  return `${this.phone_prefix || ''}${this.phone || ''}`;
});

customerSchema.virtual('image').get(function () {
  return this.photo && this.photo !== ''
    ? `${process.env.BASE_URL || ''}${this.photo}`
    : `${process.env.BASE_URL || ''}/storage/photos/user/user.png`;
});

customerSchema.virtual('country_name').get(async function () {
  if (!this.country) return '';
  const country = await mongoose.model('Country').findById(this.country);
  return country ? country.name : '';
});

customerSchema.virtual('country_flag').get(function () {
  return this.phone_country
    ? `${process.env.BASE_URL || ''}/storage/countries/${this.phone_country.toLowerCase()}.png`
    : null;
});

customerSchema.virtual('verified').get(async function () {
  const level = await mongoose
    .model('VerificationLevel')
    .findOne({ index: 1 })
    .exec();
  return this.verification_level_id === (level ? level.id : null);
});

// Overriding the toJSON method
customerSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    delete ret.password; // Hide sensitive fields
    delete ret.remember_token;
    return ret;
  },
});

// Define relationships using `ref`
customerSchema.methods.devices = function () {
  return this.model('UserDevice').find({ customer_id: this._id });
};

customerSchema.methods.documents = function () {
  return this.model('Document').find({ customer_id: this._id });
};

customerSchema.methods.wallets = function () {
  return this.model('UserWallet').find({ customer_id: this._id });
};

customerSchema.methods.clients = function () {
  return this.model('Customer').find({ referred_by: this._id });
};

customerSchema.methods.ib = function () {
  return this.model('Customer').findOne({ _id: this.referred_by });
};

customerSchema.methods.trades = function () {
  return this.model('Trade').find({ customer_id: this._id });
};

customerSchema.methods.transactions = function () {
  return this.model('Transaction').find({ customer_id: this._id });
};

customerSchema.methods.ib_wallet = function (account = 'ib') {
  return this.model('UserWallet').findOne({ customer_id: this._id, account });
};

// Create and export the Customer model
const Customer = mongoose.model('Customer', customerSchema);

module.exports = Customer;
