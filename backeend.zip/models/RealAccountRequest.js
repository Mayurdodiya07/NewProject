const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const moment = require('moment');

const FormatHelper = {
  formatDate: (date) => {
    return moment(date).format('YYYY-MM-DD HH:mm:ss');
  }
};

const realAccountRequestSchema = new Schema({
  status: { type: String },
  user_id: { type: String, ref: 'User' },
  title: { type: String },
  first_name: { type: String },
  last_name: { type: String },
  street: { type: String },
  city: { type: String },
  postal_code: { type: String },
  address_country_id: { type: String, ref: 'Country' },
  country_id: { type: String, ref: 'Country' },
  account_type_id: { type: String, ref: 'AccountType' },
  account_size_id: { type: String, ref: 'AccountSize' },
  not_us_residence: { type: Boolean },
  platform_id: { type: String, ref: 'Platform' },
  payment_method_id: { type: String, ref: 'PaymentMethod' },
  amount: { type: Number },
  transaction_id: { type: String, ref: 'Transaction' },
  screenshot: { type: String },
  account_status: { type: String },
  user_wallet_id: { type: String, ref: 'UserWallet' },
},
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: 'real_account_requests'
  });

realAccountRequestSchema.virtual('created_at_formattad').get(function () {
  return FormatHelper.formatDate(this.createdAt);
});

// Define relationships (populating references)
realAccountRequestSchema.virtual('paymentMethod', {
  ref: 'PaymentMethod',
  localField: 'payment_method_id',
  foreignField: '_id',
  justOne: true,
});

realAccountRequestSchema.virtual('accountSize', {
  ref: 'AccountSize',
  localField: 'account_size_id',
  foreignField: '_id',
  justOne: true,
});

realAccountRequestSchema.virtual('accountType', {
  ref: 'AccountType',
  localField: 'account_type_id',
  foreignField: '_id',
  justOne: true,
});

realAccountRequestSchema.virtual('platform', {
  ref: 'Platform',
  localField: 'platform_id',
  foreignField: '_id',
  justOne: true,
});

realAccountRequestSchema.virtual('user', {
  ref: 'User',
  localField: 'user_id',
  foreignField: '_id',
  justOne: true,
});

realAccountRequestSchema.virtual('userWallet', {
  ref: 'UserWallet',
  localField: 'user_wallet_id',
  foreignField: '_id',
  justOne: false,
});

// Method to convert MongoDB object to plain JavaScript object with modified fields
realAccountRequestSchema.methods.toObjectCustom = function () {
  const obj = this.toObject();
  obj.id = obj._id.toString();
  obj.name = obj.first_name + " " + obj.last_name;
  delete obj._id;
  return obj;
};


module.exports = mongoose.model('RealAccountRequest', realAccountRequestSchema);
