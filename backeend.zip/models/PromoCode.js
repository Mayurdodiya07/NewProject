const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY, formatDateTimeToDMY } = require('../helpers/dateHelper');

// Define the PromoCode Schema
const PromoCodeSchema = new Schema(
  {
    name: { type: String, required: true },
    type: { type: String, required: true },
    code: { type: String, required: true },
    discount_in_rupees: { type: Number, required: true },
    discount_in_pr: { type: Number, required: true },
    starting_date: { type: Date, required: true },
    ending_date: { type: Date, required: true },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Virtual fields for formatted dates
PromoCodeSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at); // Format created_at using the helper
});

PromoCodeSchema.virtual('starting_date_format').get(function () {
  return formatDateTimeToDMY(this.starting_date); // Format starting_date using the helper
});

PromoCodeSchema.virtual('ending_date_format').get(function () {
  return formatDateTimeToDMY(this.ending_date); // Format ending_date using the helper
});

// Soft delete method
PromoCodeSchema.methods.softDelete = function () {
  this.deleted_at = new Date(); // Set the deleted_at field to the current date
  return this.save();
};

// Restore a soft-deleted PromoCode
PromoCodeSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true }); // Set `deleted_at` to null to restore the document
};

// Override `toJSON` to include `id` instead of `_id` and remove `_id` and `__v` from the response
PromoCodeSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString(); // Replace `_id` with `id`
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Explicitly set the collection name (snake_case for two-word collection names)
PromoCodeSchema.set('collection', 'promo_code');

// Export the model
module.exports = mongoose.model('PromoCode', PromoCodeSchema);



