const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the Acquisition Schema
const acquisitionSchema = new Schema(
  {
    user_id: { type: String, required: true, ref: 'User' }, // Reference to User model
    client_id: { type: String, required: true, ref: 'User' }, // Reference to Client model
    device_id: { type: String, required: true, ref: 'Device' }, // Reference to Device model
    ip_address: { type: String },
    location: { type: String },
    link: { type: String },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
  }
);

// Virtual for formatted created_at
acquisitionSchema.virtual('created_dt_formatted').get(function () {
  const date = new Date(this.created_at);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}.${month}.${year}`;
});

// Add method for toJSON (similar to Laravel's toArray method)
acquisitionSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    if (ret._id) {
      ret.id = ret._id.toString();
      delete ret._id;
    }
    return ret;
  },
});

// Define relationships (populating foreign keys)
// These are virtuals that allow population of referenced documents

acquisitionSchema.virtual('user', {
  ref: 'User',
  localField: 'user_id',
  foreignField: '_id',
  justOne: true,
});

acquisitionSchema.virtual('client', {
  ref: 'User',
  localField: 'client_id',
  foreignField: '_id',
  justOne: true,
});

acquisitionSchema.virtual('device', {
  ref: 'Device',
  localField: 'device_id',
  foreignField: '_id',
  justOne: true,
});

// Compile the model
const Acquisition = mongoose.model('Acquisition', acquisitionSchema);

module.exports = Acquisition;
