const mongoose = require("mongoose");
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/dateHelper');// Assuming the FormatHelper is available for date formatting

// Define the News Schema
const NewsSchema = new Schema(
  {
    status: { type: String, required: true },
    currency_id: { type: String, ref: "NewsCurrency", required: true },
    event_type: { type: String, required: true },
    actual: { type: String, required: true },
    date: { type: Date, required: true },
    previous: { type: String, required: true },
    forecast: { type: String, required: true },
    description: { type: String, required: true },
    impact: { type: String, required: true },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" }, // Custom timestamps
    collection: "news", // Collection name in snake_case
  }
);
NewsSchema.virtual("created_at_formattad").get(function () {
  return formatDateToDMY(this.created_at);
});
NewsSchema.virtual("news_date_format").get(function () {
  return formatDateToDMY(this.date);
});
NewsSchema.virtual("country_name").get(function () {
  if (this.country_id) {
    return this.model("Country")
      .findById(this.country_id)
      .then((country) => (country ? country.name : ""))
      .catch(() => "");
  }
  return "";
});
NewsSchema.methods.softDelete = function () {
  this.deleted_at = new Date();
  return this.save();
};

// Static method to restore soft-deleted records
NewsSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true });
};
NewsSchema.virtual("news_currency", {
  ref: "NewsCurrency",  // The model to use
  localField: "currency_id", // The field in News model
  foreignField: "_id", // The field in NewsCurrency model
  justOne: true, // Return a single result
});
NewsSchema.virtual("currency_name").get(function () {
  if (this.currency_id) {
    return this.model("NewsCurrency")
      .findById(this.currency_id)
      .then((currency) => (currency ? currency.code : ""))
      .catch(() => "");
  }
  return "";
});
NewsSchema.set("toJSON", {
  virtuals: true,
  transform: (doc, ret) => {
    ret.currency_name = ret.news_currency?.name;
    // delete ret.currency_id;
    return ret;
  },
});

// Export the model
module.exports = mongoose.model("News", NewsSchema);
