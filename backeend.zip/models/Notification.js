const mongoose = require('mongoose');
const { Schema } = mongoose;
const { formatDateToDMY } = require('../helpers/NotificationHelper'); // Importing the date formatting helper

// Define the Notification Schema
const NotificationSchema = new Schema(
  {
    user_id: { type: String, required: true, ref: 'User' }, // Foreign key as a string with ref
    notification_type: { type: String, required: true },
    action_id: { type: String, required: true }, // Foreign key as a string with ref
    is_read: { type: Boolean, required: true },
    deleted_at: { type: Date, default: null }, // Soft delete field
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, // Custom timestamps
  }
);

// Virtual field for formatted 'created_at'
NotificationSchema.virtual('created_at_formatted').get(function () {
  return formatDateToDMY(this.created_at); // Using the provided helper for date formatting
});

// Override `toJSON` to include `id` instead of `_id` and avoid showing deleted records by default
NotificationSchema.set('toJSON', {
  virtuals: true,
  transform: (doc, ret) => {
    ret.id = ret._id.toString(); // Replace `_id` with `id` for the JSON response
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

// Soft delete method
NotificationSchema.methods.softDelete = function () {
  this.deleted_at = new Date(); // Set the deleted_at field to the current date
  return this.save();
};

// Restore a soft-deleted notification
NotificationSchema.statics.restore = function (id) {
  return this.findByIdAndUpdate(id, { deleted_at: null }, { new: true }); // Set `deleted_at` to null to restore the document
};

// Explicitly set the collection name (snake_case for two-word collection names)
NotificationSchema.set('collection', 'notification');

// Export the model
module.exports = mongoose.model('Notification', NotificationSchema);
