const mongoose = require('mongoose');
const { Schema } = mongoose;

// Define the BalanceHistory schema
const balanceHistorySchema = new Schema(
  {
    user_wallet_id: {
      type: String, // Use String for the foreign key reference
      ref: 'UserWallet', // Reference to the 'UserWallet' collection
      required: true,
    },
    balance: { type: Number, required: true },
    equity: { type: Number, required: true },
    openpnl: { type: Number, required: true },
    closepnl: { type: Number, required: true },
    credit: { type: Number, required: true },
    status: { type: String, required: true },
  },
  {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: 'balance_history', // Explicitly set collection name
  }
);

// Convert the _id to 'id' and remove '_id' from the response
balanceHistorySchema.methods.toJSON = function () {
  const obj = this.toObject();
  if (obj._id) {
    obj.id = obj._id.toString(); // Convert _id to string
    delete obj._id; // Remove _id field
  }
  return obj;
};

// Create the model
const BalanceHistory = mongoose.model('BalanceHistory', balanceHistorySchema);

module.exports = BalanceHistory;
