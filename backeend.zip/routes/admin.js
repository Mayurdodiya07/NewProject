const express = require('express');
const adminLoginController = require('../controllers/Admin/auth/loginController');
const adminDashboardController = require('../controllers/Admin/api/dashboardController');
const adminAuthenticate = require('../middleware/adminMiddleware');
const adminUserController = require('../controllers/Admin/api/userController');
const adminAccountController = require('../controllers/Admin/api/accountController');
const adminTransactionController = require('../controllers/Admin/api/transactionController');
const adminAccountRequestController = require('../controllers/Admin/api/accountRequestController');
const adminPayoutController = require('../controllers/Admin/api/payoutController');
const adminLeaderboardController = require('../controllers/Admin/api/leaderboardController');
const adminDocumentRequestController = require('../controllers/Admin/api/documentRequestController');
const adminReferredUserController = require('../controllers/Admin/api/refferedUserController');
const adminNotificationController = require('../controllers/Admin/api/notificationController');
const adminNewsController = require('../controllers/Admin/api/newsControllers');
const adminPassedAccountController = require('../controllers/Admin/api/passedAccountController');
const adminRealAccountRequestController = require('../controllers/Admin/api/realAccountRequestController');
const adminPassedAccountRequestController = require('../controllers/Admin/api/passedAccountRequestController');
const adminTradeController = require('../controllers/Admin/api/tradeController');
const adminPaymentMethodController = require('../controllers/Admin/api/paymentMethodController');
const adminNewsCurrencyController = require('../controllers/Admin/api/newsCurrencyController');
const adminDisableAccountController = require('../controllers/Admin/api/disableAccountController');
const adminSalesReportController = require('../controllers/Admin/api/salesReportController');
const adminSettingsController = require('../controllers/Admin/api/settingsController');
const adminPromoAppController = require('../controllers/Admin/api/promoAppController');
const adminPromoCodeController = require('../controllers/Admin/api/promoCodeController');
const adminIbController = require('../controllers/Admin/api/ibController');
const adminDeleteController = require('../controllers/Admin/api/deleteController');
const adminContactController = require('../controllers/Admin/api/contactController');
const adminAccountSizeController = require('../controllers/Admin/api/accountSizeController');


const router = express.Router();
const multer = require("multer");
const upload = multer();

// Admin Login/Logout Routes..
router.get('/login', upload.none(), adminLoginController.index);
router.post('/login', upload.none(), adminLoginController.login);
router.post('/logout', upload.none(), adminAuthenticate.Adminauthenticate, adminLoginController.logout);


// Admin Dashboard Route..
router.get('/dashboard', upload.none(), adminAuthenticate.Adminauthenticate, adminDashboardController.index);

// User admin routes..
router.get('/user', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.index);
router.get('/user/data', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.data);
router.put('/user/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.approve);
router.get('/user/add', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.add);
router.post('/user/store', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.store);
router.get('/user/edit/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.edit);
router.patch('/user/update/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.update);
router.get('/user/account/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.account);
router.get('/user/export-users', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.export);
router.get('/admin/user/account/data/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.accountData);
router.post('/user/toggle-status/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.toggleStatus);
router.get('/user/account/showaccount/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.showAccount);
router.post('/user/toggle-verified/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.toggleVerified);
router.post('/user/toggle-affiliate/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.toggleAffiliate);
router.get('/user/show/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminUserController.show);

// AccountController => challenge
router.get('/challenge', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.index);
router.get('/challenge/data', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.data);
router.get('/challenge/trade/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.trade);
router.get('/challenge/trade/data/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.tradeData);
router.put('/challenge/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.approve);
router.get('/challenge/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.show);
router.get('/challenge_copy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.showCopy);
router.put('/challenge/status/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.updateStatus);
router.get('/challenge/trade/showtrade/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.showTrade);
router.post('/challenge/toggle-status/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountController.toggleStatus);

// Transactions routes..
router.get('/transactions', upload.none(), adminAuthenticate.Adminauthenticate, adminTransactionController.index);
router.get('/transactions/data', upload.none(), adminAuthenticate.Adminauthenticate, adminTransactionController.data);
router.put('/transactions/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminTransactionController.approve);
router.get('/transactions/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminTransactionController.show);

// AccountRequestController routes ..
router.get('/challenge-requests', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountRequestController.index);
router.post('/account-breach', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountRequestController.accountBreach);
router.get('/challenge-requests/data', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountRequestController.data);
router.get('/challenge-requests/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountRequestController.show);
router.put('/challenge-requests/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountRequestController.approve);
router.get('/restart-manager', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountRequestController.restartManager);

//payout controller ..
router.get('/payout', upload.none(), adminAuthenticate.Adminauthenticate, adminPayoutController.index);
router.get('/payout/data', upload.none(), adminAuthenticate.Adminauthenticate, adminPayoutController.data);
router.put('/payout/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPayoutController.approve);
router.get('/payout/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPayoutController.show);
router.delete('/payout/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPayoutController.destroy);

// Leaderboard routes..
router.get('/leaderboard', upload.none(), adminAuthenticate.Adminauthenticate, adminLeaderboardController.index);
router.get('/leaderboard/data', upload.none(), adminAuthenticate.Adminauthenticate, adminLeaderboardController.data);
router.put('/leaderboard/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminLeaderboardController.approve);
router.get('/leaderboard/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminLeaderboardController.show);

// Document Requests Routes..
router.get('/document-requests', upload.none(), adminAuthenticate.Adminauthenticate, adminDocumentRequestController.index);
router.get('/document-requests/data', upload.none(), adminAuthenticate.Adminauthenticate, adminDocumentRequestController.data);
router.post('/document-requests/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminDocumentRequestController.approve);
router.get('/document-requests/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminDocumentRequestController.show);

//Referred UserController..
router.get('/referreduser', upload.none(), adminAuthenticate.Adminauthenticate, adminReferredUserController.index);
router.get('/referreduser/data', upload.none(), adminAuthenticate.Adminauthenticate, adminReferredUserController.data);
router.get('/referreduser/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminReferredUserController.show);
router.get('/referreduser/:id/data', upload.none(), adminAuthenticate.Adminauthenticate, adminReferredUserController.getReferredUserData);


// Define routes..
router.get('/notification', upload.none(), adminAuthenticate.Adminauthenticate, adminNotificationController.index);
router.get('/notification/data', upload.none(), adminAuthenticate.Adminauthenticate, adminNotificationController.data);
router.get('/notification/unreadCount', upload.none(), adminAuthenticate.Adminauthenticate, adminNotificationController.unreadCount);


//Route for News..
router.get('/news', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.index);
router.get('/news/data', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.data);
router.get('/news/add', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.add);
router.post('/news/store', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.store);
router.get('/news/edit/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.edit);
router.patch('/news/update/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.update);
router.get('/news/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.show);
router.delete('/news/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsController.destroy);

//Route for passed accounts..
router.get('/passed-accounts', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountController.index);
router.get('/passed-accounts/data', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountController.data);

//Route for Real Challenge Requests..
router.get('/real-challenge-requests', upload.none(), adminAuthenticate.Adminauthenticate, adminRealAccountRequestController.index);
router.get('/real-challenge-requests/data', upload.none(), adminAuthenticate.Adminauthenticate, adminRealAccountRequestController.data)
router.put('/real-challenge-requests/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminRealAccountRequestController.approve);
router.get('/real-challenge-requests/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminRealAccountRequestController.show);
router.get('/real-challenge-pending/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminRealAccountRequestController.pendingRequest);
router.delete('/real-challenge-pending/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminRealAccountRequestController.destroy);
router.post('/action-on-real-account-request', upload.none(), adminAuthenticate.Adminauthenticate, adminRealAccountRequestController.actionOnPassedAccount);


// Route for passed challenge..
router.get('/passed-challenge-requests', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountRequestController.index);
router.get('/passed-challenge-requests/data', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountRequestController.data);
router.put('/passed-challenge-requests/approve/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountRequestController.approve);
router.get('/passed-challenge-requests/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountRequestController.show);
router.get('/passed-challenge-pending/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountRequestController.pendingRequest);
router.delete('/passed-challenge-pending/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountRequestController.destroy);
router.post('/action-on-passed-account-request', upload.none(), adminAuthenticate.Adminauthenticate, adminPassedAccountRequestController.actionOnPassedAccount);

// Route for TradeController..
router.get('/trades', upload.none(), adminAuthenticate.Adminauthenticate, adminTradeController.index);
router.get('/trades/data', upload.none(), adminAuthenticate.Adminauthenticate, adminTradeController.data);
// router.put('/trades/approve/{id}', upload.none(), adminAuthenticate.Adminauthenticate, adminTradeController.approve);
router.get('/trades/:id', adminAuthenticate.Adminauthenticate, adminTradeController.show);

// dashbaord details and realtime data fetch
router.post("/get-trade-dashboard-details", adminAuthenticate.Adminauthenticate, adminTradeController.getTradeDashboardDetails);
router.post("/get-real-time-data-for-account-details", adminAuthenticate.Adminauthenticate, adminTradeController.getRealTimeDataForAccountDetail);

//Route for payment methods..
router.get('/payment-methods', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.index);
router.get('/payment-methods/data', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.data);
router.get('/payment-methods/add', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.add);
router.post('/payment-methods/store', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.store);
router.get('/payment-methods/edit/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.edit);
router.patch('/payment-methods/update/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.update);
router.get('/payment-methods/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.show);
router.delete('/payment-methods/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPaymentMethodController.destroy);


// Route for News CurrencyController..
router.get('/news-currencies', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsCurrencyController.index);
router.get('/news-currencies/data', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsCurrencyController.data);
router.get('/news-currencies/add', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsCurrencyController.add);
router.post('/news-currencies/store', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsCurrencyController.store);
router.get('/news-currencies/edit/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsCurrencyController.edit);
router.patch('/news-currencies/update/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsCurrencyController.update);
router.delete('/news-currencies/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminNewsCurrencyController.destroy);


//Route for Disable AccountController
router.get('/disabled-accounts', upload.none(), adminAuthenticate.Adminauthenticate, adminDisableAccountController.index);
router.get('/disabled-accounts/data', upload.none(), adminAuthenticate.Adminauthenticate, adminDisableAccountController.data);
router.get('/disabled-accounts/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminDisableAccountController.show);
router.post('/disabled-accounts/export', upload.none(), adminAuthenticate.Adminauthenticate, adminDisableAccountController.exportToExcel);



// Route for Sales ReportController
router.get('/sales-report', upload.none(), adminAuthenticate.Adminauthenticate, adminSalesReportController.index);
router.post('/sales-report/data', upload.none(), adminAuthenticate.Adminauthenticate, adminSalesReportController.getData);
router.post('/sales-report/mydata', upload.none(), adminAuthenticate.Adminauthenticate, adminSalesReportController.mydata);
router.post('/sales-report/export', upload.none(), adminAuthenticate.Adminauthenticate, adminSalesReportController.export);


// Route for SettingsController
router.get('/settings', upload.none(), adminAuthenticate.Adminauthenticate, adminSettingsController.index);
router.post('/settings/change-password', upload.none(), adminAuthenticate.Adminauthenticate, adminSettingsController.changePassword);
router.post('/settings/change-currencyRate', upload.none(), adminAuthenticate.Adminauthenticate, adminSettingsController.changeCurrencyRate);
router.post('/settings/manage-user-account', upload.none(), adminAuthenticate.Adminauthenticate, adminSettingsController.manageUserAccount);
router.get('/settings/data', upload.none(), adminAuthenticate.Adminauthenticate, adminSettingsController.data);
// router.post("/test-bcrypt", adminSettingsController.testBcrypt);

// router.get('/settings/user-wallets', upload.none(), adminAuthenticate.Adminauthenticate, adminSettingsController.getUserWallets);
// router.get('/settings/search-users', upload.none(), adminAuthenticate.Adminauthenticate, adminSettingsController.searchUsers);


//Route for PromoAppController
router.get('/promo-applied/add', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoAppController.add)
router.post('/promo-applied/store', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoAppController.store)


// Route for PromoCodeControlle
router.get('/promo-code', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoCodeController.index);
router.get('/promo-code/data', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoCodeController.data);
router.get('/promo-code/add', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoCodeController.add);
router.post('/promo-code/store', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoCodeController.store);
router.get('/promo-code/edit/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoCodeController.edit);
router.patch('/promo-code/update/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoCodeController.update);
router.delete('/promo-code/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminPromoCodeController.destroy);


// Route for PromoCodeControlle
router.get('/ib', upload.none(), adminAuthenticate.Adminauthenticate, adminIbController.index);
router.get('/ib/data', upload.none(), adminAuthenticate.Adminauthenticate, adminIbController.data);
router.put('/ib/approve/{id}', upload.none(), adminAuthenticate.Adminauthenticate, adminIbController.approve);
router.get('/ib/{id}', upload.none(), adminAuthenticate.Adminauthenticate, adminIbController.show);


// Route for PromoCodeControlle
router.get('/delete', upload.none(), adminAuthenticate.Adminauthenticate, adminDeleteController.index);
router.post('/delete', upload.none(), adminAuthenticate.Adminauthenticate, adminDeleteController.delete);
router.post('/get-model-data', upload.none(), adminAuthenticate.Adminauthenticate, adminDeleteController.getModelData);


//Route for ContactController 
router.get('/contact', upload.none(), adminAuthenticate.Adminauthenticate, adminContactController.index);
router.get('/contact/data', upload.none(), adminAuthenticate.Adminauthenticate, adminContactController.data);
router.delete('/contact/destroy/{id}', upload.none(), adminAuthenticate.Adminauthenticate, adminContactController.destroy);
router.get('/contact/{id}', upload.none(), adminAuthenticate.Adminauthenticate, adminContactController.show);

//Route for  account-size Controller 
router.get('/account-size', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.index);
router.get('/account-size/data', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.data);
router.get('/account-size/add', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.add);
router.post('/account-size/store', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.store);
router.get('/account-size/edit/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.edit);
router.patch('/account-size/update/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.update);
router.get('/account-size/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.show);
router.delete('/account-size/destroy/:id', upload.none(), adminAuthenticate.Adminauthenticate, adminAccountSizeController.destroy);


module.exports = router;








