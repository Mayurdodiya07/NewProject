const authenticate = require("../middleware/authMiddleware");
const express = require("express");
const { login, confirmRegistration, sendForgotPasswordLink, resetPassword, register, logout, } = require("../controllers/authController");
const { profile, challenges } = require("../controllers/userController");
const { country } = require("../controllers/countryController");
const accountTypeController = require("../controllers/accountTypeController");
const accountSizeController = require("../controllers/accountSizeController");
const platformController = require("../controllers/platformController");
const paymentMethodController = require("../controllers/paymentMethodController");
const currencyConvertController = require("../controllers/currencyConvertController");
const accountRequestController = require("../controllers/accountRequestController");
const realAccountRequestController = require("../controllers/realAccountRequestController");
const tradeController = require("../controllers/tradeController");
const userController = require("../controllers/userController");
const affliateController = require("../controllers/affliateController");
const PayoutsController = require("../controllers/payoutsController");
const LeaderboardController = require("../controllers/leaderboardController");
const VerificationLevelController = require("../controllers/verificationLevelController");
const ApplicationController = require("../controllers/applicationController");
const DocumentController = require("../controllers/documentController");
const transactionController = require("../controllers/transactionController");
const NewsController = require("../controllers/newsController");
const PromoCodeController = require("../controllers/promoCodeController");
const userdeviceController = require('../controllers/userdeviceController');


const multer = require("multer");
const Mt5Controller = require("../controllers/mt5Controller");
const { getUserWallets, getUserWalletsGroupWise, getUserTotalWalletBalance, makeWalletFavourite, getUserWalletDetails, getUserWallet, getUserAllWallets } = require("../controllers/walletController");
const upload = multer();
const router = express.Router();

// Routes


// User Authentication Routes
router.post("/register", upload.none(), register);
router.get("/confirmRegistration/:token", upload.none(), confirmRegistration);
router.post("/send-forget-email", upload.none(), sendForgotPasswordLink);
router.post("/reset-forgot-password", upload.none(), resetPassword);
router.post("/login", upload.none(), login);
router.post("/get-user-verification-level", upload.none(), authenticate.authenticate, userController.getUserVerificationLevel);
router.post("/logout", upload.none(), authenticate.authenticate, logout);

// User Profile Routes
router.post("/get-profile", upload.none(), authenticate.authenticate, profile);
router.post("/update-profile", upload.none(), authenticate.authenticate, userController.editProfile);
router.post("/change-password", upload.none(), authenticate.authenticate, userController.changePassword);

//user Device Routes
router.post("/get-user-device-data", upload.none(), authenticate.authenticate, userdeviceController.getUserDeviceData);

// Currency Conversion and Trade Routes
router.post("/get-convert-currency", upload.none(), authenticate.authenticate, currencyConvertController.convertCurrency);
router.post("/get-currency-volumn", upload.none(), authenticate.authenticate, tradeController.getCurrencyVolumn);
router.post("/get-trade-data-for-chart", upload.none(), authenticate.authenticate, tradeController.getTradeDataForChart);
router.post("/get-real-time-data-for-account-details", upload.none(), authenticate.authenticate, tradeController.getRealTimeDataForAccountDetail);
router.post("/get-trading-history-list", upload.none(), authenticate.authenticate, tradeController.getTradingHistoryList);
router.post("/get-daily-summary-trade-list", upload.none(), authenticate.authenticate, tradeController.getDailySummaryTradeList);
router.post("/get-data-for-account-details-date-wise", upload.none(), authenticate.authenticate, tradeController.getDataForAccountDetailsDateWise);
router.post("/get-data-for-account-details-calender", upload.none(), authenticate.authenticate, tradeController.getDataForAccountDetailsCalender);
router.post("/get-trade-dashboard-details", upload.none(), authenticate.authenticate, tradeController.getTradeDashboardDetails);
router.post("/get-analysis-data", upload.none(), authenticate.authenticate, tradeController.getAnalysisData);
router.post("/get-data-for-dashboard-details", upload.none(), authenticate.authenticate, tradeController.getDashboardDetails);
router.post("/get-trade-performance-meter", upload.none(), authenticate.authenticate, tradeController.getTradePerformanceMeter);



// Account and Challenge Management Routes
router.post("/get-challenges", upload.none(), authenticate.authenticate, challenges);
router.post("/send-challange-request", upload.none(), authenticate.authenticate, accountRequestController.store);
router.post("/get-challenge-details", upload.none(), authenticate.authenticate, accountRequestController.getChallengeDetails);
router.post("/get-challenge-requests", upload.none(), authenticate.authenticate, accountRequestController.index);
router.post("/get-real-account-requests", upload.none(), authenticate.authenticate, realAccountRequestController.index);



// Country and Account Information Routes
router.post("/get-countries", upload.none(), authenticate.authenticate, country);
router.post("/get-account-types", upload.none(), authenticate.authenticate, accountTypeController.index);
router.post("/get-account-sizes", upload.none(), authenticate.authenticate, accountSizeController.index);
router.post("/get-platforms", upload.none(), authenticate.authenticate, platformController.index);
router.post("/get-payment-methods", upload.none(), authenticate.authenticate, paymentMethodController.index);

// Affiliate Routes
router.post("/get-referral-link", upload.none(), authenticate.authenticate, affliateController.getReferralLink);
router.post("/get-affilate-details", upload.none(), authenticate.authenticate, affliateController.getAffiliateDetails);
router.post("/get-affilate-balance", upload.none(), authenticate.authenticate, affliateController.getAffiliateBalance);
router.post("/check-affiliate-available", upload.none(), authenticate.authenticate, PromoCodeController.validatePromoCode);


// Payouts Routes
router.post("/get-payouts", upload.none(), authenticate.authenticate, PayoutsController.index);
router.post("/create-request-of-payouts", upload.none(), authenticate.authenticate, PayoutsController.createRequestOfPayouts);
router.post("/get-real-user-wallet", upload.none(), authenticate.authenticate, PayoutsController.getRealUserWalletAccount);
router.post("/get-account-type-list", upload.none(), authenticate.authenticate, PayoutsController.getAccountTypeList);
router.post("/download-pdf", upload.none(), authenticate.authenticate, PayoutsController.downloadPdf);

// Leaderboard Routes
router.post("/get-winner", upload.none(), authenticate.authenticate, LeaderboardController.getWinner);
router.post("/get-best-account", upload.none(), authenticate.authenticate, LeaderboardController.getBestAccount);
router.post("/get-winner-list", upload.none(), authenticate.authenticate, LeaderboardController.getWinnerList);
router.post("/get-account-size-data", upload.none(), authenticate.authenticate, LeaderboardController.getAccountSizeData);
router.post("/get-best-account-profit", upload.none(), authenticate.authenticate, LeaderboardController.getBestAccountInProfit);
router.post("/get-leader-board-first-block-data", upload.none(), authenticate.authenticate, LeaderboardController.getLeaderBoardFirstBlockList);


//verificationLevel
router.post("/get-document-types-group-wise", upload.none(), authenticate.authenticate, VerificationLevelController.getDocumentTypesGroupWise);
router.post("/get-verification-levels", upload.none(), authenticate.authenticate, VerificationLevelController.index);

// MT5 Services base  Routes
// router.post("/create-mt5-account", upload.none(), authenticate.authenticate, Mt5Controller.createWallet);

// Wallet Controller Services base  Routes

router.post("/get-user-wallets", upload.none(), authenticate.authenticate, getUserWallets);
router.post("/get-user-wallets-group-wise", upload.none(), authenticate.authenticate, getUserWalletsGroupWise);
router.post("/get-user-wallet-total-balance", upload.none(), authenticate.authenticate, getUserTotalWalletBalance);
router.post("/make-wallet-favourite", upload.none(), authenticate.authenticate, makeWalletFavourite);
router.post("/get-wallet-details", upload.none(), authenticate.authenticate, getUserWalletDetails);
router.post("/get-user-wallet", upload.none(), authenticate.authenticate, getUserWallet);
router.post("/get-user-all-wallets", upload.none(), authenticate.authenticate, getUserAllWallets);


//real and passaccount request
router.post("/send-real-account-request", upload.none(), authenticate.authenticate, accountRequestController.sendRealAccountRequest);
router.post("/send-passed-account-request", upload.none(), authenticate.authenticate, accountRequestController.sendPassedAccountRequest);

//application controller 
router.post("/send-verification-request", upload.none(), authenticate.authenticate, ApplicationController.store);
router.post("/approve-application-request", upload.none(), authenticate.authenticate, ApplicationController.approveDocumentRequests);

//document controller
router.post("/get-verified-documents", upload.none(), authenticate.authenticate, DocumentController.getVerifiedDocuments);

//transactionController

router.post("/send-transaction-request", upload.none(), authenticate.authenticate, transactionController.store);
router.post("/get-transactions", upload.none(), authenticate.authenticate, transactionController.index);
router.post("/send-withdraw-request", upload.none(), authenticate.authenticate, transactionController.storeWithdrawRequest);

//news controller
router.post("/get-news", upload.none(), authenticate.authenticate, NewsController.index);
router.post("/get-currency-records", upload.none(), authenticate.authenticate, NewsController.getCurrencyData);

//promocode controller
router.post("/validate-promo-code", upload.none(), authenticate.authenticate, PromoCodeController.validatePromoCode);



module.exports = router;
